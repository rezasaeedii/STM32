# Parameter List Code Generator

A toolset for defining parameter lists and generating the corresponding C/C++
source and header files.

The project consists of the application used to create and manage parameter
lists, together with the libraries required to use the generated parameter-list
structures in the target application.

## Project structure

| Folder | Description |
|---|---|
| `plcogen/` | Main application for editing parameter lists and generating the corresponding C/C++ source and header files. |
| `parameter_descriptor/` | Runtime library used with the generated code to work with parameter descriptors and parameter-list structures. |
| `smart_data/` | Runtime library used with the generated code to work with parameter values and smart-data structures. |

The generated code can be integrated with the `smart_data` and
`parameter_descriptor` libraries to use the parameter-list structure in the
target application.

## Documentation

The main application documentation is located in:

`plcogen/docs/`

It contains the **User Manual**, **Developer Manual**, and usage examples.

For a quick introduction to the application, its commands, project structure,
and how to run it, see:

`plcogen/README.md`

The `plcogen/docs/` directory provides more detailed information for both users
and developers, including examples of how the generated code and libraries
are used.
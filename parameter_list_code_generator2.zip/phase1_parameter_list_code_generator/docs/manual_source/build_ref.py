# -*- coding: utf-8 -*-
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from render import file_block
import notes_core, notes_core2, notes_model, notes_io, notes_val, notes_cg, notes_tools
import notes_new, notes_drift

NOTES = {}
for m in (notes_core, notes_core2, notes_model, notes_io, notes_val, notes_cg,
          notes_tools, notes_new, notes_drift):
    NOTES.update(m.NOTES)

CHAPTERS = [
 ("۶", "c06", "ریشه‌ی <code>tools/</code>",
  "<p class='lead'>فایل‌هایی که مستقیم در پوشه‌ی <code>tools</code> هستند: نقطه‌های ورود "
  "(<code>run_*.py</code>، هرکدام با یک <code>.bat</code> هم‌نام) و چک محیط.</p>",
  ["run_generate.py", "run_make_template.py", "run_tests.py", "run_setup.py",
   "setup_environment.py"]),
 ("۷", "c07", "هسته‌ی <code>common/pl_codegen/</code>",
  "<p class='lead'>زیرساخت مشترکی که همه‌ی لایه‌های دیگر رویش سوارند: کانفیگ، پیام‌ها، "
  "نام‌گذاری، لاگ، خط فرمان و خط لوله. <b>این پوشه در هر دو فاز همان فایل‌ها، همان "
  "کلاس‌ها و همان API را دارد</b> — تنها تفاوتشان متنِ پیام‌ها و تنظیم‌های مخصوصِ اکسل "
  "است که فاز ۲ ندارد، چون اصلاً اکسل نمی‌خواند.</p>",
  ["common/pl_codegen/__init__.py", "common/pl_codegen/cli.py", "common/pl_codegen/config.py",
   "common/pl_codegen/errors.py", "common/pl_codegen/logging_utils.py",
   "common/pl_codegen/naming.py", "common/pl_codegen/pipeline.py"]),
 ("۸", "c08", "<code>model/</code> — مدل داده",
  "<p class='lead'>این پوشه نه اکسل می‌شناسد، نه XML، نه C. فقط توصیف می‌کند «یک پارامتر چیست» "
  "و همه‌ی لایه‌های دیگر رویش کار می‌کنند.</p>",
  ["common/pl_codegen/model/__init__.py", "common/pl_codegen/model/parameter.py",
   "common/pl_codegen/model/parameter_list.py", "common/pl_codegen/model/types.py",
   "common/pl_codegen/model/tags.py", "common/pl_codegen/model/defines.py"]),
 ("۹", "c09", "<code>pl_excel/</code> — خواندن اکسل",
  "<p class='lead'>مسیر «فایل <code>.xlsx</code> ⟵ مدل». <b>مخصوص فاز ۱</b> و تنها جایی از "
  "پروژه که <code>openpyxl</code> در آن ظاهر می‌شود.</p>",
  ["pl_excel/__init__.py", "pl_excel/cli.py", "pl_excel/workbook_reader.py",
   "pl_excel/column_schema.py", "pl_excel/value_parsing.py",
   "pl_excel/excel_to_model.py", "pl_excel/make_template.py"]),
 ("۱۰", "c10", "<code>xml_model/</code> — مدل میانی",
  "<p class='lead'>مسیر «مدل ⟷ XML». همان لولایی که فاز ۲ (ویرایشگر گرافیکی) به آن وصل می‌شود، "
  "و دلیل اینکه کد جنریتور اصلاً نمی‌داند ورودی از کجا آمده.</p>",
  ["common/pl_codegen/xml_model/__init__.py", "common/pl_codegen/xml_model/schema.py",
   "common/pl_codegen/xml_model/xml_writer.py", "common/pl_codegen/xml_model/xml_reader.py"]),
 ("۱۱", "c11", "<code>validation/</code> — قوانین",
  "<p class='lead'>هر قانون یک کلاس. این‌جا تصمیم گرفته می‌شود که یک ورودی قابل قبول هست یا نه.</p>",
  ["common/pl_codegen/validation/__init__.py", "common/pl_codegen/validation/validator.py",
   "common/pl_codegen/validation/rules/rule_base.py",
   "common/pl_codegen/validation/rules/__init__.py",
   "common/pl_codegen/validation/rules/name_rules.py",
   "common/pl_codegen/validation/rules/type_rules.py",
   "common/pl_codegen/validation/rules/range_rules.py",
   "common/pl_codegen/validation/rules/tag_rules.py",
   "common/pl_codegen/validation/rules/defines_rules.py"]),
 ("۱۲", "c12", "<code>layout/</code> — آفست تگ‌ها",
  "<p class='lead'>محاسبه‌ی <code>MemoryOffset</code>؛ کوچک‌ترین لایه، ولی همانی که نقشه‌ی "
  "حافظه‌ی فرم‌ور را تعیین می‌کند — جایی که تفاوت «بایت» با «مقدار» تعریف شده، و "
  "جایی که فهمیده می‌شود این اجرا چیزی را جابه‌جا کرده یا نه.</p>",
  ["common/pl_codegen/layout/__init__.py", "common/pl_codegen/layout/tag_offset.py",
   "common/pl_codegen/layout/drift.py"]),
 ("۱۳", "c13", "<code>codegen/</code> — تولید کد C",
  "<p class='lead'>سه لایه: ابزارهای پایه (لیترال، قالب، ترتیب فیلدها)، بلوک‌های کوچک C، "
  "و یک سازنده به ازای هر فایل تولیدی.</p>",
  ["common/pl_codegen/codegen/__init__.py", "common/pl_codegen/codegen/literals.py",
   "common/pl_codegen/codegen/c_style.py", "common/pl_codegen/codegen/descriptor_layout.py",
   "common/pl_codegen/codegen/blocks/__init__.py",
   "common/pl_codegen/codegen/blocks/comment.py",
   "common/pl_codegen/codegen/blocks/include.py",
   "common/pl_codegen/codegen/blocks/include_guard.py",
   "common/pl_codegen/codegen/blocks/cpp_guard.py",
   "common/pl_codegen/codegen/blocks/define.py",
   "common/pl_codegen/codegen/blocks/enum.py",
   "common/pl_codegen/codegen/blocks/variable.py",
   "common/pl_codegen/codegen/blocks/function.py",
   "common/pl_codegen/codegen/blocks/file_banner.py",
   "common/pl_codegen/codegen/blocks/file_footer.py",
   "common/pl_codegen/codegen/blocks/section_marker.py",
   "common/pl_codegen/codegen/blocks/table.py",
   "common/pl_codegen/codegen/files/__init__.py",
   "common/pl_codegen/codegen/files/file_builder.py",
   "common/pl_codegen/codegen/files/parameter_list_defines_h.py",
   "common/pl_codegen/codegen/files/parameter_types_h.py",
   "common/pl_codegen/codegen/files/smart_data_h.py",
   "common/pl_codegen/codegen/files/smart_data_c.py",
   "common/pl_codegen/codegen/files/parameter_list_h.py",
   "common/pl_codegen/codegen/files/parameter_list_c.py",
   "common/pl_codegen/codegen/files/parameter_list_table_h.py"]),
 ("۱۴", "c14", "<code>tests/</code> — تست‌ها",
  "<p class='lead'>سه اسکریپت مستقل، بدون هیچ فریم‌ورک تستی. با <code>python run_tests.py</code> "
  "همه با هم اجرا می‌شوند.</p>",
  ["tests/run_validation_test.py",
   "tests/run_compile_test.py"]),
]

out = []
for num, key, title, lead, files in CHAPTERS:
    out.append(f'<h1>{num}. {title}<span class="pgm">PGM{key}PGM</span></h1>')
    out.append(lead)
    for path in files:
        out.append(file_block(path, NOTES, level=2))
(HERE / 'parts' / 'p05_reference.html').write_text("\n".join(out), encoding='utf-8')
print("reference written:", sum(len(c[4]) for c in CHAPTERS), "files in",
      len(CHAPTERS), "chapters,", len("\n".join(out)), "chars")

# -*- coding: utf-8 -*-
NOTES = {}

NOTES["pl_excel/__init__.py"] = {
 "fa": "<p>چند <code>import</code> برای راحتی؛ منطقی ندارد.</p>", "when": "به‌ندرت."}

NOTES["pl_excel/column_schema.py"] = {
 "fa": """<p>نگاشت «سرستون اکسل ⟵ نام قانونی». <code>_normalise()</code> حروف بزرگ و کوچک،
فاصله، زیرخط و خط تیره را یکسان می‌کند، پس <code>Array Size</code>،
<code>array_size</code> و <code>ARRAY-SIZE</code> هر سه یک ستون‌اند. به همین دلیل ترتیب
و املای دقیق ستون‌ها در اکسل مهم نیست.</p>
<p>سرستون ناشناس <code>None</code> می‌گیرد که به پیام <code>EXL010</code> تبدیل می‌شود —
ستون نادیده گرفته می‌شود ولی سکوت نمی‌شود.</p>""",
 "when": "وقتی ستون تازه‌ای به اکسل اضافه می‌کنید، یا می‌خواهید املای دیگری از یک ستون هم پذیرفته شود.",
 "sym": {
  "canonical_column": "نام قانونی یک سرستون، یا <code>None</code> اگر ناشناس باشد.",
  "all_known_columns": "فهرست همه‌ی ستون‌هایی که ابزار می‌شناسد — برای پیام‌های خطا.",
  "_normalise": "یکسان‌سازی سرستون: حروف کوچک، حذف فاصله و <code>_</code> و <code>-</code>.",
  "COL_ENABLE": "نام قانونی ستون Enable.", "COL_NAME": "نام قانونی ستون Name.",
  "COL_GS_NAME": "نام قانونی ستون GS Name.", "COL_GROUP": "نام قانونی ستون Group.",
  "COL_DATA_TYPE": "نام قانونی ستون DataType.", "COL_ARRAY_SIZE": "نام قانونی ستون Array Size.",
  "COL_DEFAULT_VALUE": "نام قانونی ستون DefaultValue.", "COL_MINIMUM": "نام قانونی ستون Minimum.",
  "COL_MAXIMUM": "نام قانونی ستون Maximum.", "COL_RESOLUTION": "نام قانونی ستون Resolution.",
  "COL_UNIT": "نام قانونی ستون Unit.", "COL_DESCRIPTION": "نام قانونی ستون Description.",
 },
}

NOTES["pl_excel/value_parsing.py"] = {
 "fa": """<p>تبدیل مقدار خام یک سلول به مقدار پایتونی. الگوی مشترک همه‌ی توابع:
<b>یک زوج <code>(مقدار، پیام خطا)</code> برمی‌گردانند، نه استثنا</b> — تا خواننده بتواند
خطا را ثبت کند و به ردیف بعد برود، به‌جای اینکه کل خواندن متوقف شود.</p>""",
 "when": "وقتی می‌خواهید شکل تازه‌ای از نوشتن یک مقدار پذیرفته شود.",
 "sym": {
  "parse_bool": "سلول را بولین تفسیر می‌کند. <code>TRUE/1/yes/on/enabled</code> و قرینه‌هایشان پذیرفته می‌شوند.",
  "parse_int": "سلول را عدد صحیح تفسیر می‌کند. <code>0x</code> هم پذیرفته است.",
  "parse_number": "سلول را عدد (صحیح یا اعشاری) تفسیر می‌کند.",
  "parse_numeric_for_type": "بر اساس تایپ ردیف تصمیم می‌گیرد کدام‌یک از سه تابع بالا صدا زده شود.",
  "parse_text": "متن آزاد؛ فاصله‌های اضافی حذف و رشته‌ی خالی <code>None</code> می‌شود.",
  "parse_identifier": "مثل <code>parse_text</code>؛ اعتبارسنجی شناسه بعداً در لایه‌ی قوانین انجام می‌شود.",
 },
 "after": """<div class="warn">
<b>چرا <code>parse_int</code> عدد <code>0.5</code> را رد می‌کند به‌جای گِرد کردن</b>
<p>
چون پذیرفتنش یعنی در کد C بی‌صدا <code>0</code> شود — و رزولوشنِ صفر یعنی یک پارامتر
غیرقابل استفاده. گِرد کردن هم بهتر نیست: کاربر <code>0.5</code> نوشته و فرم‌ور
<code>1</code> می‌گیرد، بدون اینکه کسی بفهمد. پس این‌جا خطا داده می‌شود
(<code>EXL033</code>) و کاربر خودش تصمیم می‌گیرد.
</p>
</div>""",
}

NOTES["pl_excel/workbook_reader.py"] = {
 "fa": """<p><b>تنها فایلی در کل پروژه که <code>openpyxl</code> را می‌شناسد.</b> اگر روزی
کتابخانه‌ی دیگری جایش را بگیرد، فقط همین فایل عوض می‌شود.</p>
<p>کارش این است که یک شیت را به <code>SheetData</code> تبدیل کند: سرستون‌ها به نام
قانونی نگاشته می‌شوند و هر ردیف یک دیکشنری «نام ستون ⟵ مقدار» می‌شود.</p>
<p>فایل با <code>data_only=True</code> باز می‌شود، یعنی «مقدارِ محاسبه‌شده» را
می‌خواهیم نه فرمول را — و دقیقاً همین یک دام بزرگ دارد که پایین توضیح داده شده.</p>""",
 "when": "وقتی شکل خواندن اکسل باید عوض شود، یا شیت تازه‌ای لازم دارید.",
 "sym": {
  "quiet_openpyxl": "context manager ی که هشدارهای openpyxl را خاموش می‌کند. <b>هر</b> دسترسی به ورک‌بوک باید داخلش باشد — دلیلش پایین آمده.",
  "SheetRow": "یک ردیف داده‌ی شیت، کلیددار با نام قانونی ستون.",
  "SheetRow.row_number": "شماره‌ی ردیف در اکسل (از ۱)، برای پیام‌ها.",
  "SheetRow.values": "دیکشنری «ستون ⟵ مقدار».",
  "SheetRow.get": "مقدار یک ستون، یا <code>None</code>.",
  "SheetRow.is_empty": "آیا همه‌ی سلول‌های این ردیف خالی‌اند.",
  "SheetData": "یک شیت خلاصه‌شده به «سرستون‌ها + ردیف‌ها».",
  "SheetData.file": "فایل اکسلی که این شیت از آن آمده.",
  "SheetData.sheet_name": "نام شیت.",
  "SheetData.headers": "نگاشت «شماره‌ی ستون ⟵ نام قانونی».",
  "SheetData.raw_headers": "نگاشت «شماره‌ی ستون ⟵ سرستون همان‌طور که نوشته شده».",
  "SheetData.rows": "ردیف‌های غیرخالی.",
  "SheetData.location": "یک <code>SourceLocation</code> برای این شیت/ردیف/ستون می‌سازد.",
  "SheetData.has_column": "آیا این ستون در شیت هست.",
  "WorkbookReader": "خواننده‌ی شیت‌های یک ورک‌بوک.",
  "WorkbookReader.sheet_names": "نام همه‌ی شیت‌های فایل.",
  "WorkbookReader.close": "هر دو نمای باز از فایل را می‌بندد.",
  "WorkbookReader.read_column_lists": "یک شیت را به شکل «سرستون ⟵ فهرست مقادیر» می‌خواند. برای شیت <code>Defines</code> استفاده می‌شود.",
  "WorkbookReader.read_sheet": "یک شیت را به <code>SheetData</code> تبدیل می‌کند: سرستون‌ها، ردیف‌ها، و گزارش سرستون تکراری یا ناشناس.",
  "WorkbookReader._formula_sheet_rows": "ردیف‌های همان شیت، ولی به‌شکل فرمول به‌جای نتیجه. با بارگذاری دوم و <b>تنبل</b> — فقط وقتی سلول خالی‌ای پیدا شده باشد.",
  "WorkbookReader._is_formula": "آیا این مقدار یک فرمول است (با <code>=</code> شروع می‌شود).",
  "WorkbookReader._report_uncached_formulas": "برای سلول‌هایی که خالی خوانده شدند بررسی می‌کند آیا واقعاً فرمول‌اند، و <code>EXL004</code> می‌دهد.",
  "_clean": "مقدار خام سلول را مرتب می‌کند: فاصله‌های اضافی حذف، رشته‌ی خالی به <code>None</code>.",
 },
 "after": """<div class="warn">
<b>فرمولی که نتیجه‌اش ذخیره نشده</b>
<p>
اکسل در هر سلول فرمول‌دار <b>دو چیز</b> نگه می‌دارد: خود فرمول و آخرین نتیجه‌ای که
محاسبه کرده. اگر فایل را چیزی نوشته باشد که محاسبه نمی‌کند (خود <code>openpyxl</code>،
یک اسکریپت، یک صادرکننده)، نتیجه اصلاً وجود ندارد و <code>data_only=True</code>
<code>None</code> می‌دهد — یعنی سلول «خالی» به‌نظر می‌رسد.
</p>
<p>
و خالی بودن <code>Maximum</code> ایراد نیست؛ یعنی «بازه ندارم». پس فرم‌ور با بازه‌ی
اشتباه ساخته می‌شد و <b>هیچ پیامی</b> هم داده نمی‌شد. برای همین هر سلولی که خالی خوانده
شود، فایل یک بار دیگر با <code>data_only=False</code> باز و همان سلول‌ها بررسی می‌شوند؛
اگر واقعاً فرمول باشند، <code>EXL004</code> داده می‌شود.
</p>
</div>
<div class="warn">
<b>چرا <code>quiet_openpyxl()</code> باید دور <code>iter_rows()</code> باشد</b>
<p>
با <code>read_only=True</code> شیت‌ها <b>تنبل</b> خوانده می‌شوند: تجزیه هنگام
<code>iter_rows()</code> اتفاق می‌افتد، نه هنگام <code>load_workbook()</code>. پس گذاشتن
<code>catch_warnings</code> فقط دور <code>load_workbook</code> هیچ‌چیز نمی‌گیرد و
هشدارهای openpyxl همچنان روی کنسول می‌ریزند و پیام‌های واقعی را دفن می‌کنند.
</p>
</div>""",
}

NOTES["pl_excel/excel_to_model.py"] = {
 "fa": """<p>همه را به هم وصل می‌کند: برای هر فایل، شیت <code>Defines</code> و شیت پارامترها
را می‌خواند، وجود ستون‌های اجباری را چک می‌کند، و هر ردیف را به یک
<code>Parameter</code> تبدیل می‌کند. چند اکسل همین‌جا در یک
<code>ParameterList</code> ادغام می‌شوند.</p>
<p>تابع میان‌بر <code>build_model(config, diagnostics)</code> همانی است که
<code>pipeline</code> صدا می‌زند.</p>""",
 "when": "وقتی ستون تازه‌ای اضافه می‌کنید (باید این‌جا خوانده شود) یا قاعده‌ی ادغام چند اکسل عوض می‌شود.",
 "sym": {
  "ExcelModelBuilder": "سازنده‌ی مدل از روی فایل‌های اکسل.",
  "ExcelModelBuilder.build": "همه‌ی ورک‌بوک‌ها را می‌خواند و یک <code>ParameterList</code> ادغام‌شده می‌دهد.",
  "ExcelModelBuilder._read_workbook": "یک فایل: شیت Defines، شیت پارامترها، و ردیف‌ها.",
  "ExcelModelBuilder._check_required_columns": "وجود ستون‌های اجباری و ستون‌های تگ اجباری را چک می‌کند.",
  "ExcelModelBuilder._read_parameter": "یک ردیف را به <code>Parameter</code> تبدیل می‌کند؛ هر سلول قابل‌تفسیر‌نبودن یک پیام می‌گیرد.",
  "ExcelModelBuilder._read_tags": "ستون‌های تگ همان ردیف را می‌خواند و در <code>parameter.tags</code> می‌گذارد.",
  "read_defines_sheet": "فقط شیت Defines یک فایل را می‌خواند.",
  "build_model": "میان‌بر: از <code>Config</code> به <code>ParameterList</code>. همانی که خط لوله صدا می‌زند.",
  "excel_files_summary": "چند خط خلاصه از فایل‌های ورودی، برای سربرگ فایل‌های تولیدی.",
 },
 "after": """<div class="note">
<b>یک ظرافت در ردیف‌های <code>bool_t</code></b>
<p>
فقط <code>DefaultValue</code> به‌صورت بولین تفسیر می‌شود؛ <code>Minimum</code>،
<code>Maximum</code> و <code>Resolution</code> عدد ساده می‌مانند. اگر آنها هم بولین
خوانده شوند، عدد <code>3</code> به «خطای تفسیر بولین» تبدیل می‌شود، در حالی که پیام
درست «این عدد برای بولین بی‌معناست» است. <b>همین منطق عیناً در خواننده‌ی XML هم تکرار
شده</b>، وگرنه یک مدل واحد از دو مسیر، دو خروجی متفاوت می‌داد.
</p>
</div>""",
}

NOTES["common/pl_codegen/xml_model/__init__.py"] = {
 "fa": "<p>چند <code>import</code> برای راحتی.</p>", "when": "به‌ندرت."}

NOTES["common/pl_codegen/xml_model/schema.py"] = {
 "fa": """<p><b>قرارداد XML، در یک فایل.</b> فقط ثابت است: نام هر عنصر و هر صفت، به‌علاوه‌ی
<code>SCHEMA_VERSION</code>. نویسنده و خواننده هر دو از همین ثابت‌ها استفاده می‌کنند، پس
عوض کردن نام یک صفت در یک جا کافی است و دو طرف هیچ‌وقت از هم جدا نمی‌افتند.</p>
<p>GUI فاز بعد هم دقیقاً همین فایل را <code>import</code> می‌کند — این تنها چیزی است که
باید درباره‌ی قالب بداند.</p>""",
 "when": "وقتی به عنصر یا صفت تازه‌ای در XML نیاز دارید. اگر قالب طوری عوض شود که نسخه‌های قدیمی نخوانند، <code>SCHEMA_VERSION</code> را هم بالا ببرید.",
 "sym": {"SCHEMA_VERSION": "نسخه‌ی قالب XML؛ خواننده آن را چک می‌کند."},
}

NOTES["common/pl_codegen/xml_model/xml_writer.py"] = {
 "fa": """<p>مدل ⟵ XML، با <code>xml.etree.ElementTree</code> از کتابخانه‌ی استاندارد (هیچ
وابستگی خارجی).</p>
<p><code>_indent()</code> فایل را تورفته می‌کند؛ این فقط زیبایی نیست: یک XML تک‌خطی در
<code>git diff</code> غیرقابل خواندن است.</p>""",
 "when": "وقتی فیلد تازه‌ای باید در XML ذخیره شود. یادتان باشد خواننده را هم به‌روز کنید.",
 "sym": {
  "model_to_element": "کل مدل را به درخت عنصرها تبدیل می‌کند.",
  "write_xml": "درخت را در فایل می‌نویسد. با <code>emit_timestamp=False</code> صفت <code>generatedAt</code> نوشته نمی‌شود و فایل بین دو اجرا بایت‌به‌بایت یکسان می‌ماند.",
  "_parameter_to_element": "یک <code>Parameter</code> را به یک عنصر <code>&lt;Parameter&gt;</code> تبدیل می‌کند.",
  "_text": "مقدار را به متن XML تبدیل می‌کند.",
  "_set": "یک صفت را ست می‌کند و مقدار <code>None</code> را کلاً نمی‌نویسد.",
  "_indent": "تورفتگی می‌دهد تا فایل و diff آن خوانا باشد.",
 },
}

NOTES["common/pl_codegen/xml_model/xml_reader.py"] = {
 "fa": """<p>XML ⟵ مدل. نسخه‌ی schema را چک می‌کند و هر مشکلی را به‌جای استثنا، به پیام
تبدیل می‌کند. این مسیری است که <b>هر دو</b> حالت از آن رد می‌شوند: هم مرحله‌ی ۲ اجرای
عادی، هم <code>--from-xml</code> که GUI فاز بعد استفاده می‌کند.</p>""",
 "when": "وقتی فیلد تازه‌ای به XML اضافه شده و باید خوانده شود.",
 "sym": {
  "read_xml": "فایل XML را به یک <code>ParameterList</code> تبدیل می‌کند.",
  "_read_parameter": "یک عنصر <code>&lt;Parameter&gt;</code> را می‌خواند.",
  "_read_defines": "بخش <code>&lt;Defines&gt;</code> را می‌خواند.",
  "_to_bool": "یک صفت را بولین تفسیر می‌کند.",
  "_to_int": "یک صفت را عدد صحیح تفسیر می‌کند، با مقدار پیش‌فرض.",
  "_to_optional_int": "عدد صحیح یا <code>None</code>.",
  "_to_number": "یک مقدار عددی <code>&lt;Limits&gt;</code> را می‌خواند و هر چیزِ خوانده‌نشدنی را <b>گزارش</b> می‌کند.",
  "_report_bad_number": "پیام <code>XML012</code> برای مقدار خوانده‌نشدنی.",
  "_convert_tag": "مقدار متنی یک تگ را بر اساس <code>TagKind</code> به نوع درست تبدیل می‌کند.",
 },
 "after": """<div class="warn">
<b>هیچ مقداری بی‌صدا دور ریخته نمی‌شود</b>
<p>
اگر کسی XML را دستی ویرایش کند و بنویسد <code>maximum="99.9"</code> روی یک تایپ صحیح،
نسخه‌ی اولیه بی‌صدا <code>None</code> می‌داد — و <code>None</code> یعنی «خالی» یعنی
«بازه ندارم». حالا <code>XML012</code> داده می‌شود. <b>قاعده: در خواننده‌ی XML هیچ‌وقت
مقداری را بی‌صدا دور نریزید.</b>
</p>
</div>""",
}

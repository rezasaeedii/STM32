"""Render the file-by-file reference of the developer manual from api.json + notes."""
import html, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
API = {f["path"]: f for f in json.load(open(HERE / 'api.json', encoding='utf-8'))}

def esc(s):
    return html.escape(str(s), quote=False)

def code(s):
    return f'<code>{esc(s)}</code>'

_marker_seq = [0]
def marker(key):
    """An invisible ASCII tag so the page number of this heading can be found."""
    return f'<span class="pgm">PGM{key}PGM</span>'

def file_block(path, notes, level=3):
    f = API[path]
    n = notes.get(path, {})
    key = path.replace('/', '_').replace('.', '_')
    out = []
    out.append(f'<h{level} id="f_{key}">{code(path)} '
               f'<span class="ln">— {f["lines"]} خط</span>{marker(key)}</h{level}>')
    if n.get("fa"):
        out.append(n["fa"])
    if n.get("when"):
        out.append(f'<p class="when"><b>کِی سراغش می‌روید:</b> {n["when"]}</p>')

    sym = n.get("sym", {})
    consts = [c for c in f["constants"] if not c["name"].startswith("_")]
    if consts and n.get("show_consts", True):
        out.append('<p class="sub">ثابت‌های صادرشده</p><table class="api">')
        out.append('<tr><th style="width:30%">نام</th><th>مقدار / معنی</th></tr>')
        for c in consts:
            desc = sym.get(c["name"], "")
            val = code(c["value"]) if len(c["value"]) < 60 else ""
            out.append(f'<tr><td class="mono">{esc(c["name"])}</td><td>{val} {desc}</td></tr>')
        out.append('</table>')

    for cls in f["classes"]:
        base = f'({", ".join(cls["bases"])})' if cls["bases"] else ""
        deco = " ".join(f'@{d}' for d in cls["decorators"])
        out.append(f'<p class="cls"><span class="kw">class</span> '
                   f'<b>{esc(cls["name"])}</b>{esc(base)}'
                   f'{f" <span class=deco>{esc(deco)}</span>" if deco else ""}</p>')
        text = sym.get(cls["name"]) or esc(cls["doc"])
        if text:
            out.append(f'<p class="clsdoc">{text}</p>')
        if cls["fields"]:
            out.append('<table class="api"><tr><th style="width:26%">فیلد</th>'
                       '<th style="width:26%">نوع</th><th>پیش‌فرض / معنی</th></tr>')
            for fl in cls["fields"]:
                d = sym.get(f'{cls["name"]}.{fl["name"]}', "")
                default = code(fl["default"]) if fl["default"] else "<i>اجباری</i>"
                out.append(f'<tr><td class="mono">{esc(fl["name"])}</td>'
                           f'<td class="mono">{esc(fl["type"])}</td><td>{default} {d}</td></tr>')
            out.append('</table>')
        members = [m for m in cls["members"] if not m["sig"].startswith("__")]
        if members:
            out.append('<table class="api"><tr><th style="width:46%">عضو</th><th>کار</th></tr>')
            for m in members:
                name = m["sig"].split("(")[0]
                d = sym.get(f'{cls["name"]}.{name}') or esc(m["doc"])
                tag = ""
                if any("property" in x for x in m["decorators"]): tag = '<span class="pill">property</span>'
                elif any("abstract" in x for x in m["decorators"]): tag = '<span class="pill">abstract</span>'
                elif any("classmethod" in x for x in m["decorators"]): tag = '<span class="pill">classmethod</span>'
                elif any("staticmethod" in x for x in m["decorators"]): tag = '<span class="pill">static</span>'
                priv = ' <span class="pill priv">داخلی</span>' if m["private"] else ""
                sig = m["sig"].replace("self, ", "").replace("(self)", "()").replace("(self", "(")
                out.append(f'<tr><td class="mono sigcell">{esc(sig)}</td>'
                           f'<td>{tag}{priv} {d}</td></tr>')
            out.append('</table>')

    funcs = f["functions"]
    if funcs:
        out.append('<p class="sub">توابع سطح ماژول</p>')
        out.append('<table class="api"><tr><th style="width:46%">تابع</th><th>کار</th></tr>')
        for fn in funcs:
            name = fn["sig"].split("(")[0]
            d = sym.get(name) or esc(fn["doc"])
            priv = ' <span class="pill priv">داخلی</span>' if fn["private"] else ""
            out.append(f'<tr><td class="mono sigcell">{esc(fn["sig"])}</td>'
                       f'<td>{priv} {d}</td></tr>')
        out.append('</table>')

    if n.get("after"):
        out.append(n["after"])
    return "\n".join(out)

# -*- coding: utf-8 -*-
"""Persian prose for the tools/ root and the common/pl_codegen/ core modules."""

NOTES = {}

NOTES["run_generate.py"] = {
 "fa": """<p>تنها نقطه‌ی ورودِ کاربر. عمداً کوتاه است تا منطقی برای شکستن نداشته باشد: پوشه‌ی
<code>tools</code> را به مسیر جست‌وجوی پایتون اضافه می‌کند تا
<code>import common.pl_codegen</code> از هر پوشه‌ای کار کند، بعد <code>cli.main()</code> را صدا
می‌زند و کد خروجی‌اش را به سیستم‌عامل می‌دهد.</p>
<pre><code>sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.pl_codegen.cli import main
if __name__ == "__main__":
    raise SystemExit(main())</code></pre>
<p class="small"><code>__file__</code> مسیر همین فایل است؛
<code>if __name__ == "__main__"</code> یعنی «فقط وقتی مستقیم اجرا شد، نه وقتی import شد»؛
<code>SystemExit(n)</code> یعنی خروج با کد <code>n</code>.</p>""",
 "when": "تقریباً هیچ‌وقت. اگر می‌خواهید ابزار را از پایتون دیگری صدا بزنید، به‌جای این فایل مستقیم <code>common.pl_codegen.cli.main([...])</code> را import و صدا بزنید.",
}

NOTES["setup_environment.py"] = {
 "fa": """<p>نصب‌کننده‌ی «یک‌کلیکی». نکته‌ی طراحی‌اش این است که <b>خودش هیچ وابستگی خارجی
ندارد</b> — فقط کتابخانه‌ی استاندارد — پس حتی وقتی هیچ‌چیز نصب نیست هم اجرا می‌شود. اگر
از <code>openpyxl</code> استفاده می‌کرد، همان اول با خطای import می‌مرد و کاربر
نمی‌فهمید چه کند.</p>
<p>سه حالت دارد: بدون سوییچ (چک و نصب)، <code>--check-only</code> (فقط گزارش) و
<code>--upgrade</code> (به‌روزرسانی حتی اگر نصب باشد). در انتها نصب را با یک
<code>import</code> واقعی تأیید می‌کند، نه با خروجی <code>pip</code>.</p>""",
 "when": "وقتی وابستگی تازه‌ای اضافه می‌کنید. آن را به <code>requirements.txt</code> و به فهرست داخلی این فایل اضافه کنید.",
 "sym": {
  "MINIMUM_PYTHON": "کمینه‌ی نسخه‌ی پایتون که ابزار با آن کار می‌کند.",
  "REQUIREMENTS_FILE": "نام فایل وابستگی‌ها کنار همین اسکریپت.",
  "Requirement": "یک وابستگی: نام بسته، نام ماژولی که باید import شود، و دلیل نیاز به آن. نام بسته و نام ماژول همیشه یکی نیستند.",
  "check_python_version": "نسخه‌ی پایتون در حال اجرا را با <code>MINIMUM_PYTHON</code> می‌سنجد و پیام روشن می‌دهد.",
  "missing_requirements": "فهرست وابستگی‌هایی که <code>import</code> آنها شکست می‌خورد.",
  "install": "<code>pip install</code> را برای بسته‌های کم‌بود اجرا می‌کند؛ با <code>upgrade=True</code> سوییچ <code>--upgrade</code> هم می‌دهد.",
  "verify": "بعد از نصب، هر ماژول را واقعاً import می‌کند تا مطمئن شود نصب کارساز بوده.",
  "write_requirements_file": "اگر <code>requirements.txt</code> نبود، از روی فهرست داخلی می‌سازدش.",
  "main": "سوییچ‌ها را می‌خواند و مراحل بالا را به‌ترتیب اجرا می‌کند؛ ۰ یعنی محیط آماده است.",
 },
}

NOTES["common/pl_codegen/__init__.py"] = {
 "fa": """<p>فقط شناسنامه‌ی پکیج: نام و نسخه‌ی ابزار. همین دو مقدار در سربرگ هر فایل تولیدی،
در خروجی <code>--version</code> و در فایل XML ظاهر می‌شوند.</p>""",
 "when": "<b>بعد از هر تغییر معنادار.</b> عدد نسخه را این‌جا بالا ببرید؛ همان عددی است که در فایل‌های تولیدی می‌نشیند و به آدم می‌گوید کد جلوی چشمش از کدام نسخه‌ی ابزار آمده.",
 "sym": {"__tool_name__": "نامی که در سربرگ فایل‌های تولیدی و در XML می‌آید.",
         "__version__": "نسخه‌ی ابزار."},
}

NOTES["common/pl_codegen/logging_utils.py"] = {
 "fa": """<p>یک لاگر واحد برای کل ابزار، به نام <code>pl_codegen</code>. دلیل وجودش این است که
هیچ ماژولی نباید <code>print()</code> بزند: با لاگر، سطح پیام‌ها از یک‌جا
(<code>-v</code>/<code>-q</code>) کنترل می‌شود و تست‌ها می‌توانند خروجی را بگیرند و
بررسی کنند — کاری که <code>check_unknown_config_key()</code> در تست اعتبارسنجی دقیقاً
انجام می‌دهد.</p>""",
 "when": "وقتی می‌خواهید چیزی روی کنسول چاپ کنید. <code>get_logger()</code> بگیرید و از آن استفاده کنید، نه <code>print</code>.",
 "sym": {
  "setup_logging": "لاگر را می‌سازد و سطحش را تعیین می‌کند: <code>-v</code> ⟵ DEBUG، عادی ⟵ INFO، <code>-q</code> ⟵ WARNING. یک بار در <code>cli.main()</code> صدا زده می‌شود.",
  "get_logger": "همان لاگر پیکربندی‌شده را در هر ماژول دیگری برمی‌گرداند.",
  "banner": "خط‌های <code>====</code>ی بین دو مرحله‌ی خط لوله را می‌سازد.",
 },
}

NOTES["common/pl_codegen/errors.py"] = {
 "fa": """<p>زیرساخت گزارش مشکل‌ها. مهم‌ترین تصمیم معماری کل پروژه این‌جاست:</p>
<div class="ok">
<b>ایرادِ ورودیِ کاربر هیچ‌وقت استثنا نیست</b>
<p>
اگر هر ایراد اکسل یک <code>raise</code> بود، کاربر باید ابزار را ده بار اجرا می‌کرد تا ده
ایرادش را پیدا کند. به‌جایش هر ایراد به یک <code>DiagnosticCollector</code> اضافه می‌شود و
همه با هم گزارش می‌شوند. استثنا (<code>CodeGeneratorError</code>) فقط برای وقتی است که
<b>خود ابزار</b> نمی‌تواند ادامه دهد: کانفیگ خراب، فایل ناموجود.
</p>
</div>""",
 "when": "وقتی پیام تازه‌ای اضافه می‌کنید. همیشه از <code>error()</code>/<code>warning()</code>/<code>info()</code> استفاده کنید و کد، متن، مکان و <code>hint</code> بدهید.",
 "sym": {
  "CodeGeneratorError": "تنها استثنای پروژه. فقط برای خطای خود ابزار — نه برای ایراد اکسل کاربر.",
  "Severity": "سه سطح، مرتب از کم به زیاد: <code>INFO</code> ۰، <code>WARNING</code> ۱، <code>ERROR</code> ۲. چون <code>IntEnum</code> است، مقایسه‌ی <code>&gt;=</code> برای فیلتر کردن کار می‌کند.",
  "Severity.label": "برچسب متنی سطح، برای چاپ.",
  "SourceLocation": "مکان یک مشکل: فایل، شیت، ردیف، ستون. همان خطی است که زیر هر پیام چاپ می‌شود و کاربر را مستقیم به سلول می‌برد.",
  "SourceLocation.to_dict": "همان مکان به شکل دیکشنری، برای خروجی ماشین‌خوان.",
  "Diagnostic": "یک مشکل: سطح، کد (مثل <code>RNG003</code>)، متن، مکان و راهنمایی.",
  "Diagnostic.render": "متن چندخطیِ آماده‌ی چاپ روی کنسول.",
  "Diagnostic.to_dict": "همان پیام به شکل دیکشنری.",
  "DiagnosticCollector": "ظرف همه‌ی پیام‌ها. هر جای کد که یکی از این‌ها در دست دارید، می‌توانید پیام اضافه کنید.",
  "DiagnosticCollector.add": "یک <code>Diagnostic</code> آماده را اضافه می‌کند.",
  "DiagnosticCollector.error": "پیام سطح ERROR می‌سازد و اضافه می‌کند. وجود حتی یکی، تولید کد را متوقف می‌کند.",
  "DiagnosticCollector.warning": "پیام سطح WARNING. تولید کد ادامه پیدا می‌کند مگر با <code>-W</code>.",
  "DiagnosticCollector.info": "پیام سطح INFO. فقط با <code>-v</code> دیده می‌شود.",
  "DiagnosticCollector.items": "فهرست همه‌ی پیام‌ها به‌ترتیب افزوده شدن.",
  "DiagnosticCollector.count": "تعداد پیام‌های یک سطح مشخص.",
  "DiagnosticCollector.has_errors": "آیا حتی یک ERROR هست.",
  "DiagnosticCollector.has_warnings": "آیا حتی یک WARNING هست.",
  "DiagnosticCollector.render": "همه‌ی پیام‌های هم‌سطح یا بالاتر از <code>min_severity</code> را برای چاپ قالب‌بندی می‌کند.",
  "DiagnosticCollector.summary": "خط جمع‌بندی «N error(s), M warning(s), K info message(s)».",
  "DiagnosticCollector.to_list": "همه‌ی پیام‌ها به شکل لیستی از دیکشنری.",
 },
}

NOTES["common/pl_codegen/naming.py"] = {
 "fa": """<p><b>تنها جایی در کل پروژه که از نام اکسل، شناسه‌ی C ساخته می‌شود.</b> هیچ ماژول
دیگری اسم نمی‌سازد. نتیجه‌اش این است که اگر روزی قاعده‌ی نام‌گذاری شرکت عوض شد، فقط همین
یک فایل تغییر می‌کند و کل خروجی یکدست عوض می‌شود.</p>
<table class="api">
<tr><th style="width:46%">فراخوانی</th><th>خروجی</th></tr>
<tr><td class="mono">to_macro_case("PosDrone")</td><td class="mono">POS_DRONE</td></tr>
<tr><td class="mono">index_macro("PosDrone")</td><td class="mono">POS_DRONE</td></tr>
<tr><td class="mono">array_size_macro("VelDrone")</td><td class="mono">VEL_DRONE_ARRAY_SIZE</td></tr>
<tr><td class="mono">smart_data_symbol("PosDrone")</td><td class="mono">Cg_SmartData_PosDrone</td></tr>
<tr><td class="mono">offset_macro("ResetProof", "PosDrone", "PARAMETER_LIST_")</td>
    <td class="mono">PARAMETER_LIST_RESET_PROOF_POS_DRONE_OFFSET</td></tr>
<tr><td class="mono">offset_total_macro("ResetProof", "PARAMETER_LIST_")</td>
    <td class="mono">PARAMETER_LIST_RESET_PROOF_TOTAL_SIZE</td></tr>
<tr><td class="mono">include_guard("cg_parameter_list.h")</td><td class="mono">CG_PARAMETER_LIST_H</td></tr>
</table>""",
 "when": "وقتی قاعده‌ی نام‌گذاری عوض می‌شود. بعدش حتماً <code>run_compile_test.py</code> را بزنید: نام‌های تازه ممکن است با هم تداخل کنند و <code>NAME004</code> بگیرید.",
 "sym": {
  "is_valid_c_identifier": "آیا این متن یک شناسه‌ی معتبر C است (حرف یا <code>_</code> در اول، بعد حرف/رقم/<code>_</code>).",
  "is_reserved_keyword": "آیا این نام یکی از کلیدواژه‌های C یا C++ است.",
  "to_macro_case": "نامِ CamelCase را به <code>UPPER_SNAKE_CASE</code> تبدیل می‌کند. دو الگوی منظم مرز کلمه را پیدا می‌کنند: یکی <code>aB</code> و یکی <code>ABc</code> (پایان یک سرواژه) — برای همین <code>GSName</code> می‌شود <code>GS_NAME</code> نه <code>G_S_NAME</code>.",
  "index_macro": "نام ماکروی <code>#define</code>ی که ایندکس پارامتر را نگه می‌دارد.",
  "array_size_macro": "نام ماکروی سایز آرایه‌ی یک پارامتر.",
  "smart_data_symbol": "نام شیء smart data تولیدشده برای یک پارامتر.",
  "offset_macro": "نام ماکروی <code>MemoryOffset</code> برای یک زوجِ «تگ + پارامتر».",
  "offset_total_macro": "نام ماکروی «مجموع بایت‌های این تگ».",
  "include_guard": "include guard متناظر با یک نام فایل، هماهنگ با اسنیپت شرکت.",
  "tag_size_function": "نام تابع گتر اندازه‌ی یک تگ: <code>\"ResetProof\"</code> ⟵ <code>fParameterList_GetResetProofSize</code>.",
  "C_RESERVED_KEYWORDS": "مجموعه‌ی کلیدواژه‌های C و C++ که نام پارامتر نباید یکی از آنها باشد.",
 },
}

# -*- coding: utf-8 -*-
NOTES = {}

NOTES["common/pl_codegen/config.py"] = {
 "fa": """<p>خواندن و اعتبارسنجی <code>codegen_config.json</code>. پنج <code>dataclass</code> که
هرکدام یک بخش کانفیگ‌اند و در یک <code>Config</code> جمع می‌شوند. چهار تصمیم مهم:</p>
<ul>
  <li><b>گویش JSON با کامنت.</b> <code>load_jsonc()</code> پیش از تجزیه، خط‌های
      <code>//</code> و کامای اضافی را حذف می‌کند — همان گویشی که خود VS Code برای
      <code>c.json</code> به کار می‌برد.</li>
  <li><b>مسیرها نسبت به خود فایل کانفیگ</b> مطلق می‌شوند، نه نسبت به پوشه‌ی جاری. برای
      همین ابزار از هر جایی قابل اجراست.</li>
  <li><b>بخش <code>null</code> نباید برنامه را بترکاند.</b> الگوی
      <code>data.get("style") or {}</code> یعنی اگر کاربر بنویسد
      <code>"style": null</code>، به‌جای <code>None</code> یک دیکشنری خالی می‌گیریم.</li>
  <li><b>کلید ناشناس گزارش می‌شود.</b> با <code>difflib</code> نزدیک‌ترین کلید درست
      پیشنهاد می‌شود.</li>
</ul>""",
 "when": "وقتی تنظیم تازه‌ای اضافه می‌کنید: فیلد را به dataclass مربوطه اضافه کنید، و اگر آن بخش با <code>_warn_unknown_keys</code> چک می‌شود، نامش را به مجموعه‌ی کلیدهای مجاز هم اضافه کنید.",
 "sym": {
  "load_jsonc": "یک فایل JSON را که کامنت <code>//</code> و کامای اضافی دارد می‌خواند.",
  "InputConfig": "بخش <code>inputs</code>: فایل‌های اکسل و نام دو شیت.",
  "InputConfig.excel_files": "فهرست مسیرهای مطلق‌شده‌ی اکسل‌ها.",
  "InputConfig.parameter_sheet": "نام شیت پارامترها.",
  "InputConfig.defines_sheet": "نام شیت مقادیر مجاز.",
  "OutputConfig": "بخش <code>output</code>: کجا بنویسیم و با چه نامی.",
  "OutputConfig.code_directory": "پوشه‌ی فایل‌های C تولیدی.",
  "OutputConfig.xml_file": "مسیر فایل مدل XML.",
  "OutputConfig.file_prefix": "پیشوند نام همه‌ی فایل‌های تولیدی.",
  "OutputConfig.base_name": "هسته‌ی نام فایل‌ها؛ خالی یعنی از نام اولین اکسل ساخته شود.",
  "StyleConfig": "بخش <code>style</code>: قالب فایل C شرکت.",
  "StyleConfig.snippet_file": "مسیر <code>c.json</code>؛ <code>None</code> یعنی قالب پیش‌فرض داخلی.",
  "StyleConfig.company": "نامی که در بلوک کپی‌رایت می‌آید.",
  "StyleConfig.indent": "رشته‌ی تورفتگی کد تولیدی.",
  "CodegenConfig": "بخش <code>codegen</code>: محتوای کد تولیدی.",
  "CodegenConfig.emit_description": "درج رشته‌ی توضیحات در جدول descriptor.",
  "CodegenConfig.emit_unit": "درج رشته‌ی واحد.",
  "CodegenConfig.emit_generation_info": "درج بلوک شناسنامه در سربرگ فایل‌ها.",
  "CodegenConfig.emit_timestamp": "درج زمان دقیق تولید. برای گیت باید <code>false</code> باشد.",
  "CodegenConfig.index_define_prefix": "پیشوند ماکروهای ایندکس و سایز آرایه.",
  "CodegenConfig.offset_define_prefix": "پیشوند ماکروهای آفست.",
  "CodegenConfig.smart_data_prefix": "پیشوند نام اشیاء smart data.",
  "CodegenConfig.descriptor_symbol": "نام آرایه‌ی descriptor.",
  "CodegenConfig.quantity_define": "نام ماکروی تعداد پارامترها.",
  "CodegenConfig.extra_includes": "هدرهای اضافی برای <code>cg_parameter_list.c</code> — لازم وقتی یک تگ آزاد مقدارش یک ماکروی اپلیکیشن است.",
  "ValidationConfig": "بخش <code>validation</code>: سخت‌گیری اعتبارسنجی.",
  "ValidationConfig.treat_warnings_as_errors": "هشدارها هم جلوی تولید را بگیرند.",
  "ValidationConfig.require_description": "خالی بودن Description ارور شود.",
  "ValidationConfig.require_unit": "خالی بودن Unit ارور شود.",
  "Config": "کانفیگ کاملاً حل‌شده: مسیرها مطلق، مقادیر بررسی‌شده.",
  "Config.path": "مسیر خود فایل کانفیگ (مبنای حل بقیه‌ی مسیرها).",
  "Config.load": "فایل را می‌خواند، مسیرها را مطلق می‌کند، کلیدهای ناشناس را هشدار می‌دهد و در آخر <code>validate()</code> را صدا می‌زند.",
  "Config.validate": "وجود فایل‌های اکسل و اسنیپت را چک می‌کند، <code>style.indent</code> را با <code>_INDENT_SAFE</code> (فقط فاصله و tab) و <code>base_name</code>/<code>file_prefix</code> را با <code>_NAME_SAFE</code> می‌سنجد — چون این‌ها مستقیم وارد کد C می‌شوند.",
  "Config.generated_file_name": "<code>('defines', 'h')</code> ⟵ <code>cg_parameter_list_defines.h</code>.",
  "Config.smart_data_file_name": "نام فایل‌های smart data تولیدی.",
  "_dataclass_from_dict": "یک dataclass را از دیکشنری می‌سازد و کلیدهای ناشناس را با پیشنهاد جایگزین هشدار می‌دهد.",
  "_closest": "نزدیک‌ترین کلید درست به یک کلید غلط، با <code>difflib</code>.",
  "_warn_unknown_sections": "همان چک، یک سطح بالاتر: بخشِ کلاً اشتباه‌نوشته‌شده.",
  "_warn_unknown_keys": "همان چک برای بخش‌هایی که از dataclass ساخته نمی‌شوند.",
 },
 "after": """<div class="warn">
<b>چرا <code>base_name</code> اعتبارسنجی می‌شود</b>
<p>
<code>base_name</code> اگر خالی باشد از نام فایل اکسل ساخته می‌شود، و اسم یک اکسل واقعی
معمولاً چیزی مثل <code>Parameter List (v2).xlsx</code> است. آن نام مستقیم وارد
<code>#include</code> و include guard می‌شد و کدی تولید می‌شد که کامپایل نمی‌شود، بدون
اینکه هیچ‌کجا گفته باشد چرا. حالا ابزار همان اول با یک پیام روشن رد می‌کند.
</p>
</div>""",
}

NOTES["common/pl_codegen/cli.py"] = {
 "fa": """<p>همه‌ی کار با خط فرمان، و <b>تنها جایی که کد خروجی برنامه تعیین می‌شود</b>.
<code>build_parser()</code> سوییچ‌ها را تعریف می‌کند و <code>main()</code> آنها را به کار
می‌بندد.</p>
<table class="api">
<tr><th class="c" style="width:14%">کد خروجی</th><th>معنی</th></tr>
<tr><td class="c mono">0</td><td>موفق</td></tr>
<tr><td class="c mono">1</td><td>ورودی ایراد دارد؛ کدی تولید نشد</td></tr>
<tr><td class="c mono">2</td><td>خطای خود ابزار: کانفیگ خراب، اکسل ناموجود، اسنیپت گم‌شده</td></tr>
</table>
<p><code>--list-rules</code> هم این‌جاست: روی <code>ALL_RULES</code> حلقه می‌زند و
<code>rule_id</code> و <code>description</code> هرکدام را چاپ می‌کند — یعنی مستنداتِ
قوانین همیشه با خود کد هماهنگ است و نمی‌تواند کهنه شود.</p>""",
 "when": "وقتی سوییچ تازه‌ای می‌خواهید، یا رفتار کد خروجی باید عوض شود.",
 "sym": {
  "DEFAULT_CONFIG": "نام پیش‌فرض فایل کانفیگ.",
  "TOOLS_DIR": "پوشه‌ی <code>tools</code>، جایی که کانفیگ کنار <code>generate.py</code> است.",
  "EXIT_OK": "کد خروجی ۰.",
  "EXIT_VALIDATION_FAILED": "کد خروجی ۱ — ورودی ایراد دارد.",
  "EXIT_TOOL_ERROR": "کد خروجی ۲ — خطای خود ابزار.",
  "build_parser": "همه‌ی سوییچ‌های خط فرمان را تعریف می‌کند.",
  "resolve_config_path": "تصمیم می‌گیرد کانفیگ از کجا خوانده شود: اول <code>-c</code>، بعد <code>codegen_config.json</code> پوشه‌ی جاری، بعد فایل کنار <code>generate.py</code>. همین باعث می‌شود ابزار از هر پوشه‌ای اجرا شود.",
  "main": "لاگر را می‌سازد، کانفیگ را بار می‌کند، مرحله‌ی خواسته‌شده را اجرا می‌کند، پیام‌ها را چاپ می‌کند و کد خروجی می‌دهد.",
  "_print_rules": "خروجی <code>--list-rules</code>.",
  "_print_result": "خلاصه‌ی پایان اجرا: فایل‌های تولیدشده و جمع‌بندی پیام‌ها.",
 },
}

NOTES["common/pl_codegen/pipeline.py"] = {
 "fa": """<p>قلب هماهنگی: دو مرحله را به‌ترتیب صدا می‌زند و نتیجه را در یک
<code>PipelineResult</code> برمی‌گرداند. خودش هیچ منطقی درباره‌ی اکسل یا C ندارد.</p>
<div class="pipeline">
Excel files  ──►  Model  ──►  Validation  ──►  <b>XML</b><br>
&nbsp;<br>
<b>XML</b>  ──►  Model  ──►  Tag offsets  ──►  C source / header files
</div>""",
 "when": "وقتی مرحله‌ی تازه‌ای به خط لوله اضافه می‌شود، یا ترتیب کارها باید عوض شود.",
 "sym": {
  "PipelineResult": "نتیجه‌ی یک اجرا: موفقیت، پیام‌ها، مسیر XML، فایل‌های تولیدشده و تعداد پارامترها.",
  "PipelineResult.success": "آیا اجرا موفق بود.",
  "PipelineResult.diagnostics": "ظرف پیام‌های همان اجرا.",
  "PipelineResult.xml_file": "مسیر مدل XML، اگر نوشته شده باشد.",
  "PipelineResult.generated_files": "فهرست فایل‌های C تولیدشده.",
  "PipelineResult.parameter_count": "تعداد پارامترهای فعال.",
  "Pipeline": "اجراکننده‌ی مرحله‌های خواسته‌شده.",
  "Pipeline.excel_to_xml": "مرحله ۱: خواندن اکسل‌ها، ادغام، اعتبارسنجی، نوشتن XML. اگر اعتبارسنجی شکست بخورد <code>None</code> می‌دهد و چیزی نوشته نمی‌شود.",
  "Pipeline.xml_to_code": "مرحله ۲: خواندن XML، محاسبه‌ی آفست‌ها، ساخت و ذخیره‌ی شش فایل. آرگومان <code>validate</code> کلید ماجرای «پیام تکراری» است — زیر جدول توضیح داده شده.",
  "Pipeline.check": "فقط اعتبارسنجی، بدون نوشتن <b>هیچ</b> فایلی.",
  "Pipeline.run": "دو مرحله را به هم وصل می‌کند؛ <code>only_xml</code> بعد از مرحله ۱ می‌ایستد و <code>from_xml</code> مرحله ۱ را کلاً رد می‌کند.",
  "render_diagnostics": "پیام‌ها را برای کنسول قالب‌بندی می‌کند؛ بدون <code>-v</code> پیام‌های INFO را نشان نمی‌دهد.",
 },
 "after": """<div class="warn">
<b>چرا مرحله‌ی ۲ در اجرای کامل اعتبارسنجی نمی‌کند</b>
<p>
مدلی که مرحله‌ی ۲ از XML می‌خواند، همان مدلی است که مرحله‌ی ۱ همین الان چک کرده. اگر
قوانین دوباره اجرا شوند، <b>هر پیام دو بار</b> چاپ می‌شود. برای همین
<code>run()</code> متد دوم را با <code>validate=False</code> صدا می‌زند و به‌جای اجرای
دوباره‌ی قوانین، یک چک ارزان انجام می‌دهد: تعداد پارامترهای فعالِ خوانده‌شده باید با
تعدادی که نوشته شده یکی باشد، وگرنه <code>XML020</code>.
</p>
<p>
اما با <code>--from-xml</code> که مرحله‌ی ۱ اصلاً اجرا نشده، اعتبارسنجی <b>کامل</b> انجام
می‌شود — همان مسیری که GUI فاز بعد از آن استفاده می‌کند.
</p>
</div>
<div class="note">
<b>چرا <code>check()</code> جدا نوشته شده</b>
<p>
نسخه‌ی اول <code>--check</code> کار خودش را با «اجرای مرحله ۱ و بعد
<code>unlink()</code> کردن فایل» انجام می‌داد. اگر کاربر همان مسیر XML را برای خودش
نگه داشته بود، آن فایل بی‌صدا پاک می‌شد. حالا <code>check()</code> اصلاً چیزی نمی‌نویسد.
</p>
</div>""",
}

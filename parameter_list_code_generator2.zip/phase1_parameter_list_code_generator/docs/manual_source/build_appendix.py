# -*- coding: utf-8 -*-
"""Rebuild the parts of the appendix that must never disagree with the code.

Three tables in the appendix are pure facts about the tool: the validation
rules, the diagnostic codes and the data types.  They used to be written by
hand, and every one of them was wrong within a month - a rule renamed here, a
code added there, and the manual quietly started lying.

So they are generated instead, from the very registries the tool itself uses:

  * the rules from ``ALL_RULES``;
  * the diagnostic codes by reading every ``diagnostics.xxx("CODE", ...)`` call
    in the source, which is the only place a code can come from;
  * the data types from ``DATA_TYPES``.

Each generated table sits between a pair of markers in the HTML, so the prose
around them stays hand-written:

    <!-- GEN:rules -->  ...generated...  <!-- /GEN:rules -->

    cd docs/manual_source
    python build_appendix.py
"""

from __future__ import annotations

import html
import re
import sys
from pathlib import Path
from typing import Dict, List

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent.parent
TOOLS = PROJECT / "tools"
APPENDIX = HERE / "parts" / "p08_appendix.html"

sys.path.insert(0, str(TOOLS))

from common.pl_codegen.model.types import DATA_TYPES          # noqa: E402
from common.pl_codegen.validation.rules import ALL_RULES      # noqa: E402

#: 'diagnostics.error("NAME001", ...)' and the info/warning spellings of it
CODE_CALL = re.compile(r'\.(?:error|warning|info)\(\s*"([A-Z]{3,8}\d{3})"')

#: what each code prefix is about, for the second table
FAMILIES = {
    "ARR": "آرایه",
    "DEF": "لیست‌های کشویی (شیت Defines)",
    "EXL": "خواندن اکسل",
    "GRP": "گروه",
    "META": "توضیحات و واحد",
    "NAME": "نام‌ها",
    "RNG": "مقادیر و بازه",
    "STR": "استراکچر",
    "TAG": "تگ‌ها",
    "TYPE": "تایپ داده",
    "VAL": "کلی",
    "XML": "مدل XML",
}


def esc(text: object) -> str:
    return html.escape(str(text), quote=False)


def ltr(text: object) -> str:
    """English text inside a right-to-left page needs its own direction."""
    return f'<span class="ltr">{esc(text)}</span>'


def rules_table() -> str:
    rows = ['<table><tr><th class="c" style="width:7%">#</th>'
            '<th style="width:26%">کلاس</th><th style="width:20%">rule_id</th>'
            '<th>کار</th></tr>']
    for number, rule in enumerate(ALL_RULES, start=1):
        rows.append(f'<tr><td class="c">{number}</td>'
                    f'<td class="mono">{esc(type(rule).__name__)}</td>'
                    f'<td class="mono">{esc(rule.rule_id)}</td>'
                    f'<td>{ltr(rule.description)}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def codes_by_family() -> Dict[str, List[str]]:
    found: Dict[str, set] = {}
    for path in sorted(TOOLS.rglob("*.py")):
        if "__pycache__" in path.parts or path.parts[-2:-1] == ("tests",):
            continue
        for code in CODE_CALL.findall(path.read_text(encoding="utf-8", errors="ignore")):
            prefix = re.match(r"[A-Z]+", code).group(0)
            found.setdefault(prefix, set()).add(code)
    return {prefix: sorted(codes) for prefix, codes in sorted(found.items())}


def codes_table() -> str:
    families = codes_by_family()
    total = sum(len(codes) for codes in families.values())
    rows = [f'<p>در مجموع <b>{total}</b> کد، مستقیم از سورس بیرون کشیده شده. '
            f'اگر کد تازه‌ای اضافه کردید کافی است <code>python build_appendix.py</code> '
            f'را دوباره اجرا کنید.</p>',
            '<table><tr><th style="width:16%">پیشوند</th>'
            '<th style="width:26%">دسته</th><th>کدها</th></tr>']
    for prefix, codes in families.items():
        rows.append(f'<tr><td class="mono">{esc(prefix)}</td>'
                    f'<td>{esc(FAMILIES.get(prefix, "—"))}</td>'
                    f'<td class="mono">{esc(", ".join(codes))}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def types_table() -> str:
    rows = ['<table><tr><th>نام C</th><th>پسوند</th><th class="c">بایت</th>'
            '<th>ساختار</th><th>سازنده</th><th class="c">بازه</th>'
            '<th>پسوند لیترال</th><th>Resolution پیش‌فرض</th></tr>']
    for name, data_type in DATA_TYPES.items():
        has_range = "—" if data_type.is_bool else "دارد"
        rows.append(f'<tr><td class="mono">{esc(name)}</td>'
                    f'<td class="mono">{esc(data_type.suffix)}</td>'
                    f'<td class="c">{data_type.value_size}</td>'
                    f'<td class="mono">{esc(data_type.smart_data_struct)}</td>'
                    f'<td class="mono">{esc(data_type.constructor)}</td>'
                    f'<td class="c">{has_range}</td>'
                    f'<td class="mono">{esc(data_type.literal_suffix or "—")}</td>'
                    f'<td class="mono">{esc(data_type.default_resolution)}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def splice(text: str, name: str, body: str) -> str:
    """Replace what is between ``<!-- GEN:name -->`` and its closing marker."""
    pattern = re.compile(rf"(<!-- GEN:{name} -->).*?(<!-- /GEN:{name} -->)", re.S)
    if not pattern.search(text):
        raise SystemExit(f"the '{name}' markers are missing from {APPENDIX.name}")
    return pattern.sub(lambda m: f"{m.group(1)}\n{body}\n{m.group(2)}", text)


def main() -> int:
    text = APPENDIX.read_text(encoding="utf-8")
    text = splice(text, "rules", rules_table())
    text = splice(text, "codes", codes_table())
    text = splice(text, "types", types_table())
    APPENDIX.write_text(text, encoding="utf-8")

    families = codes_by_family()
    print(f"appendix rebuilt: {len(ALL_RULES)} rules, "
          f"{sum(len(c) for c in families.values())} diagnostic codes, "
          f"{len(DATA_TYPES)} data types")
    unknown = [p for p in families if p not in FAMILIES]
    if unknown:
        print("  note: no Persian name for the code prefix(es):", ", ".join(unknown))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

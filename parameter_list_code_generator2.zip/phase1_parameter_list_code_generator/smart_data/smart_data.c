/**
  ******************************************************************************
  * @file    smart_data.c
  * @brief
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  @verbatim

  @endverbatim
  */

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"

#include "chrono.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/**
 * @brief
 *
 */
#define ASSERT_DEFAULT_VALUE_(val_, min_, max_) \
    do { \
        if (((val_) > (max_)) || ((val_) < (min_))) { \
            return eSMART_DATA_ERROR_DEFAULT_VALUE_OUT_OF_RANGE; \
        } \
    } while (0)

/**
 * @brief
 *
 */
#define ASSERT_NOT_NULL_(ptr_)  \
    do {\
        if(ptr_ == NULL) {\
            return eSMART_DATA_ERROR_NULL_POINTER;\
        }\
    } while(0)

/**
 * @brief
 *
 */
#define CHECK_RANGE_(pSd_, primitiveType_, pVal_)  \
    do {\
        if((*((primitiveType_*)(pVal_)) > (pSd_)->_max) || (*((primitiveType_*)(pVal_)) < (pSd_)->_min)) {\
            return eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE;\
        }\
    } while(0)

/**
 * @brief
 *
 */
#define IS_MAX_VALID_(pSd_, max_)   \
    do {\
        if((max_ < (pSd_)->_min)) {\
            return eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE;\
        }\
    } while(0)

/**
 * @brief
 *
 */
#define IS_MIN_VALID_(pSd_, min_)   \
    do {\
        if((min_ > (pSd_)->_max)) {\
            return eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE;\
        }\
    } while(0)

/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private function prototypes --------------------------------------------- */
static eSmartDataStatus fRead(sSmartDataCore * const me, void * pOutValue);
static eSmartDataStatus fWrite(sSmartDataCore * const me, void *pValue);
static eSmartDataStatus fVerify(sSmartDataCore * const me);
static eSmartDataStatus fSetMinValue(sSmartDataCore * const me, void * pNewValue);
static eSmartDataStatus fGetMinValue(sSmartDataCore * const me, void * pOutValue);
static eSmartDataStatus fSetMaxValue(sSmartDataCore * const me, void * pNewValue);
static eSmartDataStatus fGetMaxValue(sSmartDataCore * const me, void * pOutValue);
static eSmartDataStatus fSetDefaultValue(sSmartDataCore * const me, void * pNewValue);
static eSmartDataStatus fGetDefaultValue(sSmartDataCore * const me, void * pOutValue);
static eSmartDataStatus fSetResolution(sSmartDataCore * const me, void * pNewValue);
static eSmartDataStatus fGetResolution(sSmartDataCore * const me, void * pOutValue);
static eSmartDataStatus fGetTimestamp(sSmartDataCore * const me, uint32_t *pOutTsUs);
static eSmartDataStatus fResetTimestamp(sSmartDataCore * const me);
static eSmartDataStatus fGetSmartDataSize(sSmartDataCore * const me, size_t *pOutSize);
static eSmartDataStatus fGetValueSize(sSmartDataCore * const me, size_t *pOutSize);

/**
 * @brief Vritual table that is used commonly among all smart data types.
 *
 */
static const struct sSmartDataVtbl CommonVtbl = {
    fRead,
    fWrite,
    fVerify,
    fSetMinValue,
    fGetMinValue,
    fSetMaxValue,
    fGetMaxValue,
    fSetDefaultValue,
    fGetDefaultValue,
    fSetResolution,
    fGetResolution,
    fGetTimestamp,
    fResetTimestamp,
    fGetSmartDataSize,
    fGetValueSize
};

/* Private functions -------------------------------------------------------- */

/* Exported variables ------------------------------------------------------- */

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/
/**
 * @brief
 *
 * @param me
 * @param defaultVal
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_B8_Ctor(sSmartDataB8 * const me, bool_t defaultVal) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(bool_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataB8);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_B8;
    me->_core.UserReadFlags = 0;

    me->_defaultValue = defaultVal;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_U8_Ctor(sSmartDataU8 * const me, uint8_t minVal, uint8_t maxVal, uint8_t defaultVal, uint8_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(uint8_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataU8);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_U8;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_I8_Ctor(sSmartDataI8 * const me, int8_t minVal, int8_t maxVal, int8_t defaultVal, int8_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(int8_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataI8);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_I8;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_U16_Ctor(sSmartDataU16 * const me, uint16_t minVal, uint16_t maxVal, uint16_t defaultVal, uint16_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(uint16_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataU16);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_U16;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_I16_Ctor(sSmartDataI16 * const me, int16_t minVal, int16_t maxVal, int16_t defaultVal, int16_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(int16_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataI16);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_I16;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_U32_Ctor(sSmartDataU32 * const me, uint32_t minVal, uint32_t maxVal, uint32_t defaultVal, uint32_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(uint32_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataU32);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_U32;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_I32_Ctor(sSmartDataI32 * const me, int32_t minVal, int32_t maxVal, int32_t defaultVal, int32_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(int32_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataI32);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_I32;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_U64_Ctor(sSmartDataU64 * const me, uint64_t minVal, uint64_t maxVal, uint64_t defaultVal, uint64_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(uint64_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataU64);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_U64;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_I64_Ctor(sSmartDataI64 * const me, int64_t minVal, int64_t maxVal, int64_t defaultVal, int64_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(int64_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataI64);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_I64;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_F32_Ctor(sSmartDataF32 * const me, float32_t minVal, float32_t maxVal, float32_t defaultVal, float32_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(float32_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataF32);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_F32;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param minVal
 * @param maxVal
 * @param defaultVal
 * @param resolution
 * @return eSmartDataStatus
 */
eSmartDataStatus fSmartData_F64_Ctor(sSmartDataF64 * const me, float64_t minVal, float64_t maxVal, float64_t defaultVal, float64_t resolution) {

    ASSERT_NOT_NULL_(me);

    me->_core.pVtbl = &CommonVtbl;
    me->_core.TypeInfo.ValueSize = sizeof(float64_t);
    me->_core.TypeInfo.SmartDataSize = sizeof(sSmartDataF64);
    me->_core.TimestampUs = 0x0U;
    me->_core.TypeInfo.Type = eSMART_DATA_TYPE_F64;
    me->_core.UserReadFlags = 0;

    ASSERT_DEFAULT_VALUE_(defaultVal, minVal, maxVal);

    me->_defaultValue = defaultVal;
    me->_min = minVal;
    me->_max = maxVal;
    me->_resolution = resolution;
    me->Value = defaultVal;

    return eSMART_DATA_OK;
}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/**
 * @brief
 *
 * @param me
 * @param pOutValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fRead(sSmartDataCore * const me, void * pOutValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {

            sSmartDataB8* pSd = (sSmartDataB8*)me;
            *((bool_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            *((uint8_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            *((int8_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            *((uint16_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            *((int16_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            *((uint32_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            *((int32_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            *((uint64_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            *((int64_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            *((float32_t*)pOutValue) = pSd->Value;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            *((float64_t*)pOutValue) = pSd->Value;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fWrite(sSmartDataCore * const me, void *pValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {

            sSmartDataB8* pSd = (sSmartDataB8*)me;
            pSd->Value = *(bool_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;

            CHECK_RANGE_(pSd, uint8_t, pValue);
            pSd->Value = *(uint8_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;

            CHECK_RANGE_(pSd, int8_t, pValue);
            pSd->Value = *(int8_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;

            CHECK_RANGE_(pSd, uint16_t, pValue);
            pSd->Value = *(uint16_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;

            CHECK_RANGE_(pSd, int16_t, pValue);
            pSd->Value = *(int16_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;

            CHECK_RANGE_(pSd, uint32_t, pValue);
            pSd->Value = *(uint32_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;

            CHECK_RANGE_(pSd, int32_t, pValue);
            pSd->Value = *(int32_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;

            CHECK_RANGE_(pSd, uint64_t, pValue);
            pSd->Value = *(uint64_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;

            CHECK_RANGE_(pSd, int64_t, pValue);
            pSd->Value = *(int64_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;

            CHECK_RANGE_(pSd, float32_t, pValue);
            pSd->Value = *(float32_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;

            CHECK_RANGE_(pSd, float64_t, pValue);
            pSd->Value = *(float64_t*)pValue;
            me->TimestampUs = fChrono_GetContinuousTickUs();

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    /* A new value has just been stored, so nobody has seen it yet.  Clearing
     * the flags here is what makes fSmartDataHasUserReadOnce_() mean "this user
     * has already seen the CURRENT value" instead of "this user has read this
     * object at some point in the past".
     *
     * Without this, a reader that had read the object once would never again be
     * told that the value changed - the write side set the value and the
     * timestamp but left every reader marked as up to date.
     *
     * It is done once, after the switch, so it cannot be forgotten when a new
     * type is added; and only on the success path, so a write refused by
     * CHECK_RANGE_() leaves the flags untouched - nothing changed, so nobody
     * needs to re-read. */
    me->UserReadFlags = 0;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @return eSmartDataStatus
 */
static eSmartDataStatus fVerify(sSmartDataCore * const me) {

    ASSERT_NOT_NULL_(me);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            CHECK_RANGE_(pSd, uint8_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            CHECK_RANGE_(pSd, int8_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            CHECK_RANGE_(pSd, uint16_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            CHECK_RANGE_(pSd, int16_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            CHECK_RANGE_(pSd, uint32_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            CHECK_RANGE_(pSd, int32_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            CHECK_RANGE_(pSd, uint64_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            CHECK_RANGE_(pSd, int64_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            CHECK_RANGE_(pSd, float32_t, &(pSd->Value));

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            CHECK_RANGE_(pSd, float64_t, &(pSd->Value));

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pNewValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fSetMinValue(sSmartDataCore * const me, void * pNewValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pNewValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            return eSMART_DATA_ERROR_NOT_APPLICABLE;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;

            IS_MIN_VALID_(pSd, *(uint8_t*)pNewValue);

            pSd->_min = *(uint8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;

            IS_MIN_VALID_(pSd, *(int8_t*)pNewValue);

            pSd->_min = *(int8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;

            IS_MIN_VALID_(pSd, *(uint16_t*)pNewValue);

            pSd->_min = *(uint16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;

            IS_MIN_VALID_(pSd, *(int16_t*)pNewValue);

            pSd->_min = *(int16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;

            IS_MIN_VALID_(pSd, *(uint32_t*)pNewValue);

            pSd->_min = *(uint32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;

            IS_MIN_VALID_(pSd, *(int32_t*)pNewValue);

            pSd->_min = *(int32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;

            IS_MIN_VALID_(pSd, *(uint64_t*)pNewValue);

            pSd->_min = *(uint64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;

            IS_MIN_VALID_(pSd, *(int64_t*)pNewValue);

            pSd->_min = *(int64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;

            IS_MIN_VALID_(pSd, *(float32_t*)pNewValue);

            pSd->_min = *(float32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;

            IS_MIN_VALID_(pSd, *(float64_t*)pNewValue);

            pSd->_min = *(float64_t*)pNewValue;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetMinValue(sSmartDataCore * const me, void * pOutValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            *(bool_t*)pOutValue = FALSE;
            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            *(uint8_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            *(int8_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            *(uint16_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            *(int16_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            *(uint32_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            *(int32_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            *(uint64_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            *(int64_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            *(float32_t*)pOutValue = pSd->_min;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            *(float64_t*)pOutValue = pSd->_min;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pNewValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fSetMaxValue(sSmartDataCore * const me, void * pNewValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pNewValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            return eSMART_DATA_ERROR_NOT_APPLICABLE;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;

            IS_MAX_VALID_(pSd, *(uint8_t*)pNewValue);

            pSd->_max = *(uint8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;

            IS_MAX_VALID_(pSd, *(int8_t*)pNewValue);

            pSd->_max = *(int8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;

            IS_MAX_VALID_(pSd, *(uint16_t*)pNewValue);

            pSd->_max = *(uint16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;

            IS_MAX_VALID_(pSd, *(int16_t*)pNewValue);

            pSd->_max = *(int16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;

            IS_MAX_VALID_(pSd, *(uint32_t*)pNewValue);

            pSd->_max = *(uint32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;

            IS_MAX_VALID_(pSd, *(int32_t*)pNewValue);

            pSd->_max = *(int32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;

            IS_MAX_VALID_(pSd, *(uint64_t*)pNewValue);

            pSd->_max = *(uint64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;

            IS_MAX_VALID_(pSd, *(int64_t*)pNewValue);

            pSd->_max = *(int64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;

            IS_MAX_VALID_(pSd, *(float32_t*)pNewValue);

            pSd->_max = *(float32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;

            IS_MAX_VALID_(pSd, *(float64_t*)pNewValue);

            pSd->_max = *(float64_t*)pNewValue;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetMaxValue(sSmartDataCore * const me, void * pOutValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            *(bool_t*)pOutValue = TRUE;
            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            *(uint8_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            *(int8_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            *(uint16_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            *(int16_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            *(uint32_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            *(int32_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            *(uint64_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            *(int64_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            *(float32_t*)pOutValue = pSd->_max;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            *(float64_t*)pOutValue = pSd->_max;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pNewValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fSetDefaultValue(sSmartDataCore * const me, void * pNewValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pNewValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {

            sSmartDataB8* pSd = (sSmartDataB8*)me;
            pSd->_defaultValue = *(bool_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;

            CHECK_RANGE_(pSd, uint8_t, pNewValue);
            pSd->_defaultValue = *(uint8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;

            CHECK_RANGE_(pSd, int8_t, pNewValue);
            pSd->_defaultValue = *(int8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;

            CHECK_RANGE_(pSd, uint16_t, pNewValue);
            pSd->_defaultValue = *(uint16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;

            CHECK_RANGE_(pSd, int16_t, pNewValue);
            pSd->_defaultValue = *(int16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;

            CHECK_RANGE_(pSd, uint32_t, pNewValue);
            pSd->_defaultValue = *(uint32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;

            CHECK_RANGE_(pSd, int32_t, pNewValue);
            pSd->_defaultValue = *(int32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;

            CHECK_RANGE_(pSd, uint64_t, pNewValue);
            pSd->_defaultValue = *(uint64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;

            CHECK_RANGE_(pSd, int64_t, pNewValue);
            pSd->_defaultValue = *(int64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;

            CHECK_RANGE_(pSd, float32_t, pNewValue);
            pSd->_defaultValue = *(float32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;

            CHECK_RANGE_(pSd, float64_t, pNewValue);
            pSd->_defaultValue = *(float64_t*)pNewValue;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetDefaultValue(sSmartDataCore * const me, void * pOutValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {

            sSmartDataB8* pSd = (sSmartDataB8*)me;
            *(bool_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            *(uint8_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            *(int8_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            *(uint16_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            *(int16_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            *(uint32_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            *(int32_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            *(uint64_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            *(int64_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            *(float32_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            *(float64_t*)pOutValue = pSd->_defaultValue;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pNewValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fSetResolution(sSmartDataCore * const me, void * pNewValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pNewValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            return eSMART_DATA_ERROR_NOT_APPLICABLE;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            pSd->_resolution = *(uint8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            pSd->_resolution = *(int8_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            pSd->_resolution = *(uint16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            pSd->_resolution = *(int16_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            pSd->_resolution = *(uint32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            pSd->_resolution = *(int32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            pSd->_resolution = *(uint64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            pSd->_resolution = *(int64_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            pSd->_resolution = *(float32_t*)pNewValue;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            pSd->_resolution = *(float64_t*)pNewValue;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutValue
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetResolution(sSmartDataCore * const me, void * pOutValue) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutValue);

    switch(me->TypeInfo.Type) {

        case eSMART_DATA_TYPE_B8: {
            return eSMART_DATA_ERROR_NOT_APPLICABLE;
        }

        case eSMART_DATA_TYPE_U8: {

            sSmartDataU8* pSd = (sSmartDataU8*)me;
            *(uint8_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_I8: {

            sSmartDataI8* pSd = (sSmartDataI8*)me;
            *(int8_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_U16: {

            sSmartDataU16* pSd = (sSmartDataU16*)me;
            *(uint16_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_I16: {

            sSmartDataI16* pSd = (sSmartDataI16*)me;
            *(int16_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_U32: {

            sSmartDataU32* pSd = (sSmartDataU32*)me;
            *(uint32_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_I32: {

            sSmartDataI32* pSd = (sSmartDataI32*)me;
            *(int32_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_U64: {

            sSmartDataU64* pSd = (sSmartDataU64*)me;
            *(uint64_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_I64: {

            sSmartDataI64* pSd = (sSmartDataI64*)me;
            *(int64_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_F32: {

            sSmartDataF32* pSd = (sSmartDataF32*)me;
            *(float32_t*)pOutValue = pSd->_resolution;

            break;
        }

        case eSMART_DATA_TYPE_F64: {

            sSmartDataF64* pSd = (sSmartDataF64*)me;
            *(float64_t*)pOutValue = pSd->_resolution;

            break;
        }

        default: {
            return eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED;
        }
    }

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutTsUs
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetTimestamp(sSmartDataCore * const me, uint32_t *pOutTsUs) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutTsUs);

    *pOutTsUs = me->TimestampUs;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @return eSmartDataStatus
 */
static eSmartDataStatus fResetTimestamp(sSmartDataCore * const me) {

    ASSERT_NOT_NULL_(me);

    me->TimestampUs = 0x0U;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutSize
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetSmartDataSize(sSmartDataCore * const me, size_t *pOutSize) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutSize);

    *pOutSize = me->TypeInfo.SmartDataSize;

    return eSMART_DATA_OK;
}

/**
 * @brief
 *
 * @param me
 * @param pOutSize
 * @return eSmartDataStatus
 */
static eSmartDataStatus fGetValueSize(sSmartDataCore * const me, size_t *pOutSize) {

    ASSERT_NOT_NULL_(me);
    ASSERT_NOT_NULL_(pOutSize);

    *pOutSize = me->TypeInfo.ValueSize;

    return eSMART_DATA_OK;
}

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    smart_data.h
  * @brief
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef SMART_DATA_H
#define SMART_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* Exported defines --------------------------------------------------------- */
#ifndef float32_t__

#define float32_t__
typedef float   float32_t;

#endif  //float32_t__

#ifndef float64_t__

#define float64_t__
typedef double  float64_t;

#endif  //float64_t__

#ifndef bool_t__

#define bool_t__

typedef bool    bool_t;

#ifndef FALSE
#define FALSE ((bool_t)0)
#endif  //FALSE

#ifndef TRUE
#define TRUE  ((bool_t)1)
#endif  //TRUE

#endif  //bool_t__

/* Exported macros ---------------------------------------------------------- */
/**
 * @brief Read/Write/Verify functions
 * 
 */
#define fSmartDataRead_(pSmartData_, pOutVal_) ((sSmartDataCore*)(pSmartData_))->pVtbl->fpRead((sSmartDataCore*)(pSmartData_), (pOutVal_))
#define fSmartDataWrite_(pSmartData_, pVal_)   ((sSmartDataCore*)(pSmartData_))->pVtbl->fpWrite((sSmartDataCore*)(pSmartData_), (pVal_))
#define fSmartDataVerify_(pSmartData_)         ((sSmartDataCore*)(pSmartData_))->pVtbl->fpVerify((sSmartDataCore*)(pSmartData_))

/**
 * @brief User Read functions
 * 
 */
#define fSmartDataResetUserReadFlag_(pSmartData_, userNo_)              (pSmartData_)->_core.UserReadFlags &= ~(1UL << (uint32_t)(userNo_))
#define fSmartDataResetReadFlags_(pSmartData_)                          (pSmartData_)->_core.UserReadFlags = 0
#define fSmartDataHasUserReadOnce_(pSmartData_, userNo_)                (bool)(((pSmartData_)->_core.UserReadFlags & (1UL << (uint32_t)(userNo_))) != 0)
#define fSmartDataUserRead_(pSmartData_, userNo_, pOutVal_, status_)    \
    do {\
        (status_) = ((sSmartDataCore*)(pSmartData_))->pVtbl->fpRead((sSmartDataCore*)(pSmartData_), (pOutVal_));\
        if(status_ != eSMART_DATA_OK) {\
            break;\
        }\
        if((uint32_t)(userNo_) < 32) {\
            (pSmartData_)->_core.UserReadFlags |= (1UL << (uint32_t)(userNo_));\
        } else  {\
            status_ = eSMART_DATA_ERROR_INVALID_USER_NUMBER;\
        }\
    } while(0)

/**
 * @brief Smart data Getters and Setters
 * 
 */
#define fSmartDataSetMinimum_(pSmartData_, pNewVal_)        ((sSmartDataCore*)(pSmartData_))->pVtbl->fpSetMinValue((sSmartDataCore*)(pSmartData_), (pNewVal_))
#define fSmartDataGetMinimum_(pSmartData_, pOutVal_)        ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetMinValue((sSmartDataCore*)(pSmartData_), (pOutVal_))
#define fSmartDataSetMaximum_(pSmartData_, pNewVal_)        ((sSmartDataCore*)(pSmartData_))->pVtbl->fpSetMaxValue((sSmartDataCore*)(pSmartData_), (pNewVal_))
#define fSmartDataGetMaximum_(pSmartData_, pOutVal_)        ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetMaxValue((sSmartDataCore*)(pSmartData_), (pOutVal_))
#define fSmartDataSetResolution_(pSmartData_, pNewVal_)     ((sSmartDataCore*)(pSmartData_))->pVtbl->fpSetResolutionValue((sSmartDataCore*)(pSmartData_), (pNewVal_))
#define fSmartDataGetResolution_(pSmartData_, pOutVal_)     ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetResolutionValue((sSmartDataCore*)(pSmartData_), (pOutVal_))
#define fSmartDataGetTimestamp_(pSmartData_, pOutVal_)      ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetTimestamp((sSmartDataCore*)(pSmartData_), (pOutVal_))
#define fSmartDataResetTimestamp_(pSmartData_)              ((sSmartDataCore*)(pSmartData_))->pVtbl->fpResetTimestamp((sSmartDataCore*)(pSmartData_))
#define fSmartDataGetValueSize_(pSmartData_, pOutSize_)     ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetValueSize((sSmartDataCore*)(pSmartData_), (pOutSize_))
#define fSmartDataGetSmartDataSize_(pSmartData_, pOutSize_) ((sSmartDataCore*)(pSmartData_))->pVtbl->fpGetSmartDataSize((sSmartDataCore*)(pSmartData_), (pOutSize_))

/* Exported types ----------------------------------------------------------- */
/**
 * @brief
 *
 */
typedef enum {

    eSMART_DATA_OK = 0,
    eSMART_DATA_ERROR_NULL_POINTER,
    eSMART_DATA_ERROR_DEFAULT_VALUE_OUT_OF_RANGE,
    eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE,
    eSMART_DATA_ERROR_NOT_APPLICABLE,
    eSMART_DATA_ERROR_INVALID_USER_NUMBER,
    eSMART_DATA_ERROR_DATA_TYPE_NOT_SUPPORTED,

} eSmartDataStatus;

/**
 * @brief 
 * 
 */
typedef enum {

    eSMART_DATA_TYPE_B8 = 0,
    eSMART_DATA_TYPE_U8,
    eSMART_DATA_TYPE_I8,
    eSMART_DATA_TYPE_U16,
    eSMART_DATA_TYPE_I16,
    eSMART_DATA_TYPE_U32,
    eSMART_DATA_TYPE_I32,
    eSMART_DATA_TYPE_U64,
    eSMART_DATA_TYPE_I64,
    eSMART_DATA_TYPE_F32,
    eSMART_DATA_TYPE_F64

} eSmartDataType;

/**
 * @brief 
 * 
 */
struct sSmartDataVtbl;

/**
 * @brief 
 * 
 */
typedef struct {

    eSmartDataType Type;

    size_t SmartDataSize;

    size_t ValueSize;

} sSmartDataTypeInfo;

/**
 * @brief 
 * 
 */
typedef struct {

    uint64_t TimestampUs;

    uint32_t UserReadFlags;

    sSmartDataTypeInfo TypeInfo;

    struct sSmartDataVtbl const *pVtbl;

} sSmartDataCore;

/**
 * @brief
 *
 */
struct sSmartDataVtbl {

    eSmartDataStatus(*fpRead)(sSmartDataCore * const me, void * pOutValue);
    eSmartDataStatus(*fpWrite)(sSmartDataCore * const me, void *pValue);
    eSmartDataStatus(*fpVerify)(sSmartDataCore * const me);

    eSmartDataStatus(*fpSetMinValue)(sSmartDataCore * const me, void * pNewValue);
    eSmartDataStatus(*fpGetMinValue)(sSmartDataCore * const me, void * pOutValue);
    eSmartDataStatus(*fpSetMaxValue)(sSmartDataCore * const me, void * pNewValue);
    eSmartDataStatus(*fpGetMaxValue)(sSmartDataCore * const me, void * pOutValue);
    eSmartDataStatus(*fpSetDefaultValue)(sSmartDataCore * const me, void * pNewValue);
    eSmartDataStatus(*fpGetDefaultValue)(sSmartDataCore * const me, void * pOutValue);
    eSmartDataStatus(*fpSetResolution)(sSmartDataCore * const me, void * pNewValue);
    eSmartDataStatus(*fpGetResolution)(sSmartDataCore * const me, void * pOutValue);

    eSmartDataStatus(*fpGetTimestamp)(sSmartDataCore * const me, uint32_t *pOutTsUs);
    eSmartDataStatus(*fpResetTimestamp)(sSmartDataCore * const me);

    eSmartDataStatus(*fpGetSmartDataSize)(sSmartDataCore * const me, size_t *pOutSize);
    eSmartDataStatus(*fpGetValueSize)(sSmartDataCore * const me, size_t *pOutSize);

};

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    bool_t Value;               /*!< Value of the smart data. */
    
    bool_t _defaultValue;       /*!< Default value of the smart data. */

} sSmartDataB8;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    uint8_t Value;              /*!< Value of the smart data. */
    
    uint8_t _min;               /*!< Minimum value in the range of the smart data. */

    uint8_t _max;               /*!< Maximum value in the range of the smart data. */

    uint8_t _defaultValue;      /*!< Default value of the smart data. */

    uint8_t _resolution;        /*!< Resolution of the smart data. */

} sSmartDataU8;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    int8_t Value;               /*!< Value of the smart data. */
    
    int8_t _min;                /*!< Minimum value in the range of the smart data. */

    int8_t _max;                /*!< Maximum value in the range of the smart data. */

    int8_t _defaultValue;       /*!< Default value of the smart data. */

    int8_t _resolution;         /*!< Resolution of the smart data. */

} sSmartDataI8;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    uint16_t Value;             /*!< Value of the smart data. */
    
    uint16_t _min;              /*!< Minimum value in the range of the smart data. */

    uint16_t _max;              /*!< Maximum value in the range of the smart data. */

    uint16_t _defaultValue;     /*!< Default value of the smart data. */

    uint16_t _resolution;       /*!< Resolution of the smart data. */

} sSmartDataU16;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    int16_t Value;              /*!< Value of the smart data. */
    
    int16_t _min;               /*!< Minimum value in the range of the smart data. */

    int16_t _max;               /*!< Maximum value in the range of the smart data. */

    int16_t _defaultValue;      /*!< Default value of the smart data. */

    int16_t _resolution;        /*!< Resolution of the smart data. */

} sSmartDataI16;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    uint32_t Value;             /*!< Value of the smart data. */
    
    uint32_t _min;              /*!< Minimum value in the range of the smart data. */

    uint32_t _max;              /*!< Maximum value in the range of the smart data. */

    uint32_t _defaultValue;     /*!< Default value of the smart data. */

    uint32_t _resolution;       /*!< Resolution of the smart data. */

} sSmartDataU32;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    int32_t Value;              /*!< Value of the smart data. */
    
    int32_t _min;               /*!< Minimum value in the range of the smart data. */

    int32_t _max;               /*!< Maximum value in the range of the smart data. */

    int32_t _defaultValue;      /*!< Default value of the smart data. */

    int32_t _resolution;        /*!< Resolution of the smart data. */

} sSmartDataI32;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    uint64_t Value;             /*!< Value of the smart data. */
    
    uint64_t _min;              /*!< Minimum value in the range of the smart data. */

    uint64_t _max;              /*!< Maximum value in the range of the smart data. */

    uint64_t _defaultValue;     /*!< Default value of the smart data. */

    uint64_t _resolution;       /*!< Resolution of the smart data. */

} sSmartDataU64;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    int64_t Value;              /*!< Value of the smart data. */
    
    int64_t _min;               /*!< Minimum value in the range of the smart data. */

    int64_t _max;               /*!< Maximum value in the range of the smart data. */

    int64_t _defaultValue;      /*!< Default value of the smart data. */

    int64_t _resolution;        /*!< Resolution of the smart data. */

} sSmartDataI64;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    float32_t Value;            /*!< Value of the smart data. */
    
    float32_t _min;             /*!< Minimum value in the range of the smart data. */

    float32_t _max;             /*!< Maximum value in the range of the smart data. */

    float32_t _defaultValue;    /*!< Default value of the smart data. */

    float32_t _resolution;      /*!< Resolution of the smart data. */

} sSmartDataF32;

/**
 * @brief
 *
 */
typedef struct {

    sSmartDataCore _core;       /*!< Smart data core info. This must be the first element in the smart data structures! */
    
    float64_t Value;            /*!< Value of the smart data. */
    
    float64_t _min;             /*!< Minimum value in the range of the smart data. */

    float64_t _max;             /*!< Maximum value in the range of the smart data. */

    float64_t _defaultValue;    /*!< Default value of the smart data. */

    float64_t _resolution;      /*!< Resolution of the smart data. */

} sSmartDataF64;

/* Exported functions ------------------------------------------------------- */
eSmartDataStatus fSmartData_B8_Ctor(sSmartDataB8 * const me, bool_t defaultVal);
eSmartDataStatus fSmartData_U8_Ctor(sSmartDataU8 * const me, uint8_t minVal, uint8_t maxVal, uint8_t defaultVal, uint8_t resolution);
eSmartDataStatus fSmartData_I8_Ctor(sSmartDataI8 * const me, int8_t minVal, int8_t maxVal, int8_t defaultVal, int8_t resolution);
eSmartDataStatus fSmartData_U16_Ctor(sSmartDataU16 * const me, uint16_t minVal, uint16_t maxVal, uint16_t defaultVal, uint16_t resolution);
eSmartDataStatus fSmartData_I16_Ctor(sSmartDataI16 * const me, int16_t minVal, int16_t maxVal, int16_t defaultVal, int16_t resolution);
eSmartDataStatus fSmartData_U32_Ctor(sSmartDataU32 * const me, uint32_t minVal, uint32_t maxVal, uint32_t defaultVal, uint32_t resolution);
eSmartDataStatus fSmartData_I32_Ctor(sSmartDataI32 * const me, int32_t minVal, int32_t maxVal, int32_t defaultVal, int32_t resolution);
eSmartDataStatus fSmartData_U64_Ctor(sSmartDataU64 * const me, uint64_t minVal, uint64_t maxVal, uint64_t defaultVal, uint64_t resolution);
eSmartDataStatus fSmartData_I64_Ctor(sSmartDataI64 * const me, int64_t minVal, int64_t maxVal, int64_t defaultVal, int64_t resolution);
eSmartDataStatus fSmartData_F32_Ctor(sSmartDataF32 * const me, float32_t minVal, float32_t maxVal, float32_t defaultVal, float32_t resolution);
eSmartDataStatus fSmartData_F64_Ctor(sSmartDataF64 * const me, float64_t minVal, float64_t maxVal, float64_t defaultVal, float64_t resolution);

/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* SMART_DATA_H */

/* === Copyright (c) 2026 FAS === EOF === */

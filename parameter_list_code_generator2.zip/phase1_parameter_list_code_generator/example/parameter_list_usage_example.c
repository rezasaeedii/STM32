/**
  ******************************************************************************
  * @file    parameter_list_usage_example.c
  * @brief   Short example of how the generated parameter list is used.
  *
  * This file is NOT generated and is NOT part of the firmware; it only shows
  * the four ways an application reaches a parameter. Delete it whenever you
  * do not need it any more.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  @verbatim

  @endverbatim
  */

/* Includes ----------------------------------------------------------------- */
#include "parameter_list_usage_example.h"

#include "cg_parameter_list.h"

/* Private defines ---------------------------------------------------------- */
#define EXAMPLE_USER_NUMBER  0U   /*!< This module's reader slot (0 .. 31). */

/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Way 1 - direct access to the generated object (fastest, no checks).
 *
 * @note  Writing 'Value' directly skips the allowed range check and does not
 *        update the timestamp. Use it only where speed really matters.
 *
 */
void fExample_DirectAccess(void) {

    float32_t altitude = Cg_SmartData_Altitude.Value;

    Cg_SmartData_Altitude.Value = altitude + 1.0f;
}

/**
 * @brief Way 2 - access through the smart-data API (range check + timestamp).
 *
 * @return eSmartDataStatus eSMART_DATA_OK, or the reason the write was refused.
 *
 */
eSmartDataStatus fExample_CheckedAccess(void) {

    float32_t value = 0.0f;
    float32_t newValue = 7.0f;
    eSmartDataStatus status = eSMART_DATA_OK;

    status = fSmartDataRead_(&Cg_SmartData_Altitude, &value);
    if (status != eSMART_DATA_OK) {
        return status;
    }

    /* Refused with eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE when the value is
       outside [Minimum, Maximum] of the Excel row. A row whose Minimum and
       Maximum are both 0 allows the whole range of its type, so a write to it
       is never refused for being out of range. */
    return fSmartDataWrite_(&Cg_SmartData_Altitude, &newValue);
}

/**
 * @brief Way 3 - access by index or by name through the descriptor table.
 *
 * @return uint8_t 0 when both look-ups succeeded.
 *
 */
uint8_t fExample_DescriptorAccess(void) {

    float32_t altitude = 0.0f;

    /* By index: ALTITUDE comes from cg_parameter_list_defines.h. */
    const sParameterDescriptor *pByIndex = fParameterList_GetByIndex(ALTITUDE);

    /* By name: useful for a command that arrives as text. */
    const sParameterDescriptor *pByName = fParameterList_GetByName("Altitude");

    if ((pByIndex == NULL) || (pByName == NULL)) {
        return 1U;
    }

    /* pSmartData is a void*; the read/write macros cast it internally. */
    if (fSmartDataRead_(pByIndex->pSmartData, &altitude) != eSMART_DATA_OK) {
        return 1U;
    }

    /* The tags are only carried by the descriptor - their meaning is decided
       here, in the application layer, not by the code generator. */
    if (pByName->TagLoggable.Value != 0U) {
        fExample_SendToLog(pByName->TagLogId.Value, &altitude,
                           pByName->TagLoggable.MemoryOffset);
    }

    return 0U;
}

/**
 * @brief Way 4 - an array parameter is 'ArraySize' smart-data objects in a row.
 *
 */
void fExample_ArrayAccess(void) {

    uint16_t index = 0U;
    float64_t velocity = 0.0;

    for (index = 0U; index < VEL_DRONE_ARRAY_SIZE; index++) {
        (void)fSmartDataRead_(&Cg_SmartData_VelDrone[index], &velocity);
    }

    /* The same array reached through the descriptor table. */
    {
        const sParameterDescriptor *pDescriptor = &ParameterList[VEL_DRONE];
        sSmartDataF64 *pElements = (sSmartDataF64 *)pDescriptor->pSmartData;

        for (index = 0U; index < pDescriptor->ArraySize; index++) {
            (void)fSmartDataRead_(&pElements[index], &velocity);
        }
    }
}

/**
 * @brief Detecting a value this module has not read yet.
 *
 * @return bool_t TRUE when a fresh value was consumed.
 *
 */
bool_t fExample_ReadIfNew(void) {

    float32_t altitude = 0.0f;
    eSmartDataStatus status = eSMART_DATA_OK;

    if (fSmartDataHasUserReadOnce_(&Cg_SmartData_Altitude, EXAMPLE_USER_NUMBER)) {
        return FALSE;
    }

    fSmartDataUserRead_(&Cg_SmartData_Altitude, EXAMPLE_USER_NUMBER, &altitude, status);

    return (bool_t)(status == eSMART_DATA_OK);
}

/**
 * @brief Called by the generated fParameterList_Init() once everything is up.
 *
 * @note  Defined here WITHOUT the weak specifier, so it overrides the generated
 *        default implementation.
 *
 * @return uint8_t 0 on success.
 *
 */
uint8_t fParameterList_InitCompletedCallback(void) {

    /* Good place to restore the reset-proof parameters from their storage,
       using PARAMETER_LIST_OFFSET_RESET_PROOF_* from the defines header. */
    return 0U;
}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

"""Entry point of the Excel template maker.

Usage (from the ``tools`` folder)::

    python run_make_template.py                  # a new, blank workbook
    python run_make_template.py --restyle FILE   # refresh the colours and the
                                                 # drop-downs of an existing one

Every entry point of the tool is a ``run_*.py`` next to this file, so there is
one place to look for "how do I start it": ``run_generate.py``,
``run_make_template.py``, ``run_tests.py``.  Each has a ``.bat`` beside it for
double-clicking on Windows.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running the script directly from any working directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from pl_excel.make_template import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())

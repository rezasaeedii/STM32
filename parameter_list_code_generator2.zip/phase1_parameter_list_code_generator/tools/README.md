# ابزار تولید کد لیست پارامترها — فاز ۱ (اکسل)

لیست پارامترها را در `parameter_list_template.xlsx` می‌نویسید و این ابزار از رویش
کدهای `.c` و `.h` را تولید می‌کند.

روی ویندوز کافی است دوبار کلیک کنید:

| فایل | کار |
|------|-----|
| `run_setup.bat` | فقط بار اول — `openpyxl` را نصب می‌کند |
| `run_generate.bat` | **تولید کد** از روی فایل اکسل |
| `run_make_template.bat` | ساخت یک فایل اکسل خام |
| `run_tests.bat` | اجرای تست‌های خود ابزار |

یا از خط فرمان، برای حالت‌های پیشرفته‌تر:

```
cd tools
python run_generate.py --help
```

کد در `cg_parameter_list/` نوشته می‌شود و تنظیمات در `codegen_config.json` است.

---

**همه‌ی توضیحات در راهنماها است** (فارسی، در پوشه‌ی پروژه):

* `parameter_list_user_manual_fa.pdf` — کار با ابزار
* `parameter_list_developer_manual_fa.pdf` — تغییر دادن خود ابزار

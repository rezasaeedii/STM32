"""End-to-end test: generate the code and compile it with a real C/C++ compiler.

The test
  1. runs the generator into a temporary folder,
  2. compiles the generated files together with ``smart_data.c`` as **C99** and
     compiles the generated headers as **C++**,
  3. links and runs a small program that calls ``fParameterList_Init()``,
     walks the descriptor table and exercises the usage example.

Run it with::

    python tests/run_compile_test.py

It needs ``gcc`` and ``g++`` on the PATH; on Windows a MinGW or WSL toolchain
works.  The test never touches the files under ``cg_parameter_list`` of the
project: everything is generated into a temporary folder.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from pl_excel.cli import main as generator_main  # noqa: E402
from common.pl_codegen.config import load_jsonc  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_validation_test import DEFINES, PARAMETER_HEADERS, valid_row  # noqa: E402

#: The parameters this test and 'example/parameter_list_usage_example.c' need.
#:
#: The test builds its OWN workbook instead of reading the project's
#: 'parameter_list_template.xlsx'.  That template belongs to the user: the
#: moment somebody disables a row or renames a parameter, a test that read it
#: would fail while nothing at all is wrong with the tool.  A fixture keeps this
#: test about the *code generator*.
FIXTURE_ROWS = [
    valid_row(Name="Altitude", **{"GS Name": "Altitude"}, Group="MONITORING",
              DataType="float32_t", DefaultValue=0, Minimum=-500, Maximum=10000,
              Resolution=0.01, Unit="m", LogID=100),
    valid_row(Name="VelDrone", **{"GS Name": "VelDrone", "Array Size": 6},
              Group="MONITORING", DataType="float64_t", DefaultValue=2,
              Minimum=-10, Maximum=10, Resolution=0.01, Unit="m/s", LogID=200),
    # Minimum and Maximum both 0 = the whole range of the type.  It is also not
    # loggable while a log id is still written in its cell, so the generated
    # table must hold 0 for it.
    valid_row(Name="FullRange", **{"GS Name": "Full range"}, Group="SETTING",
              DataType="int32_t", DefaultValue=500, Minimum=0, Maximum=0,
              Resolution=1, Unit=None, **{"Tag Loggable": False}, LogID=400),
    # a real range, so the constructor must refuse a value outside it
    valid_row(Name="Mode", **{"GS Name": "Mode"}, Group="COMMAND",
              DataType="uint8_t", DefaultValue=0, Minimum=0, Maximum=5,
              Resolution=1, Unit=None, LogID=300),
]


def build_fixture_workbook(path: Path) -> Path:
    """Write the workbook this test generates from."""
    from openpyxl import Workbook

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "ParameterList"
    sheet.append(PARAMETER_HEADERS)
    for row in FIXTURE_ROWS:
        sheet.append([row.get(header) for header in PARAMETER_HEADERS])

    defines = workbook.create_sheet("Defines")
    columns = list(DEFINES)
    defines.append(columns)
    for index in range(max(len(values) for values in DEFINES.values())):
        defines.append([DEFINES[column][index] if index < len(DEFINES[column]) else None
                        for column in columns])
    workbook.save(path)
    return path

C_COMPILER = "gcc"
CXX_COMPILER = "g++"

def _run(command: List[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def have_compiler(name: str) -> bool:
    return shutil.which(name) is not None


def write_config(work_dir: Path, workbook: Path) -> Path:
    """Write a configuration that generates *workbook* into *work_dir*."""
    config = {
        "inputs": {
            "excel_files": [str(workbook)],
            "parameter_sheet": "ParameterList",
            "defines_sheet": "Defines",
        },
        "output": {
            "code_directory": str(work_dir / "generated"),
            "xml_file": str(work_dir / "parameter_list.xml"),
            "file_prefix": "cg_",
            "base_name": "parameter_list",
        },
        "style": {"snippet_file": str(PROJECT_DIR / "c.json"), "company": "FAS",
                  "indent": "    "},
        "codegen": {"emit_description": True, "emit_unit": True,
                    "emit_generation_info": True, "emit_timestamp": False},
        "validation": {"treat_warnings_as_errors": False},
    }
    path = work_dir / "codegen_config.json"
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return path


# smart_data.c includes the project's chrono.h. When the firmware's real
# chrono module is not reachable from here, this stub stands in for it; the
# stub folder is searched LAST, so a real chrono.h always wins.
_CHRONO_STUB_H = """
#ifndef CHRONO_H
#define CHRONO_H
#include <stdint.h>
static uint64_t fChrono_GetContinuousTickUs(void) { return 0U; }
#endif
"""

_LOG_STUB_C = """
#include "parameter_list_usage_example.h"
void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset) {
    (void)logId; (void)pValue; (void)memoryOffset;
}
"""


def compile_c(work_dir: Path, includes: List[str]) -> bool:
    (work_dir / "log_stub.c").write_text(_LOG_STUB_C, encoding="utf-8")
    sources = [
        PROJECT_DIR / "smart_data" / "smart_data.c",
        work_dir / "generated" / "cg_smart_data.c",
        work_dir / "generated" / "cg_parameter_list.c",
        PROJECT_DIR / "example" / "parameter_list_usage_example.c",
        work_dir / "log_stub.c",
        work_dir / "main.c",
    ]
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Wpedantic",
               *includes, *[str(path) for path in sources],
               "-o", str(work_dir / "parameter_list_test")]
    result = _run(command)
    if result.returncode != 0:
        print("C compilation FAILED:\n" + result.stderr)
        return False
    if result.stderr.strip():
        print("C compiler warnings:\n" + result.stderr)
    return True


def compile_cxx(work_dir: Path, includes: List[str]) -> bool:
    """The generated headers must be usable from C++ as well."""
    source = work_dir / "cxx_include_test.cpp"
    source.write_text(
        '#include "cg_parameter_list.h"\n'
        '#include "cg_smart_data.h"\n'
        '#include "cg_parameter_list_defines.h"\n'
        '#include "cg_parameter_list_table.h"\n'
        "int main() { return (int)ParameterList[0].ArraySize - 1; }\n",
        encoding="utf-8")
    command = [CXX_COMPILER, "-std=c++11", "-Wall", "-Wextra", "-c",
               *includes, str(source), "-o", str(work_dir / "cxx_include_test.o")]
    result = _run(command)
    if result.returncode != 0:
        print("C++ compilation FAILED:\n" + result.stderr)
        return False
    return True


_MAIN_C = """
#include <stdio.h>
#include <string.h>
#include "cg_parameter_list.h"
#include "parameter_list_usage_example.h"

int main(void) {
    uint16_t index = 0U;
    uint8_t result = fParameterList_Init();
    if (result != 0U) {
        printf("fParameterList_Init failed with %u\\n", (unsigned)result);
        return 1;
    }
    if (fParameterList_GetQuantity() != PARAMETER_LIST_QTY) {
        printf("wrong quantity\\n");
        return 1;
    }
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL || pDescriptor->pName == NULL) {
            printf("descriptor %u is broken\\n", (unsigned)index);
            return 1;
        }
        if (fParameterList_GetByName(pDescriptor->pName) != pDescriptor) {
            printf("lookup by name failed for %s\\n", pDescriptor->pName);
            return 1;
        }
        if (pDescriptor->pSmartData == NULL) {
            printf("no smart data for %s\\n", pDescriptor->pName);
            return 1;
        }
    }
    if (fParameterList_GetByIndex(PARAMETER_LIST_QTY) != NULL) {
        printf("out of range index was accepted\\n");
        return 1;
    }
    /* The usage example must work as well. */
    fExample_DirectAccess();
    if (fExample_CheckedAccess() != eSMART_DATA_OK) {
        printf("fExample_CheckedAccess failed\\n");
        return 1;
    }
    if (fExample_DescriptorAccess() != 0U) {
        printf("fExample_DescriptorAccess failed\\n");
        return 1;
    }
    fExample_ArrayAccess();
    if (fExample_ReadIfNew() != TRUE || fExample_ReadIfNew() != FALSE) {
        printf("fExample_ReadIfNew failed\\n");
        return 1;
    }

    /* 'FullRange' has Minimum = Maximum = 0 in the sheet, which means "the
       whole range of int32_t". Its default is 500, so fParameterList_Init()
       above already proves the constructor accepted it - and a write at either
       end of the type must be accepted too. */
    {
        int32_t extreme = 2147483647L;
        if (fSmartDataWrite_(&Cg_SmartData_FullRange, &extreme) != eSMART_DATA_OK) {
            printf("the full range is not really full: writing INT32_MAX failed\\n");
            return 1;
        }
        extreme = (-2147483647L - 1);
        if (fSmartDataWrite_(&Cg_SmartData_FullRange, &extreme) != eSMART_DATA_OK) {
            printf("the full range is not really full: writing INT32_MIN failed\\n");
            return 1;
        }
    }

    /* A row that does have a range must still refuse a value outside it. */
    {
        uint8_t outside = 200U;
        if (fSmartDataWrite_(&Cg_SmartData_Mode, &outside) == eSMART_DATA_OK) {
            printf("a value outside [0, 5] was accepted for 'Mode'\\n");
            return 1;
        }
    }

    /* 'FullRange' is not loggable, so the log id left in its cell means
       nothing and the table must hold 0. */
    if (ParameterList[FULL_RANGE].TagLogId.Value != 0U) {
        printf("the log id of a non-loggable parameter reached the table\\n");
        return 1;
    }

    /* The generated size getters must agree with the offset macros. */
    if (fParameterList_GetResetProofSize() != PARAMETER_LIST_SIZE_RESET_PROOF) {
        printf("fParameterList_GetResetProofSize() disagrees with the macro\\n");
        return 1;
    }
    if (fParameterList_GetLoggableSize() != PARAMETER_LIST_SIZE_LOGGABLE) {
        printf("fParameterList_GetLoggableSize() disagrees with the macro\\n");
        return 1;
    }

    /* pUnit and pDescription are strings, never NULL, so they can be printed
       without a guard. */
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor->pUnit == NULL || pDescriptor->pDescription == NULL) {
            printf("parameter %u has a NULL unit or description\\n", (unsigned)index);
            return 1;
        }
    }

    /* Writing a new value must make every reader "has not seen it yet" again,
       otherwise nobody is ever told that the value changed. */
    {
        uint8_t mode = 3U;
        uint8_t seen = 0U;
        eSmartDataStatus status;
        const sParameterDescriptor *pMode = fParameterList_GetByName("Mode");

        fSmartDataUserRead_((sSmartDataU8 *)pMode->pSmartData, 3U, &seen, status);
        if (status != eSMART_DATA_OK) {
            printf("reading 'Mode' as user 3 failed\\n");
            return 1;
        }
        if (!fSmartDataHasUserReadOnce_((sSmartDataU8 *)pMode->pSmartData, 3U)) {
            printf("the read flag of user 3 was not set by a read\\n");
            return 1;
        }

        if (fSmartDataWrite_(pMode->pSmartData, &mode) != eSMART_DATA_OK) {
            printf("writing a valid value to 'Mode' failed\\n");
            return 1;
        }
        if (fSmartDataHasUserReadOnce_((sSmartDataU8 *)pMode->pSmartData, 3U)) {
            printf("a new value was written but user 3 is still marked as up to date\\n");
            return 1;
        }

        /* ... but a write that is refused changes nothing, so the flags must
           survive it. */
        fSmartDataUserRead_((sSmartDataU8 *)pMode->pSmartData, 3U, &seen, status);
        mode = 200U;
        if (fSmartDataWrite_(pMode->pSmartData, &mode) == eSMART_DATA_OK) {
            printf("a value outside [0, 5] was accepted for 'Mode'\\n");
            return 1;
        }
        if (!fSmartDataHasUserReadOnce_((sSmartDataU8 *)pMode->pSmartData, 3U)) {
            printf("a refused write cleared the read flags\\n");
            return 1;
        }
    }

    printf("OK: %u parameters initialised and verified, usage example runs,\\n"
           "          full range accepted, real range enforced, unused log id dropped,\\n"
           "          a write resets the reader flags and a refused write does not\\n",
           (unsigned)PARAMETER_LIST_QTY);
    return 0;
}
"""


def main() -> int:
    for compiler in (C_COMPILER, CXX_COMPILER):
        if not have_compiler(compiler):
            print(f"SKIPPED: '{compiler}' was not found on the PATH.")
            return 0

    with tempfile.TemporaryDirectory(prefix="pl_codegen_test_") as raw_dir:
        work_dir = Path(raw_dir)

        print("1/5 generating the code ...")
        workbook = build_fixture_workbook(work_dir / "fixture.xlsx")
        config_path = write_config(work_dir, workbook)
        exit_code = generator_main(["--config", str(config_path), "--quiet"])
        if exit_code != 0:
            print(f"FAILED: the generator returned {exit_code}.")
            return 1

        (work_dir / "main.c").write_text(_MAIN_C, encoding="utf-8")
        stub_dir = work_dir / "stubs"
        stub_dir.mkdir(exist_ok=True)
        (stub_dir / "chrono.h").write_text(_CHRONO_STUB_H, encoding="utf-8")
        includes = [f"-I{PROJECT_DIR}",
                    f"-I{PROJECT_DIR / 'example'}",
                    f"-I{PROJECT_DIR / 'smart_data'}",
                    f"-I{PROJECT_DIR / 'parameter_descriptor'}",
                    f"-I{work_dir / 'generated'}",
                    f"-I{stub_dir}"]

        print("2/5 compiling as C99 ...")
        if not compile_c(work_dir, includes):
            return 1

        print("3/5 compiling the headers as C++ ...")
        if not compile_cxx(work_dir, includes):
            return 1

        print("4/5 running the generated parameter list ...")
        result = _run([str(work_dir / "parameter_list_test")])
        print("      " + result.stdout.strip())
        if result.returncode != 0:
            print("FAILED: the test program returned a non-zero exit code.")
            return 1

        print("5/5 compiling the code of the project's own workbook ...")
        if not check_project_workbook(work_dir, stub_dir):
            return 1

    print("\nAll checks passed.")
    return 0


def project_config(work_dir: Path) -> Optional[Path]:
    """The project's OWN codegen_config.json, redirected to a temporary folder.

    Everything the user configured - the indent, the prefixes, the extra
    includes, the style file - is kept exactly as it is; only the two output
    paths are changed so the test never writes into the real cg_ folders.

    This is the whole point of this stage.  A test that builds its own
    configuration proves the generator works with the *test's* settings and says
    nothing at all about the settings the user actually ships, so a broken
    'indent' or a misspelled prefix in codegen_config.json would sail through a
    completely green test run.
    """
    source = TOOLS_DIR / "codegen_config.json"
    if not source.is_file():
        return None

    data = load_jsonc(source)
    data.setdefault("output", {})
    data["output"]["code_directory"] = str(work_dir / "generated")
    data["output"]["xml_file"] = str(work_dir / "parameter_list.xml")

    # paths inside the file are relative to the file itself, so any that are
    # still relative have to be made absolute before the copy moves elsewhere
    root = source.parent
    def absolute(value: str) -> str:
        path = Path(str(value)).expanduser()
        return str(path if path.is_absolute() else (root / path).resolve())

    inputs = data.get("inputs") or {}
    if inputs.get("excel_files"):
        inputs["excel_files"] = [absolute(entry) for entry in inputs["excel_files"]]
        data["inputs"] = inputs
    style = data.get("style") or {}
    if style.get("snippet_file"):
        style["snippet_file"] = absolute(style["snippet_file"])
        data["style"] = style

    path = work_dir / "project_codegen_config.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def check_project_workbook(work_dir: Path, stub_dir: Path) -> bool:
    """Generate with the project's real configuration and compile the result.

    Whatever parameters the project's workbook happens to hold right now, and
    whatever settings its configuration file holds, the code that comes out has
    to compile.  Deliberately nothing is asserted about the workbook's contents:
    the rows belong to whoever maintains the sheet, and they are free to add,
    rename or disable any of them.
    """
    project_dir = work_dir / "project"
    project_dir.mkdir(exist_ok=True)
    config_path = project_config(project_dir)
    if config_path is None:
        print("      skipped: the project has no tools/codegen_config.json")
        return True

    if generator_main(["--config", str(config_path), "--quiet"]) != 0:
        print("FAILED: the project's own configuration does not generate cleanly.")
        return False

    sources = sorted((project_dir / "generated").glob("*.c"))
    objects = [str(path) for path in sources]
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Werror", "-c"] + objects + [
        f"-I{PROJECT_DIR}", f"-I{PROJECT_DIR / 'smart_data'}",
        f"-I{PROJECT_DIR / 'parameter_descriptor'}",
        f"-I{project_dir / 'generated'}", f"-I{stub_dir}"]
    result = _run(command, cwd=project_dir)
    if result.returncode != 0:
        print("FAILED: the code of the project workbook does not compile:")
        print(result.stderr[:2000])
        return False
    print(f"      OK: {len(sources)} generated source file(s) compile")
    return True


if __name__ == "__main__":
    raise SystemExit(main())

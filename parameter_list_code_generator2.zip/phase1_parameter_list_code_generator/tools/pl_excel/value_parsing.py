"""Conversion of raw Excel cell values into typed Python values.

Every function returns ``(value, error_message)``.  A non-empty error message
means the cell could not be interpreted; the caller turns it into a diagnostic.
"""

from __future__ import annotations

from typing import Any, Optional, Tuple

_TRUE_WORDS = {"true", "1", "yes", "y", "on", "enable", "enabled"}
_FALSE_WORDS = {"false", "0", "no", "n", "off", "disable", "disabled"}


def parse_bool(value: Any, *, default: Optional[bool] = None) -> Tuple[Optional[bool], str]:
    """Interpret a cell as a boolean."""
    if value is None:
        return default, ""
    if isinstance(value, bool):
        return value, ""
    if isinstance(value, (int, float)) and float(value) in (0.0, 1.0):
        return bool(value), ""
    text = str(value).strip().lower()
    if text in _TRUE_WORDS:
        return True, ""
    if text in _FALSE_WORDS:
        return False, ""
    return default, f"'{value}' is not a valid boolean (use TRUE or FALSE)."


def parse_int(value: Any, *, default: Optional[int] = None) -> Tuple[Optional[int], str]:
    """Interpret a cell as an integer."""
    if value is None:
        return default, ""
    if isinstance(value, bool):
        return int(value), ""
    if isinstance(value, int):
        return value, ""
    if isinstance(value, float):
        if value.is_integer():
            return int(value), ""
        return default, f"'{value}' is not an integer."
    text = str(value).strip()
    if not text:
        return default, ""
    try:
        return int(text, 0), ""
    except ValueError:
        try:
            number = float(text)
        except ValueError:
            return default, f"'{value}' is not a valid integer."
        if number.is_integer():
            return int(number), ""
        return default, f"'{value}' is not an integer."


def parse_number(value: Any) -> Tuple[Optional[float], str]:
    """Interpret a cell as a number (int or float)."""
    if value is None:
        return None, ""
    if isinstance(value, bool):
        return float(int(value)), ""
    if isinstance(value, (int, float)):
        return float(value), ""
    text = str(value).strip()
    if not text:
        return None, ""
    try:
        return float(int(text, 0)), ""
    except ValueError:
        pass
    try:
        return float(text), ""
    except ValueError:
        return None, f"'{value}' is not a valid number."


def parse_numeric_for_type(value: Any, is_float: bool, is_bool: bool):
    """Interpret a cell as the numeric value of a parameter of the given type."""
    if is_bool:
        parsed_bool, error = parse_bool(value)
        return parsed_bool, error
    if is_float:
        return parse_number(value)
    return parse_int(value)


def parse_text(value: Any) -> Optional[str]:
    """Interpret a cell as free text."""
    if value is None:
        return None
    text = str(value).strip()
    return text if text else None


def parse_identifier(value: Any) -> Optional[str]:
    """Interpret a cell as a C identifier (kept verbatim, validated later)."""
    return parse_text(value)

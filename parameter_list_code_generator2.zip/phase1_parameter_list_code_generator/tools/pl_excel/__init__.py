"""Phase 1's front end: the Excel workbooks.

The shared core in ``common/pl_codegen`` reads exactly one thing, the XML
model.  This package is what turns a set of ``.xlsx`` workbooks into that
model, and it is the only part of phase 1 that knows Excel exists.

  * :mod:`workbook_reader`  - the only module that imports ``openpyxl``
  * :mod:`column_schema`    - sheet heading  ->  canonical column name
  * :mod:`value_parsing`    - one cell       ->  a Python value
  * :mod:`excel_to_model`   - the workbooks  ->  a ``ParameterList``
  * :mod:`make_template`    - builds/repairs the blank workbook itself

Phase 2 has no counterpart to this folder: it is the editor instead.
"""

from .excel_to_model import build_model, read_defines_sheet

__all__ = ["build_model", "read_defines_sheet"]

"""Command line interface of phase 1: the Excel workbooks are the input.

The shared core in ``common/pl_codegen`` only ever reads the XML model, so this
module is the piece that puts the Excel stage in front of it:

    Excel workbooks  ->  model  ->  validation  ->  XML  ->  C files
    \\_______________ this module ______________/   \\_ the shared core _/

Keeping the two apart is what lets phase 2 drop Excel entirely without touching
a single line of the generator, and what lets both phases produce byte-for-byte
identical C from the same model.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Optional, Sequence

from common.pl_codegen import __tool_name__, __version__
from common.pl_codegen.config import Config
from common.pl_codegen.errors import CodeGeneratorError, DiagnosticCollector, Severity
from common.pl_codegen.layout.drift import previous_build
from common.pl_codegen.logging_utils import banner, get_logger, setup_logging
from common.pl_codegen.pipeline import Pipeline, PipelineResult, render_diagnostics
from common.pl_codegen.validation.rules import ALL_RULES
from common.pl_codegen.validation.validator import Validator
from common.pl_codegen.xml_model.xml_writer import write_xml

from .excel_to_model import build_model

DEFAULT_CONFIG = "codegen_config.json"

#: The 'tools' folder, where the configuration file lives next to run_generate.py.
TOOLS_DIR = Path(__file__).resolve().parent.parent

EXIT_OK = 0
EXIT_VALIDATION_FAILED = 1
EXIT_TOOL_ERROR = 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_generate.py",
        description="Generates the parameter-list C code from one or more Excel workbooks.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python run_generate.py                       # full run with the default config\n"
            "  python run_generate.py --only-xml            # only refresh the XML model\n"
            "  python run_generate.py --from-xml model.xml  # generate code from an existing XML\n"
            "  python run_generate.py --check               # validate the Excel files only\n"))

    parser.add_argument("-c", "--config", type=Path, default=None,
                        help=f"configuration file (default: the {DEFAULT_CONFIG} of the "
                             f"current folder, otherwise the one next to run_generate.py)")
    parser.add_argument("--only-xml", action="store_true",
                        help="stop after writing the intermediate XML model")
    parser.add_argument("--from-xml", type=Path, metavar="FILE",
                        help="skip the Excel stage and generate code from FILE")
    parser.add_argument("--check", action="store_true",
                        help="validate the input only; write no file at all")
    parser.add_argument("--list-rules", action="store_true",
                        help="print every validation rule and exit")
    parser.add_argument("-W", "--warnings-as-errors", action="store_true",
                        help="treat warnings as errors")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="also show informational diagnostics")
    parser.add_argument("-q", "--quiet", action="store_true", help="only show problems")
    parser.add_argument("--version", action="version",
                        version=f"{__tool_name__} {__version__}")
    return parser


def resolve_config_path(given: Optional[Path]) -> Path:
    """Where to read the configuration from.

    ``run_generate.py`` is meant to work from any working directory, so the
    default cannot simply be a relative name.  A file in the current folder
    still wins, which is what someone experimenting with a second configuration
    expects.
    """
    if given is not None:
        return given
    local = Path(DEFAULT_CONFIG)
    if local.is_file():
        return local
    return TOOLS_DIR / DEFAULT_CONFIG


class ExcelPipeline:
    """The Excel stage, plus the shared core for everything after it."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._logger = get_logger()
        self._core = Pipeline(config)

    def read_excel(self, diagnostics: DiagnosticCollector):
        """Read every configured workbook and merge them into one model."""
        self._logger.info(banner("Stage 1/2 - reading the Excel input"))
        for path in self._config.inputs.excel_files:
            self._logger.info("  reading %s", path)
        model = build_model(self._config, diagnostics)
        self._logger.info("  %d parameter row(s) found (%d enabled)",
                          len(model), len(model.flatten()))
        return model

    def run(self, *, only_xml: bool = False,
            from_xml: Optional[Path] = None) -> PipelineResult:
        diagnostics = DiagnosticCollector()

        if from_xml is not None:
            # the model was written by someone else; check it in full
            return self._core.run(from_xml)

        model = self.read_excel(diagnostics)
        # The shared core validates in generate(), so validating here as well
        # would report every problem twice.  The XML is only written once the
        # model is known to be good, so a failed run never leaves a stale model
        # behind - hence the explicit check before writing.
        if not Validator(self._config).validate(model, DiagnosticCollector()):
            Validator(self._config).validate(model, diagnostics)
            return PipelineResult(False, diagnostics)

        # The copy of the previous build has to be read BEFORE this run
        # overwrites it, or the memory layout would be compared with itself.
        previous = previous_build(self._config.output.xml_file)

        xml_path = write_xml(model, self._config.output.xml_file,
                             emit_timestamp=self._config.codegen.emit_timestamp)
        self._logger.info("  XML model written to %s", xml_path)
        if only_xml:
            return PipelineResult(True, diagnostics, xml_path,
                                  parameter_count=len(model.flatten()))

        # Stage 1 has just validated this very model, so the core generates from
        # it directly.  Reading the XML back and validating it again would
        # report every problem twice.
        self._logger.info(banner("Stage 2/2 - generating the C code"))
        result = self._core.generate(model, diagnostics, previous)
        # the core reports the model file it would have read; phase 1 wrote its
        # own one a moment ago, and that is the one the user cares about
        result.model_file = xml_path
        return result

    def check(self) -> PipelineResult:
        """Validate the Excel input and write nothing at all."""
        diagnostics = DiagnosticCollector()
        model = self.read_excel(diagnostics)
        ok = Validator(self._config).validate(model, diagnostics)
        return PipelineResult(ok, diagnostics, parameter_count=len(model.flatten()))


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_parser().parse_args(argv)
    logger = setup_logging(verbose=arguments.verbose, quiet=arguments.quiet)

    if arguments.list_rules:
        _print_rules()
        return EXIT_OK

    try:
        config = Config.load(resolve_config_path(arguments.config))
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if arguments.warnings_as_errors:
        config.validation.treat_warnings_as_errors = True

    logger.info("%s v%s", __tool_name__, __version__)
    logger.info("configuration: %s", config.path)

    try:
        pipeline = ExcelPipeline(config)
        if arguments.check:
            result = pipeline.check()
        else:
            result = pipeline.run(only_xml=arguments.only_xml,
                                  from_xml=arguments.from_xml)
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if not arguments.quiet or not result.success:
        _print_summary(result, arguments.verbose)
    return EXIT_OK if result.success else EXIT_VALIDATION_FAILED


def _print_rules() -> None:
    print(f"{len(ALL_RULES)} validation rule(s):\n")
    for rule in ALL_RULES:
        print(f"  {rule.rule_id:<16} {rule.description}")


def _print_drift(drift) -> None:
    """Say, loudly, when this run moved something a board may already store.

    It is printed before the file list, because by the time somebody has read
    "7 files written" they have stopped reading.
    """
    if drift is None or not drift.report():
        return

    rule = "=" * 78
    print()
    print(rule)
    if drift.breaks_stored_data:
        print("  WARNING - THE MEMORY LAYOUT CHANGED SINCE THE LAST BUILD")
    else:
        print("  The parameter list changed since the last build")
    print(rule)
    for line in drift.report():
        print(line)
    print(rule)


def _print_summary(result: PipelineResult, verbose: bool) -> None:
    print(banner("Diagnostics"))
    print(render_diagnostics(result.diagnostics, verbose) or "No problems found.")
    print()
    print(result.diagnostics.summary())

    if not result.success:
        print("\nCode generation was aborted because the input contains errors.")
        return

    _print_drift(result.drift)
    if result.generated_files:
        print(f"\nGenerated {len(result.generated_files)} file(s) "
              f"for {result.parameter_count} parameter(s):")
        for path in result.generated_files:
            print(f"  {path}")
    if result.model_file:
        print(f"  {result.model_file}")
    print("\nDone.")

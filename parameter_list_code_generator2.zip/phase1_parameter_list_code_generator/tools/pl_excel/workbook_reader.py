"""Low-level Excel access: turns a worksheet into header-keyed rows.

This module knows about *openpyxl*; nothing else in the tool does.
"""

from __future__ import annotations

import contextlib
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from common.pl_codegen.errors import CodeGeneratorError, DiagnosticCollector, SourceLocation
from .column_schema import canonical_column

try:  # pragma: no cover - import guard
    from openpyxl import load_workbook
except ImportError as exc:  # pragma: no cover
    raise CodeGeneratorError(
        "The 'openpyxl' package is required.\n"
        "Run 'python setup_environment.py' in the tools folder to install the dependencies."
    ) from exc


@contextlib.contextmanager
def quiet_openpyxl():
    r"""Silence the warnings openpyxl prints about Excel features it drops.

    A workbook made by this project has drop-down lists and conditional
    formatting in it, and openpyxl announces both with a ``UserWarning`` that
    names a file deep inside site-packages::

        ...\openpyxl\worksheet\_reader.py:329: UserWarning: Data Validation
        extension is not supported and will be removed
          warn(msg)

    It looks like a serious problem and is not one: the warning is about what
    openpyxl would drop *if it saved the file*, and this tool only ever reads.
    Printing it hides the diagnostics that do matter, so it is suppressed.

    ``read_only=True`` makes openpyxl parse a worksheet lazily - during
    ``iter_rows()``, not during ``load_workbook()`` - so wrapping only the
    ``load_workbook`` call catches nothing.  Every access to the workbook has to
    happen inside this context manager.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        yield


@dataclass
class SheetRow:
    """One data row of a worksheet, keyed by canonical column name."""

    row_number: int
    values: Dict[str, Any] = field(default_factory=dict)

    def get(self, column: str) -> Any:
        return self.values.get(column)

    def is_empty(self) -> bool:
        return all(value is None or str(value).strip() == "" for value in self.values.values())


@dataclass
class SheetData:
    """A worksheet reduced to ``headers`` + ``rows``."""

    file: Path
    sheet_name: str
    headers: Dict[int, str] = field(default_factory=dict)   # column index -> canonical name
    raw_headers: Dict[int, str] = field(default_factory=dict)
    rows: List[SheetRow] = field(default_factory=list)

    def location(self, row: Optional[int] = None, column: Optional[str] = None) -> SourceLocation:
        return SourceLocation(file=str(self.file), sheet=self.sheet_name, row=row, column=column)

    def has_column(self, column: str) -> bool:
        return column in self.headers.values()


class WorkbookReader:
    """Reads the sheets of one workbook."""

    def __init__(self, path: Path, diagnostics: DiagnosticCollector) -> None:
        self._path = path
        self._diagnostics = diagnostics
        try:
            with quiet_openpyxl():
                self._workbook = load_workbook(path, data_only=True, read_only=True)
        except Exception as exc:  # noqa: BLE001 - openpyxl raises many types
            raise CodeGeneratorError(f"Cannot open workbook '{path}': {exc}") from exc
        #: second view of the same file, holding the formulas instead of their
        #: results; loaded only when a cell is actually found empty
        self._formula_workbook: Any = None

    @property
    def sheet_names(self) -> List[str]:
        return list(self._workbook.sheetnames)

    def close(self) -> None:
        for workbook in (self._workbook, self._formula_workbook):
            if workbook is None:
                continue
            try:
                workbook.close()
            except Exception:  # noqa: BLE001 - best effort
                pass

    # -- formulas without a cached result ---------------------------------
    def _formula_sheet_rows(self, sheet_name: str) -> Optional[List[tuple]]:
        """The rows of *sheet_name* as formulas rather than as results.

        Excel stores two things in a formula cell: the formula and the result it
        last computed.  ``data_only=True`` reads the *result*, and that result is
        missing whenever the file was last written by something that does not
        calculate - openpyxl itself, a script, an exporter.  The cell then reads
        back as completely empty.

        That is the dangerous part: an empty Maximum cell is not an error, it
        means "no range", so a workbook whose limits are formulas would generate
        perfectly valid code for the wrong numbers, silently.  Loading the file a
        second time shows which cells really are empty and which ones only look
        empty.
        """
        if self._formula_workbook is None:
            try:
                with quiet_openpyxl():
                    self._formula_workbook = load_workbook(self._path, data_only=False,
                                                           read_only=True)
            except Exception:  # noqa: BLE001 - the first load already succeeded
                return None
        if sheet_name not in self._formula_workbook.sheetnames:
            return None
        with quiet_openpyxl():
            return list(self._formula_workbook[sheet_name].iter_rows(values_only=True))

    @staticmethod
    def _is_formula(value: Any) -> bool:
        return isinstance(value, str) and value.startswith("=") and len(value) > 1

    def _report_uncached_formulas(self, sheet_name: str, empty_cells: List[tuple],
                                  data: Optional[SheetData] = None) -> None:
        """Report every cell of *empty_cells* that in fact holds a formula.

        *empty_cells* is a list of ``(row_number, column_index, column_name)``
        gathered while reading; nothing is loaded at all when it is empty, so a
        normal workbook costs nothing.
        """
        if not empty_cells:
            return
        rows = self._formula_sheet_rows(sheet_name)
        if rows is None:
            return

        for row_number, position, column_name in empty_cells:
            if row_number - 1 >= len(rows):
                continue
            cells = rows[row_number - 1]
            if position - 1 >= len(cells):
                continue
            if not self._is_formula(cells[position - 1]):
                continue
            location = data.location(row=row_number, column=column_name) if data is not None \
                else SourceLocation(file=str(self._path), sheet=sheet_name, row=row_number,
                                    column=column_name)
            self._diagnostics.error(
                "EXL004",
                f"The cell holds the formula '{cells[position - 1]}' but the workbook does "
                f"not store its result, so the code generator reads it as an empty cell.",
                location,
                hint="Open the workbook in Excel or LibreOffice and save it again - that "
                     "stores the computed values.  Writing the plain number in the cell "
                     "instead of a formula also works.")

    def read_column_lists(self, sheet_name: str) -> Dict[str, List[str]]:
        """Read a sheet as ``{header: [values, ...]}``.

        Used for the *Defines* sheet, which is a plain list-per-column table
        with its own headers rather than the parameter column schema.
        """
        result: Dict[str, List[str]] = {}
        if sheet_name not in self._workbook.sheetnames:
            return result

        with quiet_openpyxl():
            rows = iter(list(self._workbook[sheet_name].iter_rows(values_only=True)))
        header_row = next(rows, None)
        if header_row is None:
            return result

        headers = [str(header).strip() if header is not None else "" for header in header_row]
        for header in headers:
            if header:
                result.setdefault(header, [])

        empty_cells: List[tuple] = []
        for row_number, cells in enumerate(rows, start=2):
            row_empty_cells: List[tuple] = []
            filled = False
            for index, cell in enumerate(cells):
                if index >= len(headers) or not headers[index]:
                    continue
                if cell is None:
                    row_empty_cells.append((row_number, index + 1, headers[index]))
                    continue
                text = str(cell).strip()
                if not text:
                    row_empty_cells.append((row_number, index + 1, headers[index]))
                    continue
                filled = True
                if text not in result[headers[index]]:
                    result[headers[index]].append(text)
            if filled:
                empty_cells.extend(row_empty_cells)

        self._report_uncached_formulas(sheet_name, empty_cells)
        return result

    def read_sheet(self, sheet_name: str, *, required: bool = True) -> Optional[SheetData]:
        """Read one worksheet into a :class:`SheetData`."""
        if sheet_name not in self._workbook.sheetnames:
            message = (f"Worksheet '{sheet_name}' was not found. "
                       f"Available sheets: {', '.join(self._workbook.sheetnames)}.")
            if required:
                self._diagnostics.error("EXL001", message, SourceLocation(file=str(self._path)))
            else:
                self._diagnostics.warning("EXL002", message, SourceLocation(file=str(self._path)))
            return None

        data = SheetData(file=self._path, sheet_name=sheet_name)

        with quiet_openpyxl():
            rows_iterator = iter(list(self._workbook[sheet_name].iter_rows(values_only=True)))
        header_row = next(rows_iterator, None)
        if header_row is None:
            self._diagnostics.error("EXL003", f"Worksheet '{sheet_name}' is empty.",
                                    data.location())
            return data

        for position, cell_value in enumerate(header_row, start=1):
            if cell_value is None:
                continue
            raw = str(cell_value).strip()
            if not raw:
                continue
            data.raw_headers[position] = raw
            canonical = canonical_column(raw)
            if canonical is None:
                self._diagnostics.info(
                    "EXL010", f"Column '{raw}' is not known to the code generator and is ignored.",
                    data.location(row=1, column=raw))
                continue
            if canonical in data.headers.values():
                self._diagnostics.error(
                    "EXL011", f"Column '{canonical}' appears more than once.",
                    data.location(row=1, column=raw))
                continue
            data.headers[position] = canonical

        # Row 1 holds the headers, therefore the data starts at row 2.
        empty_cells: List[tuple] = []
        for offset, cell_values in enumerate(rows_iterator, start=2):
            values: Dict[str, Any] = {}
            row_empty_cells: List[tuple] = []
            for position, cell_value in enumerate(cell_values, start=1):
                column = data.headers.get(position)
                if column is None:
                    continue
                cleaned = _clean(cell_value)
                values[column] = cleaned
                if cleaned is None:
                    row_empty_cells.append((offset, position, column))
            row = SheetRow(row_number=offset, values=values)
            if not row.is_empty():
                data.rows.append(row)
                empty_cells.extend(row_empty_cells)

        # a wholly blank row is skipped above, so only cells of real rows are
        # looked at here
        self._report_uncached_formulas(sheet_name, empty_cells, data)
        return data


def _clean(value: Any) -> Any:
    """Normalise a raw cell value (trim strings, drop empty strings)."""
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        return text if text else None
    return value

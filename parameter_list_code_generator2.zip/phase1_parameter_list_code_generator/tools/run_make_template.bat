@echo off
REM ===========================================================================
REM  Rebuilds parameter_list_template.xlsx from scratch.
REM
REM  Careful: this makes a NEW blank workbook.  To only refresh the drop-downs
REM  and the colouring of the workbook you already have - keeping every row -
REM  open a terminal here and run:
REM      python run_make_template.py --restyle ..\parameter_list_template.xlsx
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_make_template.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     Done - the blank workbook is in the project folder.
) else (
    echo     The workbook could not be written. Is it open in Excel right now?
)

echo.
pause
exit /b %EXITCODE%

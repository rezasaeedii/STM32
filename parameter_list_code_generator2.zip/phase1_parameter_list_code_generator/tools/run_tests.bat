@echo off
REM ===========================================================================
REM  Runs every self test of the tool.  Double-click this file after any change
REM  to the tool - it needs no test framework and no internet.
REM
REM  For the list of suites without running them:
REM      python run_tests.py --list
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_tests.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     All tests passed.
) else (
    echo     SOME TESTS FAILED - scroll up to see which.
    echo     Do not deliver the tool in this state.
)

echo.
pause
exit /b %EXITCODE%

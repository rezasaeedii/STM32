@echo off
REM ===========================================================================
REM  Generates the parameter-list C code from the Excel file.
REM  Double-click this file - no command line needed.
REM
REM  For anything beyond the normal run (--check, --only-xml, --from-xml ...)
REM  open a terminal here and use  python run_generate.py --help
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_generate.py -v %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     Done - the C files are in  cg_parameter_list\
) else if "%EXITCODE%"=="1" (
    echo     The Excel input has problems. Nothing was generated.
    echo     Fix the rows listed above and run this again.
) else (
    echo     The tool could not run. Check codegen_config.json and the paths in it.
)

echo.
pause
exit /b %EXITCODE%

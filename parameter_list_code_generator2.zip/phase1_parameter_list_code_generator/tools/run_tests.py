"""Runs every test of this phase, in order, and reports one verdict.

    python run_tests.py

This is what to run after any change to the tool.  It is deliberately a plain
script: no test framework to install, and it works on a machine with no
internet.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent

SUITES = [
    ("validation rules", "tests/run_validation_test.py"),
    ("generated code compiles and runs", "tests/run_compile_test.py"),
]


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="run_tests.py",
        description="Runs every self test of this phase, in order, and reports one "
                    "verdict. Needs no test framework and no internet.",
        epilog="Suites:\n  " + "\n  ".join(f"{title:<34} {script}"
                                            for title, script in SUITES),
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("-l", "--list", action="store_true",
                        help="print the suites that would run, and stop")
    arguments = parser.parse_args()

    if arguments.list:
        for title, script in SUITES:
            mark = "ok " if (TOOLS_DIR / script).is_file() else "MISSING"
            print(f"  [{mark}] {title:<34} {script}")
        return 0

    failures = []
    skipped = []
    ran = 0
    for title, script in SUITES:
        path = TOOLS_DIR / script
        if not path.is_file():
            print(f"── {title}: {script} not found, skipped\n")
            skipped.append(title)
            continue
        print(f"══ {title}  ({script})")
        result = subprocess.run([sys.executable, str(path)], cwd=TOOLS_DIR)
        print()
        ran += 1
        if result.returncode != 0:
            failures.append(title)

    if failures:
        print(f"{len(failures)} suite(s) FAILED: " + ", ".join(failures))
        return 1
    # A suite that was not there did not pass; saying so keeps a half-copied
    # folder from looking like a healthy one.
    print(f"All {ran} suite(s) passed."
          + (f"  {len(skipped)} were missing: " + ", ".join(skipped) if skipped else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# common/ — the shared core

This folder is the code generator itself: the data model, the XML reader and
writer, the validation rules, the tag-offset map and the C code builders.
**Every phase of the project has this same folder** — the same files, the same
classes, the same API — so that the same model always produces the same C.

It knows exactly one input: the XML model. Where that XML comes from is the
phase's business:

| phase | front end | folder, in that phase's `tools/` |
|-------|-----------|----------------------------------|
| 1 | Excel workbooks | `../pl_excel/` |
| 2 | graphical editor | `../pl_gui/` |

Only one of those two front-end folders exists in any one phase.

The two copies of this folder are not quite byte-identical, and the reason is
worth knowing: **each phase supports exactly one input**, so phase 2 carries no
Excel settings in `config.py` and no "sheet" or "column" wording in its
messages. Those are the only differences. Nothing about the model, the offsets,
the validation or the generated C differs between phases.

**Do not change the behaviour of this folder in one phase only.** Make the
change once and carry it across, or the two phases stop agreeing.

"""Field order of ``sParameterDescriptor``.

The generated initialiser uses *designated initialisers in declaration order*,
which is valid in C99 **and** in C++20.  The order below therefore has to match
``parameter_descriptor.h`` exactly.
"""

from __future__ import annotations

from typing import List

from ..model.tags import TAG_REGISTRY

FIELD_NAME = "pName"
FIELD_GROUP = "Group"
FIELD_SMART_DATA = "pSmartData"
FIELD_ARRAY_SIZE = "ArraySize"
FIELD_UNIT = "pUnit"
FIELD_DESCRIPTION = "pDescription"

#: Fields that come before the tag fields, in declaration order.
LEADING_FIELDS: List[str] = [FIELD_NAME, FIELD_GROUP, FIELD_SMART_DATA, FIELD_ARRAY_SIZE,
                             FIELD_UNIT]

#: Fields that come after the tag fields, in declaration order.
TRAILING_FIELDS: List[str] = [FIELD_DESCRIPTION]


def descriptor_field_order() -> List[str]:
    """Full field order of ``sParameterDescriptor``."""
    return LEADING_FIELDS + [spec.descriptor_field for spec in TAG_REGISTRY] + TRAILING_FIELDS

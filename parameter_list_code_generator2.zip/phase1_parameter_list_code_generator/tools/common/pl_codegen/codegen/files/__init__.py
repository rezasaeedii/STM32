"""One class per generated file.

Each module here holds a ``FileBuilder`` whose ``generate()`` writes the whole
file from top to bottom with ``text += ...``.  Reading that one method tells you
exactly what the generated file will look like.

Adding a new output file: write a module here and list its class in
:data:`FILE_BUILDERS`.
"""

from __future__ import annotations

from typing import List, Type

from .file_builder import FileBuilder
from .parameter_list_c import ParameterListSource
from .parameter_list_defines_h import ParameterListDefinesHeader
from .parameter_list_h import ParameterListHeader
from .parameter_list_table_h import ParameterListTableHeader
from .parameter_types_h import ParameterTypesHeader
from .smart_data_c import SmartDataSource
from .smart_data_h import SmartDataHeader

#: Generated in this order.
FILE_BUILDERS: List[Type[FileBuilder]] = [
    ParameterListDefinesHeader,
    ParameterTypesHeader,
    SmartDataHeader,
    SmartDataSource,
    ParameterListHeader,
    ParameterListSource,
    ParameterListTableHeader,
]

__all__ = [
    "FILE_BUILDERS", "FileBuilder",
    "ParameterListDefinesHeader", "ParameterListHeader", "ParameterListSource",
    "ParameterListTableHeader", "ParameterTypesHeader",
    "SmartDataHeader", "SmartDataSource",
]

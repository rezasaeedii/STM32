"""Command line interface of the parameter-list code generator.

This is the phase-independent half: it reads the XML model(s) named in the
configuration and writes the C files.  A phase with a front end of its own puts
that in front (phase 1's Excel reader has its own command line in
``pl_excel/cli.py``); a phase whose lists are edited in the graphical editor
uses this one directly, and then it is what a build script or a CI job calls.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional, Sequence

import argparse

from . import __tool_name__, __version__
from .config import Config
from .errors import CodeGeneratorError, Severity
from .logging_utils import banner, setup_logging
from .pipeline import Pipeline, render_diagnostics
from .validation.rules import ALL_RULES

DEFAULT_CONFIG = "codegen_config.json"

#: The 'tools' folder, where the configuration file lives next to run_generate.py.
#: This module is 'tools/common/pl_codegen/cli.py', so it is three levels up.
TOOLS_DIR = Path(__file__).resolve().parent.parent.parent

EXIT_OK = 0
EXIT_VALIDATION_FAILED = 1
EXIT_TOOL_ERROR = 2


def resolve_config_path(given: Optional[Path]) -> Path:
    """Where to read the configuration from.

    ``run_generate.py`` is meant to work from any working directory - a build
    script usually calls it from the project root - so the default cannot simply
    be a relative name.  A file in the current folder still wins, which is what
    someone experimenting with a second configuration expects.
    """
    if given is not None:
        return given
    local = Path(DEFAULT_CONFIG)
    if local.is_file():
        return local
    return TOOLS_DIR / DEFAULT_CONFIG


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_generate.py",
        description="Generates the parameter-list C code from the XML model.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python run_generate.py                     # generate from the configured input\n"

            "  python run_generate.py -m other.xml        # generate from another model file\n"
            "  python run_generate.py --check             # validate only, write nothing\n"
            ))

    parser.add_argument("-c", "--config", type=Path, default=None,
                        help=f"configuration file (default: the {DEFAULT_CONFIG} of the "
                             f"current folder, otherwise the one next to run_generate.py)")
    parser.add_argument("-m", "--model", type=Path, metavar="FILE",
                        help="XML model file to use instead of the configured one(s)")
    parser.add_argument("--check", action="store_true",
                        help="validate the input only; write no file at all")
    parser.add_argument("--list-rules", action="store_true",
                        help="print every validation rule and exit")
    parser.add_argument("-W", "--warnings-as-errors", action="store_true",
                        help="treat warnings as errors")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="also show informational diagnostics")
    parser.add_argument("-q", "--quiet", action="store_true", help="only show problems")
    parser.add_argument("--version", action="version",
                        version=f"{__tool_name__} {__version__}")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_parser().parse_args(argv)
    logger = setup_logging(verbose=arguments.verbose, quiet=arguments.quiet)

    if arguments.list_rules:
        print("Validation rules:")
        for rule_class in ALL_RULES:
            print(f"  {rule_class.rule_id:<16} {rule_class.description}")
        return EXIT_OK

    try:
        config = Config.load(resolve_config_path(arguments.config))
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if arguments.warnings_as_errors:
        config.validation.treat_warnings_as_errors = True


    logger.info("%s v%s", __tool_name__, __version__)
    logger.info("configuration: %s", config.path)
    logger.info("input: %s", _describe_input(config))

    try:
        pipeline = Pipeline(config)
        if arguments.check:
            result = pipeline.check(arguments.model)
        else:
            result = pipeline.run(arguments.model)
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if not arguments.quiet or not result.success:
        _print_summary(result, arguments.verbose)
    return EXIT_OK if result.success else EXIT_VALIDATION_FAILED


def _describe_input(config) -> str:
    """One line saying exactly which files the run will read."""
    files = config.inputs.model_files
    kind = "XML model"
    if not files:
        return f"{kind} (no file configured)"
    if len(files) == 1:
        return f"{kind} {files[0]}"
    listing = "".join(f"\n         - {path}" for path in files)
    return f"{kind}, {len(files)} module(s) merged:{listing}"


def _print_drift(drift) -> None:
    """Say, loudly, when this run moved something a board may already store.

    It is printed before the file list, because by the time somebody has read
    "7 files written" they have stopped reading.
    """
    if drift is None or not drift.report():
        return

    rule = "=" * 78
    print()
    print(rule)
    if drift.breaks_stored_data:
        print("  WARNING - THE MEMORY LAYOUT CHANGED SINCE THE LAST BUILD")
    else:
        print("  The parameter list changed since the last build")
    print(rule)
    for line in drift.report():
        print(line)
    print(rule)


def _print_summary(result, verbose: bool) -> None:
    diagnostics = result.diagnostics
    print(banner("Diagnostics"))
    print(render_diagnostics(diagnostics, verbose))
    print()
    print(diagnostics.summary())

    if result.success:
        _print_drift(result.drift)
        if result.generated_files:
            print(f"\nGenerated {len(result.generated_files)} file(s) for "
                  f"{result.parameter_count} value(s):")
            for path in result.generated_files:
                print(f"  {path}")
        elif result.model_file is not None:
            print(f"\nModel: {result.model_file}  ({result.parameter_count} value(s))")
        print("\nDone.")
    else:
        print("\nCode generation was aborted because the model contains errors.")
        if diagnostics.count(Severity.ERROR) == 0:
            print("(warnings are treated as errors)")


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

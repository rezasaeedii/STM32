"""All validation rules.

To add a check: create a class deriving from :class:`ValidationRule` in this
folder and append it to :data:`ALL_RULES`.
"""

from __future__ import annotations

from typing import List, Type

from .defines_rules import DefinesSheetRule
from .name_rules import (GeneratedIdentifierRule, IndexMacroCollisionRule, NameSyntaxRule,
                         NameUniquenessRule, StructFieldRule, StructRule)
from .range_rules import (DefaultInRangeRule, MetadataRule, MinMaxOrderRule, NativeRangeRule,
                          RequiredValuesRule)
from .rule_base import ValidationRule
from .tag_rules import (FreeTagSyntaxRule, GsNameRule, LogIdRule, MandatoryTagRule,
                        TagEnumValueRule, TagValueRangeRule)
from .type_rules import ArraySizeRule, DataTypeRule, DeclaredTypeRule, GroupRule

#: Executed in this order; the order only affects the report, not the result.
ALL_RULES: List[Type[ValidationRule]] = [
    DefinesSheetRule,
    NameSyntaxRule,
    NameUniquenessRule,
    IndexMacroCollisionRule,
    GeneratedIdentifierRule,
    StructRule,
    StructFieldRule,
    DataTypeRule,
    DeclaredTypeRule,
    GroupRule,
    ArraySizeRule,
    NativeRangeRule,
    MinMaxOrderRule,
    DefaultInRangeRule,
    RequiredValuesRule,
    MetadataRule,
    MandatoryTagRule,
    TagEnumValueRule,
    TagValueRangeRule,
    FreeTagSyntaxRule,
    GsNameRule,
    LogIdRule,
]

__all__ = ["ALL_RULES", "ValidationRule"]

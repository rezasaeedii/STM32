"""Runs every validation rule over the model."""

from __future__ import annotations

from typing import List

from ..config import Config
from ..errors import DiagnosticCollector
from ..model.parameter_list import ParameterList
from .rules import ALL_RULES, ValidationRule


class Validator:
    """Applies :data:`~pl_codegen.validation.rules.ALL_RULES` to a model."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._rules: List[ValidationRule] = [rule(config) for rule in ALL_RULES]

    @property
    def rules(self) -> List[ValidationRule]:
        return list(self._rules)

    def validate(self, model: ParameterList, diagnostics: DiagnosticCollector) -> bool:
        """Run all rules; return ``True`` when code generation may continue."""
        model.assign_paths()
        for rule in self._rules:
            rule.check(model, diagnostics)

        if not model.flatten():
            diagnostics.error(
                "VAL001", "The parameter list is empty; nothing would be generated.",
                hint="Add a parameter, or enable one of the existing ones.")

        if diagnostics.has_errors:
            return False
        if self._config.validation.treat_warnings_as_errors and diagnostics.has_warnings:
            return False
        return True

"""The intermediate XML format that decouples the front end from the generator.

Stage 1  : whatever the phase uses as input  ->  XML
Stage 2  : XML                               ->  C source/header files

Phase 1 writes the XML from an Excel workbook and phase 2 from the graphical
editor; stage 2 is the same code in both, which is why the two phases produce
identical C.  A third front end needs to agree with :mod:`schema` and nothing
else.
"""

from . import schema
from .xml_reader import read_xml
from .xml_writer import model_to_element, write_xml

__all__ = ["schema", "read_xml", "write_xml", "model_to_element"]

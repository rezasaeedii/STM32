"""XML -> model.

This is the only entry point the code generator uses, so the generator is
completely independent of Excel.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from ..errors import CodeGeneratorError, DiagnosticCollector, SourceLocation
from ..model.defines import Defines
from ..model.parameter import Parameter, ParameterKind
from ..model.parameter_list import ParameterList
from ..model.tags import TAGS_BY_ID, TagKind
from ..model.types import resolve_data_type
from . import schema as sch


def read_xml(path: Path, diagnostics: DiagnosticCollector) -> ParameterList:
    """Parse *path* and rebuild the parameter list model."""
    if not path.is_file():
        raise CodeGeneratorError(f"XML model file '{path}' does not exist.")
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise CodeGeneratorError(f"'{path}' is not a valid XML file: {exc}") from exc

    if root.tag != sch.ROOT:
        raise CodeGeneratorError(
            f"'{path}' is not a parameter-list model (root element is '{root.tag}', "
            f"expected '{sch.ROOT}').")

    version = root.get(sch.ATTR_SCHEMA_VERSION, "")
    if version and version.split(".")[0] != sch.SCHEMA_VERSION.split(".")[0]:
        diagnostics.warning(
            "XML001",
            f"XML schema version '{version}' differs from the version supported by this tool "
            f"('{sch.SCHEMA_VERSION}').", SourceLocation(file=str(path)))

    model = ParameterList()
    model.generator_version = root.get(sch.ATTR_GENERATOR_VERSION, "")
    model.generated_at = root.get(sch.ATTR_GENERATED_AT, "")

    files_element = root.find(sch.SOURCE_FILES)
    if files_element is not None:
        model.source_files = [element.get(sch.ATTR_PATH, "")
                              for element in files_element.findall(sch.SOURCE_FILE)]

    model.defines = _read_defines(root)

    # The type library, if the file has one.  It is optional on purpose: a file
    # written before templates existed simply has no library, and still loads.
    templates_element = root.find(sch.STRUCT_TEMPLATES)
    if templates_element is not None:
        for element in templates_element.findall(sch.PARAMETER):
            template = _read_parameter(element, path, diagnostics)
            if template is not None:
                model.templates.append(_as_template(template))

    parameters_element = root.find(sch.PARAMETERS)
    if parameters_element is None:
        diagnostics.error("XML002", f"'{sch.PARAMETERS}' element is missing.",
                          SourceLocation(file=str(path)))
        return model

    for element in parameters_element.findall(sch.PARAMETER):
        parameter = _read_parameter(element, path, diagnostics)
        if parameter is not None:
            model.add(parameter)
    return model


def _read_defines(root: ET.Element) -> Defines:
    defines = Defines()
    defines_element = root.find(sch.DEFINES)
    if defines_element is None:
        return defines
    for group in defines_element.findall(sch.DEFINE_GROUP):
        column = group.get(sch.ATTR_NAME, "")
        for value_element in group.findall(sch.DEFINE_VALUE):
            value = value_element.get(sch.ATTR_VALUE)
            if column and value:
                defines.add(column, value)
    return defines


def _read_parameter(element: ET.Element, path: Path,
                    diagnostics: DiagnosticCollector) -> Optional[Parameter]:
    name = element.get(sch.ATTR_NAME)
    if not name:
        diagnostics.error("XML010", "A <Parameter> element has no 'name' attribute.",
                          SourceLocation(file=str(path)))
        return None

    parameter = Parameter(name=name)
    raw_kind = (element.get(sch.ATTR_KIND) or ParameterKind.PRIMITIVE.value).strip().lower()
    try:
        parameter.kind = ParameterKind(raw_kind)
    except ValueError:
        diagnostics.warning("XML012", f"Unknown parameter kind '{raw_kind}'; "
                                      "'primitive' is assumed.", parameter.source)
        parameter.kind = ParameterKind.PRIMITIVE
    parameter.enable = _to_bool(element.get(sch.ATTR_ENABLE), True)
    parameter.gs_name = element.get(sch.ATTR_GS_NAME)
    parameter.group = element.get(sch.ATTR_GROUP)
    parameter.data_type_name = element.get(sch.ATTR_DATA_TYPE)
    parameter.unit = element.get(sch.ATTR_UNIT)
    parameter.array_size = _to_int(element.get(sch.ATTR_ARRAY_SIZE), 1)

    source_element = element.find(sch.SOURCE)
    if source_element is not None:
        parameter.source = SourceLocation(
            file=source_element.get(sch.ATTR_FILE),
            sheet=source_element.get(sch.ATTR_SHEET),
            row=_to_optional_int(source_element.get(sch.ATTR_ROW)))
    else:
        parameter.source = SourceLocation(file=str(path))

    data_type = resolve_data_type(parameter.data_type_name)
    is_float = bool(data_type and data_type.is_float)
    is_bool = bool(data_type and data_type.is_bool)

    limits = element.find(sch.LIMITS)
    if limits is not None:
        # Only the default value of a bool_t row is a boolean; its minimum,
        # maximum and resolution are meaningless for that type and are kept as
        # plain numbers, exactly as the Excel reader keeps them.  Reading them
        # back as booleans would make the same model generate different files
        # depending on where it came from, and would turn "Minimum = 3" into an
        # unhelpful "not a valid boolean" instead of "a boolean has no minimum".
        def limit(attribute: str, label: str, as_bool: bool = False):
            return _to_number(limits.get(attribute), is_float, as_bool,
                              label=label, parameter=parameter,
                              type_name=parameter.data_type_name,
                              diagnostics=diagnostics)

        parameter.default_value = limit(sch.ATTR_DEFAULT, "DefaultValue", is_bool)
        parameter.minimum = limit(sch.ATTR_MINIMUM, "Minimum")
        parameter.maximum = limit(sch.ATTR_MAXIMUM, "Maximum")
        parameter.resolution = limit(sch.ATTR_RESOLUTION, "Resolution")

    tags_element = element.find(sch.TAGS)
    if tags_element is not None:
        for tag_element in tags_element.findall(sch.TAG):
            tag_id = tag_element.get(sch.ATTR_ID, "")
            spec = TAGS_BY_ID.get(tag_id)
            raw = tag_element.get(sch.ATTR_VALUE)
            if spec is None:
                diagnostics.warning("XML011", f"Unknown tag '{tag_id}' is ignored.",
                                    parameter.source)
                continue
            parameter.tags[tag_id] = _convert_tag(spec.kind, raw)

    description_element = element.find(sch.DESCRIPTION)
    if description_element is not None and description_element.text:
        parameter.description = description_element.text.strip()

    fields_element = element.find(sch.FIELDS)
    if fields_element is not None:
        for child_element in fields_element.findall(sch.PARAMETER):
            child = _read_parameter(child_element, path, diagnostics)
            if child is not None:
                _drop_inherited(child, parameter.name, diagnostics)
                parameter.children.append(child)

    return parameter


def _as_template(template: Parameter) -> Parameter:
    """Force a node read from the library into the shape a template has.

    A template is a *type*, not a parameter: it describes fields and nothing
    else.  Tags, the group and the array size belong to the parameter that will
    be made from it, so they are cleared here rather than trusted from the file -
    a hand-edited library then cannot smuggle a group into every copy.
    """
    template.kind = ParameterKind.STRUCT
    template.enable = True
    template.tags = {}
    template.group = None
    template.array_size = 1
    return template


def _drop_inherited(field: Parameter, structure: str,
                    diagnostics: DiagnosticCollector) -> None:
    """Remove tags and the group from a field, so an older file still loads.

    Tags and the group belong to the top level entry.  A file written before
    that rule existed may still carry them on a field; they are dropped here
    with a warning rather than silently kept, because keeping them would mean
    the file no longer says what the generated code does.
    """
    own_tags = sorted(key for key, value in field.tags.items() if value is not None)
    if own_tags:
        diagnostics.warning(
            "XML013",
            f"Field '{field.name}' of structure '{structure}' carried the tag(s) "
            f"{', '.join(own_tags)}; they were dropped.",
            field.source,
            hint=f"Tags belong to '{structure}'. Check them there and save the file "
                 f"again to remove this warning.")
        field.tags = {}

    if field.group:
        diagnostics.warning(
            "XML014",
            f"Field '{field.name}' of structure '{structure}' carried the group "
            f"'{field.group}'; it was dropped.",
            field.source,
            hint=f"The group belongs to '{structure}'.")
        field.group = None


def _convert_tag(kind: TagKind, raw: Optional[str]):
    if raw is None:
        return None
    if kind is TagKind.BOOLEAN:
        return _to_bool(raw, False)
    if kind is TagKind.UNSIGNED:
        return _to_optional_int(raw)
    if kind is TagKind.FREE:
        number = _to_optional_int(raw)
        return number if number is not None else raw
    return raw


def _to_bool(raw: Optional[str], default: bool) -> bool:
    if raw is None:
        return default
    return raw.strip().lower() in ("true", "1", "yes")


def _to_int(raw: Optional[str], default: int) -> int:
    value = _to_optional_int(raw)
    return default if value is None else value


def _to_optional_int(raw: Optional[str]) -> Optional[int]:
    if raw is None or not str(raw).strip():
        return None
    try:
        return int(str(raw).strip(), 0)
    except ValueError:
        try:
            number = float(raw)
        except ValueError:
            return None
        return int(number) if number.is_integer() else None


def _to_number(raw: Optional[str], is_float: bool, is_bool: bool, *,
               label: str = "", parameter=None, type_name: Optional[str] = None,
               diagnostics: Optional[DiagnosticCollector] = None):
    """One numeric attribute of a ``<Limits>`` element.

    Anything that cannot be read is *reported*, never dropped.  Returning None
    in silence would be the dangerous behaviour: an unreadable Maximum simply
    looks like an empty cell, an empty Minimum and Maximum mean "the whole
    range of the type", and the generated firmware would then accept values the
    model was written to forbid - with nothing anywhere saying so.
    """
    if raw is None or not str(raw).strip():
        return None
    if is_bool:
        return _to_bool(raw, False)

    text = str(raw).strip()
    if is_float:
        try:
            return float(text)
        except ValueError:
            _report_bad_number(label, text, type_name, parameter, diagnostics,
                               "is not a number")
            return None

    value = _to_optional_int(text)
    if value is None:
        try:
            float(text)
        except ValueError:
            reason = "is not a number"
        else:
            reason = (f"is not a whole number, and '{type_name}' is an integer type"
                      if type_name else "is not a whole number")
        _report_bad_number(label, text, type_name, parameter, diagnostics, reason)
    return value


def _report_bad_number(label: str, text: str, type_name: Optional[str], parameter,
                       diagnostics: Optional[DiagnosticCollector], reason: str) -> None:
    if diagnostics is None or parameter is None:
        return
    diagnostics.error(
        "XML012",
        f"'{label}' is '{text}' in the XML model, which {reason}.",
        parameter.source,
        hint="Correct the value in the editor, or fix it by hand in the XML file.")

"""Element and attribute names of the intermediate XML format.

The XML file is the *contract* between whatever produces a parameter list and
the code generator that consumes it: the Excel reader of phase 1 and the
graphical editor of phase 2 both write exactly this, and the generator reads
nothing else.  Keeping every tag name in one module is what lets a third front
end be written without touching the generator at all.
"""

from __future__ import annotations

SCHEMA_VERSION = "2.0"

# -- elements ------------------------------------------------------------
ROOT = "ParameterListModel"
DEFINES = "Defines"
DEFINE_GROUP = "DefineGroup"
DEFINE_VALUE = "Value"
PARAMETERS = "Parameters"
PARAMETER = "Parameter"
FIELDS = "Fields"
#: the library of reusable structure types - see ParameterList.templates
STRUCT_TEMPLATES = "StructTemplates"
SOURCE = "Source"
LIMITS = "Limits"
TAGS = "Tags"
TAG = "Tag"
DESCRIPTION = "Description"
SOURCE_FILES = "SourceFiles"
SOURCE_FILE = "SourceFile"

# -- attributes ----------------------------------------------------------
ATTR_SCHEMA_VERSION = "schemaVersion"
ATTR_GENERATOR = "generator"
ATTR_GENERATOR_VERSION = "generatorVersion"
ATTR_GENERATED_AT = "generatedAt"

ATTR_NAME = "name"
ATTR_KIND = "kind"
ATTR_ENABLE = "enable"
ATTR_GS_NAME = "gsName"
ATTR_GROUP = "group"
ATTR_DATA_TYPE = "dataType"
ATTR_ARRAY_SIZE = "arraySize"
ATTR_UNIT = "unit"

ATTR_DEFAULT = "default"
ATTR_MINIMUM = "minimum"
ATTR_MAXIMUM = "maximum"
ATTR_RESOLUTION = "resolution"

ATTR_ID = "id"
ATTR_VALUE = "value"
ATTR_KIND = "kind"

ATTR_FILE = "file"
ATTR_SHEET = "sheet"
ATTR_ROW = "row"
ATTR_PATH = "path"

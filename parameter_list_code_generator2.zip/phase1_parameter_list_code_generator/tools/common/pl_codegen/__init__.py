"""Parameter-list code generator - the part that is the same in every phase.

This package reads a parameter list as XML, checks it, and writes the C files.
It knows nothing about where the XML came from, which is what lets both phases
share it: phase 1 puts an Excel reader in front of it (``tools/pl_excel``) and
phase 2 a graphical editor (``tools/pl_gui``), and both produce identical C from
an identical model.  Same files, same classes, same API in both; the only
difference is that phase 2 carries no Excel settings and no Excel wording,
because it does not read Excel at all.

Everything under here is deliberately split into small, single-responsibility
modules, so that changing one aspect of the generated code means finding and
editing exactly one file:

    config.py          -> how the tool is configured
    errors.py          -> how problems are reported
    naming.py          -> how C identifiers are derived from parameter names
    pipeline.py        -> the run: XML -> model -> checks -> offsets -> files
    model/             -> the in-memory description of a parameter list
    xml_model/         -> model  <-> XML (the source of truth on disk)
    validation/        -> model  -> diagnostics
    layout/            -> model  -> the MemoryOffset of every tag
    codegen/           -> model  -> C source/header files

Anything phase-specific belongs *outside* this package. A change made here has
to be copied to the other phase, so that both keep generating identical C.
"""

__version__ = "2.0.0"
__tool_name__ = "parameter_list_code_generator"

__all__ = ["__version__", "__tool_name__"]

"""In-memory description of a single parameter.

A parameter is either a **primitive** (it holds one value, possibly an array of
values) or a **struct** (it holds other parameters, which may themselves be
structs).  The tree can be nested as deeply as needed.

**Tags and the group belong to the top level entry**, never to a field inside a
structure.  A structure is one thing that belongs to one subsystem, is reset
proof or is not, and is logged or is not; its fields are the smart-data objects
that make it up, and they all share that classification.  So a field carries
only what is really its own: name, type, array size, unit, limits, description.


The code generator never walks the tree itself: it asks
:meth:`~pl_codegen.model.parameter_list.ParameterList.flatten` for the list of
*leaves*, where every leaf is a primitive with a dotted name such as
``Position.Home.Lat``.  That keeps the generated descriptor table exactly the
same shape it had before structs existed.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Dict, Iterator, List, Optional, Union

from ..errors import SourceLocation
from .types import CDataType, resolve_data_type

#: Value a tag can hold once it has been read from the GUI / XML.
TagValue = Union[bool, int, str, None]

#: Numeric value of a parameter (default / min / max / resolution).
NumericValue = Union[int, float, bool, None]


class ParameterKind(Enum):
    """What a parameter is."""

    PRIMITIVE = "primitive"   #: holds a value of a supported C type
    STRUCT = "struct"         #: holds other parameters


@dataclass
class Parameter:
    """One node of the parameter tree."""

    name: str
    kind: ParameterKind = ParameterKind.PRIMITIVE
    enable: bool = True
    gs_name: Optional[str] = None
    group: Optional[str] = None
    data_type_name: Optional[str] = None
    array_size: int = 1
    default_value: NumericValue = None
    minimum: NumericValue = None
    maximum: NumericValue = None
    resolution: NumericValue = None
    unit: Optional[str] = None
    tags: Dict[str, TagValue] = field(default_factory=dict)
    description: Optional[str] = None
    children: List["Parameter"] = field(default_factory=list)
    source: SourceLocation = field(default_factory=SourceLocation)

    #: filled in by :meth:`ParameterList.flatten` - the C expression that
    #: reaches this leaf, e.g. ``Cg_SmartData_Position.Home.Lat``
    c_object: Optional[str] = None

    # -- what kind of node is this ---------------------------------------
    @property
    def is_struct(self) -> bool:
        return self.kind is ParameterKind.STRUCT

    @property
    def is_primitive(self) -> bool:
        return self.kind is ParameterKind.PRIMITIVE

    @property
    def data_type(self) -> Optional[CDataType]:
        """Resolved data type, or ``None`` for a struct/unknown type."""
        return resolve_data_type(self.data_type_name) if self.is_primitive else None

    @property
    def is_array(self) -> bool:
        return self.array_size > 1

    @property
    def range_disabled(self) -> bool:
        """True when this value is not meant to have an allowed range.

        Writing a zero minimum **and** a zero maximum means "the whole range of
        the type", as the module specification requires.  Leaving both cells
        empty means the same thing - the user simply did not ask for a range.

        What that turns into in the generated code is the *native* range of the
        C type, never ``0, 0``: the smart-data constructor refuses a default
        value outside ``[min, max]``, so ``0, 0`` would make every value with a
        non-zero default fail at run time.
        """
        return _is_zero_or_empty(self.minimum) and _is_zero_or_empty(self.maximum)

    @property
    def effective_minimum(self) -> NumericValue:
        """The minimum the generated constructor will actually be given."""
        return self._effective_limit(self.minimum, native=True, low=True)

    @property
    def effective_maximum(self) -> NumericValue:
        """The maximum the generated constructor will actually be given."""
        return self._effective_limit(self.maximum, native=True, low=False)

    def _effective_limit(self, value: NumericValue, native: bool, low: bool) -> NumericValue:
        data_type = self.data_type
        if data_type is None or not data_type.has_range:
            return None
        if self.range_disabled and native:
            return data_type.native_min if low else data_type.native_max
        # only one of the two cells was filled in: the empty one counts as zero
        return 0 if value is None else value

    @property
    def reserved_size(self) -> int:
        """Bytes this value occupies: ``sizeof(value) * array size``.

        This one number drives both the ``MemoryOffset`` of every tag and the
        number of log ids a value reserves.
        """
        data_type = self.data_type
        if data_type is None:
            return 0
        return data_type.value_size * max(1, self.array_size)

    # -- tags -------------------------------------------------------------
    def tag(self, tag_id: str) -> TagValue:
        return self.tags.get(tag_id)

    def effective_tag(self, tag_id: str) -> TagValue:
        """The value of a tag as the generated code will see it.

        Only one tag is not simply what the cell says: ``LogID`` belongs to
        logging, so it exists only while ``Tag Loggable`` is TRUE.  A number
        left behind in the LogID cell of a value that is not logged means
        nothing - it must not reserve an id, must not clash with anything, and
        must not appear in the generated table.
        """
        from .tags import LOG_ID_TAG, LOGGABLE_TAG

        if tag_id == LOG_ID_TAG and not self.has_active_tag(LOGGABLE_TAG):
            return None
        return self.tags.get(tag_id)

    def has_active_tag(self, tag_id: str) -> bool:
        """Whether this value *carries* the tag.

        This is what decides whether it takes up room in that tag's offset
        area, so it goes through :meth:`effective_tag` - a log id on a
        non-loggable value reserves nothing.

        A boolean tag is carried when it is TRUE.  Any other tag is carried
        whenever a value is written, **including zero**: 0 is a perfectly good
        log id, and treating it as "no tag" would leave that value out of the
        offset area while the log-id rule still reserved ids for it - the two
        would then disagree about the memory map.
        """
        value = self.effective_tag(tag_id)
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            return True
        return str(value).strip() != ""

    # -- tree helpers ------------------------------------------------------
    def walk(self) -> Iterator["Parameter"]:
        """Yield this node and every node below it."""
        yield self
        for child in self.children:
            yield from child.walk()

    def enabled_children(self) -> List["Parameter"]:
        return [child for child in self.children if child.enable]

    def copy_as_leaf(self, dotted_name: str, c_object: str,
                     tags: Dict[str, TagValue]) -> "Parameter":
        """A flat copy of this leaf, as the code generator wants to see it."""
        return replace(self, name=dotted_name, c_object=c_object, tags=dict(tags),
                       children=[])

    def __str__(self) -> str:  # pragma: no cover - debugging helper
        if self.is_struct:
            return f"Parameter({self.name}, struct, {len(self.children)} field(s))"
        return f"Parameter({self.name}, {self.data_type_name}, x{self.array_size})"


def _is_zero_or_empty(value: NumericValue) -> bool:
    """An empty cell and a zero mean the same thing for a limit."""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return float(value) == 0.0

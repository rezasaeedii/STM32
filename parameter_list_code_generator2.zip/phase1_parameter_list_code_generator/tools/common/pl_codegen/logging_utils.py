"""Small console-logging helper shared by the whole tool."""

from __future__ import annotations

import logging
import sys

_LOGGER_NAME = "pl_codegen"
_FORMAT = "%(levelname)-8s %(message)s"


def setup_logging(verbose: bool = False, quiet: bool = False) -> logging.Logger:
    """Configure and return the tool-wide logger."""
    level = logging.DEBUG if verbose else (logging.WARNING if quiet else logging.INFO)

    logger = logging.getLogger(_LOGGER_NAME)
    logger.setLevel(level)
    logger.handlers.clear()

    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(_FORMAT))
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def get_logger() -> logging.Logger:
    """Return the tool-wide logger (already configured by :func:`setup_logging`)."""
    return logging.getLogger(_LOGGER_NAME)


def banner(text: str) -> str:
    """Return a simple visual separator used between pipeline stages."""
    return f"\n{'=' * 78}\n{text}\n{'=' * 78}"

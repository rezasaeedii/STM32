"""The shared pipeline: XML model -> validation -> tag offsets -> C files.

This module is the core of the tool and knows exactly one input: the XML model.

    XML  ->  model  ->  validation  ->  tag offsets  ->  C files

Where that XML comes from is the front end's business, not the core's.  In this
phase the graphical editor (``pl_gui``) writes it; the core never learns that,
which is what would let a different front end be put in front of it without
touching a line here.

Several model files can be listed - one per sub-module of the project - and
they are merged into one list before anything else happens.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from .codegen.c_style import CStyle
from .codegen.files import FILE_BUILDERS
from .config import Config
from .errors import CodeGeneratorError, DiagnosticCollector, Severity
from .layout.tag_offset import build_offset_map
from .logging_utils import banner, get_logger
from .model.parameter_list import ParameterList
from .validation.validator import Validator
from .xml_model.xml_reader import read_xml
from .layout.drift import LayoutDrift, compare as compare_layout, previous_build
from .xml_model.xml_writer import write_xml


@dataclass
class PipelineResult:
    """Everything a caller needs to report the outcome of a run."""

    success: bool
    diagnostics: DiagnosticCollector
    model_file: Optional[Path] = None
    generated_files: List[Path] = field(default_factory=list)
    parameter_count: int = 0
    #: What this run moved relative to the previous one.  See ``layout/drift.py``:
    #: a value that changed byte offset is a value a board in the field will read
    #: wrongly, so it is reported even though the code is perfectly correct.
    drift: Optional[LayoutDrift] = None


#: "work out the previous build yourself" - see Pipeline.generate
_READ_FROM_DISK = object()


class Pipeline:
    """Runs the code generator."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._logger = get_logger()

    # -- reading the model -----------------------------------------------
    def load_model(self, diagnostics: DiagnosticCollector,
                   model_file: Optional[Path] = None) -> ParameterList:
        """The merged parameter list of every configured sub-module."""
        paths = [model_file] if model_file else list(self._config.inputs.model_files)

        merged = ParameterList()
        for index, path in enumerate(paths):
            self._logger.info("  reading %s", path)
            if not path.is_file():
                raise CodeGeneratorError(
                    f"The model file '{path}' does not exist.\n"
                    f"Create it with the phase's own front end, or fix "
                    f"'inputs.model_files' "
                    f"in {self._config.path.name}.")
            part = read_xml(path, diagnostics)
            if str(path) not in part.source_files:
                part.source_files.append(str(path))
            if index == 0:
                merged = part
            else:
                merged.extend(part)

        if len(paths) > 1:
            self._logger.info("  merged %d module(s) into one list", len(paths))
        return merged

    def generate(self, model: ParameterList, diagnostics: DiagnosticCollector,
                 previous: object = _READ_FROM_DISK) -> PipelineResult:
        """Validate *model* and write the C files.

        *previous* is the model the last build used; it is what the memory
        layout is compared against.  By default it is read from
        ``output.xml_file``, which is exactly where the previous run left it.
        A front end that writes that file itself before generating has to
        capture the old one first and pass it in here, or it would end up
        comparing the new model with itself.
        """
        if not Validator(self._config).validate(model, diagnostics):
            return PipelineResult(False, diagnostics)

        if previous is _READ_FROM_DISK:
            previous = previous_build(self._config.output.xml_file)
        drift = compare_layout(previous, model)

        offsets = build_offset_map(model)
        style = CStyle.load(self._config.style.snippet_file,
                            company=self._config.style.company,
                            indent=self._config.style.indent)

        generated: List[Path] = []
        directory = self._config.output.code_directory

        for builder_class in FILE_BUILDERS:
            builder = builder_class(model, self._config, offsets, style)
            path = builder.save(directory)
            generated.append(path)
            self._logger.info("  generated %s (%d lines)", path.name,
                              path.read_text(encoding="utf-8").count("\n"))

        # The copy of the merged model is what the NEXT run compares against, so
        # it is written last - only a run that got this far counts as "what the
        # firmware was built from".
        try:
            write_xml(model, self._config.output.xml_file,
                      emit_timestamp=self._config.codegen.emit_timestamp)
        except OSError as error:                 # a courtesy file, never fatal
            self._logger.warning("  could not write the model copy: %s", error)

        if drift.breaks_stored_data:
            self._logger.warning("  %s", drift.summary())

        return PipelineResult(True, diagnostics, self._config.inputs.model_file,
                              generated, len(model.flatten()), drift)


    def run(self, model_file: Optional[Path] = None) -> PipelineResult:
        """Read the model file(s) and produce the C files."""
        diagnostics = DiagnosticCollector()
        self._logger.info(banner("Reading the parameter list"))
        model = self.load_model(diagnostics, model_file)
        self._logger.info("  %d top level parameter(s), %d value(s) after flattening",
                          len(model), len(model.flatten()))

        self._logger.info(banner("Generating the C code"))
        return self.generate(model, diagnostics)

    def check(self, model_file: Optional[Path] = None) -> PipelineResult:
        """Validate the model without writing any file at all."""
        diagnostics = DiagnosticCollector()
        self._logger.info(banner("Checking the parameter list"))
        model = self.load_model(diagnostics, model_file)
        self._logger.info("  %d top level parameter(s), %d value(s) after flattening",
                          len(model), len(model.flatten()))
        ok = Validator(self._config).validate(model, diagnostics)
        return PipelineResult(ok, diagnostics, self._config.inputs.model_file,
                              parameter_count=len(model.flatten()))


def render_diagnostics(diagnostics: DiagnosticCollector, verbose: bool) -> str:
    """Format the diagnostics for the console."""
    minimum = Severity.INFO if verbose else Severity.WARNING
    return diagnostics.render(minimum)

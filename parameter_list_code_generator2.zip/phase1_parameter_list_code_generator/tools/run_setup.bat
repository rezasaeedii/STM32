@echo off
REM ===========================================================================
REM  Installs what the tool needs (openpyxl).  Run this once, on a machine
REM  that has internet for a few minutes.  Double-click this file.
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_setup.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     Ready. You can now double-click run_generate.bat.
) else (
    echo     Setup did not finish. Read the message above - it says what is
    echo     missing and what to do about it.
)

echo.
pause
exit /b %EXITCODE%

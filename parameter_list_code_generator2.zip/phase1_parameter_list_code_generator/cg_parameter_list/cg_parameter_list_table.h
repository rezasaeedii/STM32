/**
  ******************************************************************************
  * @file    cg_parameter_list_table.h
  * @brief   The parameter list, drawn as a table. Documentation only - no code.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 10:44:10 +0000
  * Input file(s)  : /home/claude/phase1/parameter_list_template.xlsx
  * Parameters     : 5 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TABLE_H
#define CG_PARAMETER_LIST_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
/* Exported defines --------------------------------------------------------- */
/*
  Parameter list - values

  +---+----+--------------+------------+------------+-----------+-----+---------+------+-------+------+------+
  | # | En | Name         | GS Name    | Group      | DataType  | Arr | Default | Min  | Max   | Res  | Unit |
  +---+----+--------------+------------+------------+-----------+-----+---------+------+-------+------+------+
  | 0 | x  | PosDrone     | PosDrone   | MONITORING | bool_t    | 1   | TRUE    | -    | -     | -    | -    |
  | 1 | x  | VelDrone     | VelDrone   | MONITORING | float64_t | 6   | 2       | -10  | 10    | 0.01 | m/s  |
  | 2 | x  | Altitude     | Altitude   | MONITORING | float32_t | 1   | 0       | -500 | 10000 | 0.01 | m    |
  | 3 | x  | FullRange    | Full range | SETTING    | int32_t   | 1   | 500     | 0    | 0     | 1    | -    |
  | 4 | x  | Samples      | Samples    | MONITORING | int16_t   | 67  | 1       | -1   | 1     | 1    | -    |
  | - |    | Mode         | Mode       | COMMAND    | uint8_t   | 1   | 0       | 0    | 5     | 1    | -    |
  | - |    | OldParameter | -          | SETTING    | int32_t   | 1   | 1       | 0    | 100   | 1    | -    |
  +---+----+--------------+------------+------------+-----------+-----+---------+------+-------+------+------+

  '#' is the index in the parameter list, the value of the matching
  #define in the defines header. A structure is not a row of the table,
  so it has no index of its own; only the values inside it have one.
*/

/*
  Parameter list - tags

  +---+--------------+------------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
  | # | Name         | SystemName       | ResetProof | Loggable | LogId | LogEncryption | ParamMode            | Tag1 | Tag2 | Tag3 | Tag4 | LogID range |
  +---+--------------+------------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
  | 0 | PosDrone     | SYS_GS_COMPUTER  | x          | x        | 100   | x             | PARAM_MODE_USER      | -    | -    | -    | -    | 100         |
  | 1 | VelDrone     | SYS_NAV          | x          | x        | 104   |               | PARAM_MODE_USER      | -    | -    | -    | -    | 104..109    |
  | 2 | Altitude     | SYS_NAV          |            | x        | 110   |               | PARAM_MODE_USER      | -    | -    | -    | -    | 110         |
  | 3 | FullRange    | SYS_NAV          | x          |          | 152   |               | PARAM_MODE_USER      | -    | -    | -    | -    | 152         |
  | 4 | Samples      | SYS_AND          |            |          | 56    |               | PARAM_MODE_READ_ONLY | -    | -    | -    | -    | 56..122     |
  | - | Mode         | SYS_AC_AUTOPILOT | x          |          | -     |               | PARAM_MODE_FACTORY   | 7    | -    | -    | -    | -           |
  | - | OldParameter | SYS_UNKNOWN      |            |          | -     |               | PARAM_MODE_USER      | -    | -    | -    | -    | -           |
  +---+--------------+------------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
*/

/*
  MemoryOffset of every parameter, per tag

  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+
  | # | Name          | Bytes | SystemName | ResetProof | Loggable | LogId | LogEncryption | ParamMode |
  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+
  | 0 | PosDrone      | 1     | 0          | 0          | 0        | 0     | 0             | 0         |
  | 1 | VelDrone      | 48    | 1          | 1          | 1        | 1     | -             | 1         |
  | 2 | Altitude      | 4     | 49         | -          | 49       | 49    | -             | 49        |
  | 3 | FullRange     | 4     | 53         | 49         | -        | -     | -             | 53        |
  | 4 | Samples       | 134   | 57         | -          | -        | -     | -             | 57        |
  |   | TOTAL (bytes) |       | 191        | 53         | 53       | 53    | 1             | 191       |
  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+

  Every tag owns an independent counter that starts at 0 and advances by
  sizeof(value) * ArraySize for every parameter that carries the tag.
  '-' means the tag is not active for that parameter, so its offset is 0.
*/

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TABLE_H */

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_smart_data.c
  * @brief   Definition and construction of the generated smart-data objects.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 10:44:10 +0000
  * Input file(s)  : /home/claude/phase1/parameter_list_template.xlsx
  * Parameters     : 5 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_smart_data.h"
#include "smart_data.h"
#include <stdint.h>

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
sSmartDataB8 Cg_SmartData_PosDrone;
sSmartDataF64 Cg_SmartData_VelDrone[VEL_DRONE_ARRAY_SIZE];
sSmartDataF32 Cg_SmartData_Altitude;
sSmartDataI32 Cg_SmartData_FullRange;
sSmartDataI16 Cg_SmartData_Samples[SAMPLES_ARRAY_SIZE];

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Constructs every generated smart-data object.
 *
 * @return uint8_t 0 on success, otherwise the failing eSmartDataStatus value.
 */
uint8_t fCgSmartData_Init(void) {

    eSmartDataStatus status = eSMART_DATA_OK;
    uint16_t index = 0U;

    status = fSmartData_B8_Ctor(&Cg_SmartData_PosDrone, TRUE);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < VEL_DRONE_ARRAY_SIZE; index++) {
        status = fSmartData_F64_Ctor(&Cg_SmartData_VelDrone[index], -10.0, 10.0, 2.0, 0.01);
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Altitude, -500.0f, 10000.0f, 0.0f, 0.01f);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_I32_Ctor(&Cg_SmartData_FullRange, INT32_MIN, INT32_MAX, 500L, 1L);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < SAMPLES_ARRAY_SIZE; index++) {
        status = fSmartData_I16_Ctor(&Cg_SmartData_Samples[index], (-1), 1, 1, 1);
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    return (uint8_t)status;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

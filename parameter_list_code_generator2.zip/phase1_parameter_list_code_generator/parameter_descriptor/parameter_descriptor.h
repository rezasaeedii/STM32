/**
  ******************************************************************************
  * @file    parameter_descriptor.h
  * @brief   Hand written description of one parameter of the parameter list.
  *
  * This file is NOT generated; it defines the shape of the table that the code
  * generator fills in. Whenever a field is added here, the field order in
  * tools/pl_codegen/codegen/descriptor_layout.py has to be updated as well,
  * because the generated initialiser uses designated initialisers in
  * declaration order (valid in C99 and in C++20).
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef PARAMETER_DESCRIPTOR_H
#define PARAMETER_DESCRIPTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

#include "smart_data.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Functional group a parameter belongs to.
 *
 */
typedef enum {

    ePARAMETER_GROUP_MONITORING = 0,
    ePARAMETER_GROUP_SETTING,
    ePARAMETER_GROUP_COMMAND

} eParameterListDescriptorGroup;

/**
 * @brief One tag of a parameter.
 *
 * @note  Value is wide enough to hold a boolean flag, an enumerator of the
 *        generated enumerations and a log identifier.
 * @note  MemoryOffset is the byte offset of this parameter inside the area
 *        that belongs to this tag. Every tag owns an independent area whose
 *        cursor advances by sizeof(value) * ArraySize for every parameter
 *        carrying the tag, so the same parameter usually has a different
 *        offset per tag. The offsets are computed by the code generator and
 *        exported as macros in cg_parameter_list_defines.h.
 *
 */
typedef struct {

    uint32_t Value;

    uint32_t MemoryOffset;

} sParameterListDescriptorTag;

/**
 * @brief Full description of one parameter.
 *
 * @note  The fields must stay in this order; the generated table relies on it.
 *
 */
typedef struct {

    const char * pName;                         /*!< Name of the parameter, as written in the Excel sheet. */

    eParameterListDescriptorGroup Group;        /*!< Functional group of the parameter. */

    void * pSmartData;                          /*!< Smart data object holding the value. Points at the first element for an array parameter. */

    uint16_t ArraySize;                         /*!< Number of smart data objects behind pSmartData (1 for a scalar parameter). */

    const char * pUnit;                         /*!< Physical unit of the value, or NULL. */

    sParameterListDescriptorTag TagSystemName;

    sParameterListDescriptorTag TagResetProof;

    sParameterListDescriptorTag TagLoggable;

    sParameterListDescriptorTag TagLogId;

    sParameterListDescriptorTag TagLogEncryption;

    sParameterListDescriptorTag TagParamMode;

    sParameterListDescriptorTag Tag1;

    sParameterListDescriptorTag Tag2;

    sParameterListDescriptorTag Tag3;

    sParameterListDescriptorTag Tag4;

    const char * pDescription;                  /*!< Free text description, or NULL. */

} sParameterDescriptor;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* PARAMETER_DESCRIPTOR_H */

/* === Copyright (c) 2026 FAS === EOF === */

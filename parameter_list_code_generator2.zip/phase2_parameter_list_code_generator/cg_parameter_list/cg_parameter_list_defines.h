/**
  ******************************************************************************
  * @file    cg_parameter_list_defines.h
  * @brief   Quantities, parameter indices, tag offsets and generated enumerations.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_DEFINES_H
#define CG_PARAMETER_LIST_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stdint.h>

/* Exported defines --------------------------------------------------------- */
/* Number of parameters in the parameter list */
#define PARAMETER_LIST_QTY  (11U)  /*!< Number of enabled parameters */

/* Index of every parameter inside the parameter list */
#define AIRSPEED               (0U)   /*!< float32_t [m/s] */
#define POSITION_HOME_LAT      (1U)   /*!< float64_t [deg] */
#define POSITION_HOME_LON      (2U)   /*!< float64_t [deg] */
#define POSITION_ALT           (3U)   /*!< float32_t [m] */
#define POSITION_SAMPLES       (4U)   /*!< int16_t[8] */
#define POSITION_HEADING       (5U)   /*!< float32_t [deg] */
#define MODE                   (6U)   /*!< uint8_t */
#define NAV_ENABLE             (7U)   /*!< bool_t */
#define NAV_STATUS_FIX_TYPE    (8U)   /*!< uint8_t */
#define NAV_STATUS_SATELLITES  (9U)   /*!< uint8_t */
#define NAV_STATUS_HDOP        (10U)  /*!< float32_t */

/* Array size of every array parameter */
#define POSITION_SAMPLES_ARRAY_SIZE  (8U)  /*!< Number of elements of 'Position.Samples' */

/* Total size used by every tag */
#define PARAMETER_LIST_SIZE_SYSTEM_NAME  (52U)  /*!< Bytes used by tag 'SystemName' (11 parameter(s)) */
#define PARAMETER_LIST_SIZE_RESET_PROOF  (50U)  /*!< Bytes used by tag 'ResetProof' (9 parameter(s)) */
#define PARAMETER_LIST_SIZE_LOGGABLE     (50U)  /*!< Bytes used by tag 'Loggable' (9 parameter(s)) */
#define PARAMETER_LIST_SIZE_LOG_ID       (50U)  /*!< Bytes used by tag 'LogId' (9 parameter(s)) */
#define PARAMETER_LIST_SIZE_PARAM_MODE   (52U)  /*!< Bytes used by tag 'ParamMode' (11 parameter(s)) */

/* MemoryOffset of every parameter, per tag */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_AIRSPEED               (0U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HOME_LAT      (4U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HOME_LON      (12U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_ALT           (20U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_SAMPLES       (24U)  /*!< 16 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HEADING       (40U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_MODE                   (44U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_ENABLE             (45U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_FIX_TYPE    (46U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_SATELLITES  (47U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_HDOP        (48U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_AIRSPEED               (0U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HOME_LAT      (4U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HOME_LON      (12U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_ALT           (20U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_SAMPLES       (24U)  /*!< 16 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HEADING       (40U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_FIX_TYPE    (44U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_SATELLITES  (45U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_HDOP        (46U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_AIRSPEED                  (0U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HOME_LAT         (4U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HOME_LON         (12U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_ALT              (20U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_SAMPLES          (24U)  /*!< 16 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HEADING          (40U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_FIX_TYPE       (44U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_SATELLITES     (45U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_HDOP           (46U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_AIRSPEED                    (0U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HOME_LAT           (4U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HOME_LON           (12U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POSITION_ALT                (20U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POSITION_SAMPLES            (24U)  /*!< 16 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HEADING            (40U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_FIX_TYPE         (44U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_SATELLITES       (45U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_HDOP             (46U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_AIRSPEED                (0U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HOME_LAT       (4U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HOME_LON       (12U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_ALT            (20U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_SAMPLES        (24U)  /*!< 16 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HEADING        (40U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_MODE                    (44U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_ENABLE              (45U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_FIX_TYPE     (46U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_SATELLITES   (47U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_HDOP         (48U)  /*!< 4 byte(s) */

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Values of the 'SYSTEM NAMES' list of the parameter list.
 *
 */
typedef enum {

    SYS_UNKNOWN         = 0,
    SYS_GS_COMPUTER     = 1,
    SYS_GS_MANAGER      = 2,
    SYS_GS_POWER        = 3,
    SYS_ANTENNA_TRACKER = 4,
    SYS_AC_MANAGER      = 5,
    SYS_AC_POWER        = 6,
    SYS_AC_AUTOPILOT    = 7,
    SYS_GIMBAL          = 8,
    SYS_LOCK_TRACK      = 9,
    SYS_LINK_GS         = 10,
    SYS_GS_USB2CAN      = 11,
    SYS_LINK_AIR        = 12,
    SYS_BOOTLOADER      = 13,
    SYS_LINK_BOX        = 14,
    SYS_GOVERNOR        = 15,
    SYS_NAV             = 16,
    SYS_AND             = 17,
    SYS_VNS             = 18,
    SYS_RHS             = 19,
    SYS_AUP             = 20

} eParameterListSystemName;

/**
 * @brief Values of the 'PARAM MODES' list of the parameter list.
 *
 */
typedef enum {

    PARAM_MODE_USER         = 0,
    PARAM_MODE_READ_ONLY    = 1,
    PARAM_MODE_PRODUCT_TYPE = 2,
    PARAM_MODE_FACTORY      = 3,
    PARAM_MODE_CALIB        = 4,
    PARAM_MODE_TEMPORARY    = 5

} eParameterListParamMode;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_DEFINES_H */

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_smart_data.c
  * @brief   Definition and construction of the generated smart-data objects.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_smart_data.h"
#include "smart_data.h"
#include <stdint.h>
#include <float.h>

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
sSmartDataF32 Cg_SmartData_Airspeed;
sCgStruct_Position Cg_SmartData_Position;
sSmartDataU8 Cg_SmartData_Mode;
sSmartDataB8 Cg_SmartData_NavEnable;
sCgStruct_NavStatus Cg_SmartData_NavStatus;

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Constructs every generated smart-data object.
 *
 * @return uint8_t 0 on success, otherwise the failing eSmartDataStatus value.
 */
uint8_t fCgSmartData_Init(void) {

    eSmartDataStatus status = eSMART_DATA_OK;
    uint16_t index = 0U;

    status = fSmartData_F32_Ctor(&Cg_SmartData_Airspeed, 0.0f, 100.0f, 0.0f, 0.1f);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F64_Ctor(&Cg_SmartData_Position.Home.Lat, -90.0, 90.0, 0.0, 1.0e-07);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F64_Ctor(&Cg_SmartData_Position.Home.Lon, -180.0, 180.0, 0.0, 1.0e-07);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Position.Alt, -500.0f, 10000.0f, 0.0f, 0.01f);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < POSITION_SAMPLES_ARRAY_SIZE; index++) {
        status = fSmartData_I16_Ctor(&Cg_SmartData_Position.Samples[index], (-100), 100, 0, 1);
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Position.Heading, 0.0f, 360.0f, 0.0f, 0.1f);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_U8_Ctor(&Cg_SmartData_Mode, 0U, 5U, 0U, 1U);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_B8_Ctor(&Cg_SmartData_NavEnable, FALSE);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_U8_Ctor(&Cg_SmartData_NavStatus.FixType, 0U, UINT8_MAX, 0U, 1U);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_U8_Ctor(&Cg_SmartData_NavStatus.Satellites, 0U, UINT8_MAX, 0U, 1U);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_NavStatus.Hdop, -FLT_MAX, FLT_MAX, 0.0f, 1.0f);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    return (uint8_t)status;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_parameter_list_table.h
  * @brief   The parameter list, drawn as a table. Documentation only - no code.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TABLE_H
#define CG_PARAMETER_LIST_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
/* Exported defines --------------------------------------------------------- */
/*
  Parameter list - values

  +----+----+--------------+------------+------------+-----------+-----+---------+------+-------+-------+------+
  | #  | En | Name         | GS Name    | Group      | DataType  | Arr | Default | Min  | Max   | Res   | Unit |
  +----+----+--------------+------------+------------+-----------+-----+---------+------+-------+-------+------+
  | 0  | x  | Airspeed     | Airspeed   | MONITORING | float32_t | 1   | 0       | 0    | 100   | 0.1   | m/s  |
  | -  | x  | Position     | -          | MONITORING | struct    | 1   | -       | -    | -     | -     | -    |
  | -  | x  |   Home       | -          | -          | struct    | 1   | -       | -    | -     | -     | -    |
  | 1  | x  |     Lat      | HomeLat    | -          | float64_t | 1   | 0       | -90  | 90    | 1e-07 | deg  |
  | 2  | x  |     Lon      | HomeLon    | -          | float64_t | 1   | 0       | -180 | 180   | 1e-07 | deg  |
  | 3  | x  |   Alt        | Alt        | -          | float32_t | 1   | 0       | -500 | 10000 | 0.01  | m    |
  | 4  | x  |   Samples    | Samples    | -          | int16_t   | 8   | 0       | -100 | 100   | 1     | -    |
  | 5  | x  |   Heading    | Heading    | -          | float32_t | 1   | 0       | 0    | 360   | 0.1   | deg  |
  | 6  | x  | Mode         | Mode       | SETTING    | uint8_t   | 1   | 0       | 0    | 5     | 1     | -    |
  | 7  | x  | NavEnable    | NavEnable  | MONITORING | bool_t    | 1   | FALSE   | -    | -     | -     | -    |
  | -  | x  | NavStatus    | -          | MONITORING | struct    | 1   | -       | -    | -     | -     | -    |
  | 8  | x  |   FixType    | FixType    | -          | uint8_t   | 1   | 0       | 0    | 0     | 1     | -    |
  | 9  | x  |   Satellites | Satellites | -          | uint8_t   | 1   | 0       | 0    | 0     | 1     | -    |
  | 10 | x  |   Hdop       | Hdop       | -          | float32_t | 1   | 0       | 0    | 0     | 1     | -    |
  +----+----+--------------+------------+------------+-----------+-----+---------+------+-------+-------+------+

  '#' is the index in the parameter list, the value of the matching
  #define in the defines header. A structure is not a row of the table,
  so it has no index of its own; only the values inside it have one.
*/

/*
  Parameter list - tags

  +---+-----------+------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
  | # | Name      | SystemName | ResetProof | Loggable | LogId | LogEncryption | ParamMode            | Tag1 | Tag2 | Tag3 | Tag4 | LogID range |
  +---+-----------+------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
  | 0 | Airspeed  | SYS_NAV    | x          | x        | 100   |               | PARAM_MODE_USER      | -    | -    | -    | -    | 100         |
  | - | Position  | SYS_NAV    | x          | x        | 104   |               | PARAM_MODE_USER      | -    | -    | -    | -    | 104..115    |
  | 6 | Mode      | SYS_NAV    |            |          | -     |               | PARAM_MODE_READ_ONLY | -    | -    | -    | -    | -           |
  | 7 | NavEnable | SYS_NAV    |            |          | -     |               | PARAM_MODE_FACTORY   | -    | -    | -    | -    | -           |
  | - | NavStatus | SYS_NAV    | x          | x        | 2000  |               | PARAM_MODE_USER      | -    | -    | -    | -    | 2000..2002  |
  +---+-----------+------------+------------+----------+-------+---------------+----------------------+------+------+------+------+-------------+
*/

/*
  MemoryOffset of every parameter, per tag

  +----+----------------------+-------+------------+------------+----------+-------+-----------+
  | #  | Name                 | Bytes | SystemName | ResetProof | Loggable | LogId | ParamMode |
  +----+----------------------+-------+------------+------------+----------+-------+-----------+
  | 0  | Airspeed             | 4     | 0          | 0          | 0        | 0     | 0         |
  | 1  | Position.Home.Lat    | 8     | 4          | 4          | 4        | 4     | 4         |
  | 2  | Position.Home.Lon    | 8     | 12         | 12         | 12       | 12    | 12        |
  | 3  | Position.Alt         | 4     | 20         | 20         | 20       | 20    | 20        |
  | 4  | Position.Samples     | 16    | 24         | 24         | 24       | 24    | 24        |
  | 5  | Position.Heading     | 4     | 40         | 40         | 40       | 40    | 40        |
  | 6  | Mode                 | 1     | 44         | -          | -        | -     | 44        |
  | 7  | NavEnable            | 1     | 45         | -          | -        | -     | 45        |
  | 8  | NavStatus.FixType    | 1     | 46         | 44         | 44       | 44    | 46        |
  | 9  | NavStatus.Satellites | 1     | 47         | 45         | 45       | 45    | 47        |
  | 10 | NavStatus.Hdop       | 4     | 48         | 46         | 46       | 46    | 48        |
  |    | TOTAL (bytes)        |       | 52         | 50         | 50       | 50    | 52        |
  +----+----------------------+-------+------------+------------+----------+-------+-----------+

  Every tag owns an independent counter that starts at 0 and advances by
  sizeof(value) * ArraySize for every parameter that carries the tag.
  '-' means the tag is not active for that parameter, so its offset is 0.
*/

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TABLE_H */

/* === Copyright (c) 2026 FAS === EOF === */

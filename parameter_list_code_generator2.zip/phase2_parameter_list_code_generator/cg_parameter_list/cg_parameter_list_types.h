/**
  ******************************************************************************
  * @file    cg_parameter_list_types.h
  * @brief   Structure types generated from the structures of the parameter list.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TYPES_H
#define CG_PARAMETER_LIST_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Structure parameter 'Position.Home'.
 *
 * @note  Home point.
 */
typedef struct {

    sSmartDataF64 Lat;  /*!< [deg] Latitude of the home point. */
    sSmartDataF64 Lon;  /*!< [deg] Longitude of the home point. */

} sCgStruct_Position_Home;

/**
 * @brief Structure parameter 'Position'.
 *
 * @note  Vehicle position.
 */
typedef struct {

    sCgStruct_Position_Home Home;  /*!< Home point. */
    sSmartDataF32           Alt;  /*!< [m] Altitude above the home point. */
    sSmartDataI16           Samples[POSITION_SAMPLES_ARRAY_SIZE];  /*!< Last raw samples, not logged. */
    sSmartDataF32           Heading;  /*!< [deg] Heading over ground. */

} sCgStruct_Position;

/**
 * @brief Structure parameter 'NavStatus'.
 *
 * @note  Navigation solution status.
 */
typedef struct {

    sSmartDataU8  FixType;  /*!< 0=none 1=2D 2=3D. */
    sSmartDataU8  Satellites;  /*!< Satellites in use. */
    sSmartDataF32 Hdop;  /*!< Horizontal dilution. */

} sCgStruct_NavStatus;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TYPES_H */

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_smart_data.h
  * @brief   Smart-data objects that hold the value of every parameter.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_SMART_DATA_H
#define CG_SMART_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"
#include "cg_parameter_list_types.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
uint8_t fCgSmartData_Init(void);

/* Exported variables ------------------------------------------------------- */
extern sSmartDataF32 Cg_SmartData_Airspeed;  /*!< [m/s] Indicated airspeed. */
extern sCgStruct_Position Cg_SmartData_Position;  /*!< Vehicle position. */
extern sSmartDataU8 Cg_SmartData_Mode;  /*!< Active flight mode. */
extern sSmartDataB8 Cg_SmartData_NavEnable;  /*!< Navigation task enabled. */
extern sCgStruct_NavStatus Cg_SmartData_NavStatus;  /*!< Navigation solution status. */

#ifdef __cplusplus
}
#endif

#endif /* CG_SMART_DATA_H */

/* === Copyright (c) 2026 FAS === EOF === */

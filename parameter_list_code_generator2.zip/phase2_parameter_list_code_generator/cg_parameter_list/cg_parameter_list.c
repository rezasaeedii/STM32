/**
  ******************************************************************************
  * @file    cg_parameter_list.c
  * @brief   Generated parameter list and its access functions.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-02 15:27:49 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  * Parameters     : 11 value(s) in 3 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_parameter_list.h"

#include <stddef.h>
#include <string.h>

#include "smart_data.h"
#include "cg_smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
/**
 * @brief Descriptor of every parameter of the merged parameter list. The order of the entries matches the index macros of 'cg_parameter_list_defines.h'.
 *
 */
const sParameterDescriptor ParameterList[PARAMETER_LIST_QTY] = {
    /* [0] AIRSPEED */
    {
        .pName = "Airspeed",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Airspeed,
        .ArraySize = 1U,
        .pUnit = "m/s",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_AIRSPEED },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_AIRSPEED },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_AIRSPEED },
        .TagLogId = { .Value = 100U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_AIRSPEED },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_AIRSPEED },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Indicated airspeed."
    },

    /* [1] POSITION_HOME_LAT */
    {
        .pName = "Position.Home.Lat",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Home.Lat,
        .ArraySize = 1U,
        .pUnit = "deg",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HOME_LAT },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HOME_LAT },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HOME_LAT },
        .TagLogId = { .Value = 104U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HOME_LAT },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HOME_LAT },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of the home point."
    },

    /* [2] POSITION_HOME_LON */
    {
        .pName = "Position.Home.Lon",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Home.Lon,
        .ArraySize = 1U,
        .pUnit = "deg",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HOME_LON },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HOME_LON },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HOME_LON },
        .TagLogId = { .Value = 105U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HOME_LON },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HOME_LON },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Longitude of the home point."
    },

    /* [3] POSITION_ALT */
    {
        .pName = "Position.Alt",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Alt,
        .ArraySize = 1U,
        .pUnit = "m",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_ALT },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_ALT },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_ALT },
        .TagLogId = { .Value = 106U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POSITION_ALT },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_ALT },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Altitude above the home point."
    },

    /* [4] POSITION_SAMPLES */
    {
        .pName = "Position.Samples",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[0],
        .ArraySize = POSITION_SAMPLES_ARRAY_SIZE,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_SAMPLES },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_SAMPLES },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_SAMPLES },
        .TagLogId = { .Value = 107U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POSITION_SAMPLES },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_SAMPLES },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Last raw samples, not logged."
    },

    /* [5] POSITION_HEADING */
    {
        .pName = "Position.Heading",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Heading,
        .ArraySize = 1U,
        .pUnit = "deg",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POSITION_HEADING },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POSITION_HEADING },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POSITION_HEADING },
        .TagLogId = { .Value = 115U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POSITION_HEADING },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POSITION_HEADING },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Heading over ground."
    },

    /* [6] MODE */
    {
        .pName = "Mode",
        .Group = ePARAMETER_GROUP_SETTING,
        .pSmartData = (void *)&Cg_SmartData_Mode,
        .ArraySize = 1U,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_MODE },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_READ_ONLY, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_MODE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Active flight mode."
    },

    /* [7] NAV_ENABLE */
    {
        .pName = "NavEnable",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavEnable,
        .ArraySize = 1U,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_ENABLE },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_FACTORY, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_ENABLE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Navigation task enabled."
    },

    /* [8] NAV_STATUS_FIX_TYPE */
    {
        .pName = "NavStatus.FixType",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.FixType,
        .ArraySize = 1U,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_FIX_TYPE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_FIX_TYPE },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_FIX_TYPE },
        .TagLogId = { .Value = 2000U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_FIX_TYPE },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_FIX_TYPE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "0=none 1=2D 2=3D."
    },

    /* [9] NAV_STATUS_SATELLITES */
    {
        .pName = "NavStatus.Satellites",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Satellites,
        .ArraySize = 1U,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_SATELLITES },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_SATELLITES },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_SATELLITES },
        .TagLogId = { .Value = 2001U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_SATELLITES },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_SATELLITES },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Satellites in use."
    },

    /* [10] NAV_STATUS_HDOP */
    {
        .pName = "NavStatus.Hdop",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop,
        .ArraySize = 1U,
        .pUnit = "",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_NAV_STATUS_HDOP },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_NAV_STATUS_HDOP },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_NAV_STATUS_HDOP },
        .TagLogId = { .Value = 2002U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_NAV_STATUS_HDOP },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_NAV_STATUS_HDOP },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution."
    }
};

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Initialises the parameter list and every smart-data object.
 *
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
uint8_t fParameterList_Init(void) {

    uint8_t result = 0U;

    result = fCgSmartData_Init();
    if (result != 0U) {
        return result;
    }

    result = fParameterList_InitCompletedCallback();
    if (result != 0U) {
        return result;
    }

    return result;

}

/**
 * @brief Called once the parameter list has been initialised.
 *
 * @note  Implement this function in the application layer without the weak specifier to hook into the initialisation.
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
PARAMETER_LIST_WEAK uint8_t fParameterList_InitCompletedCallback(void) {

    return 0U;

}

/**
 * @brief Returns the number of parameters in the list.
 *
 * @return uint16_t Always PARAMETER_LIST_QTY.
 */
uint16_t fParameterList_GetQuantity(void) {

    return (uint16_t)PARAMETER_LIST_QTY;

}

/**
 * @brief Returns the descriptor of the parameter at *index*.
 *
 * @param index Index of the parameter, see 'cg_parameter_list_defines.h'.
 * @return const sParameterDescriptor* NULL when the index is out of range.
 */
const sParameterDescriptor * fParameterList_GetByIndex(uint16_t index) {

    if (index >= (uint16_t)PARAMETER_LIST_QTY) {
        return NULL;
    }

    return &ParameterList[index];

}

/**
 * @brief Returns the descriptor of the parameter called *pName*.
 *
 * @param pName Name of the parameter; a field of a structure is  *              listed under its dotted name, e.g. "Position.Home.Lat".
 * @return const sParameterDescriptor* NULL when no such parameter exists.
 */
const sParameterDescriptor * fParameterList_GetByName(const char *pName) {

    uint16_t index = 0U;

    if (pName == NULL) {
        return NULL;
    }

    for (index = 0U; index < (uint16_t)PARAMETER_LIST_QTY; index++) {
        if (strcmp(ParameterList[index].pName, pName) == 0) {
            return &ParameterList[index];
        }
    }

    return NULL;

}

/**
 * @brief Total number of bytes reserved by the 'SystemName' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_SIZE_SYSTEM_NAME.
 */
uint32_t fParameterList_GetSystemNameSize(void) {

    return (uint32_t)PARAMETER_LIST_SIZE_SYSTEM_NAME;

}

/**
 * @brief Total number of bytes reserved by the 'ResetProof' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_SIZE_RESET_PROOF.
 */
uint32_t fParameterList_GetResetProofSize(void) {

    return (uint32_t)PARAMETER_LIST_SIZE_RESET_PROOF;

}

/**
 * @brief Total number of bytes reserved by the 'Loggable' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_SIZE_LOGGABLE.
 */
uint32_t fParameterList_GetLoggableSize(void) {

    return (uint32_t)PARAMETER_LIST_SIZE_LOGGABLE;

}

/**
 * @brief Total number of bytes reserved by the 'LogId' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_SIZE_LOG_ID.
 */
uint32_t fParameterList_GetLogIdSize(void) {

    return (uint32_t)PARAMETER_LIST_SIZE_LOG_ID;

}

/**
 * @brief Total number of bytes reserved by the 'ParamMode' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_SIZE_PARAM_MODE.
 */
uint32_t fParameterList_GetParamModeSize(void) {

    return (uint32_t)PARAMETER_LIST_SIZE_PARAM_MODE;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

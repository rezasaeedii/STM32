"""Rules about the drop-down lists ("Choices..." in the editor).

Those lists are not just a set of allowed words: two of them are written
straight into the generated header as C ``enum`` enumerators.  Whatever is typed
there ends up in the firmware, so it has to be a legal C identifier - nothing
else in the tool checks that.
"""

from __future__ import annotations

from typing import Dict, List

from ...errors import DiagnosticCollector, SourceLocation
from ...model.defines import GENERATED_ENUMS
from ...model.parameter_list import ParameterList
from ...naming import is_reserved_keyword, is_valid_c_identifier
from .rule_base import ValidationRule


class DefinesSheetRule(ValidationRule):
    """Every value that becomes an enumerator must be a usable C identifier.

    Without this, a *SYSTEM NAMES* entry written as ``GS / PC`` produces::

        typedef enum {
            SYS_NAV = 0,
            GS / PC = 1,        /* does not compile */
        } eParameterListSystemName;

    and the tool reports nothing at all.
    """

    rule_id = "DEFINES"
    description = "Values that become C enumerators must be unique, valid identifiers."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        location = SourceLocation(file=", ".join(model.source_files) or None)

        #: enumerator -> the column it came from, across every generated enum
        everywhere: Dict[str, str] = {}

        for column, type_name in GENERATED_ENUMS.items():
            values: List[str] = model.defines.get(column)

            if not values:
                diagnostics.error(
                    "DEF001",
                    f"The '{column}' list is empty, so 'enum {type_name}' cannot "
                    f"be generated.",
                    location,
                    hint=f"Every value a tag uses has to be listed under '{column}' "
                         f"(the \"Choices...\" dialog), or the generated code will "
                         f"not compile.")
                continue

            for value in values:
                text = str(value).strip()

                if not is_valid_c_identifier(text):
                    diagnostics.error(
                        "DEF002",
                        f"'{text}' in the '{column}' column is not a valid C identifier, "
                        f"and it becomes an enumerator of 'enum {type_name}'.",
                        location,
                        hint="Use letters, digits and '_' only, and do not start with "
                             "a digit.")
                elif is_reserved_keyword(text):
                    diagnostics.error(
                        "DEF002",
                        f"'{text}' in the '{column}' column is a reserved C/C++ keyword.",
                        location)

                # a value repeated inside one column cannot reach here: the
                # reader keeps the first occurrence only
                other = everywhere.get(text)
                if other is not None and other != column:
                    diagnostics.error(
                        "DEF004",
                        f"'{text}' is listed both under '{other}' and under '{column}'; "
                        f"the two generated enums would collide.", location)
                everywhere.setdefault(text, column)

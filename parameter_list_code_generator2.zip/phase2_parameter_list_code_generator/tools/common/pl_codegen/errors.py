"""Diagnostic (error / warning) infrastructure.

Every problem detected while reading a parameter list or generating code is
reported as a :class:`Diagnostic` instead of raising an exception, so that a
single run can report *all* problems at once.  Only unrecoverable problems
(missing file, unreadable XML, ...) raise :class:`CodeGeneratorError`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Dict, List, Optional


class CodeGeneratorError(Exception):
    """Unrecoverable error: the tool cannot continue at all."""


class Severity(IntEnum):
    """Severity of a diagnostic, ordered from least to most severe."""

    INFO = 0
    WARNING = 1
    ERROR = 2

    @property
    def label(self) -> str:
        return {Severity.INFO: "info", Severity.WARNING: "warning", Severity.ERROR: "error"}[self]


@dataclass(frozen=True)
class SourceLocation:
    """Where a diagnostic comes from (a parameter, an XML node or a file)."""

    file: Optional[str] = None
    sheet: Optional[str] = None
    row: Optional[int] = None
    column: Optional[str] = None
    #: dotted path of the parameter, e.g. ``Position.Home.Lat`` - this is what
    #: the GUI uses to jump to the offending parameter
    parameter: Optional[str] = None

    def __str__(self) -> str:
        parts: List[str] = []
        if self.parameter:
            parts.append(f"parameter '{self.parameter}'")
        if self.file:
            parts.append(str(self.file))
        if self.sheet:
            parts.append(f"[{self.sheet}]")
        if self.row is not None:
            parts.append(f"row {self.row}")
        if self.column:
            parts.append(f"column '{self.column}'")
        return " ".join(parts) if parts else "<unknown location>"

    def to_dict(self) -> Dict[str, object]:
        return {"file": self.file, "sheet": self.sheet, "row": self.row,
                "column": self.column, "parameter": self.parameter}


@dataclass(frozen=True)
class Diagnostic:
    """A single problem found by the tool."""

    severity: Severity
    code: str
    message: str
    location: SourceLocation = field(default_factory=SourceLocation)
    hint: Optional[str] = None

    def render(self) -> str:
        text = f"{self.severity.label.upper():7s} {self.code}: {self.message}\n            at {self.location}"
        if self.hint:
            text += f"\n            hint: {self.hint}"
        return text

    def to_dict(self) -> Dict[str, object]:
        return {
            "severity": self.severity.label,
            "code": self.code,
            "message": self.message,
            "location": self.location.to_dict(),
            "hint": self.hint,
        }


class DiagnosticCollector:
    """Collects diagnostics produced anywhere in the pipeline."""

    def __init__(self) -> None:
        self._items: List[Diagnostic] = []

    # -- adding ----------------------------------------------------------
    def add(self, diagnostic: Diagnostic) -> None:
        self._items.append(diagnostic)

    def error(self, code: str, message: str, location: Optional[SourceLocation] = None,
              hint: Optional[str] = None) -> None:
        self.add(Diagnostic(Severity.ERROR, code, message, location or SourceLocation(), hint))

    def warning(self, code: str, message: str, location: Optional[SourceLocation] = None,
                hint: Optional[str] = None) -> None:
        self.add(Diagnostic(Severity.WARNING, code, message, location or SourceLocation(), hint))

    def info(self, code: str, message: str, location: Optional[SourceLocation] = None,
             hint: Optional[str] = None) -> None:
        self.add(Diagnostic(Severity.INFO, code, message, location or SourceLocation(), hint))

    # -- querying --------------------------------------------------------
    @property
    def items(self) -> List[Diagnostic]:
        return list(self._items)

    def count(self, severity: Severity) -> int:
        return sum(1 for item in self._items if item.severity is severity)

    @property
    def has_errors(self) -> bool:
        return self.count(Severity.ERROR) > 0

    @property
    def has_warnings(self) -> bool:
        return self.count(Severity.WARNING) > 0

    def __len__(self) -> int:
        return len(self._items)

    # -- reporting -------------------------------------------------------
    def render(self, min_severity: Severity = Severity.INFO) -> str:
        selected = [item for item in self._items if item.severity >= min_severity]
        if not selected:
            return "No problems found."
        selected.sort(key=lambda item: (-int(item.severity), item.location.file or "",
                                        item.location.row or 0, item.code))
        return "\n".join(item.render() for item in selected)

    def summary(self) -> str:
        return (f"{self.count(Severity.ERROR)} error(s), "
                f"{self.count(Severity.WARNING)} warning(s), "
                f"{self.count(Severity.INFO)} info message(s)")

    def to_list(self) -> List[Dict[str, object]]:
        return [item.to_dict() for item in self._items]

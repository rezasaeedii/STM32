@echo off
REM ===========================================================================
REM  Opens the graphical parameter-list editor.
REM  Double-click this file - no command line needed.
REM
REM  The editor runs entirely on this machine: the server listens only on
REM  127.0.0.1 and the pages reference no external file.
REM  Close the editor window, then press Ctrl+C in this window to stop it.
REM
REM  For a plain browser tab instead of its own window, or another port:
REM      python run_gui.py --tab        python run_gui.py -p 8800
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_gui.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     The editor has stopped.
) else (
    echo     The editor could not start. Check codegen_config.json and the
    echo     paths in it, or try another port:  python run_gui.py -p 8800
)

echo.
pause
exit /b %EXITCODE%

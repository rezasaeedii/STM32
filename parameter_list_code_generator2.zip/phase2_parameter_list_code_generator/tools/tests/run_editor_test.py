"""Tests of the editor itself - the part of phase 2 that has no counterpart in
phase 1, and therefore no shared test.

Everything here goes through :class:`pl_gui.api.Api`, which is exactly what the
browser calls, so a test passing here means the button in the toolbar works.
The whole thing runs on a *copy* of the project in a temporary folder, so it can
create files, rewrite the configuration and reorder the build without ever
touching the project the user is working in.

Run it with::

    python tests/run_editor_test.py
"""

from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path
from typing import Callable, List, Tuple

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from common.pl_codegen.config import Config          # noqa: E402
from pl_gui.api import Api                           # noqa: E402
from pl_gui.document import Document                 # noqa: E402


class Failure(AssertionError):
    """One expectation that did not hold."""


def check(condition: bool, message: str) -> None:
    if not condition:
        raise Failure(message)


def equal(actual, expected, message: str) -> None:
    if actual != expected:
        raise Failure(f"{message}: expected {expected!r}, got {actual!r}")


# --------------------------------------------------------------- the fixture
def open_copy(work: Path, *, empty: bool = False) -> Tuple[Document, Api, Path]:
    """A Document on a throw-away copy of the project.

    With ``empty`` the document is emptied of parameters before the test starts,
    so a case can say exactly what the list contains without depending on what
    the project happens to hold today.  The drop-down lists are kept - a case
    that adds a parameter needs a group and a system name to give it.
    """
    shutil.copytree(PROJECT_DIR, work / "project", dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))
    config_path = work / "project" / "tools" / "codegen_config.json"
    document = Document(Config.load(config_path))
    document.load()
    if empty:
        document.model.parameters.clear()
        document.model.templates.clear()
    return document, Api(document), config_path


# --------------------------------------------------------------- the cases
def test_structure_types(work: Path) -> None:
    """A structure can become a data type, and a copy owns what it copied."""
    document, api, _config = open_copy(work, empty=True)

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Position"})
    document.add_parameter("Position", "primitive")
    document.update("Position.NewParameter",
                    {"name": "Lat", "data_type_name": "float64_t",
                     "minimum": -90.0, "maximum": 90.0, "resolution": 1e-07,
                     "default_value": 0.0, "unit": "deg"})
    document.add_parameter("Position", "primitive")
    document.update("Position.NewParameter",
                    {"name": "Samples", "data_type_name": "int16_t", "array_size": 4,
                     "minimum": 0, "maximum": 100, "resolution": 1, "default_value": 0})

    answer = api.save_template({"path": "Position", "name": "sPosition"})
    check(answer["ok"], f"the structure was not saved as a type: {answer}")

    listed = api.state({})["templates"]
    equal([item["name"] for item in listed], ["sPosition"], "the type list")
    equal(listed[0]["fields"], 2, "values per copy")
    equal(listed[0]["shape"], ["Lat : float64_t", "Samples[4] : int16_t"], "the shape")

    # a parameter picks the type out of the same list the data types are in
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "Target"})
    check(api.use_template({"path": "Target", "name": "sPosition"})["ok"],
          "the type could not be applied")

    target = document.find("Target")
    equal(target.kind.value, "struct", "the parameter became a structure")
    equal([child.name for child in target.children], ["Lat", "Samples"], "the copied fields")
    equal(target.children[0].maximum, 90.0, "the copied limit")
    equal(target.children[0].unit, "deg", "the copied unit")
    check(target.group is not None, "the copy kept the group of the parameter")
    check(target.tags.get("SystemName") is not None, "the copy kept its own tags")

    # ... and owns it: editing the copy leaves the type alone
    document.update("Target.Lat", {"maximum": 45.0})
    equal(document.find_template("sPosition").children[0].maximum, 90.0,
          "editing a copy changed the type")
    equal(document.find("Target").children[0].maximum, 45.0, "the copy was not edited")

    # the library survives a save and a reload
    saved = document.save()
    again = Document(document.config)
    again.load(saved)
    equal([item.name for item in again.model.templates], ["sPosition"],
          "the type library after a reload")
    equal(again.model.templates[0].group, None, "a type carries no group")
    equal(again.model.templates[0].tags, {}, "a type carries no tags")

    # a type nobody uses generates nothing
    check(api.delete_template({"name": "sPosition"})["ok"], "the type was not removed")
    equal(api.state({})["templates"], [], "the type list after removing the only type")


def test_structure_arrays(work: Path) -> None:
    """An array of structures produces one set of values per element."""
    document, _api, _config = open_copy(work, empty=True)

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Wheels", "array_size": 3,
                                  "tags": {"Loggable": True, "LogId": 900,
                                           "SystemName": "SYS_NAV",
                                           "ParamMode": "PARAM_MODE_USER",
                                           "ResetProof": False, "LogEncryption": False}})
    document.add_parameter("Wheels", "primitive")
    document.update("Wheels.NewParameter",
                    {"name": "Speed", "data_type_name": "float32_t",
                     "minimum": 0, "maximum": 0, "resolution": 0.001, "default_value": 0.0})

    leaves = document.model.flatten()
    equal([leaf.name for leaf in leaves],
          ["Wheels[0].Speed", "Wheels[1].Speed", "Wheels[2].Speed"], "the expanded leaves")
    equal([leaf.tags["LogId"] for leaf in leaves], [900, 901, 902], "one log id per value")

    # A log id counts values, never bytes: a float32_t[10] takes ten ids, and so
    # would a uint8_t[10].  Three elements of the structure therefore occupy
    # 900..909, 910..919 and 920..929.
    document.update("Wheels.Speed", {"array_size": 10})
    equal([leaf.tags["LogId"] for leaf in document.model.flatten()], [900, 910, 920],
          "an array of 10 takes 10 ids, whatever its type")

    # 'the next free id' is a property of the whole project, not of this list:
    # the other lists of the build reserve ids too, and an id that is free here
    # but taken in another list is not free.
    free = document.next_free_log_id()
    check(free >= 930, f"the next free id must be past this list's block, got {free}")
    for leaf in document.merged_model().flatten():
        log_id = leaf.tags.get("LogId")
        if isinstance(log_id, int) and not isinstance(log_id, bool):
            check(free > log_id, f"id {free} is not free: '{leaf.name}' already uses {log_id}")


def test_parameter_lists(work: Path) -> None:
    """Creating, choosing and ordering the parameter lists of the project."""
    document, api, config_path = open_copy(work)
    before = config_path.read_text(encoding="utf-8")
    check("//" in before, "the fixture configuration has no comments to preserve")

    listed = api.lists({})
    equal(Path(listed["directory"]).name, "parameter_lists", "the parameter list folder")
    check(all(item["inFolder"] for item in listed["lists"]),
          "every list of the project should live in the one folder")
    selected = [item["file"] for item in listed["lists"] if item["selected"]]
    check(len(selected) >= 1, "no list takes part in the build")

    # a name is sanitised into something that cannot leave the folder
    answer = api.new_list({"name": "../../gimbal telemetry!"})
    check(answer["ok"], f"the list was not created: {answer}")
    created = Path(answer["path"])
    equal(created.name, "gimbal_telemetry.xml", "the file name made from the typed name")
    equal(created.parent, document.list_directory(), "the new list is in the folder")
    check(created.is_file(), "the new list was not written to disk")
    check(created in document.config.inputs.model_files,
          "the new list did not join the build")

    # a name that is already taken is refused rather than overwriting a list
    check(not api.new_list({"name": "gimbal_telemetry"})["ok"],
          "creating a list twice overwrote the first one")

    # The order chosen here is the order the generator merges in, so the check
    # below needs two lists that actually hold parameters - reversed, so that
    # "the order was kept" cannot pass by accident.
    directory = document.list_directory()
    filled = [path for path in sorted(directory.glob("*.xml")) if _parameter_names(path)]
    check(len(filled) >= 2,
          "the project needs two non-empty parameter lists to test the order with")
    chosen = list(reversed(filled[:2]))
    answer = api.select_lists({"paths": [str(path) for path in chosen]})
    check(answer["ok"], f"the choice was not saved: {answer}")

    after = config_path.read_text(encoding="utf-8")
    check("//" in after, "rewriting the configuration deleted its comments")
    equal([line for line in before.splitlines() if line.strip().startswith("//")],
          [line for line in after.splitlines() if line.strip().startswith("//")],
          "the comments of the configuration file")

    reloaded = Config.load(config_path)
    equal([path.name for path in reloaded.inputs.model_files],
          [path.name for path in chosen],
          "what run_generate.py reads after the editor saved the choice")

    # ... and the indices of the generated code really follow that order: the
    # values of the first list come first, then the values of the second.
    expected = [name for path in chosen for name in _parameter_names(path)]
    document = Document(reloaded)
    document.load(reloaded.inputs.model_files[0])
    equal([leaf.name for leaf in document.merged_model().flatten()], expected,
          "the order of the values in the merged model")


def test_list_selection_edge_cases(work: Path) -> None:
    """The ways a hand-edited configuration can be odd, and what happens then."""
    document, api, config_path = open_copy(work)
    directory = document.list_directory()
    first = document.config.inputs.model_files[0]

    # The same list twice would be merged twice and every name in it would
    # collide with itself; the first mention wins so the chosen order survives.
    answer = api.select_lists({"paths": [str(first), str(directory / "power.xml"),
                                         str(first)]})
    check(answer["ok"], f"the choice was not saved: {answer}")
    equal([Path(p).name for p in answer["paths"]], [first.name, "power.xml"],
          "the duplicate should have been dropped")
    equal([path.name for path in Config.load(config_path).inputs.model_files],
          [first.name, "power.xml"], "what the configuration file says")

    # A configuration that already names a list twice still gives the dialog one
    # row per file - two rows with the same path would bind to the same object.
    document.config.inputs.model_files = [first, first]
    paths = [item["path"] for item in document.known_lists()]
    equal(len(paths), len(set(paths)), "the dialog was given a duplicated row")

    # Generating with a list that is not on disk is reported, not raised: the
    # editor shows that state as "(new)", so it is reachable by just clicking.
    document.config.inputs.model_files = [directory / "does_not_exist.xml"]
    result = api.generate({})
    check(not result["success"], "generating from a missing list reported success")
    check(bool(result.get("message")), "the failure came back with nothing to read")


def test_template_of_another_list(work: Path) -> None:
    """A type another parameter list owns is shown, but cannot be deleted here."""
    document, api, _config = open_copy(work)
    # Put a type into another list that takes part in the build - a list that
    # is not in the build contributes nothing, templates included.
    others = [path for path in document.config.inputs.model_files
              if path != document.path]
    check(bool(others), "the project needs a second list in the build for this case")
    other = others[0]
    document.load(other)
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "NavShape"})
    document.add_parameter("NavShape", "primitive")
    check(api.save_template({"path": "NavShape", "name": "sNavShape"})["ok"],
          "the type was not saved")
    document.save()

    # now edit the first list: the type is offered, because the library is the
    # project's, not the file's
    document.load(document.config.inputs.model_files[0])
    check("sNavShape" in [item["name"] for item in api.state({})["templates"]],
          "a type defined in another list is not offered here")

    # ... but deleting it from here would silently do nothing, so it says so
    answer = api.delete_template({"name": "sNavShape"})
    check(not answer["ok"], "deleting another list's type reported success")
    check(other.stem in answer["message"],
          f"the message should name the list that owns it: {answer['message']}")
    check("sNavShape" in [item["name"] for item in api.state({})["templates"]],
          "the type disappeared even though the answer said it had not")


def _parameter_names(path: Path) -> List[str]:
    """The values one parameter list contributes, in order."""
    from common.pl_codegen.errors import DiagnosticCollector
    from common.pl_codegen.xml_model.xml_reader import read_xml

    return [leaf.name for leaf in read_xml(path, DiagnosticCollector()).flatten()]


def test_layout_warning(work: Path) -> None:
    """Generating must say when it moved a value a board may already store.

    The offset of a reset-proof value is positional, so inserting, disabling,
    moving or widening a parameter shifts everything after it - and none of that
    shows up in the generated code.  This is the check that it never happens
    quietly.
    """
    document, api, _config = open_copy(work)

    # the copy carries the project's last build; drop it so the first generate
    # here really is a first build
    previous = document.config.output.xml_file
    if previous.is_file():
        previous.unlink()

    first = api.generate({})
    check(first["success"], f"the first build failed: {first.get('message')}")
    check(first["drift"]["firstRun"], "the very first build has nothing to compare with")

    # generating again without touching anything must be silent
    again = api.generate({})
    check(not again["drift"]["breaksStoredData"], "an unchanged model reported a move")
    equal(again["drift"]["moved"], [], "an unchanged model moved something")

    # ... and moving a parameter to the front must not be
    names = [node.name for node in document.model.parameters]
    check(len(names) >= 2, "the project needs two parameters for this case")
    document.move(names[-1], -(len(names) - 1))
    moved = api.generate({})
    check(moved["success"], "generating after the move failed")
    drift = moved["drift"]
    check(drift["breaksStoredData"],
          "moving a parameter to the front did not warn about the memory layout")
    check(bool(drift["moved"]), "the warning named no parameter")
    check("MOVED" in drift["summary"], f"the summary is not loud enough: {drift['summary']}")
    for entry in drift["moved"]:
        check(entry["old"] != entry["new"],
              f"'{entry['parameter']}' is listed as moved but did not move")

    # Appending to the END of the LAST list in the build changes nothing that
    # already exists - and that is the whole point of the advice the warning
    # gives, so it has to actually hold.
    api.open_file({"path": str(document.config.inputs.model_files[-1])})
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "AppendedAtTheEnd"})
    appended = api.generate({})
    check(appended["success"], "generating after the append failed")
    equal(appended["drift"]["moved"], [],
          "appending at the end of the last list moved something that existed")
    check("AppendedAtTheEnd" in appended["drift"]["added"],
          "the appended parameter was not reported as added")


def test_only_the_editor(work: Path) -> None:
    """Phase 2 supports exactly one input, and it is the editor.

    A phase that quietly grew a second way in would be a phase 3, and phase 3 is
    a later decision - so this fails rather than letting it happen by accident.
    """
    check(not list(PROJECT_DIR.glob("**/*.xlsx")), "phase 2 ships a workbook")
    offenders = []
    for path in TOOLS_DIR.rglob("*.py"):
        if "__pycache__" in path.parts or path.parts[-2:-1] == ("tests",):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "openpyxl" in text:
            offenders.append(str(path.relative_to(TOOLS_DIR)))
    equal(offenders, [], "modules that still import openpyxl")


CASES: List[Tuple[str, Callable[[Path], None]]] = [
    ("structure types (the template library)", test_structure_types),
    ("arrays of structures", test_structure_arrays),
    ("the parameter lists of the project", test_parameter_lists),
    ("odd list selections", test_list_selection_edge_cases),
    ("a type another list owns", test_template_of_another_list),
    ("the memory layout warning", test_layout_warning),
    ("the editor is the only input", test_only_the_editor),
]


def main() -> int:
    failures = 0
    width = max(len(name) for name, _case in CASES)
    for name, case in CASES:
        with tempfile.TemporaryDirectory(prefix="pl_editor_test_") as raw:
            try:
                case(Path(raw))
            except Failure as error:
                print(f"  [FAIL] {name.ljust(width)}  {error}")
                failures += 1
                continue
            except Exception as error:               # noqa: BLE001 - report and go on
                print(f"  [ERROR] {name.ljust(width)}  {type(error).__name__}: {error}")
                failures += 1
                continue
        print(f"  [PASS] {name}")

    print()
    if failures:
        print(f"{failures} of {len(CASES)} editor case(s) FAILED.")
        return 1
    print(f"All {len(CASES)} editor cases passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

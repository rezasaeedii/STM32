"""End-to-end test: generate the code and compile it with a real C/C++ compiler.

The test
  1. runs the generator on ``parameter_list.xml`` into a temporary folder,
  2. compiles the generated files together with ``smart_data.c`` as **C99** and
     compiles the generated headers as **C++**,
  3. links and runs a small program that calls ``fParameterList_Init()``,
     walks the descriptor table and exercises the usage example.

Run it with::

    python tests/run_compile_test.py

It needs ``gcc`` and ``g++`` on the PATH; on Windows a MinGW or WSL toolchain
works.  The test never touches the files under ``cg_parameter_list`` of the
project: everything is generated into a temporary folder.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from common.pl_codegen.cli import main as generator_main  # noqa: E402

C_COMPILER = "gcc"
CXX_COMPILER = "g++"

def _run(command: List[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def have_compiler(name: str) -> bool:
    return shutil.which(name) is not None


def write_config(work_dir: Path, inputs: dict, name: str = "codegen_config.json") -> Path:
    """Write a configuration that generates into *work_dir*."""
    config = {
        "inputs": inputs,
        "output": {
            "code_directory": str(work_dir / "generated"),
            "xml_file": str(work_dir / "model.xml"),
            "file_prefix": "cg_",
            "base_name": "parameter_list",
        },
        "style": {"snippet_file": str(PROJECT_DIR / "c.json"), "company": "FAS",
                  "indent": "    "},
        "codegen": {"emit_description": True, "emit_unit": True,
                    "emit_generation_info": True, "emit_timestamp": False},
        "validation": {"treat_warnings_as_errors": False},
    }
    path = work_dir / name
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return path


#: The three ways a project can feed the generator; all three must compile.
def input_variants() -> List[dict]:
    # The project's own lists, taken from its configuration rather than from
    # hard coded paths: the editor is free to add lists and to reorder them, and
    # the test has to keep testing whatever the project actually builds.
    project = [path for path in _project_lists() if path.is_file()]

    variants: List[dict] = []
    if project:
        variants.append(
            {"label": "one parameter list (the editor)",
             "inputs": {"model_files": [str(project[0])]}})
    if len(project) > 1:
        variants.append(
            {"label": f"{len(project)} parameter lists, merged",
             "inputs": {"model_files": [str(path) for path in project]}})

    # A fixture the editor could have written, kept small on purpose: it is the
    # only place where an array of structures - and an array *inside* one - is
    # compiled and run, so the generated strides are checked by the compiler
    # rather than by eye.
    variants.append(
        {"label": "an array of structures",
         "fixture": _STRUCT_ARRAY_XML,
         "with_example": False,
         "extra_checks": _STRUCT_ARRAY_CHECKS})

    return variants


def _project_lists() -> List[Path]:
    """The parameter lists the project's own configuration builds, in order."""
    from common.pl_codegen.config import Config

    try:
        return list(Config.load(TOOLS_DIR / "codegen_config.json").inputs.model_files)
    except Exception as error:                       # a broken config is its own test
        print(f"  (could not read the project configuration: {error})")
        return []


#: A parameter list with a struct array whose elements hold an array field.
_STRUCT_ARRAY_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="2.0" generator="parameter_list_code_generator"
                    generatorVersion="2.0.0">
  <SourceFiles />
  <Defines>
    <DefineGroup name="GROUP"><Value value="MONITORING" /></DefineGroup>
    <DefineGroup name="PARAM MODES"><Value value="PARAM_MODE_USER" /></DefineGroup>
    <DefineGroup name="SYSTEM NAMES"><Value value="SYS_NAV" /></DefineGroup>
    <DefineGroup name="TYPES">
      <Value value="float32_t" /><Value value="int16_t" /><Value value="uint32_t" />
    </DefineGroup>
  </Defines>
  <Parameters>
    <Parameter name="Car" kind="struct" enable="true" gsName="Car"
               group="MONITORING" arraySize="1" description="One vehicle.">
      <Source /><Limits />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogId" kind="unsigned" value="600" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Fields>
        <Parameter name="Wheels" kind="struct" enable="true" gsName="Wheels"
                   arraySize="2" description="One entry per wheel.">
          <Source /><Limits /><Tags />
          <Fields>
            <Parameter name="Speed" kind="primitive" enable="true" gsName="Speed"
                       dataType="float32_t" arraySize="1" unit="m/s">
              <Source />
              <Limits default="0" minimum="0" maximum="120" resolution="0.001" />
              <Tags />
            </Parameter>
            <Parameter name="Samples" kind="primitive" enable="true" gsName="Samples"
                       dataType="int16_t" arraySize="4">
              <Source />
              <Limits default="0" minimum="0" maximum="0" resolution="1" />
              <Tags />
            </Parameter>
          </Fields>
        </Parameter>
        <Parameter name="Vin" kind="primitive" enable="true" gsName="Vin"
                   dataType="uint32_t" arraySize="1">
          <Source />
          <Limits default="7" minimum="0" maximum="0" resolution="1" />
          <Tags />
        </Parameter>
      </Fields>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

#: What the struct array must produce, checked by the compiler and at run time.
_STRUCT_ARRAY_CHECKS = """
    /* The array sizes are declarations, so every element shares one macro. */
    if (CAR_WHEELS_ARRAY_SIZE != 2U || CAR_WHEELS_SAMPLES_ARRAY_SIZE != 4U) {
        printf("array size macros are wrong\\n");
        return 1;
    }
    /* Two elements of one struct array are two separate values. */
    if ((void *)&Cg_SmartData_Car.Wheels[0].Speed
        == (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the elements of the struct array alias each other\\n");
        return 1;
    }
    /* Each element has its own row, pointing inside that element. */
    if (ParameterList[CAR_WHEELS_1_SPEED].pSmartData
        != (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the descriptor does not point at the element\\n");
        return 1;
    }
    /* A log id counts values, never bytes: Samples[4] takes four of them. */
    if (ParameterList[CAR_WHEELS_0_SPEED].TagLogId.Value != 600U
        || ParameterList[CAR_WHEELS_0_SAMPLES].TagLogId.Value != 601U
        || ParameterList[CAR_WHEELS_1_SPEED].TagLogId.Value != 605U
        || ParameterList[CAR_VIN].TagLogId.Value != 610U) {
        printf("the log ids of the struct array are wrong\\n");
        return 1;
    }
    /* Writing one element leaves its neighbour alone. */
    {
        float32_t written = 12.5F;
        float32_t readBack = 1.0F;
        if (fSmartDataWrite_(&Cg_SmartData_Car.Wheels[1].Speed, &written)
            != eSMART_DATA_OK) {
            printf("writing an element of the struct array failed\\n");
            return 1;
        }
        (void)fSmartDataRead_(&Cg_SmartData_Car.Wheels[0].Speed, &readBack);
        if (readBack != 0.0F) {
            printf("writing one element disturbed its neighbour\\n");
            return 1;
        }
        (void)fSmartDataRead_(&Cg_SmartData_Car.Wheels[1].Speed, &readBack);
        if (readBack != 12.5F) {
            printf("the element did not keep the value that was written\\n");
            return 1;
        }
    }

    /* A write clears every reader's flag, because nobody has seen the new
       value yet; a write REFUSED by the range check leaves them alone, because
       nothing changed. */
    {
        float32_t value = 1.0F;
        eSmartDataStatus readStatus = eSMART_DATA_OK;
        const uint8_t reader = 0U;

        (void)fSmartDataWrite_(&Cg_SmartData_Car.Wheels[0].Speed, &value);
        fSmartDataUserRead_(&Cg_SmartData_Car.Wheels[0].Speed, reader, &value, readStatus);
        if (readStatus != eSMART_DATA_OK) {
            printf("the first user read failed\\n");
            return 1;
        }
        if (fSmartDataHasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != TRUE) {
            printf("reading did not mark the reader as up to date\\n");
            return 1;
        }

        value = 2.0F;
        (void)fSmartDataWrite_(&Cg_SmartData_Car.Wheels[0].Speed, &value);
        if (fSmartDataHasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != FALSE) {
            printf("a write did not clear the reader flags\\n");
            return 1;
        }

        /* ... and a write the range check refuses changes nothing, so the
           readers stay as they were. */
        fSmartDataUserRead_(&Cg_SmartData_Car.Wheels[0].Speed, reader, &value, readStatus);
        value = -1.0F;   /* below the minimum of this parameter */
        if (fSmartDataWrite_(&Cg_SmartData_Car.Wheels[0].Speed, &value)
            == eSMART_DATA_OK) {
            printf("an out of range write was accepted\\n");
            return 1;
        }
        if (fSmartDataHasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != TRUE) {
            printf("a refused write cleared the reader flags\\n");
            return 1;
        }
    }

"""


# smart_data.c includes the project's chrono.h. When the firmware's real
# chrono module is not reachable from here, this stub stands in for it; the
# stub folder is searched LAST, so a real chrono.h always wins.
_CHRONO_STUB_H = """
#ifndef CHRONO_H
#define CHRONO_H
#include <stdint.h>
static uint64_t fChrono_GetContinuousTickUs(void) { return 0U; }
#endif
"""

_LOG_STUB_C = """
#include "parameter_list_usage_example.h"

void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset) {
    (void)logId; (void)pValue; (void)memoryOffset;
}

uint8_t fExample_UseHome(const sCgStruct_Position_Home *pHome) {
    return (pHome == NULL) ? 1U : 0U;
}
"""


def compile_c(work_dir: Path, includes: List[str], with_example: bool = True) -> bool:
    """The example uses the demo parameters, so it only fits the XML model."""
    (work_dir / "log_stub.c").write_text(_LOG_STUB_C, encoding="utf-8")
    sources = [
        PROJECT_DIR / "smart_data" / "smart_data.c",
        work_dir / "generated" / "cg_smart_data.c",
        work_dir / "generated" / "cg_parameter_list.c",
    ]
    if with_example:
        sources += [PROJECT_DIR / "example" / "parameter_list_usage_example.c",
                    work_dir / "log_stub.c"]
    sources.append(work_dir / "main.c")
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Wpedantic",
               *includes, *[str(path) for path in sources],
               "-o", str(work_dir / "parameter_list_test")]
    result = _run(command)
    if result.returncode != 0:
        print("C compilation FAILED:\n" + result.stderr)
        return False
    if result.stderr.strip():
        print("C compiler warnings:\n" + result.stderr)
    return True


def compile_cxx(work_dir: Path, includes: List[str]) -> bool:
    """The generated headers must be usable from C++ as well."""
    source = work_dir / "cxx_include_test.cpp"
    source.write_text(
        '#include "cg_parameter_list.h"\n'
        '#include "cg_smart_data.h"\n'
        '#include "cg_parameter_list_defines.h"\n'
        '#include "cg_parameter_list_table.h"\n'
        '#include "cg_parameter_list_types.h"\n'
        "int main() { return (int)ParameterList[0].ArraySize - 1; }\n",
        encoding="utf-8")
    command = [CXX_COMPILER, "-std=c++11", "-Wall", "-Wextra", "-c",
               *includes, str(source), "-o", str(work_dir / "cxx_include_test.o")]
    result = _run(command)
    if result.returncode != 0:
        print("C++ compilation FAILED:\n" + result.stderr)
        return False
    return True


_MAIN_HEAD = """
#include <stdio.h>
#include <string.h>
#include "cg_parameter_list.h"
#include "cg_smart_data.h"
#include "cg_parameter_list_table.h"
"""

_MAIN_HEAD_WITH_EXAMPLE = _MAIN_HEAD + '#include "parameter_list_usage_example.h"\n'

_MAIN_BODY = """
int main(void) {
    uint16_t index = 0U;
    uint8_t result = fParameterList_Init();
    if (result != 0U) {
        printf("fParameterList_Init failed with %u\\n", (unsigned)result);
        return 1;
    }
    if (fParameterList_GetQuantity() != PARAMETER_LIST_QTY) {
        printf("wrong quantity\\n");
        return 1;
    }
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL || pDescriptor->pName == NULL) {
            printf("descriptor %u is broken\\n", (unsigned)index);
            return 1;
        }
        if (fParameterList_GetByName(pDescriptor->pName) != pDescriptor) {
            printf("lookup by name failed for %s\\n", pDescriptor->pName);
            return 1;
        }
        if (pDescriptor->pSmartData == NULL) {
            printf("no smart data for %s\\n", pDescriptor->pName);
            return 1;
        }
    }
    if (fParameterList_GetByIndex(PARAMETER_LIST_QTY) != NULL) {
        printf("out of range index was accepted\\n");
        return 1;
    }
    EXAMPLE_CALLS
    EXTRA_CHECKS
    printf("OK: %u parameters initialised and verified" EXAMPLE_NOTE "\\n",
           (unsigned)PARAMETER_LIST_QTY);
    return 0;
}
"""

_EXAMPLE_CALLS = """
    /* The usage example must work as well. */
    fExample_DirectAccess();
    if (fExample_CheckedAccess() != eSMART_DATA_OK) {
        printf("fExample_CheckedAccess failed\\n");
        return 1;
    }
    if (fExample_DescriptorAccess() != 0U) {
        printf("fExample_DescriptorAccess failed\\n");
        return 1;
    }
    if (fExample_StructAccess() != 0U) {
        printf("fExample_StructAccess failed\\n");
        return 1;
    }
    fExample_ArrayAccess();
    if (fExample_ReadIfNew() != TRUE || fExample_ReadIfNew() != FALSE) {
        printf("fExample_ReadIfNew failed\\n");
        return 1;
    }
"""


def main_source(with_example: bool, extra_checks: str = "") -> str:
    head = _MAIN_HEAD_WITH_EXAMPLE if with_example else _MAIN_HEAD
    calls = _EXAMPLE_CALLS if with_example else ""
    note = '", usage example runs"' if with_example else '""'
    return (head + f"#define EXAMPLE_NOTE {note}\n"
            + _MAIN_BODY.replace("    EXAMPLE_CALLS", calls)
                        .replace("    EXTRA_CHECKS", extra_checks))


def main() -> int:
    for compiler in (C_COMPILER, CXX_COMPILER):
        if not have_compiler(compiler):
            print(f"SKIPPED: '{compiler}' was not found on the PATH.")
            return 0

    variants = input_variants()
    print(f"Checking {len(variants)} input variant(s).\n")

    for number, variant in enumerate(variants, start=1):
        label = variant["label"]
        with_example = variant.get("with_example", True)
        print(f"=== {number}/{len(variants)}  {label} ===")
        if not check_one(variant, with_example):
            return 1
        print()

    print("All checks passed.")
    return 0


def check_one(variant: dict, with_example: bool) -> bool:
    """Generate from *variant*, compile the result and run it."""
    with tempfile.TemporaryDirectory(prefix="pl_codegen_test_") as raw_dir:
        work_dir = Path(raw_dir)

        # A variant either points at a file of the project or brings its own
        # model along; a fixture keeps the test independent of what the user
        # happens to have in the editor.
        inputs = variant.get("inputs")
        if inputs is None:
            fixture = work_dir / "fixture.xml"
            fixture.write_text(variant["fixture"], encoding="utf-8")
            inputs = {"model_files": [str(fixture)]}

        print("  1/4 generating the code ...")
        config_path = write_config(work_dir, inputs)
        exit_code = generator_main(["--config", str(config_path), "--quiet"])
        if exit_code != 0:
            print(f"  FAILED: the generator returned {exit_code}.")
            return False

        (work_dir / "main.c").write_text(
            main_source(with_example, variant.get("extra_checks", "")),
            encoding="utf-8")
        stub_dir = work_dir / "stubs"
        stub_dir.mkdir(exist_ok=True)
        (stub_dir / "chrono.h").write_text(_CHRONO_STUB_H, encoding="utf-8")
        includes = [f"-I{PROJECT_DIR}",
                    f"-I{PROJECT_DIR / 'example'}",
                    f"-I{PROJECT_DIR / 'smart_data'}",
                    f"-I{PROJECT_DIR / 'parameter_descriptor'}",
                    f"-I{work_dir / 'generated'}",
                    f"-I{stub_dir}"]

        print("  2/4 compiling as C99 ...")
        if not compile_c(work_dir, includes, with_example):
            return False

        print("  3/4 compiling the headers as C++ ...")
        if not compile_cxx(work_dir, includes):
            return False

        print("  4/4 running the generated parameter list ...")
        result = _run([str(work_dir / "parameter_list_test")])
        print("        " + result.stdout.strip())
        if result.returncode != 0:
            print("  FAILED: the test program returned a non-zero exit code.")
            return False
    return True


if __name__ == "__main__":
    raise SystemExit(main())

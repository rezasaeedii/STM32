"""Starts the graphical parameter-list editor.

    cd tools
    python run_gui.py

The editor runs entirely on this machine:

  * the server binds to 127.0.0.1, the loopback interface, so nothing on the
    network can reach it;
  * the pages reference no external file, so nothing leaves the machine;
  * when a Chromium based browser is installed, the editor opens in its own
    window - no address bar, no tabs - started with every background-networking
    switch turned off.  Otherwise the default browser is used.

Close the window and press Ctrl+C here to stop the server.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from common.pl_codegen.config import Config          # noqa: E402
from common.pl_codegen.errors import CodeGeneratorError  # noqa: E402
from common.pl_codegen.logging_utils import setup_logging  # noqa: E402
from pl_gui.server import GuiServer           # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Parameter list editor (GUI).")
    parser.add_argument("-c", "--config", type=Path, default=Path("codegen_config.json"),
                        help="configuration file (default: codegen_config.json)")
    parser.add_argument("-p", "--port", type=int, default=8765, help="port to listen on")
    parser.add_argument("--no-browser", action="store_true",
                        help="do not open anything; just print the address")
    parser.add_argument("--tab", action="store_true",
                        help="open a tab in the default browser instead of a "
                             "separate application window")
    arguments = parser.parse_args()

    setup_logging()
    try:
        config = Config.load(arguments.config)
    except CodeGeneratorError as error:
        print(error)
        return 2

    GuiServer(config, port=arguments.port).serve_forever(
        open_browser=not arguments.no_browser,
        app_window=not arguments.tab)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

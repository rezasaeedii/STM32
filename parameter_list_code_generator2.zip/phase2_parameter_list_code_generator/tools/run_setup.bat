@echo off
REM ===========================================================================
REM  Checks that this machine can run the tool.  Nothing is installed and
REM  nothing is downloaded: phase 2 uses only the Python standard library.
REM  Double-click this file once, before the first use.
REM ===========================================================================
setlocal
cd /d "%~dp0"

python run_setup.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
    echo     Ready. You can now double-click run_gui.bat.
) else (
    echo     This Python installation cannot run the tool. Read the message
    echo     above - it says which part is missing.
)

echo.
pause
exit /b %EXITCODE%

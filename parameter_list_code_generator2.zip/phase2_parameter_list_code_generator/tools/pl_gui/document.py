"""The document the GUI edits: the parameter list plus its file and undo stack.

Everything the front end does goes through this class, so the rules about what
a valid edit is live in one place.
"""

from __future__ import annotations

import copy
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from common.pl_codegen.config import Config
from common.pl_codegen.errors import DiagnosticCollector, Severity
from common.pl_codegen.layout.tag_offset import reserved_log_ids
from common.pl_codegen.model.defines import (COLUMN_GROUPS, COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES,
                                      COLUMN_TYPES, Defines)
from common.pl_codegen.model.parameter import Parameter, ParameterKind
from common.pl_codegen.model.parameter_list import PATH_SEPARATOR, ParameterList
from common.pl_codegen.model.tags import TAG_REGISTRY
from common.pl_codegen.model.types import DATA_TYPES
from common.pl_codegen.pipeline import Pipeline
from common.pl_codegen.validation.validator import Validator
from common.pl_codegen.xml_model.xml_reader import read_xml
from common.pl_codegen.xml_model.xml_writer import write_xml

from .config_file import rewrite_model_files

#: how many steps of undo the GUI keeps
UNDO_DEPTH = 60

# The drop-down lists a brand new model starts with - the company's lists.
# Edit them here, or per model with the "Choices..." button in the editor.
DEFAULT_GROUPS = [
    "MONITORING",
    "COMMAND",
    "SETTING",
]

DEFAULT_SYSTEM_NAMES = [
    "SYS_UNKNOWN",
    "SYS_GS_COMPUTER",
    "SYS_GS_MANAGER",
    "SYS_GS_POWER",
    "SYS_ANTENNA_TRACKER",
    "SYS_AC_MANAGER",
    "SYS_AC_POWER",
    "SYS_AC_AUTOPILOT",
    "SYS_GIMBAL",
    "SYS_LOCK_TRACK",
    "SYS_LINK_GS",
    "SYS_GS_USB2CAN",
    "SYS_LINK_AIR",
    "SYS_BOOTLOADER",
    "SYS_LINK_BOX",
    "SYS_GOVERNOR",
    "SYS_NAV",
    "SYS_AND",
    "SYS_VNS",
    "SYS_RHS",
    "SYS_AUP",
]

DEFAULT_PARAM_MODES = [
    "PARAM_MODE_USER",
    "PARAM_MODE_READ_ONLY",
    "PARAM_MODE_PRODUCT_TYPE",
    "PARAM_MODE_FACTORY",
    "PARAM_MODE_CALIB",
    "PARAM_MODE_TEMPORARY",
]


class Document:
    """The in-memory parameter list plus everything the GUI needs around it."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.model = ParameterList()
        self.path: Optional[Path] = config.inputs.model_file
        self.dirty = False
        self._undo: List[Tuple[str, ParameterList]] = []
        self._redo: List[Tuple[str, ParameterList]] = []

    # -- loading and saving ------------------------------------------------
    def load(self, path: Optional[Path] = None) -> List[Dict[str, object]]:
        """Read the XML model.  Returns the diagnostics of the read."""
        target = Path(path) if path else self.path
        diagnostics = DiagnosticCollector()
        if target is not None and target.is_file():
            self.model = read_xml(target, diagnostics)
            self.path = target
        else:
            self.model = ParameterList()
            self.path = target
        self._ensure_defines()
        self.dirty = False
        self._undo.clear()
        self._redo.clear()
        return diagnostics.to_list()

    def save(self, path: Optional[Path] = None) -> Path:
        target = Path(path) if path else self.path
        if target is None:
            raise ValueError("No file name given.")
        write_xml(self.model, target,
                  emit_timestamp=self.config.codegen.emit_timestamp)
        self.path = target
        self.dirty = False
        return target

    def _ensure_defines(self) -> None:
        """Make sure the drop-down lists are never empty."""
        defines: Defines = self.model.defines
        if not defines.get(COLUMN_TYPES):
            for name in DATA_TYPES:
                defines.add(COLUMN_TYPES, name)
        for column, values in ((COLUMN_GROUPS, DEFAULT_GROUPS),
                               (COLUMN_SYSTEM_NAMES, DEFAULT_SYSTEM_NAMES),
                               (COLUMN_PARAM_MODES, DEFAULT_PARAM_MODES)):
            if not defines.get(column):
                for value in values:
                    defines.add(column, value)

    # -- undo / redo --------------------------------------------------------
    def snapshot(self, label: str) -> None:
        """Remember the current state before changing it."""
        self._undo.append((label, copy.deepcopy(self.model)))
        del self._undo[:-UNDO_DEPTH]
        self._redo.clear()
        self.dirty = True

    def undo(self) -> Optional[str]:
        if not self._undo:
            return None
        label, state = self._undo.pop()
        self._redo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    def redo(self) -> Optional[str]:
        if not self._redo:
            return None
        label, state = self._redo.pop()
        self._undo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    # -- finding nodes ------------------------------------------------------
    def find(self, path: str) -> Optional[Parameter]:
        return self.model.find(path) if path else None

    def parent_of(self, path: str) -> Tuple[Optional[Parameter], List[Parameter]]:
        """Return ``(parent node or None, the list the node lives in)``."""
        parts = path.split(PATH_SEPARATOR)
        if len(parts) == 1:
            return None, self.model.parameters
        parent = self.model.find(PATH_SEPARATOR.join(parts[:-1]))
        return parent, parent.children if parent else self.model.parameters

    # -- editing ------------------------------------------------------------
    def add_parameter(self, parent_path: str = "", kind: str = "primitive") -> str:
        """Add a parameter (or a struct) under *parent_path*; return its path."""
        self.snapshot("add")
        parent = self.find(parent_path) if parent_path else None
        siblings = parent.children if parent is not None and parent.is_struct \
            else self.model.parameters
        prefix = parent_path if (parent is not None and parent.is_struct) else ""

        node = Parameter(
            name=_unique_name("NewStruct" if kind == "struct" else "NewParameter", siblings),
            kind=ParameterKind.STRUCT if kind == "struct" else ParameterKind.PRIMITIVE)
        if node.is_primitive:
            node.data_type_name = "uint8_t"
            node.default_value = 0
            node.minimum = 0
            node.maximum = 0
            node.resolution = 1
        if prefix == "":
            node.group = self.model.defines.get(COLUMN_GROUPS)[0] \
                if self.model.defines.get(COLUMN_GROUPS) else "MONITORING"
            node.tags = {spec.tag_id: _default_tag(spec, self.model.defines)
                         for spec in TAG_REGISTRY}
        siblings.append(node)
        return f"{prefix}{PATH_SEPARATOR}{node.name}" if prefix else node.name

    def duplicate(self, path: str) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("duplicate")
        _parent, siblings = self.parent_of(path)
        clone = copy.deepcopy(node)
        clone.name = _unique_name(node.name, siblings)
        _clear_log_ids(clone)
        siblings.insert(siblings.index(node) + 1, clone)
        prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
        return f"{prefix}{PATH_SEPARATOR}{clone.name}" if prefix else clone.name

    def delete(self, path: str) -> bool:
        node = self.find(path)
        if node is None:
            return False
        self.snapshot("delete")
        _parent, siblings = self.parent_of(path)
        siblings.remove(node)
        return True

    def move(self, path: str, offset: int) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        _parent, siblings = self.parent_of(path)
        index = siblings.index(node)
        target = index + offset
        if not 0 <= target < len(siblings):
            return None
        self.snapshot("move")
        siblings.pop(index)
        siblings.insert(target, node)
        return path

    def update(self, path: str, changes: Dict[str, object]) -> Optional[str]:
        """Apply the values coming from the editor form.  Returns the new path."""
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("edit")

        # Tags and the group belong to the top level entry.  A field inside a
        # structure cannot set them, so drop them here as well as in the form -
        # that way a stale page can never write them either.
        if PATH_SEPARATOR in path:
            changes.pop("tags", None)
            changes.pop("group", None)

        new_path = path
        if "name" in changes:
            name = str(changes.pop("name") or "").strip()
            if name and name != node.name:
                node.name = name
                prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
                new_path = f"{prefix}{PATH_SEPARATOR}{name}" if prefix else name

        tags = changes.pop("tags", None)
        if isinstance(tags, dict):
            node.tags = dict(tags)

        for key, value in changes.items():
            if hasattr(node, key):
                setattr(node, key, value)
        return new_path

    # -- the parameter lists of the project --------------------------------------
    #
    # A project is one parameter list split over several files, one per
    # sub-module.  They all live in one folder (``inputs.model_directory``), and
    # the configuration says which of them take part in a build and in what
    # order - that order is the order of the indices in the generated code, so
    # it is a real decision and not a detail.  The editor writes that choice back
    # into codegen_config.json, because that file is what run_generate.py reads:
    # if the two could disagree, the code someone generates from the command line
    # would not be the code they saw in the editor.

    def list_directory(self) -> Path:
        return self.config.inputs.model_directory

    def known_lists(self) -> List[Dict[str, object]]:
        """Every parameter list of the project, selected ones first, in order.

        A file in the folder that no configuration mentions is still shown -
        that is how somebody finds the list a colleague added - it is simply not
        selected, so it takes no part in the build until someone says so.
        """
        # A configuration edited by hand can name the same file twice; the rows
        # are what the dialog binds its checkboxes to, so each file appears once
        # here and 'select_lists' drops the duplicate when it writes back.
        chosen: List[Path] = []
        for path in self.config.inputs.model_files:
            if path not in chosen:
                chosen.append(path)

        directory = self.list_directory()
        found = sorted(directory.glob("*.xml")) if directory.is_dir() else []

        entries: List[Dict[str, object]] = []
        for order, path in enumerate(chosen):
            entries.append(self._list_entry(path, selected=True, order=order))
        for path in found:
            if path not in chosen:
                entries.append(self._list_entry(path, selected=False, order=-1))
        return entries

    def _list_entry(self, path: Path, *, selected: bool, order: int) -> Dict[str, object]:
        return {
            "path": str(path),
            "name": path.stem,
            "file": path.name,
            "selected": selected,
            "order": order,
            "exists": path.is_file(),
            "current": self.path is not None and path == self.path,
            "inFolder": path.parent == self.list_directory(),
        }

    def create_list(self, name: str) -> Path:
        """Make a new, empty parameter list in the project's folder.

        It is written to disk straight away and added to the build, so the file
        the editor is about to open really exists and ``run_generate.py`` sees
        the same project the editor does.
        """
        stem = _safe_stem(name)
        if not stem:
            raise ValueError("A parameter list needs a name.")

        directory = self.list_directory()
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / f"{stem}.xml"
        if target.exists():
            raise FileExistsError(f"'{target.name}' already exists in {directory}.")

        fresh = ParameterList()
        fresh.defines = copy.deepcopy(self.model.defines)
        write_xml(fresh, target, emit_timestamp=self.config.codegen.emit_timestamp)

        self.select_lists([str(path) for path in self.config.inputs.model_files]
                          + [str(target)])
        return target

    def select_lists(self, paths: List[str]) -> List[Path]:
        """Set which lists take part in a build, in this order.

        The choice is written into the configuration file *and* into the
        configuration this session is using, so the change takes effect at once
        without a restart.
        """
        directory = self.list_directory()

        # The same list twice would be merged twice, and every parameter in it
        # would collide with itself - a screenful of NAME003 errors about names
        # the user only wrote once.  The first mention wins, so the order the
        # user chose is kept.
        chosen: List[Path] = []
        for item in paths:
            if not str(item).strip():
                continue
            path = Path(item).expanduser().resolve()
            if path not in chosen:
                chosen.append(path)

        # A list that lives in the project's folder is written as a bare file
        # name, which is what makes the folder the one place lists live in; one
        # kept elsewhere keeps a path relative to the configuration file.
        names: List[str] = []
        for path in chosen:
            if path.parent == directory:
                names.append(path.name)
            else:
                names.append(_relative_to(path, self.config.path.parent))

        rewrite_model_files(self.config.path, names)
        self.config.inputs.model_files = chosen
        return chosen

    # -- the library of reusable structure types --------------------------------
    #
    # A template is offered in the "Data type" list next to float32_t and the
    # other types, because that is where someone looks for "a Position".  What it
    # produces is an ordinary structure, not a link: the fields are *copied* into
    # the new parameter, which then owns them, so its limits, its unit and its
    # tags are edited exactly like any other parameter's and changing the
    # template later never rewrites a parameter behind the user's back.

    def templates(self) -> List[Parameter]:
        """The library of this module plus the ones the other modules define."""
        return self.merged_model().templates

    def find_template(self, name: str) -> Optional[Parameter]:
        return next((item for item in self.templates() if item.name == name), None)

    def save_template(self, path: str, name: str = "") -> Optional[str]:
        """Put the structure at *path* into the library.  Returns its name."""
        node = self.find(path)
        if node is None or not node.is_struct:
            return None
        name = (name or node.name).strip()
        if not name:
            return None

        self.snapshot("save type")
        template = copy.deepcopy(node)
        template.name = name
        _strip_to_template(template)

        existing = next((item for item in self.model.templates if item.name == name), None)
        if existing is not None:
            self.model.templates[self.model.templates.index(existing)] = template
        else:
            self.model.templates.append(template)
        return name

    def delete_template(self, name: str) -> Tuple[bool, str]:
        """Remove a type from *this* list's library.  ``(removed, why not)``.

        The list shown in the editor is the merged one, so it also holds the
        types the other parameter lists define - and this document cannot delete
        those: they live in a file it is not editing.  Saying so beats removing
        nothing and reporting success.
        """
        template = next((item for item in self.model.templates if item.name == name), None)
        if template is not None:
            self.snapshot("delete type")
            self.model.templates.remove(template)
            return True, ""

        owner = next((path.stem for path in self.config.inputs.model_files
                      if path != self.path and _defines_template(path, name)), "")
        if owner:
            return False, (f"The type '{name}' belongs to the parameter list '{owner}'. "
                           f"Open that list to remove it.")
        return False, f"There is no type called '{name}'."

    def apply_template(self, path: str, name: str) -> Optional[str]:
        """Turn the parameter at *path* into a structure built from a template.

        Everything that belongs to the *parameter* is kept - its name, its group,
        its tags, its array size, its description - and everything that belongs
        to the *value* is replaced by the fields of the template.  That is what
        makes the type list work the way the data types next to it do: choosing
        one changes what the parameter holds, not what it is called or how it is
        classified.
        """
        node = self.find(path)
        template = self.find_template(name)
        if node is None or template is None:
            return None

        self.snapshot("use type")
        node.kind = ParameterKind.STRUCT
        node.data_type_name = None
        node.unit = None
        node.default_value = None
        node.minimum = None
        node.maximum = None
        node.resolution = None
        node.children = [copy.deepcopy(child) for child in template.children]
        if not node.description:
            node.description = template.description
        return path

    # -- defines -------------------------------------------------------------
    def set_defines(self, column: str, values: List[str]) -> None:
        self.snapshot("defines")
        self.model.defines.values[column.upper()] = [str(v).strip()
                                                     for v in values if str(v).strip()]

    # -- validation and generation -------------------------------------------
    def merged_model(self) -> ParameterList:
        """This module as it is being edited, plus the others as they are on disk.

        The project is one parameter list even when it is split over several
        files, so a name or a log id clashing with another sub-module has to
        show up while editing, not at the end.
        """
        others = [path for path in self.config.inputs.model_files
                  if self.path is None or path != self.path]
        if not others:
            return self.model

        merged = copy.deepcopy(self.model)
        quiet = DiagnosticCollector()
        for path in others:
            if path.is_file():
                merged.extend(read_xml(path, quiet))
        return merged

    def validate(self) -> List[Dict[str, object]]:
        diagnostics = DiagnosticCollector()
        Validator(self.config).validate(self.merged_model(), diagnostics)
        return diagnostics.to_list()

    def generate(self) -> Dict[str, object]:
        """Save the model, then generate the code from every configured module.

        Saving first is not a convenience - it is what keeps the editor and
        ``run_generate.py`` from ever disagreeing.  If the editor generated from the
        model in its memory while the file on disk still held the previous
        version, the next command line run would silently produce different
        code.  So the file is written first, and the generator then reads the
        same files the command line reads.
        """
        diagnostics = DiagnosticCollector()
        pipeline = Pipeline(self.config)

        saved = None
        if self.path is not None:
            saved = self.save()

        # Every other sub-module is read from disk and merged in, so the editor
        # generates exactly what "python run_generate.py" would.
        model = pipeline.load_model(diagnostics) if saved is not None else self.model

        result = pipeline.generate(model, diagnostics)
        drift = result.drift
        return {
            "success": result.success,
            "files": [str(path) for path in result.generated_files],
            "count": result.parameter_count,
            "saved": str(saved) if saved else "",
            "modules": [str(path) for path in self.config.inputs.model_files],
            "diagnostics": diagnostics.to_list(),
            # What this build moved relative to the last one.  A value that
            # changed byte offset is a value a board already in the field will
            # read wrongly, so the editor shows this before anything else.
            "drift": {
                "breaksStoredData": drift.breaks_stored_data,
                "summary": drift.summary(),
                "report": drift.report(),
                "moved": [{"parameter": m.parameter, "tag": m.tag_id,
                           "old": m.old, "new": m.new} for m in drift.moved],
                "reindexed": [{"parameter": n, "old": o, "new": w}
                              for n, o, w in drift.reindexed],
                "added": list(drift.added),
                "removed": list(drift.removed),
                "firstRun": drift.first_run,
            } if drift is not None else None,
        }

    def next_free_log_id(self) -> int:
        """The first log id no parameter has reserved yet.

        ``flatten()`` has already spread every structure's block over its
        leaves, so looking at the leaves covers structures too.  A leaf reserves
        one id per *value* - ``reserved_log_ids``, not its size in bytes: a
        ``float64_t[10]`` at 410 ends at 419 and the next free id is 420.

        The other sub-modules count as well: the log ids of a project have to be
        unique across all of them, so an id that is free here but taken in
        another file is not free.
        """
        highest = 0
        for leaf in self.merged_model().flatten():
            log_id = leaf.tags.get("LogId")
            if isinstance(log_id, int) and not isinstance(log_id, bool):
                highest = max(highest, log_id + reserved_log_ids(leaf))
        return highest

    # -- what the front end renders -------------------------------------------
    def error_count(self) -> int:
        return sum(1 for item in self.validate()
                   if item["severity"] == Severity.ERROR.label)


def _default_tag(spec, defines: Defines):
    from common.pl_codegen.model.tags import TagKind
    if spec.kind is TagKind.BOOLEAN:
        return False
    if spec.kind is TagKind.ENUM and spec.defines_column:
        values = defines.get(spec.defines_column)
        return values[0] if values else None
    return None


def _defines_template(path: Path, name: str) -> bool:
    """Whether the parameter list at *path* defines a structure type called *name*."""
    if not path.is_file():
        return False
    quiet = DiagnosticCollector()
    return any(item.name == name for item in read_xml(path, quiet).templates)


def _safe_stem(name: str) -> str:
    """Turn what somebody typed into a file name that cannot surprise them.

    Only letters, digits, ``_`` and ``-`` survive, so a name can never walk out
    of the project's folder with a ``..`` or a slash, and never collides with a
    shell or a path separator on any of the three platforms this runs on.
    """
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", str(name).strip()).strip("_-")
    return cleaned[:64]


def _relative_to(path: Path, root: Path) -> str:
    """*path* written relative to *root* when it can be, else in full."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        pass
    try:
        return Path(os.path.relpath(path, root)).as_posix()
    except ValueError:
        return path.as_posix()


def _unique_name(base: str, siblings: List[Parameter]) -> str:
    taken = {node.name for node in siblings}
    if base not in taken:
        return base
    index = 2
    while f"{base}{index}" in taken:
        index += 1
    return f"{base}{index}"


def _strip_to_template(node: Parameter) -> None:
    """Reduce a structure to the type it describes.

    Tags, the group, the GS name and the array size belong to the *parameter*,
    not to its type: a copy takes those from whatever parameter it is copied
    into.  Everything below the top level is the type itself and is kept
    untouched - a ``Wheels[4]`` inside the structure is part of what the type
    *is*, and so are the limits, units and descriptions of every field.  That is
    what makes a template worth having.
    """
    node.kind = ParameterKind.STRUCT
    node.enable = True
    node.tags = {}
    node.group = None
    node.array_size = 1
    node.gs_name = None
    for child in node.walk():
        if child is not node:
            child.tags = {}
            child.group = None


def _clear_log_ids(node: Parameter) -> None:
    """A copy must not reuse the log ids of the original."""
    if "LogId" in node.tags:
        node.tags["LogId"] = None
    for child in node.children:
        _clear_log_ids(child)

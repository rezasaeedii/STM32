/* ==========================================================================
   app.js - wires the toolbar, the tree, the editor and the problems panel
   together.  This is the only file that knows about all of them.
   ========================================================================== */

const app = {
  state: null,
  selected: "",

  async start() {
    treeView.init(document.getElementById("tree"), (path, keepEditor) => {
      this.selected = path;
      this.paint(keepEditor);
    });
    editorView.init(
      document.getElementById("editor"),
      document.getElementById("editor-title"),
      document.getElementById("editor-path"),
      (changes) => this.applyChanges(changes));

    this.bindToolbar();
    this.bindShortcuts();
    trackTopbarHeight();
    await this.refresh();
    setStatus("Ready");
  },

  /* ------------------------------------------------------------ loading */
  async refresh(keepEditor) {
    this.state = await api.state();
    this.paint(keepEditor);
  },

  paint(keepEditor) {
    const state = this.state;

    document.getElementById("file-name").textContent = state.file || "(no file)";
    document.getElementById("file-name").classList.toggle("dirty", state.dirty);
    this.paintModules(state);
    document.getElementById("btn-undo").disabled = !state.canUndo;
    document.getElementById("btn-redo").disabled = !state.canRedo;

    const problemPaths = new Set(
      state.diagnostics.filter((d) => d.severity === "error")
                       .map((d) => d.location.parameter).filter(Boolean));
    treeView.render(state.tree, this.selected, problemPaths);

    const node = findNode(state.tree, this.selected);
    if (!node) { this.selected = ""; editorView.clear(); }
    else if (!keepEditor) editorView.show(node, state);

    this.paintProblems(state.diagnostics);
    this.paintCounts(state);
    this.updateButtons(node);
  },

  /* The project can be split over several files, one per sub-module. The
     editor works on one of them; the others are still validated against, so a
     clash between two sub-modules shows up here and not at the end. */
  paintModules(state) {
    const picker = document.getElementById("module-picker");
    const modules = state.modules || [];
    picker.hidden = modules.length < 2;
    if (picker.hidden) return;

    picker.innerHTML = modules.map((module) => {
      const label = escapeHtml(module.name) + (module.exists ? "" : " (new)");
      return `<option value="${escapeHtml(module.path)}"` +
             `${module.current ? " selected" : ""}>${label}</option>`;
    }).join("");
  },

  paintCounts(state) {
    const leaves = countLeaves(state.tree);
    const structs = countStructs(state.tree);
    document.getElementById("tree-count").textContent =
      `${leaves} value(s)` + (structs ? ` in ${structs} structure(s)` : "");
    const errors = state.diagnostics.filter((d) => d.severity === "error").length;
    const warnings = state.diagnostics.filter((d) => d.severity === "warning").length;
    document.getElementById("status-counts").textContent =
      `${leaves} values · ${errors} errors · ${warnings} warnings`;
  },

  paintProblems(diagnostics) {
    const badge = document.getElementById("problem-badge");
    const errors = diagnostics.filter((d) => d.severity === "error").length;
    const warnings = diagnostics.filter((d) => d.severity === "warning").length;
    badge.textContent = errors || warnings || 0;
    badge.className = "badge " + (errors ? "bad" : warnings ? "warn" : "ok");

    const list = document.getElementById("problems");
    if (!diagnostics.length) {
      list.innerHTML = `<div class="problem-empty">No problems. The model is ready to generate.</div>`;
      return;
    }
    const order = { error: 0, warning: 1, info: 2 };
    const sorted = diagnostics.slice().sort((a, b) => order[a.severity] - order[b.severity]);

    list.innerHTML = sorted.map((item) => `
      <div class="problem ${item.severity}" data-path="${escapeHtml(item.location.parameter || "")}">
        <span class="sev">${item.severity}</span>
        <span class="code">${escapeHtml(item.code)}</span>
        <span class="msg">${escapeHtml(item.message)}
          ${item.location.parameter ? `<span class="where">→ ${escapeHtml(item.location.parameter)}</span>` : ""}
          ${item.hint ? `<span class="hint">${escapeHtml(item.hint)}</span>` : ""}
        </span>
      </div>`).join("");

    for (const row of list.querySelectorAll(".problem")) {
      row.addEventListener("click", () => this.select(row.dataset.path));
    }
  },

  updateButtons(node) {
    /* the two "into the selected structure" buttons only make sense on a structure */
    const intoStruct = !node || node.kind !== "struct";
    document.getElementById("btn-add-field").disabled = intoStruct;
    document.getElementById("btn-add-substruct").disabled = intoStruct;
    for (const id of ["btn-duplicate", "btn-delete", "btn-up", "btn-down"]) {
      document.getElementById(id).disabled = !node;
    }
  },

  /* Select a node by path and reveal it (used by the Problems panel and by
     the "edit them on <structure>" button of a field). */
  select(path) {
    if (!path) return;
    this.selected = path;
    expandTo(path);
    this.paint();
  },

  /* ------------------------------------------------------------ editing */
  async applyChanges(changes) {
    if (!this.selected) return;
    const answer = await api.update(this.selected, changes);
    if (answer.selected) this.selected = answer.selected;
    await this.refresh();
    setStatus("Edited");
  },

  async addNode(kind, intoStruct) {
    const parent = intoStruct ? this.selected : "";
    const answer = await api.add(parent, kind);
    this.selected = answer.selected;
    if (parent) treeView.collapsed.delete(parent);
    await this.refresh();
    setStatus(kind === "struct" ? "Structure added" : "Parameter added");
  },

  /* --------------------------------------- the parameter lists of the project */
  /* A project is one parameter list split over several files. Which of them take
     part, and in what ORDER, decides the order of the indices in the generated
     code - so the choice is made here and written straight into
     codegen_config.json, which is the file run_generate.py reads. The editor and
     the command line then cannot disagree about what the project is. */
  async editListSelection() {
    const answer = await api.lists();
    /* the working copy the dialog edits; nothing is written until OK */
    let rows = answer.lists.map((item) => Object.assign({}, item));

    const render = () => {
      const chosen = rows.filter((r) => r.selected);
      const spare = rows.filter((r) => !r.selected);

      const line = (item, index, inOrder) => `
        <div class="list-row${item.selected ? " on" : ""}" data-path="${escapeHtml(item.path)}">
          <input type="checkbox" ${item.selected ? "checked" : ""} data-toggle>
          <div class="list-name">
            <b>${escapeHtml(item.name)}</b>
            <span class="hint mono">${escapeHtml(item.file)}${item.inFolder ? "" : "  (outside the folder)"}</span>
            ${item.exists ? "" : `<span class="hint">the file does not exist yet</span>`}
          </div>
          ${inOrder ? `<span class="count">#${index}</span>
            <button type="button" class="inline-btn" data-up ${index === 0 ? "disabled" : ""}>↑</button>
            <button type="button" class="inline-btn" data-down
                    ${index === chosen.length - 1 ? "disabled" : ""}>↓</button>` : ""}
        </div>`;

      document.getElementById("list-chosen").innerHTML =
        chosen.length ? chosen.map((item, index) => line(item, index, true)).join("")
                      : `<div class="problem-empty">Nothing is selected, so a build
                         would generate nothing.</div>`;
      document.getElementById("list-spare").innerHTML =
        spare.length ? spare.map((item) => line(item, 0, false)).join("")
                     : `<div class="problem-empty">Every list in the folder is in the build.</div>`;
      wire();
    };

    const wire = () => {
      for (const row of document.querySelectorAll(".list-row")) {
        const item = rows.find((r) => r.path === row.dataset.path);
        row.querySelector("[data-toggle]").addEventListener("change", (event) => {
          item.selected = event.target.checked;
          if (item.selected) { rows = rows.filter((r) => r !== item).concat([item]); }
          render();
        });
        const up = row.querySelector("[data-up]");
        const down = row.querySelector("[data-down]");
        if (up) up.addEventListener("click", () => { moveChosen(item, -1); render(); });
        if (down) down.addEventListener("click", () => { moveChosen(item, 1); render(); });
      }
    };

    /* Only the selected rows have an order, so the move works on that subset and
       is written back into the full list. */
    const moveChosen = (item, offset) => {
      const chosen = rows.filter((r) => r.selected);
      const index = chosen.indexOf(item);
      const target = index + offset;
      if (target < 0 || target >= chosen.length) return;
      chosen.splice(index, 1);
      chosen.splice(target, 0, item);
      const spare = rows.filter((r) => !r.selected);
      rows = chosen.concat(spare);
    };

    showModal("Parameter lists",
      `<p class="modal-note">Every list of the project lives in
       <code>${escapeHtml(answer.directory)}</code>. The ones that are ticked are
       merged into one parameter list, <b>in the order shown</b> &mdash; that order
       is the order of the indices in the generated code. The choice is saved into
       <code>${escapeHtml(answer.config)}</code>, so
       <code>run_generate.py</code> builds exactly what you see here.</p>
       <button type="button" class="inline-btn" id="btn-new-list">+ New parameter list</button>
       <label>In the build</label>
       <div class="list-box" id="list-chosen"></div>
       <label>In the folder, not in the build</label>
       <div class="list-box" id="list-spare"></div>`,
      async () => {
        const answer2 = await api.selectLists(rows.filter((r) => r.selected)
                                                  .map((r) => r.path));
        if (!answer2.ok) { toast(answer2.message || "Could not save the choice.", "bad"); return; }
        await this.refresh();
        toast(`${answer2.paths.length} list(s) take part in the build.`, "good");
      });

    render();
    document.getElementById("btn-new-list").addEventListener("click", () => this.newList());
  },

  /* Creating a list writes the file and puts it in the build straight away, so
     what the editor opens next is a file that really exists. */
  newList() {
    showModal("New parameter list",
      `<p class="modal-note">A new, empty list is created in the project's
       parameter-list folder and added to the build. It starts with the same
       drop-down lists as the one open now.</p>
       <label>Name</label>
       <input type="text" id="new-list-name" class="mono" value="parameter_list_">`,
      async () => {
        const name = document.getElementById("new-list-name").value.trim();
        const answer = await api.newList(name);
        if (!answer.ok) { toast(answer.message || "Could not create the list.", "bad"); return; }
        await api.open(answer.path);
        this.selected = "";
        await this.refresh();
        toast(`Created ${answer.path}`, "good");
        setStatus("New parameter list");
      });
  },

  /* ------------------------------------------- reusable structure types */
  /* A type is a shape, and a parameter made from one owns its copy: nothing
     links back, so editing the parameter never edits the type and editing the
     type never rewrites a parameter that was made earlier. */
  async useTemplate(path, name) {
    const answer = await api.useTemplate(path, name);
    if (!answer.ok) { toast(`No type called '${name}'.`, "bad"); return; }
    treeView.collapsed.delete(path);
    await this.refresh();
    toast(`'${path}' now holds a copy of the type '${name}'.`, "good");
    setStatus("Type applied");
  },

  saveTemplate(node) {
    const existing = (this.state.templates || []).some((t) => t.name === node.name);
    showModal("Save as a reusable type",
      `<p class="modal-note">The structure is stored in the type library under this
       name and appears in the <b>Data type</b> list of every parameter.</p>
       <label>Type name</label>
       <input type="text" id="template-name" class="mono"
              value="${escapeHtml(node.name)}">
       ${existing ? `<p class="modal-note">A type called
         <code>${escapeHtml(node.name)}</code> already exists; saving replaces it.
         Parameters made from it earlier keep the fields they have.</p>` : ""}`,
      async () => {
        const name = document.getElementById("template-name").value.trim();
        if (!name) { toast("A type needs a name.", "bad"); return; }
        const answer = await api.saveTemplate(node.path, name);
        if (!answer.ok) { toast(answer.message || "Could not save the type.", "bad"); return; }
        await this.refresh(true);
        toast(`'${answer.name}' is now in the Data type list.`, "good");
      });
  },

  editTemplates() {
    const templates = this.state.templates || [];
    if (!templates.length) {
      showModal("Structure types",
        `<p class="modal-note">The library is empty. Build a structure, select it,
         and press <b>Save as a type</b> in its editor; it then appears in the
         <b>Data type</b> list of every parameter, next to
         <code>float32_t</code>.</p>`, null);
      return;
    }

    const rows = templates.map((template) => `
      <div class="template-row" data-name="${escapeHtml(template.name)}">
        <div>
          <b>${escapeHtml(template.name)}</b>
          <span class="count">${template.fields} value(s) per copy</span>
          ${template.description ? `<div class="hint">${escapeHtml(template.description)}</div>` : ""}
          <div class="hint mono">${(template.shape || []).map(escapeHtml).join("<br>")}</div>
        </div>
        <button type="button" class="inline-btn danger" data-delete="${escapeHtml(template.name)}">
          Remove</button>
      </div>`).join("");

    showModal("Structure types",
      `<p class="modal-note">These are offered in the <b>Data type</b> list of every
       parameter. Removing one here changes nothing that was already built from it:
       a parameter owns its copy of the fields.</p>
       <div class="template-list">${rows}</div>`, null);

    for (const button of document.querySelectorAll("[data-delete]")) {
      button.addEventListener("click", async () => {
        const name = button.dataset.delete;
        const answer = await api.deleteTemplate(name);
        if (!answer.ok) {
          /* a type another parameter list owns cannot be removed from here */
          toast(answer.message || `Could not remove the type '${name}'.`, "bad");
          return;
        }
        await this.refresh(true);
        toast(`Type '${name}' removed from the library.`, "good");
        this.editTemplates();
      });
    }
  },

  /* ------------------------------------------------------------ toolbar */
  bindToolbar() {
    const on = (id, handler) => document.getElementById(id).addEventListener("click", handler);

    on("btn-save", () => this.save());
    on("btn-reload", async () => {
      if (this.state.dirty && !confirm("Discard the unsaved changes and reload?")) return;
      await api.open(null); this.selected = ""; await this.refresh(); setStatus("Reloaded");
    });

    document.getElementById("module-picker").addEventListener("change", async (event) => {
      const path = event.target.value;
      if (this.state.dirty &&
          !confirm("This module has unsaved changes. Switch anyway and lose them?")) {
        this.paint(true);   // put the picker back on the current module
        return;
      }
      await api.open(path);
      this.selected = "";
      await this.refresh();
      setStatus("Switched module");
    });

    on("btn-add", () => this.addNode("primitive", false));
    on("btn-add-struct", () => this.addNode("struct", false));
    on("btn-add-field", () => this.addNode("primitive", true));
    on("btn-add-substruct", () => this.addNode("struct", true));

    on("btn-duplicate", async () => {
      const answer = await api.duplicate(this.selected);
      if (answer.selected) this.selected = answer.selected;
      await this.refresh(); setStatus("Duplicated");
    });
    on("btn-delete", () => this.remove());
    on("btn-up", () => this.moveNode(-1));
    on("btn-down", () => this.moveNode(1));

    on("btn-undo", async () => { await api.undo(); await this.refresh(); setStatus("Undo"); });
    on("btn-redo", async () => { await api.redo(); await this.refresh(); setStatus("Redo"); });

    on("btn-lists-select", () => this.editListSelection());
    on("btn-types", () => this.editTemplates());
    on("btn-lists", () => this.editLists());
    on("btn-generate", () => this.generate());

    document.getElementById("filter").addEventListener("input", (event) => {
      treeView.filter = event.target.value.trim();
      this.paint(true);
    });

    document.getElementById("btn-toggle-problems").addEventListener("click", (event) => {
      event.stopPropagation();
      document.getElementById("problems-pane").classList.toggle("collapsed");
    });
  },

  bindShortcuts() {
    document.addEventListener("keydown", (event) => {
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
      if (event.ctrlKey && event.key.toLowerCase() === "s") { event.preventDefault(); this.save(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "g") { event.preventDefault(); this.generate(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "n") { event.preventDefault(); this.addNode("primitive", false); }
      else if (event.ctrlKey && event.key.toLowerCase() === "d") { event.preventDefault(); document.getElementById("btn-duplicate").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "z") { event.preventDefault(); document.getElementById("btn-undo").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "y") { event.preventDefault(); document.getElementById("btn-redo").click(); }
      else if (event.key === "Delete" && !typing && this.selected) { this.remove(); }
    });
  },

  async remove() {
    if (!this.selected) return;
    if (!confirm(`Delete '${this.selected}'?`)) return;
    await api.remove(this.selected);
    this.selected = "";
    await this.refresh();
    setStatus("Deleted");
  },

  async moveNode(offset) {
    await api.move(this.selected, offset);
    await this.refresh();
  },

  async save() {
    const answer = await api.save(null);
    await this.refresh(true);
    toast(`Saved to ${answer.path}`, "good");
    setStatus("Saved");
  },

  /* ------------------------------------------------------------ actions */
  async generate() {
    setStatus("Generating…");
    let result;
    try {
      result = await api.generate();
    } catch (error) {
      /* Never leave the page sitting on "Generating…": a request that failed
         outright still has to say so. */
      toast(`Generation failed: ${error.message}`, "bad");
      setStatus("Generation failed");
      return;
    }
    await this.refresh(true);
    if (!result.success) {
      toast(result.message
        ? `Nothing was generated: ${result.message}`
        : "The model has errors - nothing was generated. See Problems.", "bad");
      document.getElementById("problems-pane").classList.remove("collapsed");
      setStatus("Generation aborted");
      return;
    }
    const files = result.files.map((f) => `<div>${escapeHtml(f)}</div>`).join("");
    const modules = (result.modules || []).length > 1
      ? `<p class="modal-note">Read from ${result.modules.length} sub-module(s):</p>
         <div class="file-list">${result.modules
           .map((m) => `<div>${escapeHtml(m)}</div>`).join("")}</div>` : "";
    const saved = result.saved
      ? `<p class="modal-note">The model was saved to
         <code>${escapeHtml(result.saved)}</code> first, so
         <code>python run_generate.py</code> now produces exactly the same code.</p>` : "";

    const drift = this.driftHtml(result.drift);

    showModal(result.drift && result.drift.breaksStoredData
                ? "Code generated - CHECK THE MEMORY LAYOUT"
                : "Code generated",
      `${drift}${saved}${modules}<p class="modal-note">${result.count} value(s) written into
       ${result.files.length} file(s):</p><div class="file-list">${files}</div>`,
      null);
    setStatus(result.drift && result.drift.breaksStoredData
      ? `Generated ${result.files.length} files - the memory layout MOVED`
      : `Generated ${result.files.length} files`);
  },

  /* --------------------------------------------- the memory layout warning */
  /* The offset of a reset-proof value is positional: it is the sum of the sizes
     of everything before it. So inserting a parameter in the middle, disabling
     one, moving one, or widening one moves EVERY parameter after it - and a
     board that already has data in flash then reads the wrong value at the old
     offset. None of that shows up in the generated code, which is why the
     editor says it here, before anything else in the dialog. */
  driftHtml(drift) {
    if (!drift || drift.firstRun) return "";

    if (drift.breaksStoredData) {
      const rows = drift.moved.slice(0, 14).map((m) => `
        <tr><td class="mono">${escapeHtml(m.parameter)}</td>
            <td class="mono">${escapeHtml(m.tag)}</td>
            <td class="c mono">${m.old}</td><td class="c mono">${m.new}</td></tr>`).join("");
      const more = drift.moved.length > 14
        ? `<p class="hint">... and ${drift.moved.length - 14} more.</p>` : "";
      return `<div class="drift bad">
        <b>The stored position of ${drift.moved.length} value(s) changed.</b>
        <p>A board that already has data in flash will read the <b>wrong value</b>
           at these offsets. Before flashing, erase the stored area, migrate it,
           or move the new parameters to the <b>end</b> of the list instead of
           the middle.</p>
        <div class="drift-table">
          <table><tr><th>parameter</th><th>tag</th><th class="c">was</th>
                     <th class="c">now</th></tr>${rows}</table>
        </div>${more}
      </div>`;
    }

    const bits = [];
    if (drift.added.length) bits.push(`${drift.added.length} added`);
    if (drift.removed.length) bits.push(`${drift.removed.length} removed`);
    if (drift.reindexed.length) bits.push(`${drift.reindexed.length} reindexed`);
    if (!bits.length) return "";
    return `<div class="drift ok">
      <b>The list changed, but nothing moved.</b>
      <p>${escapeHtml(bits.join(", "))} &mdash; every value that existed before is
         still at the same offset, so a board in the field keeps reading what it
         was reading.</p></div>`;
  },


  /* The four drop-down lists the editor offers, and the enums generated from them. */
  editLists() {
    const defines = this.state.defines;
    const keys = ["groups", "systemNames", "paramModes", "types"];
    const labels = {
      groups: "Groups", systemNames: "System names",
      paramModes: "Parameter modes", types: "Data types",
    };

    let body = `<p class="modal-note">One value per line, in the order they should get
       their enum value. These are the choices the editor offers and the enumerations
       the generator writes into <code>cg_parameter_list_defines.h</code>.</p>
       <button type="button" class="inline-btn" id="btn-restore-lists">
         Restore the company defaults</button>`;
    for (const key of keys) {
      body += `<label>${labels[key]} <span class="count" id="count-${key}"></span></label>
        <textarea id="list-${key}">${escapeHtml((defines[key] || []).join("\n"))}</textarea>`;
    }

    showModal("Drop-down lists", body, async () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").map((v) => v.trim()).filter(Boolean);
        await api.setDefines(key, values);
      }
      await this.refresh();
      toast("Lists updated.", "good");
    });

    /* live count under each box, so a truncated list is obvious */
    const recount = () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").filter((v) => v.trim());
        document.getElementById(`count-${key}`).textContent = `(${values.length})`;
      }
    };
    for (const key of keys) {
      document.getElementById(`list-${key}`).addEventListener("input", recount);
    }
    recount();

    document.getElementById("btn-restore-lists").addEventListener("click", async () => {
      const defaults = await api.defaultDefines();
      for (const key of keys) {
        document.getElementById(`list-${key}`).value = (defaults[key] || []).join("\n");
      }
      recount();
    });
  },
};

/* ---------------------------------------------------------------- helpers */
/* Everything below the top bar is positioned from --topbar-h, and the toolbar
   wraps to a second row on a narrow window, so that height cannot be a constant:
   it is measured here and republished whenever the bar changes size.  Without
   this the wrapped row lies on top of the parameter tree. */
function trackTopbarHeight() {
  const bar = document.querySelector(".topbar");
  if (!bar) return;
  const apply = () => document.documentElement.style.setProperty(
    "--topbar-h", `${Math.ceil(bar.getBoundingClientRect().height)}px`);
  if (window.ResizeObserver) new ResizeObserver(apply).observe(bar);
  else window.addEventListener("resize", apply);
  apply();
}

function findNode(nodes, path) {
  for (const node of nodes) {
    if (node.path === path) return node;
    const found = findNode(node.children || [], path);
    if (found) return found;
  }
  return null;
}

/* How many values these nodes put in the generated table.  An array of
   structures contributes one full set of values PER ELEMENT, which is what
   makes this different from simply counting the leaves of the tree - get it
   wrong and the count under the tree disagrees with PARAMETER_LIST_QTY. */
function countLeaves(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (!node.enable) continue;
    total += node.kind === "struct"
      ? countLeaves(node.children) * Math.max(1, node.arraySize || 1)
      : 1;
  }
  return total;
}

function countStructs(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === "struct") total += 1 + countStructs(node.children);
  }
  return total;
}

function expandTo(path) {
  const parts = path.split(".");
  for (let index = 1; index < parts.length; index++) {
    treeView.collapsed.delete(parts.slice(0, index).join("."));
  }
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

let toastTimer = null;
function toast(message, kind) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.className = "toast " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.add("hidden"), 4200);
}

function showModal(title, bodyHtml, onOk) {
  const modal = document.getElementById("modal");
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-body").innerHTML = bodyHtml;
  const okButton = document.getElementById("modal-ok");
  const cancelButton = document.getElementById("modal-cancel");
  okButton.textContent = onOk ? "OK" : "Close";
  cancelButton.style.display = onOk ? "" : "none";

  const close = () => { modal.classList.add("hidden"); };
  okButton.onclick = async () => { if (onOk) await onOk(); close(); };
  cancelButton.onclick = close;
  modal.classList.remove("hidden");
}

window.addEventListener("DOMContentLoaded", () => app.start());

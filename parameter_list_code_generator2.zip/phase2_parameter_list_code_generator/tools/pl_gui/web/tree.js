/* ==========================================================================
   tree.js - draws the parameter tree on the left and reports clicks.
   ========================================================================== */

const treeView = {
  element: null,
  onSelect: () => {},
  collapsed: new Set(),
  filter: "",

  init(element, onSelect) {
    this.element = element;
    this.onSelect = onSelect;
  },

  /* nodes: the "tree" array of /api/state ; problems: dotted paths with errors */
  render(nodes, selectedPath, problemPaths) {
    const rows = [];
    const walk = (list, depth) => {
      for (const node of list) {
        const open = !this.collapsed.has(node.path);
        rows.push(this.row(node, depth, selectedPath, problemPaths, open));
        if (node.kind === "struct" && open) walk(node.children, depth + 1);
      }
    };
    walk(nodes, 0);

    this.element.innerHTML = rows.join("");
    for (const row of this.element.querySelectorAll(".tree-row")) {
      row.addEventListener("click", (event) => {
        if (event.target.classList.contains("twisty")) {
          const path = row.dataset.path;
          if (this.collapsed.has(path)) this.collapsed.delete(path);
          else this.collapsed.add(path);
          this.onSelect(path, true);
          return;
        }
        this.onSelect(row.dataset.path, false);
      });
    }
  },

  row(node, depth, selectedPath, problemPaths, open) {
    const classes = ["tree-row"];
    if (node.path === selectedPath) classes.push("selected");
    if (!node.enable) classes.push("disabled");
    if (problemPaths.has(node.path)) classes.push("has-error");
    if (this.filter && !this.matches(node)) classes.push("hidden");

    const isStruct = node.kind === "struct";
    const twisty = isStruct
      ? `<span class="twisty">${open ? "▾" : "▸"}</span>`
      : `<span class="twisty leaf">•</span>`;
    const icon = isStruct
      ? `<span class="node-icon struct">▣</span>`
      : `<span class="node-icon prim">◆</span>`;

    const type = isStruct
      ? `struct (${node.children.length})`
      : escapeHtml(node.dataType || "—");
    const array = node.arraySize > 1 ? `<span class="node-badge">[${node.arraySize}]</span>` : "";

    return `
      <div class="${classes.join(" ")}" data-path="${escapeHtml(node.path)}"
           style="padding-left:${12 + depth * 16}px">
        <span class="name-cell">${twisty}${icon}
          <span class="node-name">${escapeHtml(node.name)}</span>${array}</span>
        <span class="col-type">${type}</span>
        <span class="col-group">${escapeHtml(node.group || "")}</span>
      </div>`;
  },

  matches(node) {
    const needle = this.filter.toLowerCase();
    if (node.path.toLowerCase().includes(needle)) return true;
    return (node.children || []).some((child) => this.matches(child));
  },
};

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

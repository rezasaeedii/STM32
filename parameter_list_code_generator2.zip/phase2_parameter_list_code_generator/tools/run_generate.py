"""Entry point of the parameter-list code generator.

Usage (from anywhere; the configuration next to this file is the default)::

    python run_generate.py            # generates the C files
    python run_generate.py --check    # validates the lists, writes nothing

Phase 2 needs no package installed at all - ``setup_environment.py`` only
checks that the Python on this machine is complete enough.  Everything else is
configured in ``codegen_config.json``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running the script directly from any working directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from common.pl_codegen.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())

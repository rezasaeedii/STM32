"""Entry point of the environment check.

    cd tools
    python run_setup.py

Like every other ``run_*.py`` in this folder it is deliberately three lines
long: the real work lives in a module (:mod:`setup_environment`) and this file
only exists so that **every user-facing action has the same shape**::

    run_gui.py       run_gui.bat        the graphical editor
    run_generate.py  run_generate.bat   generate the C files
    run_tests.py     run_tests.bat      run every self test
    run_setup.py     run_setup.bat      check this machine

Nobody has to remember which of them is a script and which is a module, and
the ``tools`` folder answers "what can I run?" by itself.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from setup_environment import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())

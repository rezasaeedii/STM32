# -*- coding: utf-8 -*-
"""Render the reference of ``pl_gui/web/`` — the same shape as render.py.

A separate renderer rather than a flag on the Python one, because the words
differ: a JavaScript file has an *object* with *members*, not a class with
methods, and its "constants" are section titles in CSS and element ids in HTML.
Forcing all three into the Python vocabulary would produce a table with the
wrong headings, which is worse than a second forty-line module.
"""

import html
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WEB_API = {f["path"]: f for f in
           json.load(open(HERE / "web_api.json", encoding="utf-8"))}

#: Column heading of the "constants" table, per file kind.  This is the whole
#: reason this module exists.
CONST_TITLE = {
    ".html": ("عنصرهای دارای <code>id</code>",
              "<tr><th style='width:34%'>id</th><th>چه چیزی است</th></tr>"),
    ".css": ("بخش‌های فایل",
             "<tr><th style='width:34%'>بخش</th><th>انتخابگرهای اصلی</th></tr>"),
    ".js": ("ثابت‌های ماژول",
            "<tr><th style='width:34%'>نام</th><th>مقدار / معنی</th></tr>"),
}


def esc(s):
    return html.escape(str(s), quote=False)


def web_file_block(path, notes, level=2):
    f = WEB_API[path]
    n = notes.get(path, {})
    key = path.replace("/", "_").replace(".", "_")
    sym = n.get("sym", {})
    out = [f'<h{level} id="f_{key}"><code>{esc(path)}</code> '
           f'<span class="ln">— {f["lines"]} خط</span>'
           f'<span class="pgm">PGM{key}PGM</span></h{level}>']
    if n.get("fa"):
        out.append(n["fa"])
    if n.get("when"):
        out.append(f'<p class="when"><b>کِی سراغش می‌روید:</b> {n["when"]}</p>')

    suffix = "." + path.rsplit(".", 1)[1]
    if f["constants"]:
        title, head = CONST_TITLE[suffix]
        out.append(f'<p class="sub">{title}</p><table class="api">{head}')
        for c in f["constants"]:
            described = sym.get(c["name"], "")
            value = f'<code>{esc(c["value"])}</code>' if c["value"] else ""
            out.append(f'<tr><td class="mono">{esc(c["name"])}</td>'
                       f'<td>{value} {described}</td></tr>')
        out.append("</table>")

    for obj in f["classes"]:
        out.append(f'<p class="cls"><span class="kw">const</span> '
                   f'<b>{esc(obj["name"])}</b> = {{ … }}</p>')
        described = sym.get(obj["name"], "")
        if described:
            out.append(f'<p class="clsdoc">{described}</p>')
        owner = obj["name"]
        if obj["fields"]:
            out.append('<table class="api"><tr><th style="width:26%">حالت</th>'
                       '<th style="width:26%">مقدار اولیه</th><th>معنی</th></tr>')
            for field in obj["fields"]:
                described = sym.get(owner + "." + field["name"], "")
                out.append(f'<tr><td class="mono">{esc(field["name"])}</td>'
                           f'<td class="mono">{esc(field["default"])}</td>'
                           f'<td>{described}</td></tr>')
            out.append("</table>")
        if obj["members"]:
            out.append('<table class="api"><tr><th style="width:46%">عضو</th>'
                       '<th>کار</th></tr>')
            for member in obj["members"]:
                name = member["sig"].split("(")[0]
                tag = ('<span class="pill">async</span>'
                       if member["decorators"] else "")
                described = sym.get(owner + "." + name, "")
                out.append(f'<tr><td class="mono sigcell">{esc(member["sig"])}</td>'
                           f'<td>{tag} {described}</td></tr>')
            out.append("</table>")

    if f["functions"]:
        out.append('<p class="sub">توابع سطح فایل</p>'
                   '<table class="api"><tr><th style="width:46%">تابع</th>'
                   '<th>کار</th></tr>')
        for fn in f["functions"]:
            name = fn["sig"].split("(")[0]
            out.append(f'<tr><td class="mono sigcell">{esc(fn["sig"])}</td>'
                       f'<td>{sym.get(name, "")}</td></tr>')
        out.append("</table>")

    if n.get("after"):
        out.append(n["after"])
    return "\n".join(out)

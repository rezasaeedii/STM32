# -*- coding: utf-8 -*-
"""Inventory of ``pl_gui/web/`` — the files the browser loads.

``inventory.py`` walks the Python with :mod:`ast`, which is exact.  There is no
such luxury here: JavaScript, CSS and HTML each need their own reader, and none
of them can be parsed properly in a hundred lines.  So this module does the one
thing that IS reliable for the way these four files are written, and refuses to
guess about anything else:

* **JavaScript** — every file in ``web/`` is one top-level ``const NAME = {...}``
  object plus a few plain functions.  A brace-depth scan finds the object and
  its members exactly, because a member at depth 1 of that object is a member
  and nothing else can be.
* **CSS** — the selectors are grouped by the ``/* ---- title ---- */`` banner
  comments the file already uses, so the manual shows the same sections a
  reader sees when they open the file.
* **HTML** — every ``id="..."`` is collected, because an ``id`` is precisely the
  handle JavaScript uses; anything without one is layout the reader can see for
  themselves.

The output is ``web_api.json``, shaped like ``api.json`` so that the manual's
renderer treats a ``.js`` file exactly like a ``.py`` one.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
WEB = HERE.parent.parent / "tools" / "pl_gui" / "web"

#: Files documented, in the order the manual presents them: what the page IS,
#: then what it LOOKS like, then what it DOES (innermost layer first).
FILES = ["index.html", "style.css", "api.js", "tree.js", "editor.js", "app.js"]


def _strip_comments(text: str) -> str:
    """Blank out //, /*...*/ and string bodies, keeping every byte position.

    Positions have to survive, because the brace scan below reports offsets
    back into the original text.  So each removed character becomes a space
    instead of disappearing.
    """
    out = list(text)
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            while i < n and text[i] != "\n":
                out[i] = " "
                i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            while i < n and not (text[i] == "*" and i + 1 < n and text[i + 1] == "/"):
                if text[i] != "\n":
                    out[i] = " "
                i += 1
            for j in range(i, min(i + 2, n)):
                out[j] = " "
            i += 2
        elif c in "\"'`":
            quote = c
            i += 1
            while i < n and text[i] != quote:
                if text[i] == "\\":
                    out[i] = " "
                    i += 1
                if i < n and text[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = " "
            i += 1
        else:
            i += 1
    return "".join(out)


_MEMBER = re.compile(r"^\s*(?:(async)\s+)?([A-Za-z_$][\w$]*)\s*\(([^)]*)\)\s*\{")
_FIELD = re.compile(r"^\s*([A-Za-z_$][\w$]*)\s*:\s*(.+?),?\s*$")
_FUNC = re.compile(r"^function\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)", re.M)
_CONST = re.compile(r"^const\s+([A-Z][A-Z0-9_]*)\s*=\s*(.+?);\s*$", re.M)


def _js_objects(text: str, blank: str):
    """Every top-level ``const NAME = { ... }`` with its depth-1 members."""
    objects = []
    for match in re.finditer(r"^const\s+([A-Za-z_$][\w$]*)\s*=\s*\{", blank, re.M):
        name = match.group(1)
        start = blank.index("{", match.start())
        depth, i, n = 0, start, len(blank)
        while i < n:
            if blank[i] == "{":
                depth += 1
            elif blank[i] == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        body_lines = text[start + 1:i].splitlines()
        blank_lines = blank[start + 1:i].splitlines()

        members, fields, depth = [], [], 0
        for real, safe in zip(body_lines, blank_lines):
            if depth == 0:
                hit = _MEMBER.match(safe)
                if hit:
                    args = ", ".join(a.strip().split("=")[0].strip()
                                     for a in hit.group(3).split(",") if a.strip())
                    members.append({
                        "sig": f"{hit.group(2)}({args})",
                        "doc": "", "private": hit.group(2).startswith("_"),
                        "decorators": ["async"] if hit.group(1) else [],
                    })
                else:
                    field = _FIELD.match(safe)
                    if field and "(" not in field.group(2).split("=>")[0]:
                        value = real.strip().split(":", 1)[1].strip().rstrip(",")
                        fields.append({"name": field.group(1), "type": "",
                                       "default": value[:60]})
            depth += safe.count("{") + safe.count("[") - safe.count("}") - safe.count("]")
        objects.append({"name": name, "bases": [], "decorators": [], "doc": "",
                        "fields": fields, "members": members})
    return objects


def _css_sections(text: str):
    """The banner comments of style.css, and the selectors under each."""
    sections, title, selectors = [], "بالای فایل", []
    for line in text.splitlines():
        banner = re.match(r"\s*/\*\s*[-=]{2,}\s*(.+?)\s*(?:[-=]{2,}\s*)?\*/", line)
        if banner:
            if selectors:
                sections.append({"name": title, "value": " · ".join(selectors[:9])})
            title, selectors = banner.group(1), []
            continue
        rule = re.match(r"^([.#:\[a-zA-Z][^{}/\n]*?)\s*\{\s*$", line)
        if rule:
            selectors.append(rule.group(1).strip())
    if selectors:
        sections.append({"name": title, "value": " · ".join(selectors[:9])})
    return sections


def collect():
    files = []
    for name in FILES:
        path = WEB / name
        text = path.read_text(encoding="utf-8")
        entry = {"path": f"pl_gui/web/{name}", "lines": len(text.splitlines()),
                 "classes": [], "functions": [], "constants": []}

        if name.endswith(".js"):
            blank = _strip_comments(text)
            entry["classes"] = _js_objects(text, blank)
            for hit in _FUNC.finditer(blank):
                args = ", ".join(a.strip().split("=")[0].strip()
                                 for a in hit.group(2).split(",") if a.strip())
                entry["functions"].append({"sig": f"{hit.group(1)}({args})",
                                           "doc": "", "private": False})
            entry["constants"] = [{"name": c.group(1), "value": c.group(2)[:60]}
                                  for c in _CONST.finditer(blank)]
        elif name.endswith(".css"):
            entry["constants"] = _css_sections(text)
        else:
            ids = re.findall(r'id="([^"]+)"', text)
            entry["constants"] = [{"name": i, "value": ""} for i in ids]
        files.append(entry)
    return files


if __name__ == "__main__":
    data = collect()
    (HERE / "web_api.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(data)} web files")
    for f in data:
        members = sum(len(c["members"]) for c in f["classes"])
        print(f"  {f['path']:<26} {f['lines']:>4} خط | "
              f"{len(f['classes'])} آبجکت، {members} عضو، "
              f"{len(f['functions'])} تابع، {len(f['constants'])} ورودی")

# -*- coding: utf-8 -*-
"""Persian prose for xml_model/ - the contract between input and generator."""

NOTES = {}

NOTES["common/pl_codegen/xml_model/__init__.py"] = {
 "fa": "<p>چند <code>import</code> برای راحتی.</p>", "when": "به‌ندرت."}

NOTES["common/pl_codegen/xml_model/schema.py"] = {
 "fa": """<p><b>قرارداد XML، در یک فایل.</b> فقط ثابت است: نام هر عنصر و هر صفت، به‌علاوه‌ی
<code>SCHEMA_VERSION</code>. نویسنده و خواننده هر دو از همین ثابت‌ها استفاده می‌کنند، پس
عوض کردن نام یک صفت در یک جا کافی است و دو طرف هیچ‌وقت از هم جدا نمی‌افتند.</p>
<p>GUI فاز بعد هم دقیقاً همین فایل را <code>import</code> می‌کند — این تنها چیزی است که
باید درباره‌ی قالب بداند.</p>""",
 "when": "وقتی به عنصر یا صفت تازه‌ای در XML نیاز دارید. اگر قالب طوری عوض شود که نسخه‌های قدیمی نخوانند، <code>SCHEMA_VERSION</code> را هم بالا ببرید.",
 "sym": {"SCHEMA_VERSION": "نسخه‌ی قالب XML؛ خواننده آن را چک می‌کند."},
}

NOTES["common/pl_codegen/xml_model/xml_writer.py"] = {
 "fa": """<p>مدل ⟵ XML، با <code>xml.etree.ElementTree</code> از کتابخانه‌ی استاندارد (هیچ
وابستگی خارجی).</p>
<p><code>_indent()</code> فایل را تورفته می‌کند؛ این فقط زیبایی نیست: یک XML تک‌خطی در
<code>git diff</code> غیرقابل خواندن است.</p>""",
 "when": "وقتی فیلد تازه‌ای باید در XML ذخیره شود. یادتان باشد خواننده را هم به‌روز کنید.",
 "sym": {
  "model_to_element": "کل مدل را به درخت عنصرها تبدیل می‌کند.",
  "write_xml": "درخت را در فایل می‌نویسد. با <code>emit_timestamp=False</code> صفت <code>generatedAt</code> نوشته نمی‌شود و فایل بین دو اجرا بایت‌به‌بایت یکسان می‌ماند.",
  "_parameter_to_element": "یک <code>Parameter</code> را به یک عنصر <code>&lt;Parameter&gt;</code> تبدیل می‌کند.",
  "_text": "مقدار را به متن XML تبدیل می‌کند.",
  "_set": "یک صفت را ست می‌کند و مقدار <code>None</code> را کلاً نمی‌نویسد.",
  "_indent": "تورفتگی می‌دهد تا فایل و diff آن خوانا باشد.",
 },
}

NOTES["common/pl_codegen/xml_model/xml_reader.py"] = {
 "fa": """<p>XML ⟵ مدل. نسخه‌ی schema را چک می‌کند و هر مشکلی را به‌جای استثنا، به پیام
تبدیل می‌کند. این مسیری است که <b>هر دو</b> حالت از آن رد می‌شوند: هم مرحله‌ی ۲ اجرای
عادی، هم <code>--from-xml</code> که GUI فاز بعد استفاده می‌کند.</p>""",
 "when": "وقتی فیلد تازه‌ای به XML اضافه شده و باید خوانده شود.",
 "sym": {
  "read_xml": "فایل XML را به یک <code>ParameterList</code> تبدیل می‌کند.",
  "_read_parameter": "یک عنصر <code>&lt;Parameter&gt;</code> را می‌خواند.",
  "_read_defines": "بخش <code>&lt;Defines&gt;</code> را می‌خواند.",
  "_to_bool": "یک صفت را بولین تفسیر می‌کند.",
  "_to_int": "یک صفت را عدد صحیح تفسیر می‌کند، با مقدار پیش‌فرض.",
  "_to_optional_int": "عدد صحیح یا <code>None</code>.",
  "_to_number": "یک مقدار عددی <code>&lt;Limits&gt;</code> را می‌خواند و هر چیزِ خوانده‌نشدنی را <b>گزارش</b> می‌کند.",
  "_report_bad_number": "پیام <code>XML012</code> برای مقدار خوانده‌نشدنی.",
  "_convert_tag": "مقدار متنی یک تگ را بر اساس <code>TagKind</code> به نوع درست تبدیل می‌کند.",
 },
 "after": """<div class="warn">
<b>هیچ مقداری بی‌صدا دور ریخته نمی‌شود</b>
<p>
اگر کسی XML را دستی ویرایش کند و بنویسد <code>maximum="99.9"</code> روی یک تایپ صحیح،
نسخه‌ی اولیه بی‌صدا <code>None</code> می‌داد — و <code>None</code> یعنی «خالی» یعنی
«بازه ندارم». حالا <code>XML012</code> داده می‌شود. <b>قاعده: در خواننده‌ی XML هیچ‌وقت
مقداری را بی‌صدا دور نریزید.</b>
</p>
</div>""",
}

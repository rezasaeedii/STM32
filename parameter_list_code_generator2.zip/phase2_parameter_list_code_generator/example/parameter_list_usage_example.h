/**
  ******************************************************************************
  * @file    parameter_list_usage_example.h
  * @brief   Short example of how the generated parameter list is used.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef PARAMETER_LIST_USAGE_EXAMPLE_H
#define PARAMETER_LIST_USAGE_EXAMPLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_types.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
void fExample_DirectAccess(void);

eSmartDataStatus fExample_CheckedAccess(void);

uint8_t fExample_StructAccess(void);

uint8_t fExample_DescriptorAccess(void);

void fExample_ArrayAccess(void);

bool_t fExample_ReadIfNew(void);

void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset);

uint8_t fExample_UseHome(const sCgStruct_Position_Home *pHome);

/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* PARAMETER_LIST_USAGE_EXAMPLE_H */

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    parameter_list_usage_example.c
  * @brief   Short example of how the generated parameter list is used.
  *
  * This file is NOT generated and is NOT part of the firmware; it only shows
  * how an application reaches a parameter, including the fields of a structure.
  * Delete it whenever you do not need it any more.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  @verbatim

  @endverbatim
  */

/* Includes ----------------------------------------------------------------- */
#include "parameter_list_usage_example.h"

#include "cg_parameter_list.h"

/* Private defines ---------------------------------------------------------- */
#define EXAMPLE_USER_NUMBER  0U   /*!< This module's reader slot (0 .. 31). */

/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Way 1 - direct access to the generated object (fastest, no checks).
 *
 * @note  Writing 'Value' directly skips the allowed range check and does not
 *        update the timestamp. Use it only where speed really matters.
 *
 */
void fExample_DirectAccess(void) {

    float32_t airspeed = Cg_SmartData_Airspeed.Value;

    Cg_SmartData_Airspeed.Value = airspeed + 1.0f;
}

/**
 * @brief Way 2 - access through the smart-data API (range check + timestamp).
 *
 * @return eSmartDataStatus eSMART_DATA_OK, or the reason the write was refused.
 *
 */
eSmartDataStatus fExample_CheckedAccess(void) {

    float32_t value = 0.0f;
    float32_t newValue = 7.0f;
    eSmartDataStatus status = eSMART_DATA_OK;

    status = fSmartDataRead_(&Cg_SmartData_Airspeed, &value);
    if (status != eSMART_DATA_OK) {
        return status;
    }

    /* Refused with eSMART_DATA_ERROR_VALUE_OUT_OF_RANGE when the value is
       outside [Minimum, Maximum] set in the editor. */
    return fSmartDataWrite_(&Cg_SmartData_Airspeed, &newValue);
}

/**
 * @brief Way 3 - a structure parameter.
 *
 * @note  A structure is ONE C object whose members are the smart-data objects
 *        of its fields, so the tree built in the editor is the tree in the code.
 *
 * @return uint8_t 0 on success.
 *
 */
uint8_t fExample_StructAccess(void) {

    float64_t latitude = 0.0;
    float32_t altitude = 0.0f;

    /* Nested field: Position -> Home -> Lat */
    if (fSmartDataRead_(&Cg_SmartData_Position.Home.Lat, &latitude) != eSMART_DATA_OK) {
        return 1U;
    }
    if (fSmartDataRead_(&Cg_SmartData_Position.Alt, &altitude) != eSMART_DATA_OK) {
        return 1U;
    }

    /* The whole structure can be passed around as one object. */
    return fExample_UseHome(&Cg_SmartData_Position.Home);
}

/**
 * @brief Way 4 - access by index or by name through the descriptor table.
 *
 * @note  A field of a structure is listed under its dotted name, so the table
 *        stays flat even though the data is nested.
 *
 * @return uint8_t 0 when both look-ups succeeded.
 *
 */
uint8_t fExample_DescriptorAccess(void) {

    float64_t latitude = 0.0;

    /* By index: POSITION_HOME_LAT comes from cg_parameter_list_defines.h */
    const sParameterDescriptor *pByIndex = fParameterList_GetByIndex(POSITION_HOME_LAT);

    /* By name: useful for a command that arrives as text */
    const sParameterDescriptor *pByName = fParameterList_GetByName("Position.Home.Lat");

    if ((pByIndex == NULL) || (pByName != pByIndex)) {
        return 1U;
    }

    if (fSmartDataRead_(pByIndex->pSmartData, &latitude) != eSMART_DATA_OK) {
        return 1U;
    }

    /* tags are interpreted by the application, not by the generator */
    if (pByName->TagLoggable.Value != 0U) {
        fExample_SendToLog(pByName->TagLogId.Value, &latitude,
                           pByName->TagLoggable.MemoryOffset);
    }

    return 0U;
}

/**
 * @brief Way 5 - an array field is 'ArraySize' smart-data objects in a row.
 *
 */
void fExample_ArrayAccess(void) {

    uint16_t index = 0U;
    int16_t sample = 0;

    for (index = 0U; index < POSITION_SAMPLES_ARRAY_SIZE; index++) {
        (void)fSmartDataRead_(&Cg_SmartData_Position.Samples[index], &sample);
    }

    /* The same array reached through the descriptor table. */
    {
        const sParameterDescriptor *pDescriptor = &ParameterList[POSITION_SAMPLES];
        sSmartDataI16 *pElements = (sSmartDataI16 *)pDescriptor->pSmartData;

        for (index = 0U; index < pDescriptor->ArraySize; index++) {
            (void)fSmartDataRead_(&pElements[index], &sample);
        }
    }
}

/**
 * @brief Detecting a value this module has not read yet.
 *
 * @return bool_t TRUE when a fresh value was consumed.
 *
 */
bool_t fExample_ReadIfNew(void) {

    float32_t airspeed = 0.0f;
    eSmartDataStatus status = eSMART_DATA_OK;

    if (fSmartDataHasUserReadOnce_(&Cg_SmartData_Airspeed, EXAMPLE_USER_NUMBER)) {
        return FALSE;
    }

    fSmartDataUserRead_(&Cg_SmartData_Airspeed, EXAMPLE_USER_NUMBER, &airspeed, status);

    return (bool_t)(status == eSMART_DATA_OK);
}

/**
 * @brief Called by the generated fParameterList_Init() once everything is up.
 *
 * @note  Defined here WITHOUT the weak specifier, so it overrides the generated
 *        default implementation.
 *
 * @return uint8_t 0 on success.
 *
 */
uint8_t fParameterList_InitCompletedCallback(void) {

    /* Good place to restore the reset-proof parameters from their storage,
       using PARAMETER_LIST_OFFSET_RESET_PROOF_* from the defines header. */
    return 0U;
}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

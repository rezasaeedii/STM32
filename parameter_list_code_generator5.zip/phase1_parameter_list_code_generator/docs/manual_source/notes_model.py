# -*- coding: utf-8 -*-
NOTES = {}

NOTES["common/pl_codegen/model/__init__.py"] = {
 "fa": "<p>فقط چند <code>import</code> تا بقیه‌ی کد بتواند بنویسد <code>from ..model import Parameter</code> به‌جای مسیر کامل.</p>",
 "when": "وقتی کلاس تازه‌ای به مدل اضافه می‌کنید و می‌خواهید از خود پکیج قابل import باشد.",
}

NOTES["common/pl_codegen/model/types.py"] = {
 "fa": """<p>رجیستری یازده تایپ پشتیبانی‌شده. هر تایپ یک <code>CDataType</code> است و
<b>همه‌چیزِ</b> آن تایپ از همین یک ورودی مشتق می‌شود: نام ساختار smart data، نام سازنده،
اندازه به بایت (که آفست تگ‌ها را تعیین می‌کند — و نه تعداد LogIDها؛ آن‌ها مقدار می‌شمارند نه بایت)، بازه‌ی طبیعی و پسوند لیترال.</p>
<p>به همین دلیل افزودن یک تایپ تازه فقط یک سطر است — نه گشتن در ده فایل.</p>""",
 "when": "وقتی ماژول smart data تایپ تازه‌ای اضافه می‌کند. یک ورودی به <code>DATA_TYPES</code> بدهید و نامش را در ستون <code>TYPES</code> شیت Defines بنویسید.",
 "sym": {
  "DATA_TYPES": "نگاشت «نام C ⟵ توصیف تایپ». منبع حقیقت برای همه‌ی تایپ‌ها.",
  "TYPE_ALIASES": "نام‌های مستعار پذیرفته‌شده در اکسل: <code>u8</code>، <code>float</code>، <code>double</code>، <code>bool</code> و مانند آن.",
  "CDataType": "هرچه ابزار درباره‌ی یک تایپ C باید بداند.",
  "CDataType.c_name": "نام تایپ در C، مثل <code>uint16_t</code>.",
  "CDataType.suffix": "پسوند smart data، مثل <code>U16</code> — نام ساختار و سازنده از این ساخته می‌شود.",
  "CDataType.kind": "دسته: <code>int</code> / <code>float</code> / <code>bool</code>.",
  "CDataType.signed": "علامت‌دار بودن.",
  "CDataType.bits": "تعداد بیت.",
  "CDataType.literal_suffix": "پسوند لیترال C: <code>U</code>، <code>LL</code>، <code>F</code> و … .",
  "CDataType.native_min": "کمینه‌ی طبیعی تایپ، به‌صورت عدد (برای اعتبارسنجی).",
  "CDataType.limit_min_macro": "نام ماکروی استاندارد همان کمینه در C: <code>INT32_MIN</code>، <code>0U</code>، <code>-DBL_MAX</code> و … . برای «بازه‌ی غیرفعال» <b>این</b> در کد نوشته می‌شود، نه عدد.",
  "CDataType.limit_max_macro": "نام ماکروی بیشینه: <code>UINT16_MAX</code>، <code>FLT_MAX</code> و … .",
  "CDataType.limit_header": "هدری که آن ماکروها را تعریف می‌کند: <code>stdint.h</code> یا <code>float.h</code>.",
  "CDataType.default_resolution": "گامی که وقتی کاربر <code>Resolution</code> را خالی بگذارد به‌کار می‌رود: ۱ برای صحیح، <code>0.001</code> برای <code>float32_t</code> و <code>0.000001</code> برای <code>float64_t</code>.",
  "CDataType.has_limit_macros": "آیا این تایپ ماکروی حد استاندارد دارد (بولین ندارد).",
  "CDataType.native_max": "بیشینه‌ی طبیعی تایپ.",
  "CDataType.smart_data_struct": "نام ساختار، مثل <code>sSmartDataU16</code>.",
  "CDataType.constructor": "نام سازنده، مثل <code>fSmartData_U16_Ctor</code>.",
  "CDataType.enum_name": "نام عضو enum تایپ در کد تولیدی.",
  "CDataType.value_size": "اندازه‌ی <b>مقدار</b> به بایت. مبنای محاسبه‌ی آفست تگ‌هاست و <b>بس</b> — تعداد LogIDهای رزروشده به تایپ کاری ندارد.",
  "CDataType.has_range": "آیا این تایپ min/max/resolution دارد — برای <code>bool_t</code> نه.",
  "CDataType.is_float": "آیا اعشاری است.",
  "CDataType.is_bool": "آیا بولین است.",
  "resolve_data_type": "نام نوشته‌شده در اکسل (با هر املای پذیرفته‌شده) را به <code>CDataType</code> نگاشت می‌کند؛ برای نام ناشناس <code>None</code>.",
  "supported_type_names": "فهرست نام تایپ‌ها با کاما — برای متن پیام‌های خطا.",
  "_int": "سازنده‌ی کمکی که یک تایپ صحیح را با بازه‌ی طبیعی درست می‌سازد.",
 },
}

NOTES["common/pl_codegen/model/tags.py"] = {
 "fa": """<p>رجیستری ده تگ. مهم‌ترین فیلد هر <code>TagSpec</code>، فیلد
<code>descriptor_field</code> است: نام فیلد متناظر در
<code>sParameterDescriptor</code>. همین است که تولید کد را <b>داده‌محور</b> می‌کند —
حلقه‌ی نوشتن جدول descriptor روی <code>TAG_REGISTRY</code> می‌چرخد و هیچ نام تگی در
کد تولیدکننده hard-code نشده.</p>""",
 "when": "وقتی تگ تازه‌ای اضافه می‌شود. سناریوی کاملش در فصل «افزودن یک تگ» آمده.",
 "sym": {
  "TAG_REGISTRY": "فهرست مرتبِ ده تگ. ترتیبش همان ترتیب فیلدها در descriptor است.",
  "TAGS_BY_ID": "نگاشت «شناسه‌ی تگ ⟵ TagSpec» برای جست‌وجوی سریع.",
  "TAGS_BY_COLUMN": "نگاشت «نام ستون اکسل (حروف کوچک) ⟵ TagSpec».",
  "LOG_ID_TAG": "شناسه‌ی تگ LogID؛ چون رفتار ویژه دارد، به‌صورت ثابت نگه داشته شده.",
  "LOGGABLE_TAG": "شناسه‌ی تگ Loggable — همانی که معنادار بودن LogID را تعیین می‌کند.",
  "TagKind": "شکل نوشته شدن مقدار تگ در اکسل.",
  "TagKind.BOOLEAN": "TRUE/FALSE.",
  "TagKind.ENUM": "یکی از مقادیر یک ستون شیت Defines.",
  "TagKind.UNSIGNED": "عدد بی‌علامت (مثل LogID).",
  "TagKind.FREE": "عدد یا یک شناسه‌ی C دلخواه (تگ‌های آزاد).",
  "TagSpec": "توصیف ایستای یک تگ.",
  "TagSpec.tag_id": "شناسه‌ی داخلی تگ؛ در XML هم همین می‌آید.",
  "TagSpec.excel_column": "نام ستون متناظر در اکسل.",
  "TagSpec.descriptor_field": "نام فیلد متناظر در <code>sParameterDescriptor</code>.",
  "TagSpec.kind": "نوع مقدار (<code>TagKind</code>).",
  "TagSpec.mandatory": "آیا پر کردنش اجباری است.",
  "TagSpec.defines_column": "برای تگ enum: کدام ستون شیت Defines مقادیر مجازش را دارد.",
  "TagSpec.description": "توضیح یک‌خطی، برای پیام‌ها و مستندات.",
  "TagSpec.is_boolean": "میان‌بر برای <code>kind is TagKind.BOOLEAN</code>.",
  "mandatory_tags": "فقط تگ‌های اجباری.",
  "optional_tags": "فقط تگ‌های اختیاری.",
 },
}

NOTES["common/pl_codegen/model/defines.py"] = {
 "fa": """<p>شیت <code>Defines</code> به شکل یک دیکشنریِ «نام ستون ⟵ فهرست مقادیر»، با
<code>merge()</code> برای وقتی که چند اکسل با هم ادغام می‌شوند.</p>
<p><code>GENERATED_ENUMS</code> می‌گوید کدام ستون‌ها واقعاً به <code>enum</code> C تبدیل
می‌شوند. همین ثابت است که <code>DefinesSheetRule</code> بر اساسش مقادیر را به‌عنوان
شناسه‌ی C اعتبارسنجی می‌کند.</p>""",
 "when": "وقتی ستون تازه‌ای در شیت Defines قرار است به enum تبدیل شود.",
 "sym": {
  "COLUMN_GROUPS": "نام ستون گروه‌ها در شیت Defines.",
  "COLUMN_TYPES": "نام ستون تایپ‌ها.",
  "COLUMN_SYSTEM_NAMES": "نام ستون نام زیرسیستم‌ها.",
  "COLUMN_PARAM_MODES": "نام ستون حالت‌های دسترسی.",
  "COLUMN_BOOLEANS": "نام ستون TRUE/FALSE — فقط برای لیست کشویی خود اکسل، نه برای کد.",
  "GENERATED_ENUMS": "«ستون ⟵ نام enum تولیدی». فقط این ستون‌ها به کد C تبدیل می‌شوند.",
  "Defines": "مقادیر مجاز جمع‌آوری‌شده از شیت Defines همه‌ی اکسل‌ها.",
  "Defines.values": "دیکشنری «ستون ⟵ فهرست مقادیر».",
  "Defines.add": "یک مقدار به یک ستون اضافه می‌کند؛ تکراری را دور می‌ریزد.",
  "Defines.get": "فهرست مقادیر یک ستون (خالی اگر نبود).",
  "Defines.contains": "آیا این مقدار در آن ستون هست — مبنای چک تگ‌های enum.",
  "Defines.merge": "شیت Defines یک اکسل دیگر را با این یکی ادغام می‌کند.",
  "Defines.groups": "میان‌بر به مقادیر ستون GROUP.",
  "Defines.types": "میان‌بر به ستون TYPES.",
  "Defines.system_names": "میان‌بر به ستون SYSTEM NAMES.",
  "Defines.param_modes": "میان‌بر به ستون PARAM MODES.",
  "group_enum_member": "<code>MONITORING</code> ⟵ <code>ePARAMETER_GROUP_MONITORING</code>، مطابق <code>parameter_descriptor.h</code>.",
 },
}

NOTES["common/pl_codegen/model/parameter.py"] = {
 "fa": """<p>کلاس <code>Parameter</code> — یک ردیف اکسل. فیلدهایش همان ستون‌هایند، به‌علاوه‌ی
<code>tags</code> (دیکشنری) و <code>source</code> (مکان در فایل، برای پیام‌ها).</p>
<p>مهم‌ترین چیز در این فایل، تفاوت میان مقدارِ <b>نوشته‌شده</b> و مقدارِ <b>مؤثر</b> است.
سه <code>@property</code> این تفاوت را پیاده می‌کنند و بقیه‌ی ابزار باید همیشه نسخه‌ی
مؤثر را بخواند.</p>""",
 "when": "وقتی ستون تازه‌ای به اکسل اضافه می‌کنید، یا قاعده‌ی «مقدار مؤثر» عوض می‌شود.",
 "sym": {
  "TagValue": "چیزی که یک تگ می‌تواند نگه دارد: bool، int، str یا None.",
  "NumericValue": "مقدار عددی یک پارامتر: int، float، bool یا None.",
  "Parameter": "یک ردیف شیت <code>ParameterList</code>.",
  "Parameter.name": "نام پارامتر؛ باید شناسه‌ی معتبر C و در همه‌ی اکسل‌ها یکتا باشد.",
  "Parameter.enable": "<code>False</code> یعنی این ردیف کلاً از تولید کد حذف می‌شود.",
  "Parameter.gs_name": "نام نمایشی ایستگاه زمینی.",
  "Parameter.group": "گروه؛ به <code>eParameterGroup</code> تبدیل می‌شود.",
  "Parameter.data_type_name": "نام تایپ همان‌طور که در اکسل نوشته شده (هنوز حل‌نشده).",
  "Parameter.array_size": "۱ یعنی اسکالر؛ بیشتر یعنی آرایه.",
  "Parameter.default_value": "مقدار اولیه.",
  "Parameter.minimum": "کمینه‌ی <b>نوشته‌شده</b> — نه لزوماً آنچه در کد می‌آید.",
  "Parameter.maximum": "بیشینه‌ی نوشته‌شده.",
  "Parameter.resolution": "گام تغییر مقدار.",
  "Parameter.unit": "رشته‌ی واحد.",
  "Parameter.tags": "دیکشنری «شناسه‌ی تگ ⟵ مقدار».",
  "Parameter.description": "متن آزاد.",
  "Parameter.source": "فایل/شیت/ردیفی که این پارامتر از آن آمده.",
  "Parameter.data_type": "<code>CDataType</code>ی حل‌شده از <code>data_type_name</code>؛ <code>None</code> اگر تایپ ناشناس باشد.",
  "Parameter.is_array": "<code>array_size &gt; 1</code>.",
  "Parameter.range_disabled": "هر دو حد صفر یا خالی ⟵ «این پارامتر بازه‌ی محدودکننده ندارد».",
  "Parameter.effective_minimum": "کمینه‌ای که <b>واقعاً</b> به سازنده‌ی C داده می‌شود: بازه‌ی طبیعی تایپ اگر بازه غیرفعال باشد، وگرنه مقدار سلول (و خانه‌ی خالی = صفر).",
  "Parameter.effective_maximum": "همان برای بیشینه.",
  "Parameter._effective_limit": "پیاده‌سازی مشترک دو مورد بالا.",
  "Parameter.tag": "مقدار خام یک تگ، همان‌طور که در سلول بود.",
  "Parameter.effective_tag": "مقدار تگ آن‌طور که <b>کد تولیدی</b> می‌بیند. تنها استثنا <code>LogID</code> است: اگر <code>Loggable</code> نباشد <code>None</code> برمی‌گردد.",
  "Parameter.has_active_tag": "آیا این پارامتر آن تگ را «حمل می‌کند» — همانی که تعیین می‌کند در ناحیه‌ی آفست آن تگ جا بگیرد یا نه.",
  "_is_zero_or_empty": "سلول خالی و صفر برای یک حد، یک معنی دارند.",
 },
 "after": """<div class="warn">
<b>چرا <code>effective_minimum</code> جدا از <code>minimum</code> است</b>
<p>
<code>fSmartData_XX_Ctor</code> همیشه مقدار پیش‌فرض را با دو حدی که می‌گیرد مقایسه
می‌کند و راهی برای گفتن «بازه ندارم» ندارد. اگر <code>0, 0</code> بنویسیم، هر پارامتری با
مقدار پیش‌فرض غیرصفر در <b>زمان اجرا</b> رد می‌شود و
<code>fParameterList_Init()</code> شکست می‌خورد — بدون اینکه هیچ‌کجای کد پایتون خطایی
داده باشد. پس «بازه‌ی غیرفعال» در لحظه‌ی تولید لیترال به بازه‌ی کامل تایپ ترجمه می‌شود.
</p>
<p class="small">
<b>قاعده:</b> هر کد تازه‌ای که حدها را می‌خواند باید از <code>effective_*</code>
استفاده کند، نه از <code>minimum</code>/<code>maximum</code> خام.
</p>
</div>
<div class="warn">
<b><code>bool</code> در پایتون زیرکلاس <code>int</code> است</b>
<p>
<code>isinstance(False, int)</code> برابر <code>True</code> است. در
<code>has_active_tag()</code> اول <code>bool</code> چک می‌شود و بعد <code>int</code>؛
اگر ترتیب برعکس شود، یک تگ بولینِ <code>FALSE</code> مثل «عدد صفر» تفسیر می‌شود و
«تگ فعال» به حساب می‌آید. به همین دلیل عدد <code>0</code> یک <code>LogID</code> کاملاً
معتبر است، ولی <code>FALSE</code> یعنی «تگ را ندارد».
</p>
</div>""",
}

NOTES["common/pl_codegen/model/parameter_list.py"] = {
 "fa": """<p>ظرف نهایی: فهرست <code>Parameter</code>ها به‌علاوه‌ی <code>Defines</code> و فهرست
فایل‌های منبع. چند اکسل این‌جا به یک لیست واحد تبدیل می‌شوند.</p>
<p><code>enabled</code> و <code>disabled</code> دو <code>@property</code>اند و
<b>ترتیب اکسل را حفظ می‌کنند</b> — همان ترتیبی که ایندکس‌های C از آن ساخته می‌شود، پس
جابه‌جا کردن دو ردیف در اکسل یعنی جابه‌جا شدن دو ایندکس در فرم‌ور.</p>""",
 "when": "وقتی به یک نمای تازه از کل لیست نیاز دارید (مثلاً «همه‌ی پارامترهای آرایه‌ای»).",
 "sym": {
  "ParameterList": "همه‌ی پارامترهای همه‌ی اکسل‌ها، به‌عنوان یک لیست واحد.",
  "ParameterList.parameters": "همه‌ی ردیف‌ها، فعال و غیرفعال، به ترتیب اکسل.",
  "ParameterList.defines": "شیت Defines ادغام‌شده.",
  "ParameterList.source_files": "فهرست فایل‌های ورودی؛ در سربرگ فایل‌های تولیدی می‌آید.",
  "ParameterList.generator_version": "نسخه‌ی ابزاری که این مدل را ساخته.",
  "ParameterList.generated_at": "زمان ساخت مدل (اگر <code>emit_timestamp</code> روشن باشد).",
  "ParameterList.add": "یک پارامتر به لیست اضافه می‌کند.",
  "ParameterList.enabled": "پارامترهایی که در تولید کد شرکت می‌کنند، به ترتیب اکسل.",
  "ParameterList.disabled": "ردیف‌های <code>Enable = FALSE</code>؛ فقط برای گزارش.",
  "ParameterList.index_of": "ایندکس یک پارامتر بر اساس نامش — همان عددی که ماکروی ایندکس می‌گیرد.",
  "ParameterList.by_name": "دیکشنری «نام ⟵ پارامتر» برای جست‌وجوی سریع.",
  "ParameterList.used_data_type_suffixes": "پسوندهای smart data که واقعاً استفاده شده‌اند؛ به تولیدکننده می‌گوید کدام سازنده‌ها لازم است.",
  "ParameterList.has_array_parameters": "آیا اصلاً پارامتر آرایه‌ای وجود دارد.",
 },
}

"""Rules about the data type, the array size and the group of a parameter."""

from __future__ import annotations

from ...errors import DiagnosticCollector
from ...model.defines import COLUMN_GROUPS, group_enum_member
from ...model.parameter_list import ParameterList
from ...model.parameter import ParameterKind
from ...model.types import resolve_data_type, supported_type_names
from .rule_base import ValidationRule, enabled_leaves, enabled_nodes

#: Groups declared by ``parameter_descriptor.h``.  A group that is listed in the
#: Excel *Defines* sheet but not here would not compile.
KNOWN_GROUPS = ("MONITORING", "SETTING", "COMMAND")

MAX_ARRAY_SIZE = 65535


class DataTypeRule(ValidationRule):
    """The data type must be one of the supported primitive types."""

    rule_id = "TYPE"
    description = "Every value must have one of the supported data types."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            if not parameter.data_type_name:
                diagnostics.error("TYPE001", "No data type is set.", parameter.source)
                continue
            if resolve_data_type(parameter.data_type_name) is None:
                diagnostics.error(
                    "TYPE002",
                    f"Data type '{parameter.data_type_name}' is not supported.",
                    parameter.source,
                    hint=f"Supported types: {supported_type_names()}. A structure is "
                         f"not a data type here: build it with '+ Structure' and give "
                         f"each field inside it one of these types.")


class DeclaredTypeRule(ValidationRule):
    """The data type should also be listed in the *Defines* sheet."""

    rule_id = "TYPE_DECLARED"
    description = "Data types should be listed in the 'TYPES' column of the Defines sheet."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        declared = model.defines.types
        if not declared:
            return
        for parameter in enabled_leaves(model):
            name = parameter.data_type_name
            if name and name not in declared and resolve_data_type(name) is not None:
                diagnostics.warning(
                    "TYPE003",
                    f"Data type '{name}' is not listed in the 'TYPES' column of the "
                    f"Defines sheet.", parameter.source)


class GroupRule(ValidationRule):
    """The group must be one of the enumerators of ``eParameterGroup``."""

    rule_id = "GROUP"
    description = "The parameter group must exist in parameter_descriptor.h."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        declared = model.defines.get(COLUMN_GROUPS)
        for parameter in model.flatten():
            if not parameter.group:
                diagnostics.error("GRP001", "No group is set (and no structure above "
                                  "it sets one).", parameter.source)
                continue
            group = parameter.group.strip().upper()
            if group not in KNOWN_GROUPS:
                diagnostics.error(
                    "GRP002",
                    f"Group '{parameter.group}' has no matching enumerator "
                    f"({group_enum_member(group)}) in parameter_descriptor.h.",
                    parameter.source,
                    hint=f"Known groups: {', '.join(KNOWN_GROUPS)}.")
            elif declared and parameter.group not in declared:
                diagnostics.warning(
                    "GRP003",
                    f"Group '{parameter.group}' is not listed in the Defines sheet.",
                    parameter.source)


class ArraySizeRule(ValidationRule):
    """The array size must be a sensible positive integer."""

    rule_id = "ARRAY"
    description = "Array sizes must be integers between 1 and 65535."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            size = parameter.array_size
            if size < 1:
                diagnostics.error(
                    "ARR001",
                    f"Array size {size} is invalid; it must be 1 or greater.",
                    parameter.source,
                    hint="Leave the cell empty for a scalar parameter.")
            elif size > MAX_ARRAY_SIZE:
                diagnostics.error(
                    "ARR002",
                    f"Array size {size} exceeds the maximum of {MAX_ARRAY_SIZE}.",
                    parameter.source)

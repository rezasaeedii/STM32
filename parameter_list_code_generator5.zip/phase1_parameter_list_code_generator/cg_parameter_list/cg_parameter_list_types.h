/**
  ******************************************************************************
  * @file    cg_parameter_list_types.h
  * @brief   Structure types generated from the structures of the parameter list.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-03 10:36:00 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase1_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 5 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TYPES_H
#define CG_PARAMETER_LIST_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* The parameter list contains no structure. */

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TYPES_H */

/* === Copyright (c) 2026 FAS === EOF === */

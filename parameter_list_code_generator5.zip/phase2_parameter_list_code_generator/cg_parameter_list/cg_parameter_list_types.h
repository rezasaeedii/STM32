/**
  ******************************************************************************
  * @file    cg_parameter_list_types.h
  * @brief   Structure types generated from the structures of the parameter list.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TYPES_H
#define CG_PARAMETER_LIST_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Structure parameter 'NavStatus'.
 *
 * @note  Navigation solution status.
 */
typedef struct {

    sSmartDataU8  FixType;  /*!< GNSS fix type. */
    sSmartDataU8  FixType2;  /*!< GNSS fix type. */
    sSmartDataB8  Satellites;  /*!< Satellites used in the solution. */
    sSmartDataF32 Hdop[NAV_STATUS_HDOP_ARRAY_SIZE];  /*!< Horizontal dilution of precision. */

} sCgStruct_NavStatus;

/**
 * @brief Structure parameter 'Position.Home'.
 *
 * @note  Home point.
 */
typedef struct {

    sSmartDataF64 Lat;  /*!< [deg] Latitude of the home point. */
    sSmartDataF64 Lon;  /*!< [deg] Longitude of the home point. */

} sCgStruct_Position_Home;

/**
 * @brief Structure parameter 'Position'.
 *
 * @note  Vehicle position.
 */
typedef struct {

    sCgStruct_Position_Home Home;  /*!< Home point. */
    sSmartDataF32           Alt;  /*!< [m] Altitude above mean sea level. */
    sSmartDataI16           Samples[POSITION_SAMPLES_ARRAY_SIZE];  /*!< Ring buffer of recent altitude samples. */
    sSmartDataF32           Heading;  /*!< [deg] True heading. */

} sCgStruct_Position;

/**
 * @brief Structure parameter 'Motor'.
 *
 * @note  One entry per motor.
 */
typedef struct {

    sSmartDataU16 Rpm;  /*!< [rpm] Measured shaft speed. */
    sSmartDataF32 Winding[MOTOR_WINDING_ARRAY_SIZE];  /*!< [degC] Temperature of each winding. */

} sCgStruct_Motor;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TYPES_H */

/* === Copyright (c) 2026 FAS === EOF === */

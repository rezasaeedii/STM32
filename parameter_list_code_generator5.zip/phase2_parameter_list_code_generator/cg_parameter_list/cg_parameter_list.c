/**
  ******************************************************************************
  * @file    cg_parameter_list.c
  * @brief   Generated parameter list and its access functions.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_parameter_list.h"

#include <stddef.h>
#include <string.h>

#include "smart_data.h"
#include "cg_smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
/**
 * @brief Descriptor of every parameter of the merged parameter list. The order of the entries matches the index macros of 'cg_parameter_list_defines.h'.
 *
 */
const sParameterDescriptor ParameterList[PARAMETER_LIST_QTY] = {
    /* [0] NAV_STATUS_FIX_TYPE */
    {
        .pName = "NavStatus.FixType",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.FixType,
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_FIX_TYPE_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_FIX_TYPE_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_FIX_TYPE_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "GNSS fix type."
    },

    /* [1] NAV_STATUS_FIX_TYPE2 */
    {
        .pName = "NavStatus.FixType2",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.FixType2,
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_FIX_TYPE2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_FIX_TYPE2_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_FIX_TYPE2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "GNSS fix type."
    },

    /* [2] NAV_STATUS_SATELLITES */
    {
        .pName = "NavStatus.Satellites",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Satellites,
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_SATELLITES_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_SATELLITES_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_SATELLITES_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Satellites used in the solution."
    },

    /* [3] NAV_STATUS_HDOP_0 */
    {
        .pName = "NavStatus.Hdop[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[0],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_0_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [4] NAV_STATUS_HDOP_1 */
    {
        .pName = "NavStatus.Hdop[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[1],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_1_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [5] NAV_STATUS_HDOP_2 */
    {
        .pName = "NavStatus.Hdop[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[2],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_2_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [6] NAV_STATUS_HDOP_3 */
    {
        .pName = "NavStatus.Hdop[3]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[3],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_3_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_3_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_3_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [7] NAV_STATUS_HDOP_4 */
    {
        .pName = "NavStatus.Hdop[4]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[4],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_4_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_4_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_4_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [8] NAV_STATUS_HDOP_5 */
    {
        .pName = "NavStatus.Hdop[5]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[5],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_5_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_5_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_5_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [9] NAV_STATUS_HDOP_6 */
    {
        .pName = "NavStatus.Hdop[6]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[6],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_6_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_6_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_6_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [10] NAV_STATUS_HDOP_7 */
    {
        .pName = "NavStatus.Hdop[7]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[7],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_7_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_7_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_7_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [11] NAV_STATUS_HDOP_8 */
    {
        .pName = "NavStatus.Hdop[8]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[8],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_8_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_8_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_8_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [12] NAV_STATUS_HDOP_9 */
    {
        .pName = "NavStatus.Hdop[9]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[9],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_9_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_9_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_9_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [13] NAV_STATUS_HDOP_10 */
    {
        .pName = "NavStatus.Hdop[10]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[10],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_10_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_10_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_10_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [14] NAV_STATUS_HDOP_11 */
    {
        .pName = "NavStatus.Hdop[11]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_NavStatus.Hdop[11],
        .LogId = 0U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_11_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_11_OFFSET },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_11_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Horizontal dilution of precision."
    },

    /* [15] WAYPOINT_LAT_0 */
    {
        .pName = "WaypointLat[0]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[0],
        .LogId = 2100U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_0_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [16] WAYPOINT_LAT_1 */
    {
        .pName = "WaypointLat[1]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[1],
        .LogId = 2101U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_1_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [17] WAYPOINT_LAT_2 */
    {
        .pName = "WaypointLat[2]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[2],
        .LogId = 2102U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_2_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [18] WAYPOINT_LAT_3 */
    {
        .pName = "WaypointLat[3]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[3],
        .LogId = 2103U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_3_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_3_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_3_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_3_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [19] WAYPOINT_LAT_4 */
    {
        .pName = "WaypointLat[4]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[4],
        .LogId = 2104U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_4_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_4_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_4_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_4_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [20] WAYPOINT_LAT_5 */
    {
        .pName = "WaypointLat[5]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[5],
        .LogId = 2105U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_5_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_5_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_5_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_5_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [21] WAYPOINT_LAT_6 */
    {
        .pName = "WaypointLat[6]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[6],
        .LogId = 2106U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_6_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_6_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_6_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_6_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [22] WAYPOINT_LAT_7 */
    {
        .pName = "WaypointLat[7]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[7],
        .LogId = 2107U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_7_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_7_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_7_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_7_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [23] WAYPOINT_LAT_8 */
    {
        .pName = "WaypointLat[8]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[8],
        .LogId = 2108U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_8_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_8_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_8_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_8_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [24] WAYPOINT_LAT_9 */
    {
        .pName = "WaypointLat[9]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[9],
        .LogId = 2109U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_9_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_9_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_9_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_9_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [25] WAYPOINT_LAT_10 */
    {
        .pName = "WaypointLat[10]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[10],
        .LogId = 2110U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_10_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_10_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_10_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_10_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [26] WAYPOINT_LAT_11 */
    {
        .pName = "WaypointLat[11]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[11],
        .LogId = 2111U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_11_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_11_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_11_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_11_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [27] WAYPOINT_LAT_12 */
    {
        .pName = "WaypointLat[12]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[12],
        .LogId = 2112U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_12_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_12_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_12_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_12_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [28] WAYPOINT_LAT_13 */
    {
        .pName = "WaypointLat[13]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[13],
        .LogId = 2113U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_13_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_13_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_13_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_13_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [29] WAYPOINT_LAT_14 */
    {
        .pName = "WaypointLat[14]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[14],
        .LogId = 2114U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_14_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_14_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_14_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_14_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [30] WAYPOINT_LAT_15 */
    {
        .pName = "WaypointLat[15]",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_WaypointLat[15],
        .LogId = 2115U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_15_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_15_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_15_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_15_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of each stored waypoint."
    },

    /* [31] AIRSPEED */
    {
        .pName = "Airspeed",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Airspeed,
        .LogId = 100U,
        .TagSystemName = { .Value = (uint32_t)SYS_AC_AUTOPILOT, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_AIRSPEED_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_AIRSPEED_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_AIRSPEED_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_AIRSPEED_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Indicated airspeed."
    },

    /* [32] POSITION_HOME_LAT */
    {
        .pName = "Position.Home.Lat",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Home.Lat,
        .LogId = 104U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HOME_LAT_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HOME_LAT_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_HOME_LAT_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HOME_LAT_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Latitude of the home point."
    },

    /* [33] POSITION_HOME_LON */
    {
        .pName = "Position.Home.Lon",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Home.Lon,
        .LogId = 105U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HOME_LON_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HOME_LON_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_HOME_LON_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HOME_LON_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Longitude of the home point."
    },

    /* [34] POSITION_ALT */
    {
        .pName = "Position.Alt",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Alt,
        .LogId = 106U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_ALT_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_ALT_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_ALT_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_ALT_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Altitude above mean sea level."
    },

    /* [35] POSITION_SAMPLES_0 */
    {
        .pName = "Position.Samples[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[0],
        .LogId = 107U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_0_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [36] POSITION_SAMPLES_1 */
    {
        .pName = "Position.Samples[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[1],
        .LogId = 108U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_1_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [37] POSITION_SAMPLES_2 */
    {
        .pName = "Position.Samples[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[2],
        .LogId = 109U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_2_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [38] POSITION_SAMPLES_3 */
    {
        .pName = "Position.Samples[3]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[3],
        .LogId = 110U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_3_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_3_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_3_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_3_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [39] POSITION_SAMPLES_4 */
    {
        .pName = "Position.Samples[4]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[4],
        .LogId = 111U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_4_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_4_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_4_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_4_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [40] POSITION_SAMPLES_5 */
    {
        .pName = "Position.Samples[5]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[5],
        .LogId = 112U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_5_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_5_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_5_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_5_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [41] POSITION_SAMPLES_6 */
    {
        .pName = "Position.Samples[6]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[6],
        .LogId = 113U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_6_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_6_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_6_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_6_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [42] POSITION_SAMPLES_7 */
    {
        .pName = "Position.Samples[7]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Samples[7],
        .LogId = 114U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_7_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_7_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_7_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_7_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Ring buffer of recent altitude samples."
    },

    /* [43] POSITION_HEADING */
    {
        .pName = "Position.Heading",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Position.Heading,
        .LogId = 115U,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HEADING_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HEADING_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_POSITION_HEADING_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HEADING_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "True heading."
    },

    /* [44] MOTOR_0_RPM */
    {
        .pName = "Motor[0].Rpm",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[0].Rpm,
        .LogId = 300U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_RPM_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_RPM_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_RPM_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Measured shaft speed."
    },

    /* [45] MOTOR_0_WINDING_0 */
    {
        .pName = "Motor[0].Winding[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[0].Winding[0],
        .LogId = 301U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [46] MOTOR_0_WINDING_1 */
    {
        .pName = "Motor[0].Winding[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[0].Winding[1],
        .LogId = 302U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [47] MOTOR_0_WINDING_2 */
    {
        .pName = "Motor[0].Winding[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[0].Winding[2],
        .LogId = 303U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [48] MOTOR_1_RPM */
    {
        .pName = "Motor[1].Rpm",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[1].Rpm,
        .LogId = 304U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_RPM_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_RPM_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_RPM_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Measured shaft speed."
    },

    /* [49] MOTOR_1_WINDING_0 */
    {
        .pName = "Motor[1].Winding[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[1].Winding[0],
        .LogId = 305U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [50] MOTOR_1_WINDING_1 */
    {
        .pName = "Motor[1].Winding[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[1].Winding[1],
        .LogId = 306U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [51] MOTOR_1_WINDING_2 */
    {
        .pName = "Motor[1].Winding[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[1].Winding[2],
        .LogId = 307U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [52] MOTOR_2_RPM */
    {
        .pName = "Motor[2].Rpm",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[2].Rpm,
        .LogId = 308U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_RPM_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_RPM_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_RPM_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Measured shaft speed."
    },

    /* [53] MOTOR_2_WINDING_0 */
    {
        .pName = "Motor[2].Winding[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[2].Winding[0],
        .LogId = 309U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [54] MOTOR_2_WINDING_1 */
    {
        .pName = "Motor[2].Winding[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[2].Winding[1],
        .LogId = 310U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [55] MOTOR_2_WINDING_2 */
    {
        .pName = "Motor[2].Winding[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[2].Winding[2],
        .LogId = 311U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [56] MOTOR_3_RPM */
    {
        .pName = "Motor[3].Rpm",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[3].Rpm,
        .LogId = 312U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_RPM_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_RPM_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_RPM_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Measured shaft speed."
    },

    /* [57] MOTOR_3_WINDING_0 */
    {
        .pName = "Motor[3].Winding[0]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[3].Winding[0],
        .LogId = 313U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_0_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_0_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_0_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [58] MOTOR_3_WINDING_1 */
    {
        .pName = "Motor[3].Winding[1]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[3].Winding[1],
        .LogId = 314U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_1_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_1_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_1_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [59] MOTOR_3_WINDING_2 */
    {
        .pName = "Motor[3].Winding[2]",
        .Type = ePARAMETER_TYPE_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Motor[3].Winding[2],
        .LogId = 315U,
        .TagSystemName = { .Value = (uint32_t)SYS_GOVERNOR, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_2_OFFSET },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_2_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_2_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Temperature of each winding."
    },

    /* [60] MODE */
    {
        .pName = "Mode",
        .Type = ePARAMETER_TYPE_SETTING,
        .pSmartData = (void *)&Cg_SmartData_Mode,
        .LogId = 200U,
        .TagSystemName = { .Value = (uint32_t)SYS_AC_AUTOPILOT, .MemoryOffset = PARAMETER_LIST_TAG_SYSTEM_NAME_MODE_OFFSET },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_RESET_PROOF_MODE_OFFSET },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_TAG_LOGGABLE_MODE_OFFSET },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_READ_ONLY, .MemoryOffset = PARAMETER_LIST_TAG_PARAM_MODE_MODE_OFFSET },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Active flight mode."
    }
};

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Initialises the parameter list and every smart-data object.
 *
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
uint8_t fParameterList_Init(void) {

    uint8_t result = 0U;

    result = fCgSmartData_Init();
    if (result != 0U) {
        return result;
    }

    result = fParameterList_InitCompletedCallback();
    if (result != 0U) {
        return result;
    }

    return result;

}

/**
 * @brief Called once the parameter list has been initialised.
 *
 * @note  Implement this function in the application layer without the weak specifier to hook into the initialisation.
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
PARAMETER_LIST_WEAK uint8_t fParameterList_InitCompletedCallback(void) {

    return 0U;

}

/**
 * @brief Returns the number of parameters in the list.
 *
 * @return uint16_t Always PARAMETER_LIST_QTY.
 */
uint16_t fParameterList_GetQuantity(void) {

    return (uint16_t)PARAMETER_LIST_QTY;

}

/**
 * @brief Returns the descriptor of the parameter at *index*.
 *
 * @param index Index of the parameter, see 'cg_parameter_list_defines.h'.
 * @return const sParameterDescriptor* NULL when the index is out of range.
 */
const sParameterDescriptor * fParameterList_GetByIndex(uint16_t index) {

    if (index >= (uint16_t)PARAMETER_LIST_QTY) {
        return NULL;
    }

    return &ParameterList[index];

}

/**
 * @brief Returns the descriptor of the parameter called *pName*.
 *
 * @param pName Name of the parameter; a field of a structure is  *              listed under its dotted name, e.g. "Position.Home.Lat".
 * @return const sParameterDescriptor* NULL when no such parameter exists.
 */
const sParameterDescriptor * fParameterList_GetByName(const char *pName) {

    uint16_t index = 0U;

    if (pName == NULL) {
        return NULL;
    }

    for (index = 0U; index < (uint16_t)PARAMETER_LIST_QTY; index++) {
        if (strcmp(ParameterList[index].pName, pName) == 0) {
            return &ParameterList[index];
        }
    }

    return NULL;

}

/**
 * @brief Total number of bytes reserved by the 'SystemName' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_TAG_SYSTEM_NAME_SIZE.
 */
uint32_t fParameterList_GetSystemNameSize(void) {

    return (uint32_t)PARAMETER_LIST_TAG_SYSTEM_NAME_SIZE;

}

/**
 * @brief Total number of bytes reserved by the 'ResetProof' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_TAG_RESET_PROOF_SIZE.
 */
uint32_t fParameterList_GetResetProofSize(void) {

    return (uint32_t)PARAMETER_LIST_TAG_RESET_PROOF_SIZE;

}

/**
 * @brief Total number of bytes reserved by the 'Loggable' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_TAG_LOGGABLE_SIZE.
 */
uint32_t fParameterList_GetLoggableSize(void) {

    return (uint32_t)PARAMETER_LIST_TAG_LOGGABLE_SIZE;

}

/**
 * @brief Total number of bytes reserved by the 'ParamMode' tag.
 *
 * @note  This is the sum over every parameter that carries the tag, each one taking sizeof(value) x array size bytes.
 * @return uint32_t Always PARAMETER_LIST_TAG_PARAM_MODE_SIZE.
 */
uint32_t fParameterList_GetParamModeSize(void) {

    return (uint32_t)PARAMETER_LIST_TAG_PARAM_MODE_SIZE;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

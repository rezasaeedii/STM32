/**
  ******************************************************************************
  * @file    cg_parameter_list_table.h
  * @brief   The parameter list, drawn as a table. Documentation only - no code.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TABLE_H
#define CG_PARAMETER_LIST_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
/* Exported defines --------------------------------------------------------- */
/*
  Parameter list - values

  +-------+----+--------------+-------------+------------+-----------+-----+---------+------+-------+-------+------+
  | Index | En | Name         | GS Name     | Type       | ValueType | Arr | Default | Min  | Max   | Res   | Unit |
  +-------+----+--------------+-------------+------------+-----------+-----+---------+------+-------+-------+------+
  | -     | x  | NavStatus    | NavStatus   | MONITORING | struct    | 1   | -       | -    | -     | -     | -    |
  | 0     | x  |   FixType    | FixType     | -          | uint8_t   | 1   | 0       | 0    | 5     | 1     | -    |
  | 1     | x  |   FixType2   | FixType     | -          | uint8_t   | 1   | 0       | 0    | 5     | 1     | -    |
  | 2     | x  |   Satellites | Satellites  | -          | bool_t    | 1   | FALSE   | 0    | 1     | 1     | -    |
  | 3     | x  |   Hdop       | Hdop        | -          | float32_t | 12  | 0       | 0    | 99    | 0.01  | -    |
  | 15    | x  | WaypointLat  | WaypointLat | SETTING    | float64_t | 16  | 0       | -90  | 90    | 1e-07 | deg  |
  | 31    | x  | Airspeed     | Airspeed    | MONITORING | float32_t | 1   | 0       | 0    | 120   | 0.1   | m/s  |
  | -     | x  | Position     | Position    | MONITORING | struct    | 1   | -       | -    | -     | -     | -    |
  | -     | x  |   Home       | Home        | -          | struct    | 1   | -       | -    | -     | -     | -    |
  | 32    | x  |     Lat      | Lat         | -          | float64_t | 1   | 0       | -90  | 90    | 1e-07 | deg  |
  | 33    | x  |     Lon      | Lon         | -          | float64_t | 1   | 0       | -180 | 180   | 1e-07 | deg  |
  | 34    | x  |   Alt        | Alt         | -          | float32_t | 1   | 0       | -500 | 10000 | 0.01  | m    |
  | 35    | x  |   Samples    | Samples     | -          | int16_t   | 8   | 0       | -100 | 100   | 1     | -    |
  | 43    | x  |   Heading    | Heading     | -          | float32_t | 1   | 0       | 0    | 360   | 0.1   | deg  |
  | -     | x  | Motor        | Motor       | MONITORING | struct    | 4   | -       | -    | -     | -     | -    |
  | 44    | x  |   Rpm        | Rpm         | -          | uint16_t  | 1   | 0       | 0    | 30000 | 1     | rpm  |
  | 45    | x  |   Winding    | Winding     | -          | float32_t | 3   | 0       | -40  | 200   | 0.1   | degC |
  | 60    | x  | Mode         | Mode        | SETTING    | uint8_t   | 1   | 1       | 0    | 9     | 1     | -    |
  +-------+----+--------------+-------------+------------+-----------+-----+---------+------+-------+-------+------+

  '#' is the index in the parameter list, the value of the matching
  #define in the defines header. A structure is not a row of the table,
  so it has no index of its own; only the values inside it have one.
  A structure with an array size is expanded element by element, so
  the index shown for one of its fields is that of the FIRST element;
  the next elements follow one full set of fields apart.
*/

/*
  Parameter list - tags

  +-------+-------------+------------------+------------+----------+---------------+----------------------+------+------+------+------+-------------+
  | Index | Name        | SystemName       | ResetProof | Loggable | LogEncryption | ParamMode            | Tag1 | Tag2 | Tag3 | Tag4 | LogID range |
  +-------+-------------+------------------+------------+----------+---------------+----------------------+------+------+------+------+-------------+
  | -     | NavStatus   | SYS_NAV          | x          |          |               | PARAM_MODE_USER      | -    | -    | -    | -    | -           |
  | 15    | WaypointLat | SYS_NAV          | x          | x        |               | PARAM_MODE_USER      | -    | -    | -    | -    | 2100..2115  |
  | 31    | Airspeed    | SYS_AC_AUTOPILOT | x          | x        |               | PARAM_MODE_USER      | -    | -    | -    | -    | 100         |
  | -     | Position    | SYS_NAV          | x          | x        |               | PARAM_MODE_USER      | -    | -    | -    | -    | 104..115    |
  | -     | Motor       | SYS_GOVERNOR     |            | x        |               | PARAM_MODE_USER      | -    | -    | -    | -    | 300..315    |
  | 60    | Mode        | SYS_AC_AUTOPILOT | x          | x        |               | PARAM_MODE_READ_ONLY | -    | -    | -    | -    | 200         |
  +-------+-------------+------------------+------------+----------+---------------+----------------------+------+------+------+------+-------------+
*/

/*
  MemoryOffset of every parameter, per tag

  +-------+----------------------+-------+------------+------------+----------+-----------+
  | Index | Name                 | Bytes | SystemName | ResetProof | Loggable | ParamMode |
  +-------+----------------------+-------+------------+------------+----------+-----------+
  | 0     | NavStatus.FixType    | 1     | 0          | 0          | -        | 0         |
  | 1     | NavStatus.FixType2   | 1     | 1          | 1          | -        | 1         |
  | 2     | NavStatus.Satellites | 1     | 2          | 2          | -        | 2         |
  | 3     | NavStatus.Hdop[0]    | 4     | 3          | 3          | -        | 3         |
  | 4     | NavStatus.Hdop[1]    | 4     | 7          | 7          | -        | 7         |
  | 5     | NavStatus.Hdop[2]    | 4     | 11         | 11         | -        | 11        |
  | 6     | NavStatus.Hdop[3]    | 4     | 15         | 15         | -        | 15        |
  | 7     | NavStatus.Hdop[4]    | 4     | 19         | 19         | -        | 19        |
  | 8     | NavStatus.Hdop[5]    | 4     | 23         | 23         | -        | 23        |
  | 9     | NavStatus.Hdop[6]    | 4     | 27         | 27         | -        | 27        |
  | 10    | NavStatus.Hdop[7]    | 4     | 31         | 31         | -        | 31        |
  | 11    | NavStatus.Hdop[8]    | 4     | 35         | 35         | -        | 35        |
  | 12    | NavStatus.Hdop[9]    | 4     | 39         | 39         | -        | 39        |
  | 13    | NavStatus.Hdop[10]   | 4     | 43         | 43         | -        | 43        |
  | 14    | NavStatus.Hdop[11]   | 4     | 47         | 47         | -        | 47        |
  | 15    | WaypointLat[0]       | 8     | 51         | 51         | 0        | 51        |
  | 16    | WaypointLat[1]       | 8     | 59         | 59         | 8        | 59        |
  | 17    | WaypointLat[2]       | 8     | 67         | 67         | 16       | 67        |
  | 18    | WaypointLat[3]       | 8     | 75         | 75         | 24       | 75        |
  | 19    | WaypointLat[4]       | 8     | 83         | 83         | 32       | 83        |
  | 20    | WaypointLat[5]       | 8     | 91         | 91         | 40       | 91        |
  | 21    | WaypointLat[6]       | 8     | 99         | 99         | 48       | 99        |
  | 22    | WaypointLat[7]       | 8     | 107        | 107        | 56       | 107       |
  | 23    | WaypointLat[8]       | 8     | 115        | 115        | 64       | 115       |
  | 24    | WaypointLat[9]       | 8     | 123        | 123        | 72       | 123       |
  | 25    | WaypointLat[10]      | 8     | 131        | 131        | 80       | 131       |
  | 26    | WaypointLat[11]      | 8     | 139        | 139        | 88       | 139       |
  | 27    | WaypointLat[12]      | 8     | 147        | 147        | 96       | 147       |
  | 28    | WaypointLat[13]      | 8     | 155        | 155        | 104      | 155       |
  | 29    | WaypointLat[14]      | 8     | 163        | 163        | 112      | 163       |
  | 30    | WaypointLat[15]      | 8     | 171        | 171        | 120      | 171       |
  | 31    | Airspeed             | 4     | 179        | 179        | 128      | 179       |
  | 32    | Position.Home.Lat    | 8     | 183        | 183        | 132      | 183       |
  | 33    | Position.Home.Lon    | 8     | 191        | 191        | 140      | 191       |
  | 34    | Position.Alt         | 4     | 199        | 199        | 148      | 199       |
  | 35    | Position.Samples[0]  | 2     | 203        | 203        | 152      | 203       |
  | 36    | Position.Samples[1]  | 2     | 205        | 205        | 154      | 205       |
  | 37    | Position.Samples[2]  | 2     | 207        | 207        | 156      | 207       |
  | 38    | Position.Samples[3]  | 2     | 209        | 209        | 158      | 209       |
  | 39    | Position.Samples[4]  | 2     | 211        | 211        | 160      | 211       |
  | 40    | Position.Samples[5]  | 2     | 213        | 213        | 162      | 213       |
  | 41    | Position.Samples[6]  | 2     | 215        | 215        | 164      | 215       |
  | 42    | Position.Samples[7]  | 2     | 217        | 217        | 166      | 217       |
  | 43    | Position.Heading     | 4     | 219        | 219        | 168      | 219       |
  | 44    | Motor[0].Rpm         | 2     | 223        | -          | 172      | 223       |
  | 45    | Motor[0].Winding[0]  | 4     | 225        | -          | 174      | 225       |
  | 46    | Motor[0].Winding[1]  | 4     | 229        | -          | 178      | 229       |
  | 47    | Motor[0].Winding[2]  | 4     | 233        | -          | 182      | 233       |
  | 48    | Motor[1].Rpm         | 2     | 237        | -          | 186      | 237       |
  | 49    | Motor[1].Winding[0]  | 4     | 239        | -          | 188      | 239       |
  | 50    | Motor[1].Winding[1]  | 4     | 243        | -          | 192      | 243       |
  | 51    | Motor[1].Winding[2]  | 4     | 247        | -          | 196      | 247       |
  | 52    | Motor[2].Rpm         | 2     | 251        | -          | 200      | 251       |
  | 53    | Motor[2].Winding[0]  | 4     | 253        | -          | 202      | 253       |
  | 54    | Motor[2].Winding[1]  | 4     | 257        | -          | 206      | 257       |
  | 55    | Motor[2].Winding[2]  | 4     | 261        | -          | 210      | 261       |
  | 56    | Motor[3].Rpm         | 2     | 265        | -          | 214      | 265       |
  | 57    | Motor[3].Winding[0]  | 4     | 267        | -          | 216      | 267       |
  | 58    | Motor[3].Winding[1]  | 4     | 271        | -          | 220      | 271       |
  | 59    | Motor[3].Winding[2]  | 4     | 275        | -          | 224      | 275       |
  | 60    | Mode                 | 1     | 279        | 223        | 228      | 279       |
  |       | TOTAL (bytes)        |       | 280        | 224        | 229      | 280       |
  +-------+----------------------+-------+------------+------------+----------+-----------+

  Every tag owns an independent counter that starts at 0 and advances by
  sizeof(value) * ArraySize for every parameter that carries the tag.
  '-' means the tag is not active for that parameter, so its offset is 0.
*/

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TABLE_H */

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_smart_data.h
  * @brief   Smart-data objects that hold the value of every parameter.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_SMART_DATA_H
#define CG_SMART_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"
#include "cg_parameter_list_types.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
uint8_t fCgSmartData_Init(void);

/* Exported variables ------------------------------------------------------- */
extern sCgStruct_NavStatus Cg_SmartData_NavStatus;  /*!< Navigation solution status. */
extern sSmartDataF64 Cg_SmartData_WaypointLat[WAYPOINT_LAT_ARRAY_SIZE];  /*!< [deg] Latitude of each stored waypoint. */
extern sSmartDataF32 Cg_SmartData_Airspeed;  /*!< [m/s] Indicated airspeed. */
extern sCgStruct_Position Cg_SmartData_Position;  /*!< Vehicle position. */
extern sCgStruct_Motor Cg_SmartData_Motor[MOTOR_ARRAY_SIZE];  /*!< One entry per motor. */
extern sSmartDataU8 Cg_SmartData_Mode;  /*!< Active flight mode. */

#ifdef __cplusplus
}
#endif

#endif /* CG_SMART_DATA_H */

/* === Copyright (c) 2026 FAS === EOF === */

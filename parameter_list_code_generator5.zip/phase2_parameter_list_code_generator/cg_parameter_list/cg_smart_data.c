/**
  ******************************************************************************
  * @file    cg_smart_data.c
  * @brief   Definition and construction of the generated smart-data objects.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_smart_data.h"
#include "smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
sCgStruct_NavStatus Cg_SmartData_NavStatus;
sSmartDataF64 Cg_SmartData_WaypointLat[WAYPOINT_LAT_ARRAY_SIZE];
sSmartDataF32 Cg_SmartData_Airspeed;
sCgStruct_Position Cg_SmartData_Position;
sCgStruct_Motor Cg_SmartData_Motor[MOTOR_ARRAY_SIZE];
sSmartDataU8 Cg_SmartData_Mode;

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Constructs every generated smart-data object.
 *
 * @return uint8_t 0 on success, otherwise the failing eSmartDataStatus value.
 */
uint8_t fCgSmartData_Init(void) {

    eSmartDataStatus status = eSMART_DATA_OK;
    uint16_t index = 0U;

    status = fSmartData_U8_Ctor(&Cg_SmartData_NavStatus.FixType, 0U, 5U, 0U, 1U, "");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_U8_Ctor(&Cg_SmartData_NavStatus.FixType2, 0U, 5U, 0U, 1U, "");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_B8_Ctor(&Cg_SmartData_NavStatus.Satellites, FALSE, "");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < NAV_STATUS_HDOP_ARRAY_SIZE; index++) {
        status = fSmartData_F32_Ctor(&Cg_SmartData_NavStatus.Hdop[index], 0.0f, 99.0f, 0.0f, 0.01f, "");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    for (index = 0U; index < WAYPOINT_LAT_ARRAY_SIZE; index++) {
        status = fSmartData_F64_Ctor(&Cg_SmartData_WaypointLat[index], -90.0, 90.0, 0.0, 1.0e-07, "deg");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Airspeed, 0.0f, 120.0f, 0.0f, 0.1f, "m/s");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F64_Ctor(&Cg_SmartData_Position.Home.Lat, -90.0, 90.0, 0.0, 1.0e-07, "deg");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F64_Ctor(&Cg_SmartData_Position.Home.Lon, -180.0, 180.0, 0.0, 1.0e-07, "deg");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Position.Alt, -500.0f, 10000.0f, 0.0f, 0.01f, "m");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < POSITION_SAMPLES_ARRAY_SIZE; index++) {
        status = fSmartData_I16_Ctor(&Cg_SmartData_Position.Samples[index], (-100), 100, 0, 1, "");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_F32_Ctor(&Cg_SmartData_Position.Heading, 0.0f, 360.0f, 0.0f, 0.1f, "deg");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_U16_Ctor(&Cg_SmartData_Motor[0].Rpm, 0U, 30000U, 0U, 1U, "rpm");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < MOTOR_WINDING_ARRAY_SIZE; index++) {
        status = fSmartData_F32_Ctor(&Cg_SmartData_Motor[0].Winding[index], -40.0f, 200.0f, 0.0f, 0.1f, "degC");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_U16_Ctor(&Cg_SmartData_Motor[1].Rpm, 0U, 30000U, 0U, 1U, "rpm");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < MOTOR_WINDING_ARRAY_SIZE; index++) {
        status = fSmartData_F32_Ctor(&Cg_SmartData_Motor[1].Winding[index], -40.0f, 200.0f, 0.0f, 0.1f, "degC");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_U16_Ctor(&Cg_SmartData_Motor[2].Rpm, 0U, 30000U, 0U, 1U, "rpm");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < MOTOR_WINDING_ARRAY_SIZE; index++) {
        status = fSmartData_F32_Ctor(&Cg_SmartData_Motor[2].Winding[index], -40.0f, 200.0f, 0.0f, 0.1f, "degC");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_U16_Ctor(&Cg_SmartData_Motor[3].Rpm, 0U, 30000U, 0U, 1U, "rpm");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < MOTOR_WINDING_ARRAY_SIZE; index++) {
        status = fSmartData_F32_Ctor(&Cg_SmartData_Motor[3].Winding[index], -40.0f, 200.0f, 0.0f, 0.1f, "degC");
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_U8_Ctor(&Cg_SmartData_Mode, 0U, 9U, 1U, 1U, "");
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    return (uint8_t)status;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

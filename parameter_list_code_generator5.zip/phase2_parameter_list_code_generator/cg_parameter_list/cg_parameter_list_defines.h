/**
  ******************************************************************************
  * @file    cg_parameter_list_defines.h
  * @brief   Quantities, parameter indices, tag offsets and generated enumerations.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-09-05 00:28:07 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\navigation.xml
  *                   C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_lists\parameter_list.xml
  * Parameters     : 61 value(s) in 4 structure(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_DEFINES_H
#define CG_PARAMETER_LIST_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stdint.h>

/* Exported defines --------------------------------------------------------- */
/* Number of parameters in the parameter list */
#define PARAMETER_LIST_QTY  (61U)  /*!< Number of enabled parameters */

/* Index of every parameter inside the parameter list */
#define NAV_STATUS_FIX_TYPE    (0U)   /*!< uint8_t */
#define NAV_STATUS_FIX_TYPE2   (1U)   /*!< uint8_t */
#define NAV_STATUS_SATELLITES  (2U)   /*!< bool_t */
#define NAV_STATUS_HDOP_0      (3U)   /*!< float32_t (element 0 of 12) */
#define NAV_STATUS_HDOP_1      (4U)   /*!< float32_t (element 1 of 12) */
#define NAV_STATUS_HDOP_2      (5U)   /*!< float32_t (element 2 of 12) */
#define NAV_STATUS_HDOP_3      (6U)   /*!< float32_t (element 3 of 12) */
#define NAV_STATUS_HDOP_4      (7U)   /*!< float32_t (element 4 of 12) */
#define NAV_STATUS_HDOP_5      (8U)   /*!< float32_t (element 5 of 12) */
#define NAV_STATUS_HDOP_6      (9U)   /*!< float32_t (element 6 of 12) */
#define NAV_STATUS_HDOP_7      (10U)  /*!< float32_t (element 7 of 12) */
#define NAV_STATUS_HDOP_8      (11U)  /*!< float32_t (element 8 of 12) */
#define NAV_STATUS_HDOP_9      (12U)  /*!< float32_t (element 9 of 12) */
#define NAV_STATUS_HDOP_10     (13U)  /*!< float32_t (element 10 of 12) */
#define NAV_STATUS_HDOP_11     (14U)  /*!< float32_t (element 11 of 12) */
#define WAYPOINT_LAT_0         (15U)  /*!< float64_t (element 0 of 16) [deg] */
#define WAYPOINT_LAT_1         (16U)  /*!< float64_t (element 1 of 16) [deg] */
#define WAYPOINT_LAT_2         (17U)  /*!< float64_t (element 2 of 16) [deg] */
#define WAYPOINT_LAT_3         (18U)  /*!< float64_t (element 3 of 16) [deg] */
#define WAYPOINT_LAT_4         (19U)  /*!< float64_t (element 4 of 16) [deg] */
#define WAYPOINT_LAT_5         (20U)  /*!< float64_t (element 5 of 16) [deg] */
#define WAYPOINT_LAT_6         (21U)  /*!< float64_t (element 6 of 16) [deg] */
#define WAYPOINT_LAT_7         (22U)  /*!< float64_t (element 7 of 16) [deg] */
#define WAYPOINT_LAT_8         (23U)  /*!< float64_t (element 8 of 16) [deg] */
#define WAYPOINT_LAT_9         (24U)  /*!< float64_t (element 9 of 16) [deg] */
#define WAYPOINT_LAT_10        (25U)  /*!< float64_t (element 10 of 16) [deg] */
#define WAYPOINT_LAT_11        (26U)  /*!< float64_t (element 11 of 16) [deg] */
#define WAYPOINT_LAT_12        (27U)  /*!< float64_t (element 12 of 16) [deg] */
#define WAYPOINT_LAT_13        (28U)  /*!< float64_t (element 13 of 16) [deg] */
#define WAYPOINT_LAT_14        (29U)  /*!< float64_t (element 14 of 16) [deg] */
#define WAYPOINT_LAT_15        (30U)  /*!< float64_t (element 15 of 16) [deg] */
#define AIRSPEED               (31U)  /*!< float32_t [m/s] */
#define POSITION_HOME_LAT      (32U)  /*!< float64_t [deg] */
#define POSITION_HOME_LON      (33U)  /*!< float64_t [deg] */
#define POSITION_ALT           (34U)  /*!< float32_t [m] */
#define POSITION_SAMPLES_0     (35U)  /*!< int16_t (element 0 of 8) */
#define POSITION_SAMPLES_1     (36U)  /*!< int16_t (element 1 of 8) */
#define POSITION_SAMPLES_2     (37U)  /*!< int16_t (element 2 of 8) */
#define POSITION_SAMPLES_3     (38U)  /*!< int16_t (element 3 of 8) */
#define POSITION_SAMPLES_4     (39U)  /*!< int16_t (element 4 of 8) */
#define POSITION_SAMPLES_5     (40U)  /*!< int16_t (element 5 of 8) */
#define POSITION_SAMPLES_6     (41U)  /*!< int16_t (element 6 of 8) */
#define POSITION_SAMPLES_7     (42U)  /*!< int16_t (element 7 of 8) */
#define POSITION_HEADING       (43U)  /*!< float32_t [deg] */
#define MOTOR_0_RPM            (44U)  /*!< uint16_t [rpm] */
#define MOTOR_0_WINDING_0      (45U)  /*!< float32_t (element 0 of 3) [degC] */
#define MOTOR_0_WINDING_1      (46U)  /*!< float32_t (element 1 of 3) [degC] */
#define MOTOR_0_WINDING_2      (47U)  /*!< float32_t (element 2 of 3) [degC] */
#define MOTOR_1_RPM            (48U)  /*!< uint16_t [rpm] */
#define MOTOR_1_WINDING_0      (49U)  /*!< float32_t (element 0 of 3) [degC] */
#define MOTOR_1_WINDING_1      (50U)  /*!< float32_t (element 1 of 3) [degC] */
#define MOTOR_1_WINDING_2      (51U)  /*!< float32_t (element 2 of 3) [degC] */
#define MOTOR_2_RPM            (52U)  /*!< uint16_t [rpm] */
#define MOTOR_2_WINDING_0      (53U)  /*!< float32_t (element 0 of 3) [degC] */
#define MOTOR_2_WINDING_1      (54U)  /*!< float32_t (element 1 of 3) [degC] */
#define MOTOR_2_WINDING_2      (55U)  /*!< float32_t (element 2 of 3) [degC] */
#define MOTOR_3_RPM            (56U)  /*!< uint16_t [rpm] */
#define MOTOR_3_WINDING_0      (57U)  /*!< float32_t (element 0 of 3) [degC] */
#define MOTOR_3_WINDING_1      (58U)  /*!< float32_t (element 1 of 3) [degC] */
#define MOTOR_3_WINDING_2      (59U)  /*!< float32_t (element 2 of 3) [degC] */
#define MODE                   (60U)  /*!< uint8_t */

/* Array size of every array parameter */
#define NAV_STATUS_HDOP_ARRAY_SIZE   (12U)  /*!< Number of elements of 'NavStatus.Hdop' */
#define WAYPOINT_LAT_ARRAY_SIZE      (16U)  /*!< Number of elements of 'WaypointLat' */
#define POSITION_SAMPLES_ARRAY_SIZE  (8U)   /*!< Number of elements of 'Position.Samples' */
#define MOTOR_ARRAY_SIZE             (4U)   /*!< Number of elements of 'Motor' */
#define MOTOR_WINDING_ARRAY_SIZE     (3U)   /*!< Number of elements of 'Motor.Winding' */

/* Total size used by every tag */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_SIZE  (280U)  /*!< Bytes used by tag 'SystemName' (61 parameter(s)) */
#define PARAMETER_LIST_TAG_RESET_PROOF_SIZE  (224U)  /*!< Bytes used by tag 'ResetProof' (45 parameter(s)) */
#define PARAMETER_LIST_TAG_LOGGABLE_SIZE     (229U)  /*!< Bytes used by tag 'Loggable' (46 parameter(s)) */
#define PARAMETER_LIST_TAG_PARAM_MODE_SIZE   (280U)  /*!< Bytes used by tag 'ParamMode' (61 parameter(s)) */

/* MemoryOffset of every parameter, per tag */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_FIX_TYPE_OFFSET    (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_FIX_TYPE2_OFFSET   (1U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_SATELLITES_OFFSET  (2U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_0_OFFSET      (3U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_1_OFFSET      (7U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_2_OFFSET      (11U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_3_OFFSET      (15U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_4_OFFSET      (19U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_5_OFFSET      (23U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_6_OFFSET      (27U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_7_OFFSET      (31U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_8_OFFSET      (35U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_9_OFFSET      (39U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_10_OFFSET     (43U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_NAV_STATUS_HDOP_11_OFFSET     (47U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_0_OFFSET         (51U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_1_OFFSET         (59U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_2_OFFSET         (67U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_3_OFFSET         (75U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_4_OFFSET         (83U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_5_OFFSET         (91U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_6_OFFSET         (99U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_7_OFFSET         (107U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_8_OFFSET         (115U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_9_OFFSET         (123U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_10_OFFSET        (131U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_11_OFFSET        (139U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_12_OFFSET        (147U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_13_OFFSET        (155U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_14_OFFSET        (163U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_WAYPOINT_LAT_15_OFFSET        (171U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_AIRSPEED_OFFSET               (179U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HOME_LAT_OFFSET      (183U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HOME_LON_OFFSET      (191U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_ALT_OFFSET           (199U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_0_OFFSET     (203U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_1_OFFSET     (205U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_2_OFFSET     (207U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_3_OFFSET     (209U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_4_OFFSET     (211U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_5_OFFSET     (213U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_6_OFFSET     (215U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_SAMPLES_7_OFFSET     (217U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_POSITION_HEADING_OFFSET       (219U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_RPM_OFFSET            (223U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_0_OFFSET      (225U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_1_OFFSET      (229U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_0_WINDING_2_OFFSET      (233U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_RPM_OFFSET            (237U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_0_OFFSET      (239U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_1_OFFSET      (243U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_1_WINDING_2_OFFSET      (247U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_RPM_OFFSET            (251U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_0_OFFSET      (253U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_1_OFFSET      (257U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_2_WINDING_2_OFFSET      (261U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_RPM_OFFSET            (265U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_0_OFFSET      (267U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_1_OFFSET      (271U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MOTOR_3_WINDING_2_OFFSET      (275U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_SYSTEM_NAME_MODE_OFFSET                   (279U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_FIX_TYPE_OFFSET    (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_FIX_TYPE2_OFFSET   (1U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_SATELLITES_OFFSET  (2U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_0_OFFSET      (3U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_1_OFFSET      (7U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_2_OFFSET      (11U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_3_OFFSET      (15U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_4_OFFSET      (19U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_5_OFFSET      (23U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_6_OFFSET      (27U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_7_OFFSET      (31U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_8_OFFSET      (35U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_9_OFFSET      (39U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_10_OFFSET     (43U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_NAV_STATUS_HDOP_11_OFFSET     (47U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_0_OFFSET         (51U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_1_OFFSET         (59U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_2_OFFSET         (67U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_3_OFFSET         (75U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_4_OFFSET         (83U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_5_OFFSET         (91U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_6_OFFSET         (99U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_7_OFFSET         (107U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_8_OFFSET         (115U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_9_OFFSET         (123U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_10_OFFSET        (131U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_11_OFFSET        (139U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_12_OFFSET        (147U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_13_OFFSET        (155U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_14_OFFSET        (163U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_WAYPOINT_LAT_15_OFFSET        (171U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_AIRSPEED_OFFSET               (179U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HOME_LAT_OFFSET      (183U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HOME_LON_OFFSET      (191U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_ALT_OFFSET           (199U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_0_OFFSET     (203U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_1_OFFSET     (205U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_2_OFFSET     (207U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_3_OFFSET     (209U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_4_OFFSET     (211U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_5_OFFSET     (213U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_6_OFFSET     (215U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_SAMPLES_7_OFFSET     (217U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_POSITION_HEADING_OFFSET       (219U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_RESET_PROOF_MODE_OFFSET                   (223U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_0_OFFSET            (0U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_1_OFFSET            (8U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_2_OFFSET            (16U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_3_OFFSET            (24U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_4_OFFSET            (32U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_5_OFFSET            (40U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_6_OFFSET            (48U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_7_OFFSET            (56U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_8_OFFSET            (64U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_9_OFFSET            (72U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_10_OFFSET           (80U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_11_OFFSET           (88U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_12_OFFSET           (96U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_13_OFFSET           (104U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_14_OFFSET           (112U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_WAYPOINT_LAT_15_OFFSET           (120U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_AIRSPEED_OFFSET                  (128U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_HOME_LAT_OFFSET         (132U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_HOME_LON_OFFSET         (140U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_ALT_OFFSET              (148U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_0_OFFSET        (152U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_1_OFFSET        (154U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_2_OFFSET        (156U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_3_OFFSET        (158U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_4_OFFSET        (160U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_5_OFFSET        (162U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_6_OFFSET        (164U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_SAMPLES_7_OFFSET        (166U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_POSITION_HEADING_OFFSET          (168U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_RPM_OFFSET               (172U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_0_OFFSET         (174U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_1_OFFSET         (178U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_0_WINDING_2_OFFSET         (182U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_RPM_OFFSET               (186U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_0_OFFSET         (188U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_1_OFFSET         (192U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_1_WINDING_2_OFFSET         (196U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_RPM_OFFSET               (200U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_0_OFFSET         (202U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_1_OFFSET         (206U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_2_WINDING_2_OFFSET         (210U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_RPM_OFFSET               (214U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_0_OFFSET         (216U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_1_OFFSET         (220U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MOTOR_3_WINDING_2_OFFSET         (224U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_LOGGABLE_MODE_OFFSET                      (228U)  /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_FIX_TYPE_OFFSET     (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_FIX_TYPE2_OFFSET    (1U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_SATELLITES_OFFSET   (2U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_0_OFFSET       (3U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_1_OFFSET       (7U)    /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_2_OFFSET       (11U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_3_OFFSET       (15U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_4_OFFSET       (19U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_5_OFFSET       (23U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_6_OFFSET       (27U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_7_OFFSET       (31U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_8_OFFSET       (35U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_9_OFFSET       (39U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_10_OFFSET      (43U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_NAV_STATUS_HDOP_11_OFFSET      (47U)   /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_0_OFFSET          (51U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_1_OFFSET          (59U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_2_OFFSET          (67U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_3_OFFSET          (75U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_4_OFFSET          (83U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_5_OFFSET          (91U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_6_OFFSET          (99U)   /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_7_OFFSET          (107U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_8_OFFSET          (115U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_9_OFFSET          (123U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_10_OFFSET         (131U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_11_OFFSET         (139U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_12_OFFSET         (147U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_13_OFFSET         (155U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_14_OFFSET         (163U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_WAYPOINT_LAT_15_OFFSET         (171U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_AIRSPEED_OFFSET                (179U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HOME_LAT_OFFSET       (183U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HOME_LON_OFFSET       (191U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_ALT_OFFSET            (199U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_0_OFFSET      (203U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_1_OFFSET      (205U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_2_OFFSET      (207U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_3_OFFSET      (209U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_4_OFFSET      (211U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_5_OFFSET      (213U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_6_OFFSET      (215U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_SAMPLES_7_OFFSET      (217U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_POSITION_HEADING_OFFSET        (219U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_RPM_OFFSET             (223U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_0_OFFSET       (225U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_1_OFFSET       (229U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_0_WINDING_2_OFFSET       (233U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_RPM_OFFSET             (237U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_0_OFFSET       (239U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_1_OFFSET       (243U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_1_WINDING_2_OFFSET       (247U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_RPM_OFFSET             (251U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_0_OFFSET       (253U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_1_OFFSET       (257U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_2_WINDING_2_OFFSET       (261U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_RPM_OFFSET             (265U)  /*!< 2 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_0_OFFSET       (267U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_1_OFFSET       (271U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MOTOR_3_WINDING_2_OFFSET       (275U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_TAG_PARAM_MODE_MODE_OFFSET                    (279U)  /*!< 1 byte(s) */

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Values of the 'SYSTEM NAMES' list of the parameter list.
 *
 */
typedef enum {

    SYS_UNKNOWN         = 0,
    SYS_GS_COMPUTER     = 1,
    SYS_GS_MANAGER      = 2,
    SYS_GS_POWER        = 3,
    SYS_ANTENNA_TRACKER = 4,
    SYS_AC_MANAGER      = 5,
    SYS_AC_POWER        = 6,
    SYS_AC_AUTOPILOT    = 7,
    SYS_GIMBAL          = 8,
    SYS_LOCK_TRACK      = 9,
    SYS_LINK_GS         = 10,
    SYS_GS_USB2CAN      = 11,
    SYS_LINK_AIR        = 12,
    SYS_BOOTLOADER      = 13,
    SYS_LINK_BOX        = 14,
    SYS_GOVERNOR        = 15,
    SYS_NAV             = 16,
    SYS_AND             = 17,
    SYS_VNS             = 18,
    SYS_RHS             = 19,
    SYS_AUP             = 20

} eParameterListSystemName;

/**
 * @brief Values of the 'PARAM MODES' list of the parameter list.
 *
 */
typedef enum {

    PARAM_MODE_USER         = 0,
    PARAM_MODE_READ_ONLY    = 1,
    PARAM_MODE_PRODUCT_TYPE = 2,
    PARAM_MODE_FACTORY      = 3,
    PARAM_MODE_CALIB        = 4,
    PARAM_MODE_TEMPORARY    = 5

} eParameterListParamMode;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_DEFINES_H */

/* === Copyright (c) 2026 FAS === EOF === */

# -*- coding: utf-8 -*-
"""Assemble the developer manual, then fill its contents with real page numbers.

The page numbers are the reason this is a script and not a single HTML file: a
table of contents cannot know what page a chapter lands on until the PDF exists.
So the manual is printed twice.  The first pass carries an invisible marker next
to every heading (white, 1pt - present in the text layer, invisible on paper);
the numbers are read back out of that PDF with ``pdftotext``, written into the
contents, and the whole thing is printed again.

    cd docs/manual_source
    python assemble.py
"""
import re, shutil, subprocess, sys, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DOCS = HERE.parent
PROJECT = DOCS.parent
OUT_HTML = DOCS / 'developer_manual_fa.html'
OUT_PDF = PROJECT / 'parameter_list_developer_manual_fa.pdf'
PARTS = HERE / 'parts'

#: Any Chromium-based browser prints this; the one the machine has is found the
#: same way docs/build_manual.py finds it.
sys.path.insert(0, str(DOCS))
try:
    from build_manual import find_browser as _find_browser
    BROWSER = str(_find_browser() or '')
except Exception:
    BROWSER = ''
if not BROWSER:
    BROWSER = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'

EXTRA_CSS = """
<style>
/* ---- developer manual additions ---- */
h2 code, h1 code { font-size:inherit; background:none; border:0; padding:0; }
.ln{ font-size:8.5pt; color:var(--muted); font-weight:400; }
.when{ background:var(--soft); border-right:3px solid var(--accent);
       padding:2mm 3mm; margin:0 0 3.5mm; font-size:9.3pt; }
.cls{ margin:5mm 0 1mm; font-size:10.4pt; background:var(--accent-soft);
      border-right:3px solid var(--accent); padding:1.5mm 3mm; page-break-after:avoid; }
.cls .kw{ color:var(--accent); font-family:"DejaVu Sans Mono",monospace; font-size:9pt; }
.cls b{ font-family:"DejaVu Sans Mono",monospace; }
.cls .deco{ font-family:"DejaVu Sans Mono",monospace; font-size:8.2pt; color:var(--muted); }
.clsdoc{ margin:0 0 2mm; font-size:9.5pt; }
.sub{ font-weight:700; font-size:9.6pt; margin:4mm 0 1.5mm; color:#2c3742;
      page-break-after:avoid; }
table.api{ font-size:8.6pt; margin-bottom:3.5mm; }
table.api th{ font-size:8.4pt; }
td.sigcell{ font-size:7.9pt; line-height:1.45; }
.pill{ display:inline-block; font-size:7pt; padding:0 4px; border-radius:8px;
       background:var(--accent-soft); color:#0a3d6b; margin-left:3px;
       font-family:"DejaVu Sans Mono",monospace; }
.pill.priv{ background:#eee; color:#777; }
.ltr{ display:inline-block; direction:ltr; text-align:left; }
/* the invisible page markers: present in the text layer, invisible on paper */
.pgm{ font-size:1pt; color:#ffffff; }
/* table of contents with page numbers */
.toc2{ page-break-after:always; }
.toc2 h1{ page-break-before:avoid; }
.toc2 ul{ list-style:none; padding:0; margin:0; }
.toc2 li{ font-size:9.6pt; margin-bottom:.8mm; display:flex; align-items:baseline; }
.toc2 li.part{ font-weight:700; color:var(--accent); margin-top:4mm;
               font-size:10.4pt; border-bottom:1px solid var(--line); padding-bottom:1mm; }
.toc2 li.f{ font-size:8.7pt; color:var(--muted); padding-right:7mm; }
.toc2 .t{ order:1; }
.toc2 .dots{ order:2; flex:1; border-bottom:1px dotted #c3ccd4; margin:0 2mm 2px; }
.toc2 .pg{ order:3; font-family:"DejaVu Sans Mono",monospace; font-size:8.6pt;
           color:var(--ink); min-width:7mm; text-align:left; direction:ltr; }
.toc2 li.part .pg{ color:var(--accent); }
</style>
"""

#: The cover.  {py} and {web} are filled in from the inventories, because a
#: count typed into a cover page is a count that is wrong the next time somebody
#: adds a file - which is exactly what happened to the first version of this.
COVER = """<body>
<section class="cover">
  <div class="kicker">شرکت FAS &nbsp;·&nbsp; مستندات فنی</div>
  <h1>ابزار تولید کد اتوماتیک<br>لیست پارامترها</h1>
  <div class="sub">راهنمای توسعه‌دهنده</div>
  <div class="rule"></div>
  <div class="meta">
    <div><b>فاز:</b> دو &nbsp;—&nbsp; ویرایشگر گرافیکی</div>
    <div><b>نسخه ابزار:</b> {ver}</div>
    <div><b>پوشه:</b> <code>phase2_parameter_list_code_generator</code></div>
  </div>
  <div class="meta" style="margin-top:12mm">
    <div>مرجع کامل هر {py} فایل پایتون و هر {web} فایل رابط وب،</div>
    <div>با همه‌ی کلاس‌ها، متدها و توابعشان،</div>
    <div>به‌علاوه‌ی یک فصل کامل آموزش جاوااسکریپت و رابط کاربری از صفر.</div>
  </div>
</section>
"""


def tool_version() -> str:
    """The tool's own version string - never a number typed into the manual."""
    import sys
    sys.path.insert(0, str(PROJECT / "tools"))
    from common.pl_codegen import __version__
    return __version__


def persian_version() -> str:
    """tool_version() with Persian digits, for the running footer."""
    return tool_version().translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def cover_html():
    """The cover with its two file counts filled in from the inventories."""
    import json
    py = len(json.load(open(HERE / "api.json", encoding="utf-8")))
    web = len(json.load(open(HERE / "web_api.json", encoding="utf-8")))
    digits = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
    COVER_V = COVER.replace("{ver}", tool_version().translate(digits))
    return COVER_V.replace("{py}", str(py).translate(digits)) \
                .replace("{web}", str(web).translate(digits))

#: Numbers the prose quotes about the tool.  They are substituted here rather
#: than typed into the text, because a number typed into prose is a number that
#: is wrong the next time somebody adds a file or a rule.
def live_numbers():
    import json
    import sys
    sys.path.insert(0, str(PROJECT / "tools"))
    from common.pl_codegen.validation.rules import ALL_RULES
    from common.pl_codegen.model.types import VALUE_TYPES

    digits = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")

    def fa(value):
        return str(value).translate(digits)

    api = json.loads((HERE / "api.json").read_text(encoding="utf-8"))
    return {
        "{{FILE_COUNT}}": fa(len(api)),
        "{{RULE_COUNT}}": fa(len(ALL_RULES)),
        "{{TYPE_COUNT}}": fa(len(VALUE_TYPES)),
    }


def build_body():
    order = ['p01_intro.html', 'p02_python.html', 'p03_arch.html', 'p04_map.html',
             'p05_reference.html', 'p09_web.html', 'p06_recipes.html',
             'p10_trace.html', 'p11_trouble.html',
             'p07_pitfalls.html', 'p08_appendix.html']
    body = "\n".join((PARTS / name).read_text(encoding='utf-8') for name in order)
    for placeholder, value in live_numbers().items():
        body = body.replace(placeholder, value)
    return body

def collect_entries(body):
    """Every chapter heading and every file heading, in document order."""
    entries = []
    for m in re.finditer(r'<h([12])[^>]*>(.*?)</h\1>', body, re.S):
        raw = m.group(2)
        mk = re.search(r'PGM([A-Za-z0-9_]+)PGM', raw)
        if not mk:
            continue
        text = re.sub(r'<span class="pgm">.*?</span>', '', raw)
        text = re.sub(r'<[^>]+>', '', text).strip()
        entries.append({"key": mk.group(1), "text": text,
                        "kind": "part" if m.group(1) == "1" else "f"})
    return entries

def toc_html(entries, pages):
    rows = ['<section class="toc2">', '<h1 class="first">فهرست مطالب</h1>', '<ul>']
    for e in entries:
        pg = pages.get(e["key"], "")
        rows.append(f'<li class="{e["kind"]}"><span class="t">{e["text"]}</span>'
                    f'<span class="dots"></span><span class="pg">{pg}</span></li>')
    rows += ['</ul>', '</section>']
    return "\n".join(rows)

def write_html(head, body, entries, pages):
    OUT_HTML.write_text(head + "\n" + cover_html() + toc_html(entries, pages) + "\n" +
                        body + "\n</body>\n</html>\n", encoding='utf-8')

def render_pdf():
    with tempfile.TemporaryDirectory() as profile:
        subprocess.run([BROWSER, "--headless", "--disable-gpu", "--no-sandbox",
                        "--no-pdf-header-footer", "--run-all-compositor-stages-before-draw",
                        "--virtual-time-budget=20000", f"--user-data-dir={profile}",
                        f"--print-to-pdf={OUT_PDF}", OUT_HTML.as_uri()],
                       capture_output=True, text=True)
    return OUT_PDF

def pdf_pages_text():
    """The text of the PDF, one string per page.

    'pdftotext' from poppler is tried first because it is a plain executable:
    the project installs nothing, and asking a machine with no internet for a
    Python PDF package is asking for a build that cannot be run.  pdfplumber is
    kept as the fallback for a machine that has the package but not the tool.
    """
    if shutil.which('pdftotext'):
        # -layout keeps the markers on the line they were printed on; the pages
        # come back separated by form feeds, which is what tells them apart.
        result = subprocess.run(['pdftotext', '-layout', '-q', str(OUT_PDF), '-'],
                                capture_output=True, text=True, encoding='utf-8',
                                errors='replace')
        if result.returncode == 0:
            return result.stdout.split('\f')

    try:
        import pdfplumber
    except ImportError:
        raise SystemExit(
            "Neither 'pdftotext' (poppler) nor the 'pdfplumber' package is available, "
            "so the page numbers of the table of contents cannot be read back.\n"
            "Install poppler-utils, or put pdftotext on the PATH, and run this again.")
    with pdfplumber.open(OUT_PDF) as pdf:
        return [page.extract_text() or "" for page in pdf.pages]


def page_numbers():
    found = {}
    for number, text in enumerate(pdf_pages_text(), start=1):
        for key in re.findall(r'PGM([A-Za-z0-9_]+)PGM', text.replace(" ", "")):
            found.setdefault(key, number)
    return found

def user_manual_head():
    """The <head> both manuals share: the CSS and the embedded Vazirmatn font.

    It is taken from the built user manual, which is in the repository, rather
    than from a scratch copy somewhere on the machine: this used to read
    '/tmp/manual_parts/head.html', a file left over from the session that first
    wrote the manual.  Once that temp folder was gone the developer manual could
    not be rebuilt at all - on any machine, let alone a Windows one.
    """
    source = DOCS / 'user_manual_fa.html'
    text = source.read_text(encoding='utf-8')
    end = text.find('</head>')
    if end < 0:
        raise SystemExit(f"{source.name} has no </head>; cannot borrow the style from it.")
    return text[:end] + '</head>'


def main():
    head = (user_manual_head()
            .replace('<title>راهنمای ابزار تولید کد لیست پارامترها</title>',
                     '<title>راهنمای توسعه‌دهنده — ابزار تولید کد لیست پارامترها</title>')
            .replace('content:"راهنمای ابزار تولید کد لیست پارامترها  ·  نسخه ۱٫۰٫۰";',
                     'content:"راهنمای توسعه‌دهنده — ابزار تولید کد لیست پارامترها'
                     '  ·  نسخه ' + persian_version() + '";')
            .replace('</head>', EXTRA_CSS + '</head>'))
    body = build_body()
    entries = collect_entries(body)
    print(f"{len(entries)} entries in the table of contents")

    pages, previous = {}, None
    for attempt in range(1, 5):
        write_html(head, body, entries, pages)
        render_pdf()
        pages = page_numbers()
        missing = [e["key"] for e in entries if e["key"] not in pages]
        print(f"  pass {attempt}: {len(pages)} located, {len(missing)} missing")
        if missing[:3]:
            print("    missing sample:", missing[:3])
        if pages == previous:
            print("  page numbers are stable")
            break
        previous = dict(pages)
    write_html(head, body, entries, pages)
    render_pdf()
    size = OUT_PDF.stat().st_size // 1024
    # The page count comes from the text we already extracted, so the build
    # needs no second PDF tool just to print one number.
    print(f"pages: {len(pdf_pages_text())}")
    print(f"written: {OUT_PDF.name} ({size} KB), {OUT_HTML.stat().st_size//1024} KB HTML")

main()

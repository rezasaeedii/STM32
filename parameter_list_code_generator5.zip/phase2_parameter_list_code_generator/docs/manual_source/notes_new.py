# -*- coding: utf-8 -*-
"""Persian prose for the files that arrived with the two-phase restructure."""

NOTES = {}

NOTES["run_tests.py"] = {
 "fa": """<p>همه‌ی تست‌ها را پشت سر هم اجرا می‌کند و یک نتیجه‌ی واحد می‌دهد. عمداً یک اسکریپت
ساده است: هیچ فریم‌ورک تستی نصب نمی‌شود و روی ماشین بدون اینترنت هم کار می‌کند.
<code>python run_tests.py --list</code> فقط اسم تست‌ها را می‌گوید و چیزی اجرا نمی‌کند.</p>
<p>لیست تست‌ها در بالای فایل، در <code>SUITES</code>، است — یک تاپل
<code>(عنوان، مسیر اسکریپت)</code> برای هرکدام. اضافه کردن یک تست جدید یعنی یک خط اینجا.</p>
<p class="when"><b>یک ریزه‌کاری که مهم است:</b> اگر اسکریپتی روی دیسک نباشد، «رد شد» شمرده
می‌شود نه «قبول شد»، و در انتها اسمش گزارش می‌شود. دلیلش این است که یک پوشه‌ی نیمه‌کپی‌شده
نباید شبیه یک پوشه‌ی سالم به نظر برسد.</p>""",
 "when": "هر بار که تست جدیدی می‌نویسید.",
}

NOTES["common/pl_codegen/codegen/files/parameter_types_h.py"] = {
 "fa": """<p>سازنده‌ی <code>cg_parameter_list_types.h</code> — به ازای هر استراکچر، یک
<code>typedef struct</code>.</p>
<p>اگر لیست هیچ استراکچری نداشته باشد، این فایل فقط یک کامنت است که همین را می‌گوید —
تولید می‌شود تا <code>#include</code>ها در بقیه‌ی فایل‌ها همیشه معتبر بمانند.</p>
<p><b>ترتیب مهم است:</b> استراکچرِ داخلی باید <i>قبل از</i> استراکچری که از آن استفاده
می‌کند تعریف شود، وگرنه کامپایلر نوعِ ناشناخته می‌بیند. برای همین
<code>model.struct_parameters()</code> لیست را <b>عمیق‌ترین اول</b> برمی‌گرداند و این
سازنده فقط به همان ترتیب می‌نویسد.</p>
<pre><code>typedef struct {
    sSmartDataF64 Lat;
    sSmartDataF64 Lon;
} sCgStruct_Position_Home;      /* اول این */

typedef struct {
    sCgStruct_Position_Home Home;   /* بعد این، که از بالایی استفاده می‌کند */
    sSmartDataF32           Alt;
} sCgStruct_Position;</code></pre>
<p>اگر فیلدی آرایه باشد — چه یک مقدار ساده و چه یک ساب‌استراکچر — سایزش از ماکرو
<code>..._ARRAY_SIZE</code> می‌آید نه از یک عدد ثابت، پس عوض کردن سایز در ورودی، هم
اعلان و هم ماکرو را با هم عوض می‌کند.</p>""",
 "when": "وقتی می‌خواهید شکل استراکچرهای تولیدی عوض شود — مثلاً اضافه شدن <code>__attribute__((packed))</code> یا یک کامنت بیشتر.",
}

NOTES["run_setup.py"] = {
 "fa": """<p>نقطه‌ی ورودِ چک محیط. سه خط بیشتر نیست و کل کارش صدا زدن
<code>setup_environment.main()</code> است.</p>
<p class="when"><b>چرا وقتی خودِ <code>setup_environment.py</code> هم مستقیم اجرا می‌شود،
این فایل هم هست؟</b> چون قاعده‌ی پوشه‌ی <code>tools</code> این است که
<b>هر کاری که کاربر شروع می‌کند یک <code>run_*.py</code> دارد و یک <code>.bat</code>
هم‌نام کنارش</b>. با این فایل، جوابِ «چه چیزهایی را می‌شود اجرا کرد؟» فقط یک
<code>dir run_*</code> است و کسی لازم نیست بداند کدام‌یک اسکریپت است و کدام ماژول:</p>
<pre><code>run_gui.py       run_gui.bat        ویرایشگر گرافیکی
run_generate.py  run_generate.bat   تولید کد
run_tests.py     run_tests.bat      تست‌های خود ابزار
run_setup.py     run_setup.bat      چک محیط</code></pre>
<p><code>setup_environment.py</code> سر جایش می‌ماند، چون خودش <i>ماژول</i> است نه نقطه‌ی
ورود — دقیقاً همان‌طور که <code>cli.py</code> ماژول است و <code>run_generate.py</code>
نقطه‌ی ورودش.</p>""",
 "when": "تقریباً هیچ‌وقت. اگر چکِ محیط سوییچ تازه‌ای بخواهد، به <code>setup_environment.py</code> اضافه‌اش کنید نه اینجا.",
}

"""Checks that a faulty parameter list is rejected with the right diagnostics.

Each case builds a small model in memory, runs the validator on it and asserts
which diagnostic code comes back.  No compiler needed.

Run it with::

    python tests/run_validation_test.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from common.pl_codegen.config import Config  # noqa: E402
from common.pl_codegen.errors import DiagnosticCollector, Severity  # noqa: E402
from common.pl_codegen.logging_utils import (BOLD, BRIGHT_RED, GREEN,  # noqa: E402
                                            colour_supported, paint, setup_logging)
import common.pl_codegen.logging_utils as _logging_utils  # noqa: E402
from common.pl_codegen.model.defines import (COLUMN_TYPES, COLUMN_PARAM_MODES,  # noqa: E402
                                      COLUMN_SYSTEM_NAMES, COLUMN_VALUE_TYPES, Defines)
from common.pl_codegen.model.parameter import Parameter, ParameterKind  # noqa: E402
from common.pl_codegen.model.parameter_list import ParameterList  # noqa: E402
from common.pl_codegen.model.types import VALUE_TYPES  # noqa: E402
from common.pl_codegen.validation.validator import Validator  # noqa: E402

_logging_utils._colour_enabled = colour_supported()

SYSTEM_NAMES = ["SYS_UNKNOWN", "SYS_NAV"]
PARAM_MODES = ["PARAM_MODE_USER", "PARAM_MODE_READ_ONLY"]
PARAMETER_TYPES = ["MONITORING", "SETTING", "COMMAND"]


# ---------------------------------------------------------------- builders
def tags(**overrides: Any) -> Dict[str, Any]:
    base = {"SystemName": "SYS_NAV", "ResetProof": False, "Loggable": False,
            "LogEncryption": False, "ParamMode": "PARAM_MODE_USER"}
    base.update(overrides)
    return base


def value(name: str = "GoodParam", **overrides: Any) -> Parameter:
    node = Parameter(name=name, param_type="MONITORING", value_type_name="uint8_t",
                     default_value=5, minimum=0, maximum=10, resolution=1,
                     unit="mm", gs_name=name, description="A valid parameter.")
    node.tags = tags()
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def struct(name: str, *children: Parameter, **overrides: Any) -> Parameter:
    node = Parameter(name=name, kind=ParameterKind.STRUCT, param_type="MONITORING",
                     description="A structure.")
    node.tags = tags()
    node.children = list(children)
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def field(name: str, **overrides: Any) -> Parameter:
    """A field of a structure: no tags and no type of its own."""
    node = Parameter(name=name, value_type_name="uint8_t", default_value=0,
                     minimum=0, maximum=10, resolution=1, gs_name=name,
                     description="A field.")
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def inner(name: str, *children: Parameter, **overrides: Any) -> Parameter:
    """A sub-structure: like a field, it carries no tags and no type."""
    node = Parameter(name=name, kind=ParameterKind.STRUCT, description="A structure.")
    node.children = list(children)
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def model(*parameters: Parameter) -> ParameterList:
    result = ParameterList(parameters=list(parameters))
    defines = Defines()
    for name in VALUE_TYPES:
        defines.add(COLUMN_VALUE_TYPES, name)
    for name in PARAMETER_TYPES:
        defines.add(COLUMN_TYPES, name)
    for name in SYSTEM_NAMES:
        defines.add(COLUMN_SYSTEM_NAMES, name)
    for name in PARAM_MODES:
        defines.add(COLUMN_PARAM_MODES, name)
    result.defines = defines
    return result


# ---------------------------------------------------------------- the cases
CASES: List[Dict[str, Any]] = [
    # ---- names -----------------------------------------------------------
    {"name": "invalid_name", "expect": "NAME001",
     "model": lambda: model(value("2Bad Name"))},
    {"name": "reserved_name", "expect": "NAME002",
     "model": lambda: model(value("struct"))},
    {"name": "duplicate_top_level", "expect": "NAME003",
     "model": lambda: model(value("Same"), value("Same"))},
    {"name": "duplicate_field", "expect": "NAME003",
     "model": lambda: model(struct("S", field("A"), field("A")))},
    {"name": "macro_collision", "expect": "NAME004",
     "model": lambda: model(value("TestVar"), value("Test_Var"))},

    # ---- structures ------------------------------------------------------
    {"name": "empty_struct", "expect": "STR001",
     "model": lambda: model(struct("Empty"))},
    {"name": "struct_array_size_zero", "expect": "STR002",
     "model": lambda: model(struct("S", field("A"), array_size=0))},
    {"name": "array_of_struct", "expect": None,
     "model": lambda: model(struct("S", field("A"), array_size=4))},
    {"name": "array_of_struct_with_array_field", "expect": None,
     "model": lambda: model(struct("S", field("A", array_size=3), array_size=4))},
    {"name": "array_of_nested_struct", "expect": None,
     "model": lambda: model(struct("S", inner("Inner", field("A")), array_size=2))},

    # ---- types and ranges -------------------------------------------------
    {"name": "unsupported_type", "expect": "TYPE002",
     "model": lambda: model(value(value_type_name="sMyStruct"))},
    # NAME005 had no case at all, so nothing would have noticed if the rule
    # stopped firing.  '_' is a legal C identifier and derives an EMPTY macro,
    # which is exactly the gap between NAME001 and NAME005.
    {"name": "name_derives_a_bad_macro", "expect": "NAME005",
     "model": lambda: model(value("_"))},
    {"name": "unknown_parameter_type", "expect": "GRP002",
     "model": lambda: model(value(param_type="TELEMETRY"))},
    {"name": "struct_without_parameter_type", "expect": "GRP001",
     "model": lambda: model(struct("S", field("A"), param_type=None))},
    {"name": "field_with_own_tag", "expect": "STR004",
     "model": lambda: model(struct("S", field("A", tags={"Loggable": True})))},
    {"name": "field_with_own_parameter_type", "expect": "STR005",
     "model": lambda: model(struct("S", field("A", param_type="SETTING")))},
    {"name": "substruct_with_own_tag", "expect": "STR004",
     "model": lambda: model(struct("S", inner("Inner", field("A"),
                                              tags={"SystemName": "SYS_NAV"})))},
    {"name": "bad_array_size", "expect": "ARR001",
     "model": lambda: model(value(array_size=0))},
    {"name": "value_out_of_c_type", "expect": "RNG001",
     "model": lambda: model(value(maximum=5000))},
    {"name": "min_greater_than_max", "expect": "RNG002",
     "model": lambda: model(value(minimum=10, maximum=1, default_value=5))},
    {"name": "default_out_of_range", "expect": "RNG003",
     "model": lambda: model(value(default_value=99))},

    # ---- tags -------------------------------------------------------------
    {"name": "missing_mandatory_tag", "expect": "TAG001",
     "model": lambda: model(value(tags={"SystemName": None}))},
    {"name": "unknown_system_name", "expect": "TAG003",
     "model": lambda: model(value(tags={"SystemName": "SYS_NOPE"}))},
    {"name": "loggable_without_log_id", "expect": "TAG010",
     "model": lambda: model(value(tags={"Loggable": True}))},
    {"name": "duplicate_log_id", "expect": "TAG012",
     "model": lambda: model(value("A", tags={"Loggable": True}, log_id=500),
                            value("B", tags={"Loggable": True}, log_id=500))},
    # float64_t x2 reserves 16 ids: 400..415, so 410 must be refused
    # A log id reserves ONE id per array element and does not depend on the
    # type: float64_t[10] at 400 hands 400..409 to its ten elements, so the
    # element that got 405 and 'Next' are two values holding the same id.
    {"name": "log_id_inside_an_array", "expect": "TAG012",
     "model": lambda: model(
         value("Wide", value_type_name="float64_t", array_size=10, minimum=0, maximum=0,
               default_value=0, tags={"Loggable": True}, log_id=400),
         value("Next", tags={"Loggable": True}, log_id=405))},

    # The descriptor stores the log id in a uint16_t, and an array reserves one
    # id per element - so it is the END of the range that has to fit.  65530
    # itself is legal; 65530 plus ten elements is not.
    {"name": "log_id_over_uint16", "expect": "TAG015",
     "model": lambda: model(value("Late", array_size=10,
                                  tags={"Loggable": True}, log_id=65530))},
    # every element of an array is a value with an id of its own, so an array
    # of 10 really does占 ten of them
    {"name": "log_id_one_per_element", "expect": None,
     "model": lambda: model(
         value("Block", array_size=4, tags={"Loggable": True}, log_id=800),
         value("After", tags={"Loggable": True}, log_id=804))},
    {"name": "log_id_last_that_fits", "expect": None,
     "model": lambda: model(value("Last", array_size=6,
                                  tags={"Loggable": True}, log_id=65530))},

    # ---- the good cases ---------------------------------------------------
    {"name": "log_id_range_ok", "expect": None,
     "model": lambda: model(
         value("Wide", value_type_name="float64_t", array_size=2, minimum=0, maximum=0,
               default_value=0, tags={"Loggable": True}, log_id=400),
         value("Next", tags={"Loggable": True}, log_id=416))},
    {"name": "empty_list", "expect": "VAL001", "model": lambda: model()},
    {"name": "all_disabled", "expect": "VAL001",
     "model": lambda: model(value(enable=False))},
    {"name": "flat_ok", "expect": None,
     "model": lambda: model(value("First"), value("Second"))},
    # every field takes the mandatory tags and the type of its structure
    {"name": "struct_inherits_ok", "expect": None,
     "model": lambda: model(struct("Position",
                                   inner("Home", field("Lat"), field("Lon")),
                                   field("Alt")))},
    # one log id on the structure covers all of its fields
    {"name": "struct_log_id_ok", "expect": None,
     "model": lambda: model(struct("S", field("A"), field("B"), field("C"),
                                   tags={"Loggable": True}, log_id=700))},
    # an exact clash with one of the fields is the clearer TAG012
    {"name": "struct_log_id_hits_field", "expect": "TAG012",
     "model": lambda: model(
         struct("S", field("A"), field("B"), field("C"),
                tags={"Loggable": True}, log_id=700),
         value("After", tags={"Loggable": True}, log_id=702))},
    # A struct hands one id per leaf value: three fields at 700 take 700, 701
    # and 702.  An array of 2 starting at 701 wants 701 and 702 as well, so both
    # of its elements collide with a field.
    {"name": "struct_log_id_block_collides", "expect": "TAG012",
     "model": lambda: model(
         struct("S", field("A"), field("B"), field("C"),
                tags={"Loggable": True}, log_id=700),
         value("After", array_size=2, tags={"Loggable": True}, log_id=701))},
    # the block of S is 700..702, so 703 is the first free id
    {"name": "struct_log_id_block_ok", "expect": None,
     "model": lambda: model(
         struct("S", field("A"), field("B"), field("C"),
                tags={"Loggable": True}, log_id=700),
         value("After", tags={"Loggable": True}, log_id=703))},

    # ---- names the generator invents, which the user never sees -----------
    # 'A_B' and 'A.B' both become the C type 'sCgStruct_A_B'.  Nothing else
    # catches it - the fields have different names, so no macro collides - and
    # the generated header would hold two typedefs of one name.
    {"name": "struct_type_name_collision", "expect": "NAME004",
     "model": lambda: model(struct("A_B", field("X")),
                            struct("A", inner("B", field("Y"))))},
    {"name": "struct_type_names_distinct", "expect": None,
     "model": lambda: model(struct("A_C", field("X")),
                            struct("A", inner("B", field("Y"))))},
    # The elements of a struct array share one declaration, so they must share
    # one array size macro rather than collide over it.
    {"name": "struct_array_shares_one_size_macro", "expect": None,
     "model": lambda: model(struct("Wheels", field("Samples", array_size=4),
                                   array_size=3))},
]


def run_case(config: Config, build: Callable[[], ParameterList]) -> Set[str]:
    diagnostics = DiagnosticCollector()
    Validator(config).validate(build(), diagnostics)
    return {item.code for item in diagnostics.items if item.severity is Severity.ERROR}


def main() -> int:
    setup_logging(quiet=True)
    failures = 0

    with tempfile.TemporaryDirectory(prefix="pl_codegen_validation_") as raw_dir:
        work_dir = Path(raw_dir)
        config_path = work_dir / "config.json"
        config_path.write_text(json.dumps({
            "inputs": {"model_file": str(work_dir / "model.xml")},
            "output": {"code_directory": str(work_dir / "gen")},
            "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
        }), encoding="utf-8")
        config = Config.load(config_path)

        for case in CASES:
            codes = run_case(config, case["model"])
            expected: Optional[str] = case["expect"]

            if expected is None:
                ok = not codes
                detail = "no error expected"
            else:
                ok = expected in codes
                detail = f"expected {expected}"

            mark = paint("PASS", GREEN) if ok else paint("FAIL", BOLD + BRIGHT_RED)
            print(f"  [{mark}] {case['name']:<24} {detail}; "
                  f"reported: {', '.join(sorted(codes)) or '-'}")
            if not ok:
                failures += 1

    print()
    if failures:
        print(paint(f"{failures} of {len(CASES)} validation case(s) FAILED.",
                    BOLD + BRIGHT_RED))
        return 1
    print(paint(f"All {len(CASES)} validation cases passed.", GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Tests of the editor itself - the part of phase 2 that has no counterpart in
phase 1, and therefore no shared test.

Everything here goes through :class:`pl_gui.api.Api`, which is exactly what the
browser calls, so a test passing here means the button in the toolbar works.
The whole thing runs on a *copy* of the project in a temporary folder, so it can
create files, rewrite the configuration and reorder the build without ever
touching the project the user is working in.

Run it with::

    python tests/run_editor_test.py
"""

from __future__ import annotations

import shutil
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable, List, Tuple

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from common.pl_codegen.config import Config          # noqa: E402
from common.pl_codegen.errors import DiagnosticCollector          # noqa: E402
from common.pl_codegen.xml_model.xml_reader import read_xml       # noqa: E402
from common.pl_codegen.xml_model.xml_writer import write_xml      # noqa: E402
from common.pl_codegen.logging_utils import (BOLD, BRIGHT_RED, GREEN,  # noqa: E402
                                            colour_supported, paint)
import common.pl_codegen.logging_utils as _logging_utils  # noqa: E402
from pl_gui.api import Api                           # noqa: E402
from pl_gui.document import Document                 # noqa: E402

_logging_utils._colour_enabled = colour_supported()


class Failure(AssertionError):
    """One expectation that did not hold."""


def check(condition: bool, message: str) -> None:
    if not condition:
        raise Failure(message)


def equal(actual, expected, message: str) -> None:
    if actual != expected:
        raise Failure(f"{message}: expected {expected!r}, got {actual!r}")


# --------------------------------------------------------------- the fixture
def open_copy(work: Path, *, empty: bool = False) -> Tuple[Document, Api, Path]:
    """A Document on a throw-away copy of the project.

    With ``empty`` the document is emptied of parameters before the test starts,
    so a case can say exactly what the list contains without depending on what
    the project happens to hold today.  The drop-down lists are kept - a case
    that adds a parameter needs a type and a system name to give it.

    Emptying the open list is *not* enough on its own.  ``Api.state`` reports
    the type library of the whole project (``merged_model().templates``),
    because a type one list defines is offered in every other - so a structure
    somebody happened to save in another list would show up in a case that
    thought it had started from nothing.  The other lists are therefore emptied
    on disk as well, which is what makes ``empty`` mean empty.
    """
    shutil.copytree(PROJECT_DIR, work / "project", dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))
    config_path = work / "project" / "tools" / "codegen_config.json"
    document = Document(Config.load(config_path))
    document.load()
    if empty:
        _empty_the_other_lists(document)
        document.model.parameters.clear()
        document.model.templates.clear()
    return document, Api(document), config_path


def _empty_the_other_lists(document: Document) -> None:
    """Strip every list of the build except the open one, on disk."""
    for path in document.config.inputs.model_files:
        if path == document.path or not path.is_file():
            continue
        other = read_xml(path, DiagnosticCollector())
        other.parameters.clear()
        other.templates.clear()
        write_xml(other, path, emit_timestamp=False)


# --------------------------------------------------------------- the cases
def test_structure_types(work: Path) -> None:
    """A structure can become a data type, and a copy owns what it copied."""
    document, api, _config = open_copy(work, empty=True)

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Position"})
    document.add_parameter("Position", "primitive")
    document.update("Position.NewParameter",
                    {"name": "Lat", "value_type_name": "float64_t",
                     "minimum": -90.0, "maximum": 90.0, "resolution": 1e-07,
                     "default_value": 0.0, "unit": "deg"})
    document.add_parameter("Position", "primitive")
    document.update("Position.NewParameter",
                    {"name": "Samples", "value_type_name": "int16_t", "array_size": 4,
                     "minimum": 0, "maximum": 100, "resolution": 1, "default_value": 0})

    answer = api.save_template({"path": "Position", "name": "sPosition"})
    check(answer["ok"], f"the structure was not saved as a type: {answer}")

    listed = api.state({})["templates"]
    equal([item["name"] for item in listed], ["sPosition"], "the type list")
    equal(listed[0]["fields"], 2, "values per copy")
    equal(listed[0]["shape"], ["Lat : float64_t", "Samples[4] : int16_t"], "the shape")

    # a parameter picks the type out of the same list the data types are in
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "Target"})
    check(api.use_template({"path": "Target", "name": "sPosition"})["ok"],
          "the type could not be applied")

    target = document.find("Target")
    equal(target.kind.value, "struct", "the parameter became a structure")
    equal([child.name for child in target.children], ["Lat", "Samples"], "the copied fields")
    equal(target.children[0].maximum, 90.0, "the copied limit")
    equal(target.children[0].unit, "deg", "the copied unit")
    check(target.param_type is not None, "the copy kept the type of the parameter")
    check(target.tags.get("SystemName") is not None, "the copy kept its own tags")

    # ... and owns it: editing the copy leaves the type alone
    document.update("Target.Lat", {"maximum": 45.0})
    equal(document.find_template("sPosition").children[0].maximum, 90.0,
          "editing a copy changed the type")
    equal(document.find("Target").children[0].maximum, 45.0, "the copy was not edited")

    # the library survives a save and a reload
    saved = document.save()
    again = Document(document.config)
    again.load(saved)
    equal([item.name for item in again.model.templates], ["sPosition"],
          "the type library after a reload")
    equal(again.model.templates[0].param_type, None, "a type carries no parameter type")
    equal(again.model.templates[0].tags, {}, "a type carries no tags")

    # a type nobody uses generates nothing
    check(api.delete_template({"name": "sPosition"})["ok"], "the type was not removed")
    equal(api.state({})["templates"], [], "the type list after removing the only type")


def test_structure_arrays(work: Path) -> None:
    """An array of structures produces one set of values per element."""
    document, _api, _config = open_copy(work, empty=True)

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Wheels", "array_size": 3,
                                  # log_id is a field of its own, not a tag
                                  "log_id": 900,
                                  "tags": {"Loggable": True,
                                           "SystemName": "SYS_NAV",
                                           "ParamMode": "PARAM_MODE_USER",
                                           "ResetProof": False, "LogEncryption": False}})
    document.add_parameter("Wheels", "primitive")
    document.update("Wheels.NewParameter",
                    {"name": "Speed", "value_type_name": "float32_t",
                     "minimum": 0, "maximum": 0, "resolution": 0.001, "default_value": 0.0})

    leaves = document.model.flatten()
    equal([leaf.name for leaf in leaves],
          ["Wheels[0].Speed", "Wheels[1].Speed", "Wheels[2].Speed"], "the expanded leaves")
    equal([leaf.log_id for leaf in leaves], [900, 901, 902], "one log id per value")

    # A log id counts values, never bytes: a float32_t[10] takes ten ids, and so
    # would a uint8_t[10].  Every element is a value in its own right - its own
    # row, its own index, its own id - so three struct elements each holding an
    # array of 10 produce thirty values numbered 900..929.
    document.update("Wheels.Speed", {"array_size": 10})
    expanded = document.model.flatten()
    equal(len(expanded), 30, "three elements of ten values each")
    equal([leaf.name for leaf in expanded[:2]],
          ["Wheels[0].Speed[0]", "Wheels[0].Speed[1]"], "every element is its own value")
    equal([expanded[0].log_id, expanded[10].log_id, expanded[20].log_id],
          [900, 910, 920], "each struct element starts a block of ten ids")
    equal([leaf.log_id for leaf in expanded], list(range(900, 930)),
          "the ids run without a gap, one per value")

    # 'the next free id' is a property of the whole project, not of this list:
    # the other lists of the build reserve ids too, and an id that is free here
    # but taken in another list is not free.
    free = document.next_free_log_id()
    check(free >= 930, f"the next free id must be past this list's block, got {free}")
    for leaf in document.merged_model().flatten():
        log_id = leaf.log_id
        if isinstance(log_id, int) and not isinstance(log_id, bool):
            check(free > log_id, f"id {free} is not free: '{leaf.name}' already uses {log_id}")


def test_parameter_lists(work: Path) -> None:
    """Creating, choosing and ordering the parameter lists of the project."""
    document, api, config_path = open_copy(work)
    before = config_path.read_text(encoding="utf-8")
    check("//" in before, "the fixture configuration has no comments to preserve")

    listed = api.lists({})
    equal(Path(listed["directory"]).name, "parameter_lists", "the parameter list folder")
    check(all(item["inFolder"] for item in listed["lists"]),
          "every list of the project should live in the one folder")
    selected = [item["file"] for item in listed["lists"] if item["selected"]]
    check(len(selected) >= 1, "no list takes part in the build")

    # a name is sanitised into something that cannot leave the folder
    answer = api.new_list({"name": "../../gimbal telemetry!"})
    check(answer["ok"], f"the list was not created: {answer}")
    created = Path(answer["path"])
    equal(created.name, "gimbal_telemetry.xml", "the file name made from the typed name")
    equal(created.parent, document.list_directory(), "the new list is in the folder")
    check(created.is_file(), "the new list was not written to disk")
    check(created in document.config.inputs.model_files,
          "the new list did not join the build")

    # a name that is already taken is refused rather than overwriting a list
    check(not api.new_list({"name": "gimbal_telemetry"})["ok"],
          "creating a list twice overwrote the first one")

    # The order chosen here is the order the generator merges in, so the check
    # below needs two lists that actually hold parameters - reversed, so that
    # "the order was kept" cannot pass by accident.
    directory = document.list_directory()
    filled = [path for path in sorted(directory.glob("*.xml")) if _parameter_names(path)]
    check(len(filled) >= 2,
          "the project needs two non-empty parameter lists to test the order with")
    chosen = list(reversed(filled[:2]))
    answer = api.select_lists({"paths": [str(path) for path in chosen]})
    check(answer["ok"], f"the choice was not saved: {answer}")

    after = config_path.read_text(encoding="utf-8")
    check("//" in after, "rewriting the configuration deleted its comments")
    equal([line for line in before.splitlines() if line.strip().startswith("//")],
          [line for line in after.splitlines() if line.strip().startswith("//")],
          "the comments of the configuration file")

    reloaded = Config.load(config_path)
    equal([path.name for path in reloaded.inputs.model_files],
          [path.name for path in chosen],
          "what run_generate.py reads after the editor saved the choice")

    # ... and the indices of the generated code really follow that order: the
    # values of the first list come first, then the values of the second.
    expected = [name for path in chosen for name in _parameter_names(path)]
    document = Document(reloaded)
    document.load(reloaded.inputs.model_files[0])
    equal([leaf.name for leaf in document.merged_model().flatten()], expected,
          "the order of the values in the merged model")


def test_list_selection_edge_cases(work: Path) -> None:
    """The ways a hand-edited configuration can be odd, and what happens then."""
    document, api, config_path = open_copy(work)
    directory = document.list_directory()
    first = document.config.inputs.model_files[0]

    # The same list twice would be merged twice and every name in it would
    # collide with itself; the first mention wins so the chosen order survives.
    answer = api.select_lists({"paths": [str(first), str(directory / "power.xml"),
                                         str(first)]})
    check(answer["ok"], f"the choice was not saved: {answer}")
    equal([Path(p).name for p in answer["paths"]], [first.name, "power.xml"],
          "the duplicate should have been dropped")
    equal([path.name for path in Config.load(config_path).inputs.model_files],
          [first.name, "power.xml"], "what the configuration file says")

    # A configuration that already names a list twice still gives the dialog one
    # row per file - two rows with the same path would bind to the same object.
    document.config.inputs.model_files = [first, first]
    paths = [item["path"] for item in document.known_lists()]
    equal(len(paths), len(set(paths)), "the dialog was given a duplicated row")

    # Generating with a list that is not on disk is reported, not raised: the
    # editor shows that state as "(new)", so it is reachable by just clicking.
    document.config.inputs.model_files = [directory / "does_not_exist.xml"]
    result = api.generate({})
    check(not result["success"], "generating from a missing list reported success")
    check(bool(result.get("message")), "the failure came back with nothing to read")


def test_template_of_another_list(work: Path) -> None:
    """A type another parameter list owns is shown, but cannot be deleted here."""
    document, api, _config = open_copy(work)
    # Put a type into another list that takes part in the build - a list that
    # is not in the build contributes nothing, templates included.
    others = [path for path in document.config.inputs.model_files
              if path != document.path]
    check(bool(others), "the project needs a second list in the build for this case")
    other = others[0]
    document.load(other)
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "NavShape"})
    document.add_parameter("NavShape", "primitive")
    check(api.save_template({"path": "NavShape", "name": "sNavShape"})["ok"],
          "the type was not saved")
    document.save()

    # now edit the first list: the type is offered, because the library is the
    # project's, not the file's
    document.load(document.config.inputs.model_files[0])
    check("sNavShape" in [item["name"] for item in api.state({})["templates"]],
          "a type defined in another list is not offered here")

    # ... but deleting it from here would silently do nothing, so it says so
    answer = api.delete_template({"name": "sNavShape"})
    check(not answer["ok"], "deleting another list's type reported success")
    check(other.stem in answer["message"],
          f"the message should name the list that owns it: {answer['message']}")
    check("sNavShape" in [item["name"] for item in api.state({})["templates"]],
          "the type disappeared even though the answer said it had not")


def _parameter_names(path: Path) -> List[str]:
    """The values one parameter list contributes, in order."""
    from common.pl_codegen.errors import DiagnosticCollector
    from common.pl_codegen.xml_model.xml_reader import read_xml

    return [leaf.name for leaf in read_xml(path, DiagnosticCollector()).flatten()]


def test_layout_warning(work: Path) -> None:
    """Generating must say when it moved a value a board may already store.

    The offset of a reset-proof value is positional, so inserting, disabling,
    moving or widening a parameter shifts everything after it - and none of that
    shows up in the generated code.  This is the check that it never happens
    quietly.

    The case builds its own parameters rather than using whatever the project
    holds today.  Every step here has to *generate*, and a project someone is
    halfway through editing may legitimately not - a duplicate name while two
    lists are being merged, say.  Depending on that would turn "your draft has
    an error" into "the memory layout warning is broken", which is a different
    and much more alarming thing to read.
    """
    document, api, _config = open_copy(work, empty=True)

    for name in ("Alpha", "Beta", "Gamma"):
        path = document.add_parameter("", "primitive")
        document.update(path, {"name": name, "gs_name": name})
    document.save()

    # the copy carries the project's last build; drop it so the first generate
    # here really is a first build
    previous = document.config.output.xml_file
    if previous.is_file():
        previous.unlink()

    first = api.generate({})
    check(first["success"], f"the first build failed: {first.get('message')}")
    check(first["drift"]["firstRun"], "the very first build has nothing to compare with")

    # generating again without touching anything must be silent
    again = api.generate({})
    check(not again["drift"]["breaksStoredData"], "an unchanged model reported a move")
    equal(again["drift"]["moved"], [], "an unchanged model moved something")

    # ... and moving a parameter to the front must not be
    names = [node.name for node in document.model.parameters]
    check(len(names) >= 2, "the project needs two parameters for this case")
    document.move(names[-1], -(len(names) - 1))
    moved = api.generate({})
    check(moved["success"], "generating after the move failed")
    drift = moved["drift"]
    check(drift["breaksStoredData"],
          "moving a parameter to the front did not warn about the memory layout")
    check(bool(drift["moved"]), "the warning named no parameter")
    check("MOVED" in drift["summary"], f"the summary is not loud enough: {drift['summary']}")
    for entry in drift["moved"]:
        check(entry["old"] != entry["new"],
              f"'{entry['parameter']}' is listed as moved but did not move")

    # Appending to the END of the LAST list in the build changes nothing that
    # already exists - and that is the whole point of the advice the warning
    # gives, so it has to actually hold.
    api.open_file({"path": str(document.config.inputs.model_files[-1])})
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "AppendedAtTheEnd"})
    appended = api.generate({})
    check(appended["success"], "generating after the append failed")
    equal(appended["drift"]["moved"], [],
          "appending at the end of the last list moved something that existed")
    check("AppendedAtTheEnd" in appended["drift"]["added"],
          "the appended parameter was not reported as added")


def test_only_the_editor(work: Path) -> None:
    """Phase 2 supports exactly one input, and it is the editor.

    A phase that quietly grew a second way in would be a phase 3, and phase 3 is
    a later decision - so this fails rather than letting it happen by accident.
    """
    check(not list(PROJECT_DIR.glob("**/*.xlsx")), "phase 2 ships a workbook")
    offenders = []
    for path in TOOLS_DIR.rglob("*.py"):
        if "__pycache__" in path.parts or path.parts[-2:-1] == ("tests",):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "openpyxl" in text:
            offenders.append(str(path.relative_to(TOOLS_DIR)))
    equal(offenders, [], "modules that still import openpyxl")


def test_every_pane_redraws(_project: Path) -> None:
    """A mutation must never redraw only half the screen.

    The editor keeps no state of its own: the model is the truth and every pane
    is drawn from it.  ``refresh(true)`` is the one exception - it leaves the
    form on the right alone so that typing is not interrupted mid-word - and it
    is safe ONLY where the action cannot have changed the selected node.

    Ticking Enabled in the tree broke exactly that rule once: the model and the
    tree moved, the form did not, and the two halves of the screen then
    disagreed about the same parameter with nothing to say which was right.

    So: any method that calls ``api.update`` - the one action that changes a
    node's fields - must redraw the form as well.  A DOM test could catch this
    too, but it would need a browser; this reads the source and needs nothing.
    """
    # the real source, not the temporary fixture copy: this reads the code the
    # project ships, and the fixture has no web/ folder
    app_js = (TOOLS_DIR / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")

    # Comments are stripped first, or the rule catches the comment that explains
    # the rule - "NOT refresh(true), because ..." reads as a call to it.
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)

    # split into methods: "  name(args) {" or "  async name(args) {" at one indent
    methods = re.split(r"\n  (?=(?:async )?[A-Za-z_]\w*\s*\()", code)
    offenders = []
    for body in methods:
        name = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if not name:
            continue
        if "api.update(" not in body:
            continue
        if re.search(r"refresh\(\s*true\s*\)", body):
            offenders.append(name.group(1))

    equal(offenders, [],
          "methods that change a node but keep the stale form (use refresh(), "
          "not refresh(true))")

    # and the checkbox in the tree has to go through that same update action,
    # rather than poking the model or the DOM behind its back
    bodies = {}
    for body in methods:
        found = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if found:
            bodies.setdefault(found.group(1), body)

    check("setEnabled" in bodies, "app.js still has a setEnabled method")
    check("api.update(" in bodies["setEnabled"],
          "the tree's Enabled tick goes through the normal update action")


def test_one_name_for_one_thing(_project: Path) -> None:
    """A concept must be called the same thing everywhere.

    Renaming something across a project is the change most likely to be left
    half done: the compiler catches the identifiers, the tests catch the keys,
    and nothing at all catches a heading in a generated comment, a label in a
    dialog, or a sentence in a docstring.  Every one of those was missed once.

    So the banned words are listed here.  If a rename is ever reversed, or a new
    name is chosen, this list is the one place that decides it - and the suite
    says exactly which files still disagree.
    """
    # word that must not appear -> what it is called now, and why
    BANNED = {
        "eParameterListDescriptorGroup": "eParameterType",
        "sParameterListDescriptorTag": "sParameterTag",
        "ePARAMETER_GROUP_": "ePARAMETER_TYPE_",
        "DEFAULT_GROUPS": "DEFAULT_PARAMETER_TYPES",
        "GroupRule": "ParameterTypeRule",
        "COLUMN_GROUPS": "COLUMN_TYPES",
        "data_type_name": "value_type_name",
        "PARAMETER_LIST_OFFSET_": "PARAMETER_LIST_TAG_<TAG>_<NAME>_OFFSET",
        "PARAMETER_LIST_SIZE_": "PARAMETER_LIST_TAG_<TAG>_SIZE",
        "TagLogId": "LogId (it is not a tag)",
        "fParameterList_GetLogIdSize": "removed with the LogId offset area",
        "ArraySize;": "removed: one descriptor is one value",
        "DataTypeRule": "ValueTypeRule",
        # the heading of the generated overview table
        '"DataType"': '"ValueType"',
    }
    # the old smart-data macro spelling, before the file_Function_ convention
    for old in ("fSmartDataRead_", "fSmartDataWrite_", "fSmartDataSetMinimum_",
                "fSmartDataGetMaximum_", "fSmartDataUserRead_"):
        BANNED[old] = old.replace("fSmartData", "fSmartData_")

    # The documentation is searched too.  It is the place a stale name survives
    # longest, because nothing compiles it and nobody greps it - and a manual
    # that calls a button by a name it no longer has is worse than no manual.
    searched = []
    for pattern in ("*.py", "*.js", "*.c", "*.h", "*.json", "*.html"):
        searched += [p for p in PROJECT_DIR.rglob(pattern)
                     if "__pycache__" not in p.parts and ".dist" not in p.parts]

    offences = []
    for path in searched:
        # this file names the banned words on purpose
        if path.name == "run_editor_test.py":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        # A manual that explains a rename has to name the old thing; those
        # sections are marked, and only those are exempt.
        text = re.sub(r"<!-- HISTORY-BLOCK.*?/HISTORY-BLOCK -->", "", text, flags=re.S)
        for banned, instead in BANNED.items():
            if banned in text:
                offences.append(f"{path.relative_to(PROJECT_DIR)}: '{banned}' "
                                f"(now: {instead})")

    equal(sorted(offences), [], "old names still in the source")

    # The manuals name the controls of the editor.  A label that was renamed in
    # index.html and not in the manual sends the reader looking for something
    # that is not on screen, so the two are checked against each other.
    labels = (TOOLS_DIR / "pl_gui" / "web" / "index.html").read_text(encoding="utf-8")
    grid = (TOOLS_DIR / "pl_gui" / "web" / "grid.js").read_text(encoding="utf-8")
    for shown, gone in (("Value type", "Data type"),
                        ("Tag ParamMode", "ParamMode column"),
                        ("Manage…", "Lists ▾")):
        if shown in labels or shown in grid:
            continue
        raise Failure(f"the editor no longer shows '{shown}'; the manuals still "
                      f"describe it, so update them and this list together "
                      f"(it replaced '{gone}')")


def test_changing_the_value_type(work: Path) -> None:
    """Changing the type must leave nothing the new type cannot hold.

    The minimum, the maximum, the resolution and the default value only mean
    anything in terms of the value type, so a type change has to bring them
    along.  Left behind they are not merely untidy - turning a float32_t into a
    bool_t used to keep its 0..120 range, and the boolean form has no minimum
    or maximum box, so the warning that followed could be read and could not be
    acted on from the editor at all.

    Every pair of types is walked here, in both directions, and the model has
    to come out clean each time.
    """
    from common.pl_codegen.model.types import VALUE_TYPES

    document, api, _config = open_copy(work, empty=True)
    document.add_parameter("", "primitive")
    document.update("NewParameter", {
        "name": "Probe", "param_type": "MONITORING",
        "tags": {"SystemName": "SYS_NAV", "ParamMode": "PARAM_MODE_USER",
                 "ResetProof": False, "Loggable": False, "LogEncryption": False}})

    names = list(VALUE_TYPES)
    for start in names:
        for target in names:
            # a plausible starting point for the first type
            document.update("Probe", {"value_type_name": start})
            begin = document.find("Probe")
            if start == "bool_t":
                document.update("Probe", {"default_value": True})
            else:
                document.update("Probe", {"minimum": 0, "maximum": 100,
                                          "default_value": 7, "resolution": 1})

            document.update("Probe", {"value_type_name": target})

            # only what this test is about: an empty description or GS name is
            # a house-style notice and has nothing to do with the type change
            complaints = [item for item in api.state({})["diagnostics"]
                          if str(item.get("location", {}).get("parameter", "")) == "Probe"
                          and item["code"][:3] in ("RNG", "TYP", "VAL")]
            equal([f"{c['code']}: {c['message']}" for c in complaints], [],
                  f"{start} -> {target} left the parameter in a state the editor "
                  f"cannot repair")

            node = document.find("Probe")
            if target == "bool_t":
                equal(isinstance(node.default_value, bool), True,
                      f"{start} -> bool_t left a non-boolean default")
            else:
                check(not isinstance(node.default_value, bool),
                      f"{start} -> {target} left a boolean default on a number")


CASES: List[Tuple[str, Callable[[Path], None]]] = [
    ("structure types (the template library)", test_structure_types),
    ("arrays of structures", test_structure_arrays),
    ("the parameter lists of the project", test_parameter_lists),
    ("odd list selections", test_list_selection_edge_cases),
    ("a type another list owns", test_template_of_another_list),
    ("the memory layout warning", test_layout_warning),
    ("the editor is the only input", test_only_the_editor),
    ("every pane redraws after a change", test_every_pane_redraws),
    ("one name for one thing", test_one_name_for_one_thing),
    ("changing the value type", test_changing_the_value_type),
]


def main() -> int:
    failures = 0
    width = max(len(name) for name, _case in CASES)
    for name, case in CASES:
        with tempfile.TemporaryDirectory(prefix="pl_editor_test_") as raw:
            try:
                case(Path(raw))
            except Failure as error:
                print(f"  [{paint('FAIL', BOLD + BRIGHT_RED)}] "
                      f"{name.ljust(width)}  {paint(str(error), BRIGHT_RED)}")
                failures += 1
                continue
            except Exception as error:               # noqa: BLE001 - report and go on
                print(f"  [ERROR] {name.ljust(width)}  {type(error).__name__}: {error}")
                failures += 1
                continue
        print(f"  [{paint('PASS', GREEN)}] {name}")

    print()
    if failures:
        print(paint(f"{failures} of {len(CASES)} editor case(s) FAILED.",
                    BOLD + BRIGHT_RED))
        return 1
    print(paint(f"All {len(CASES)} editor cases passed.", GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""End-to-end test: generate the code and compile it with a real C/C++ compiler.

The test
  1. runs the generator on ``parameter_list.xml`` into a temporary folder,
  2. compiles the generated files together with ``smart_data.c`` as **C99** and
     compiles the generated headers as **C++**,
  3. links and runs a small program that calls ``fParameterList_Init()``,
     walks the descriptor table and exercises the usage example.

Run it with::

    python tests/run_compile_test.py

It needs ``gcc`` and ``g++`` on the PATH; on Windows a MinGW or WSL toolchain
works.  The test never touches the files under ``cg_parameter_list`` of the
project: everything is generated into a temporary folder.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from common.pl_codegen.cli import main as generator_main  # noqa: E402
from common.pl_codegen.logging_utils import (BOLD, BRIGHT_RED, CYAN,  # noqa: E402
                                            GREEN, YELLOW, colour_supported, paint)
import common.pl_codegen.logging_utils as _logging_utils  # noqa: E402

_logging_utils._colour_enabled = colour_supported()

C_COMPILER = "gcc"
CXX_COMPILER = "g++"

def _run(command: List[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def have_compiler(name: str) -> bool:
    return shutil.which(name) is not None


def write_config(work_dir: Path, inputs: dict, name: str = "codegen_config.json") -> Path:
    """Write a configuration that generates into *work_dir*."""
    config = {
        "inputs": inputs,
        "output": {
            "code_directory": str(work_dir / "generated"),
            "xml_file": str(work_dir / "model.xml"),
            "file_prefix": "cg_",
            "base_name": "parameter_list",
        },
        "style": {"snippet_file": str(PROJECT_DIR / "c.json"), "company": "FAS",
                  "indent": "    "},
        "codegen": {"emit_description": True, "emit_unit": True,
                    "emit_generation_info": True, "emit_timestamp": False},
        "validation": {"treat_warnings_as_errors": False},
    }
    path = work_dir / name
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return path


#: The three ways a project can feed the generator; all three must compile.
def input_variants() -> List[dict]:
    # The project's own lists, taken from its configuration rather than from
    # hard coded paths: the editor is free to add lists and to reorder them, and
    # the test has to keep testing whatever the project actually builds.
    project = [path for path in _project_lists() if path.is_file()]

    # The usage example is written against the demo parameters (Airspeed,
    # Position.Home.Lat, Position.Samples), so it only compiles against the
    # list that actually holds them.  Picking "the first list in the
    # configuration" instead would make this test fail the moment somebody
    # reorders the build in the editor - which is a supported thing to do, and
    # not a reason to call the tool broken.
    single = _list_holding_the_example(project)

    variants: List[dict] = []
    if single is not None:
        variants.append(
            {"label": f"one parameter list ({single.name})",
             "inputs": {"model_files": [str(single)]}})
    elif project:
        variants.append(
            {"label": f"one parameter list ({project[0].name}, without the example)",
             "inputs": {"model_files": [str(project[0])]},
             "with_example": False})
    if len(project) > 1:
        # The merged build needs the same guard as the single one.  It used to
        # compile the example unconditionally, on the assumption that merging
        # every list can only ever ADD parameters - true of the set, but not of
        # the configuration: the moment somebody unticks the demo list in the
        # editor, the merged model no longer holds Airspeed or Position and the
        # suite failed with a wall of "undeclared identifier" that said nothing
        # about the real cause.  Unticking a list is a supported thing to do.
        merged_names = _names_in(project)
        variants.append(
            {"label": f"{len(project)} parameter lists, merged",
             "inputs": {"model_files": [str(path) for path in project]},
             "with_example": all(needed in merged_names for needed in _EXAMPLE_NEEDS)})

    # A fixture the editor could have written, kept small on purpose: it is the
    # only place where an array of structures - and an array *inside* one - is
    # compiled and run, so the generated strides are checked by the compiler
    # rather than by eye.
    variants.append(
        {"label": "an array of structures",
         "fixture": _STRUCT_ARRAY_XML,
         "with_example": False,
         "extra_checks": _STRUCT_ARRAY_CHECKS})

    return variants


#: The values example/parameter_list_usage_example.c reaches for by name.  A
#: list that has all of them can compile the example; any other cannot.
_EXAMPLE_NEEDS = ("Airspeed", "Position")


def _names_in(paths: List[Path]) -> set:
    """Every top level parameter name across *paths*, skipping unreadable ones."""
    from common.pl_codegen.errors import DiagnosticCollector
    from common.pl_codegen.xml_model.xml_reader import read_xml

    names = set()
    for path in paths:
        try:
            model = read_xml(path, DiagnosticCollector())
        except Exception:                 # a list that will not even parse
            continue
        names.update(parameter.name for parameter in model.parameters)
    return names


def _list_holding_the_example(candidates: List[Path]) -> Optional[Path]:
    """The project list the usage example fits, or ``None`` if no list does."""
    for path in candidates:
        if all(needed in _names_in([path]) for needed in _EXAMPLE_NEEDS):
            return path
    return None


def _project_lists() -> List[Path]:
    """The parameter lists the project's own configuration builds, in order."""
    from common.pl_codegen.config import Config

    try:
        return list(Config.load(TOOLS_DIR / "codegen_config.json").inputs.model_files)
    except Exception as error:                       # a broken config is its own test
        print(f"  (could not read the project configuration: {error})")
        return []


#: A parameter list with a struct array whose elements hold an array field.
_STRUCT_ARRAY_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="2.0" generator="parameter_list_code_generator"
                    generatorVersion="2.0.0">
  <SourceFiles />
  <Defines>
    <DefineGroup name="TYPE"><Value value="MONITORING" /></DefineGroup>
    <DefineGroup name="PARAM MODES"><Value value="PARAM_MODE_USER" /></DefineGroup>
    <DefineGroup name="SYSTEM NAMES"><Value value="SYS_NAV" /></DefineGroup>
    <DefineGroup name="VALUE TYPES">
      <Value value="float32_t" /><Value value="int16_t" /><Value value="uint32_t" />
    </DefineGroup>
  </Defines>
  <Parameters>
    <Parameter name="Car" kind="struct" enable="true" gsName="Car"
               type="MONITORING" arraySize="1" logId="600" description="One vehicle.">
      <Source /><Limits />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Fields>
        <Parameter name="Wheels" kind="struct" enable="true" gsName="Wheels"
                   arraySize="2" description="One entry per wheel.">
          <Source /><Limits /><Tags />
          <Fields>
            <Parameter name="Speed" kind="primitive" enable="true" gsName="Speed"
                       valueType="float32_t" arraySize="1" unit="m/s">
              <Source />
              <Limits default="0" minimum="0" maximum="120" resolution="0.001" />
              <Tags />
            </Parameter>
            <Parameter name="Samples" kind="primitive" enable="true" gsName="Samples"
                       valueType="int16_t" arraySize="4">
              <Source />
              <Limits default="0" minimum="0" maximum="0" resolution="1" />
              <Tags />
            </Parameter>
          </Fields>
        </Parameter>
        <Parameter name="Vin" kind="primitive" enable="true" gsName="Vin"
                   valueType="uint32_t" arraySize="1">
          <Source />
          <Limits default="7" minimum="0" maximum="0" resolution="1" />
          <Tags />
        </Parameter>
      </Fields>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

#: What the struct array must produce, checked by the compiler and at run time.
_STRUCT_ARRAY_CHECKS = """
    /* The array sizes are declarations, so every element shares one macro. */
    if (CAR_WHEELS_ARRAY_SIZE != 2U || CAR_WHEELS_SAMPLES_ARRAY_SIZE != 4U) {
        printf("array size macros are wrong\\n");
        return 1;
    }
    /* Two elements of one struct array are two separate values. */
    if ((void *)&Cg_SmartData_Car.Wheels[0].Speed
        == (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the elements of the struct array alias each other\\n");
        return 1;
    }
    /* Each element has its own row, pointing inside that element. */
    if (ParameterList[CAR_WHEELS_1_SPEED].pSmartData
        != (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the descriptor does not point at the element\\n");
        return 1;
    }
    /* One row per VALUE: Samples[4] is four rows, not one row of four, and the
       four of them are consecutive indices starting at the element-0 macro. */
    if (CAR_WHEELS_0_SAMPLES_1 != CAR_WHEELS_0_SAMPLES_0 + 1
        || CAR_WHEELS_0_SAMPLES_3 != CAR_WHEELS_0_SAMPLES_0 + 3
        || CAR_WHEELS_1_SPEED != CAR_WHEELS_0_SAMPLES_3 + 1) {
        printf("the elements of an array are not consecutive rows\\n");
        return 1;
    }
    /* Each of those rows points at its own element of the one C array. */
    if (ParameterList[CAR_WHEELS_0_SAMPLES_2].pSmartData
        != (void *)&Cg_SmartData_Car.Wheels[0].Samples[2]) {
        printf("an array element row does not point at its element\\n");
        return 1;
    }
    /* A log id counts values, never bytes: Samples[4] takes four of them.
       It is a plain uint16_t field and not a tag, so there is no .Value and no
       .MemoryOffset behind it. */
    if (ParameterList[CAR_WHEELS_0_SPEED].LogId != 600U
        || ParameterList[CAR_WHEELS_0_SAMPLES_0].LogId != 601U
        || ParameterList[CAR_WHEELS_0_SAMPLES_3].LogId != 604U
        || ParameterList[CAR_WHEELS_1_SPEED].LogId != 605U
        || ParameterList[CAR_VIN].LogId != 610U) {
        printf("the log ids of the struct array are wrong\\n");
        return 1;
    }
    /* The unit lives on the smart data object, not on the descriptor. */
    if (Cg_SmartData_Car.Wheels[0].Speed._core.pUnit == NULL
        || strcmp(Cg_SmartData_Car.Wheels[0].Speed._core.pUnit, "m/s") != 0) {
        printf("the unit did not reach the smart data object\\n");
        return 1;
    }
    if (Cg_SmartData_Car.Vin._core.pUnit == NULL
        || Cg_SmartData_Car.Vin._core.pUnit[0] != '\\0') {
        printf("a value with no unit should carry \\"\\", not rubbish\\n");
        return 1;
    }
    /* Writing one element leaves its neighbour alone. */
    {
        float32_t written = 12.5F;
        float32_t readBack = 1.0F;
        if (fSmartData_Write_(&Cg_SmartData_Car.Wheels[1].Speed, &written)
            != eSMART_DATA_OK) {
            printf("writing an element of the struct array failed\\n");
            return 1;
        }
        (void)fSmartData_Read_(&Cg_SmartData_Car.Wheels[0].Speed, &readBack);
        if (readBack != 0.0F) {
            printf("writing one element disturbed its neighbour\\n");
            return 1;
        }
        (void)fSmartData_Read_(&Cg_SmartData_Car.Wheels[1].Speed, &readBack);
        if (readBack != 12.5F) {
            printf("the element did not keep the value that was written\\n");
            return 1;
        }
    }

    /* A write clears every reader's flag, because nobody has seen the new
       value yet; a write REFUSED by the range check leaves them alone, because
       nothing changed. */
    {
        float32_t value = 1.0F;
        eSmartDataStatus readStatus = eSMART_DATA_OK;
        const uint8_t reader = 0U;

        (void)fSmartData_Write_(&Cg_SmartData_Car.Wheels[0].Speed, &value);
        fSmartData_UserRead_(&Cg_SmartData_Car.Wheels[0].Speed, reader, &value, readStatus);
        if (readStatus != eSMART_DATA_OK) {
            printf("the first user read failed\\n");
            return 1;
        }
        if (fSmartData_HasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != TRUE) {
            printf("reading did not mark the reader as up to date\\n");
            return 1;
        }

        value = 2.0F;
        (void)fSmartData_Write_(&Cg_SmartData_Car.Wheels[0].Speed, &value);
        if (fSmartData_HasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != FALSE) {
            printf("a write did not clear the reader flags\\n");
            return 1;
        }

        /* ... and a write the range check refuses changes nothing, so the
           readers stay as they were. */
        fSmartData_UserRead_(&Cg_SmartData_Car.Wheels[0].Speed, reader, &value, readStatus);
        value = -1.0F;   /* below the minimum of this parameter */
        if (fSmartData_Write_(&Cg_SmartData_Car.Wheels[0].Speed, &value)
            == eSMART_DATA_OK) {
            printf("an out of range write was accepted\\n");
            return 1;
        }
        if (fSmartData_HasUserReadOnce_(&Cg_SmartData_Car.Wheels[0].Speed, reader) != TRUE) {
            printf("a refused write cleared the reader flags\\n");
            return 1;
        }
    }

"""


# smart_data.c includes the project's chrono.h. When the firmware's real
# chrono module is not reachable from here, this stub stands in for it; the
# stub folder is searched LAST, so a real chrono.h always wins.
_CHRONO_STUB_H = """
#ifndef CHRONO_H
#define CHRONO_H
#include <stdint.h>
static uint64_t fChrono_GetContinuousTickUs(void) { return 0U; }
#endif
"""

_LOG_STUB_C = """
#include "parameter_list_usage_example.h"

void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset) {
    (void)logId; (void)pValue; (void)memoryOffset;
}

uint8_t fExample_UseHome(const sCgStruct_Position_Home *pHome) {
    return (pHome == NULL) ? 1U : 0U;
}
"""


def compile_c(work_dir: Path, includes: List[str], with_example: bool = True) -> bool:
    """The example uses the demo parameters, so it only fits the XML model."""
    (work_dir / "log_stub.c").write_text(_LOG_STUB_C, encoding="utf-8")
    sources = [
        PROJECT_DIR / "smart_data" / "smart_data.c",
        work_dir / "generated" / "cg_smart_data.c",
        work_dir / "generated" / "cg_parameter_list.c",
    ]
    if with_example:
        sources += [PROJECT_DIR / "example" / "parameter_list_usage_example.c",
                    work_dir / "log_stub.c"]
    sources.append(work_dir / "main.c")
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Wpedantic",
               *includes, *[str(path) for path in sources],
               "-o", str(work_dir / "parameter_list_test")]
    result = _run(command)
    if result.returncode != 0:
        print(paint("C compilation FAILED:", BOLD + BRIGHT_RED) + "\n" + result.stderr)
        return False
    if result.stderr.strip():
        print("C compiler warnings:\n" + result.stderr)
    return True


def compile_cxx(work_dir: Path, includes: List[str]) -> bool:
    """The generated headers must be usable from C++ as well."""
    source = work_dir / "cxx_include_test.cpp"
    source.write_text(
        '#include "cg_parameter_list.h"\n'
        '#include "cg_smart_data.h"\n'
        '#include "cg_parameter_list_defines.h"\n'
        '#include "cg_parameter_list_table.h"\n'
        '#include "cg_parameter_list_types.h"\n'
        "int main() { return ParameterList[0].pSmartData == 0; }\n",
        encoding="utf-8")
    command = [CXX_COMPILER, "-std=c++11", "-Wall", "-Wextra", "-c",
               *includes, str(source), "-o", str(work_dir / "cxx_include_test.o")]
    result = _run(command)
    if result.returncode != 0:
        print(paint("C++ compilation FAILED:", BOLD + BRIGHT_RED) + "\n" + result.stderr)
        return False
    return True


_MAIN_HEAD = """
#include <stdio.h>
#include <string.h>
#include "cg_parameter_list.h"
#include "cg_smart_data.h"
#include "cg_parameter_list_table.h"
"""

_MAIN_HEAD_WITH_EXAMPLE = _MAIN_HEAD + '#include "parameter_list_usage_example.h"\n'

_MAIN_BODY = """
int main(void) {
    uint16_t index = 0U;
    uint8_t result = fParameterList_Init();
    if (result != 0U) {
        printf("fParameterList_Init failed with %u\\n", (unsigned)result);
        return 1;
    }
    if (fParameterList_GetQuantity() != PARAMETER_LIST_QTY) {
        printf("wrong quantity\\n");
        return 1;
    }
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL || pDescriptor->pName == NULL) {
            printf("descriptor %u is broken\\n", (unsigned)index);
            return 1;
        }
        if (fParameterList_GetByName(pDescriptor->pName) != pDescriptor) {
            printf("lookup by name failed for %s\\n", pDescriptor->pName);
            return 1;
        }
        if (pDescriptor->pSmartData == NULL) {
            printf("no smart data for %s\\n", pDescriptor->pName);
            return 1;
        }
    }
    if (fParameterList_GetByIndex(PARAMETER_LIST_QTY) != NULL) {
        printf("out of range index was accepted\\n");
        return 1;
    }
    EXAMPLE_CALLS
    EXTRA_CHECKS
    printf("OK: %u parameters initialised and verified" EXAMPLE_NOTE "\\n",
           (unsigned)PARAMETER_LIST_QTY);
    return 0;
}
"""

_EXAMPLE_CALLS = """
    /* The usage example must work as well. */
    fExample_DirectAccess();
    if (fExample_CheckedAccess() != eSMART_DATA_OK) {
        printf("fExample_CheckedAccess failed\\n");
        return 1;
    }
    if (fExample_DescriptorAccess() != 0U) {
        printf("fExample_DescriptorAccess failed\\n");
        return 1;
    }
    if (fExample_StructAccess() != 0U) {
        printf("fExample_StructAccess failed\\n");
        return 1;
    }
    fExample_ArrayAccess();
    if (fExample_ReadIfNew() != TRUE || fExample_ReadIfNew() != FALSE) {
        printf("fExample_ReadIfNew failed\\n");
        return 1;
    }
"""


def main_source(with_example: bool, extra_checks: str = "") -> str:
    head = _MAIN_HEAD_WITH_EXAMPLE if with_example else _MAIN_HEAD
    calls = _EXAMPLE_CALLS if with_example else ""
    note = '", usage example runs"' if with_example else '""'
    return (head + f"#define EXAMPLE_NOTE {note}\n"
            + _MAIN_BODY.replace("    EXAMPLE_CALLS", calls)
                        .replace("    EXTRA_CHECKS", extra_checks))


def main() -> int:
    for compiler in (C_COMPILER, CXX_COMPILER):
        if not have_compiler(compiler):
            print(paint(f"SKIPPED: '{compiler}' was not found on the PATH.", YELLOW))
            return 0

    variants = input_variants()
    print(f"Checking {len(variants)} input variant(s).\n")

    for number, variant in enumerate(variants, start=1):
        label = variant["label"]
        with_example = variant.get("with_example", True)
        print(paint(f"=== {number}/{len(variants)}  {label} ===", CYAN))
        if not check_one(variant, with_example):
            return 1
        print()

    print(paint("All checks passed.", GREEN))
    return 0


def check_one(variant: dict, with_example: bool) -> bool:
    """Generate from *variant*, compile the result and run it."""
    with tempfile.TemporaryDirectory(prefix="pl_codegen_test_") as raw_dir:
        work_dir = Path(raw_dir)

        # A variant either points at a file of the project or brings its own
        # model along; a fixture keeps the test independent of what the user
        # happens to have in the editor.
        inputs = variant.get("inputs")
        if inputs is None:
            fixture = work_dir / "fixture.xml"
            fixture.write_text(variant["fixture"], encoding="utf-8")
            inputs = {"model_files": [str(fixture)]}

        print("  1/4 generating the code ...")
        config_path = write_config(work_dir, inputs)
        exit_code = generator_main(["--config", str(config_path), "--quiet"])
        if exit_code != 0:
            # Two very different things end up here and they need different
            # answers from the reader, so the message says which one it is: the
            # tool may be broken, or this project's own parameter lists may
            # simply not be valid right now.  Only the second is fixed in the
            # editor rather than in the code.
            if variant.get("inputs") is not None:
                print(f"  FAILED: the generator refused this project's parameter "
                      f"list(s) (exit {exit_code}).\n"
                      f"          The diagnostics above are about the MODEL, not "
                      f"about the tool - fix them in the editor and run again.")
            else:
                print(f"  FAILED: the generator returned {exit_code} on the "
                      f"test's own fixture, so the tool is at fault.")
            return False

        (work_dir / "main.c").write_text(
            main_source(with_example, variant.get("extra_checks", "")),
            encoding="utf-8")
        stub_dir = work_dir / "stubs"
        stub_dir.mkdir(exist_ok=True)
        (stub_dir / "chrono.h").write_text(_CHRONO_STUB_H, encoding="utf-8")
        includes = [f"-I{PROJECT_DIR}",
                    f"-I{PROJECT_DIR / 'example'}",
                    f"-I{PROJECT_DIR / 'smart_data'}",
                    f"-I{PROJECT_DIR / 'parameter_descriptor'}",
                    f"-I{work_dir / 'generated'}",
                    f"-I{stub_dir}"]

        print("  2/4 compiling as C99 ...")
        if not compile_c(work_dir, includes, with_example):
            return False

        print("  3/4 compiling the headers as C++ ...")
        if not compile_cxx(work_dir, includes):
            return False

        print("  4/4 running the generated parameter list ...")
        result = _run([str(work_dir / "parameter_list_test")])
        print("        " + result.stdout.strip())
        if result.returncode != 0:
            print(paint("  FAILED: the test program returned a non-zero exit code.",
                        BOLD + BRIGHT_RED))
            return False
    return True


if __name__ == "__main__":
    raise SystemExit(main())

/* ==========================================================================
   app.js - wires the toolbar, the tree, the editor and the problems panel
   together.  This is the only file that knows about all of them.
   ========================================================================== */

/* The picker's value for "every list": '*' and '?' are illegal in a Windows
   path and in a POSIX file name here, so this can never collide with a real
   one.  A NUL byte would have been shorter and does not survive being written
   into an HTML attribute - the parser turns it into U+FFFD, and the comparison
   then never matches. */
const ALL_LISTS = "*?all-lists?*";

const app = {
  state: null,
  selected: "",
  allLists: false,

  async start() {
    treeView.init(document.getElementById("tree"), (path, keepEditor) => {
      this.selected = path;
      this.paint(keepEditor);
    }, (path, enabled) => this.setEnabled(path, enabled));
    /* A grid row opens the same editor the tree does: one place to edit, so
       one place for the rules to live. */
    gridView.init(document.getElementById("grid"), (path) => {
      this.selected = path;
      this.paint();
    });
    /* Typing in a filter box only changes what is SHOWN, so the model is not
       touched and only the grid is redrawn. */
    gridView.onFilter = () => gridView.render(
      this.state.tree, this.selected, this.problemPaths());
    editorView.init(
      document.getElementById("editor"),
      document.getElementById("editor-title"),
      document.getElementById("editor-path"),
      (changes) => this.applyChanges(changes));

    this.bindToolbar();
    this.bindShortcuts();
    this.paintThemeLabel();
    trackTopbarHeight();
    let remembered = "tree";
    try {
      remembered = localStorage.getItem("pl-view") || "tree";
    } catch (error) { /* storage blocked: start on the tree */ }
    this.setView(remembered === "grid" ? "grid" : "tree");
    if (await this.reload()) setStatus("Ready");
  },

  /* Every action ends up here when its request throws.  A request that failed
     has to SAY so: the page redraws itself from the model after every change,
     so an action that dies silently leaves the screen showing the old model
     and the user believing the change landed.  Saving is the dangerous one - a
     file the tool cannot write used to look exactly like a successful save. */
  failed(what, error) {
    toast(`${what} failed: ${error.message}`, "bad");
    setStatus(`${what} failed`);
    return null;
  },

  /* ------------------------------------------------------------ loading */
  async refresh(keepEditor) {
    this.state = await api.state(this.allLists);
    this.paint(keepEditor);
  },

  /* refresh() that reports instead of throwing; for the places where nothing
     else is going to catch. */
  async reload(keepEditor) {
    try {
      await this.refresh(keepEditor);
      return true;
    } catch (error) {
      this.failed("Reading the model", error);
      return false;
    }
  },

  paint(keepEditor) {
    const state = this.state;

    document.getElementById("file-name").textContent = state.file || "(no file)";
    document.getElementById("file-name").classList.toggle("dirty", state.dirty);
    this.paintModules(state);

    /* The 'List' column only earns its width in the merged view. */
    const owner = gridView.columns.find((column) => column.key === "owner");
    owner.width = this.allLists ? "132px" : "0px";

    const problemPaths = this.problemPaths();
    if (this.view === "grid") {
      gridView.render(state.tree, this.selected, problemPaths);
    } else {
      treeView.render(state.tree, this.selected, problemPaths);
    }
    this.paintAddMenu();

    const node = findNode(state.tree, this.selected);
    if (!node) { this.selected = ""; editorView.clear(); }
    else if (!keepEditor) editorView.show(node, state);

    this.paintProblems(state.diagnostics);
    this.paintCounts(state);
    this.updateButtons(node);
  },

  /* The project can be split over several files, one per sub-module. The
     editor works on one of them; the others are still validated against, so a
     clash between two sub-modules shows up here and not at the end. */
  paintModules(state) {
    const picker = document.getElementById("module-picker");
    const modules = state.modules || [];
    picker.hidden = modules.length < 2;
    if (picker.hidden) return;

    /* One entry per list, plus the whole build as one tree.  Editing one list
       at a time is what you do; seeing all of them together is how you answer
       "what is actually in the generated table?", which no single list can. */
    const all = `<option value="${ALL_LISTS}"${this.allLists ? " selected" : ""}
                 >— every list, merged —</option>`;
    picker.innerHTML = all + modules.map((module) => {
      const label = escapeHtml(module.name) + (module.exists ? "" : " (new)");
      const selected = module.current && !this.allLists;
      return `<option value="${escapeHtml(module.path)}"` +
             `${selected ? " selected" : ""}>${label}</option>`;
    }).join("");
  },

  paintCounts(state) {
    const leaves = countLeaves(state.tree);
    const structs = countStructs(state.tree);
    document.getElementById("tree-count").textContent =
      `${leaves} value(s)` + (structs ? ` in ${structs} structure(s)` : "");
    const errors = state.diagnostics.filter((d) => d.severity === "error").length;
    const warnings = state.diagnostics.filter((d) => d.severity === "warning").length;
    document.getElementById("status-counts").textContent =
      `${leaves} values · ${errors} errors · ${warnings} warnings`;
  },

  paintProblems(diagnostics) {
    /* A panel with nothing in it should not hold the window open.  It collapses
       to its title bar on its own when the model is clean, and opens again the
       moment there is something to read - unless the user has taken it over by
       clicking the twisty, in which case their choice wins. */
    const pane = document.getElementById("problems-pane");
    if (!this.problemsPinned) {
      pane.classList.toggle("collapsed", diagnostics.length === 0);
    }
    this.sizeProblems();

    const badge = document.getElementById("problem-badge");
    const errors = diagnostics.filter((d) => d.severity === "error").length;
    const warnings = diagnostics.filter((d) => d.severity === "warning").length;
    badge.textContent = errors || warnings || 0;
    badge.className = "badge " + (errors ? "bad" : warnings ? "warn" : "ok");

    const list = document.getElementById("problems");
    if (!diagnostics.length) {
      list.innerHTML = `<div class="problem-empty">No problems. The model is ready to generate.</div>`;
      return;
    }
    const order = { error: 0, warning: 1, info: 2 };
    const sorted = diagnostics.slice().sort((a, b) => order[a.severity] - order[b.severity]);

    list.innerHTML = sorted.map((item) => `
      <div class="problem ${item.severity}" data-path="${escapeHtml(item.location.parameter || "")}">
        <span class="sev">${item.severity}</span>
        <span class="code">${escapeHtml(item.code)}</span>
        <span class="msg">${escapeHtml(item.message)}
          ${item.location.parameter ? `<span class="where">→ ${escapeHtml(item.location.parameter)}</span>` : ""}
          ${item.hint ? `<span class="hint">${escapeHtml(item.hint)}</span>` : ""}
        </span>
      </div>`).join("");

    for (const row of list.querySelectorAll(".problem")) {
      row.addEventListener("click", () => this.select(row.dataset.path));
    }
  },

  updateButtons(node) {
    /* The merged view is read only: an entry there can come from any of the
       files, and an edit would have to guess which one to write back to. */
    const frozen = !!this.allLists;
    for (const id of ["btn-duplicate", "btn-delete", "btn-up", "btn-down"]) {
      document.getElementById(id).disabled = !node || frozen;
    }
    /* Assigned, never only set: a button switched off by the merged view has
       to switch back on when a single list is opened again. */
    document.getElementById("btn-add-menu").disabled = frozen;
    document.getElementById("btn-save").disabled = frozen;
    document.getElementById("btn-undo").disabled = frozen || !this.state.canUndo;
    document.getElementById("btn-redo").disabled = frozen || !this.state.canRedo;
    document.getElementById("editor").classList.toggle("read-only", frozen);
  },

  /* The two "into the selected structure" entries only mean something on a
     structure.  They are greyed rather than hidden, so the menu keeps the same
     shape and the reader can see what they would need to select first. */
  paintAddMenu() {
    if (this.allLists) return;
    const node = findNode(this.state.tree, this.selected);
    const intoStruct = !node || node.kind !== "struct";
    const name = node ? node.name : "";
    const field = document.getElementById("mi-add-field");
    const sub = document.getElementById("mi-add-substruct");
    field.disabled = intoStruct;
    sub.disabled = intoStruct;
    field.textContent = intoStruct
      ? "Field of the selected structure" : `Field of '${name}'`;
    sub.textContent = intoStruct
      ? "Sub-structure of the selected structure" : `Sub-structure of '${name}'`;
  },

  /* Removing a list is two questions, asked separately: taking it out of the
     build is a change of mind and can be undone by adding it back, while
     deleting the file cannot be undone at all.  So the second one is never
     implied by the first. */
  async removeList(item) {
    const fromBuild = confirm(
      `Remove '${item.name}' from the build?

` +
      `The generated code will no longer contain its parameters, and every ` +
      `index after them will move.

The file itself is kept.`);
    if (!fromBuild) return;

    let alsoDelete = false;
    if (item.exists) {
      alsoDelete = confirm(
        `Also DELETE the file from the disk?

${item.file}

` +
        `This cannot be undone. Choose Cancel to keep the file and only take ` +
        `it out of the build.`);
    }

    try {
      const answer = await api.removeList(item.path, alsoDelete);
      if (!answer.ok) { toast(answer.message, "bad"); return; }
      closeModal();
      if (answer.wasOpen && answer.openInstead) await api.open(answer.openInstead);
      await this.reload();
      setStatus(answer.deleted
        ? `Removed '${item.name}' and deleted its file`
        : `Removed '${item.name}' from the build; the file is kept`);
    } catch (error) { this.failed("Removing the list", error); }
  },

  /* Ticking the box in the tree is an ordinary edit: it goes through the same
     update action the form does, so it lands on the undo stack and is
     validated like anything else. */
  async setEnabled(path, enabled) {
    try {
      await api.update(path, { enable: enabled });
      /* NOT refresh(true): keeping the editor would leave the form on the right
         still showing the old Enabled tick, so the two halves of the screen
         would disagree about the same parameter.  Every pane redraws from the
         model, always - that is the whole reason the model is the only state. */
      await this.refresh();
      setStatus(enabled ? "Enabled" : "Disabled (it will not be generated)");
    } catch (error) { this.failed("Changing the parameter", error); }
  },

  /* Tell the layout how tall the Problems panel is right now, so the body can
     take back the space a collapsed panel is not using.  Measured rather than
     assumed, because the panel's height is a CSS variable somebody may change. */
  sizeProblems() {
    const pane = document.getElementById("problems-pane");
    document.documentElement.style.setProperty(
      "--problems-now", `${Math.ceil(pane.getBoundingClientRect().height)}px`);
  },

  /* The theme is a per-machine preference, not part of the model, so it is
     the one thing the editor keeps in the browser rather than on disk. */
  toggleTheme() {
    const root = document.documentElement;
    const next = root.dataset.theme === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    this.paintThemeLabel();
    try {
      localStorage.setItem("pl-theme", next);
    } catch (error) {
      /* private window, or site data blocked: the theme still switches, it
         just will not be remembered. Not worth interrupting anyone over. */
    }
    setStatus(next === "dark" ? "Dark theme" : "Light theme");
  },

  paintThemeLabel() {
    document.getElementById("theme-label").textContent =
      document.documentElement.dataset.theme === "dark"
        ? "Switch to the light theme" : "Switch to the dark theme";
  },

  /* ------------------------------------------------------------- menus */
  /* A menu is a button plus a box: the box opens on click, closes on the next
     click anywhere else or on Escape, and closes after it is used.  Two of
     them, so it is worth the twenty lines rather than a library. */
  bindMenu(buttonId, menuId, actions) {
    const button = document.getElementById(buttonId);
    const menu = document.getElementById(menuId);

    const close = () => {
      menu.hidden = true;
      button.setAttribute("aria-expanded", "false");
    };
    const open = () => {
      /* only one menu at a time */
      for (const other of document.querySelectorAll(".menu")) other.hidden = true;
      menu.hidden = false;
      button.setAttribute("aria-expanded", "true");
    };

    button.addEventListener("click", (event) => {
      event.stopPropagation();
      menu.hidden ? open() : close();
    });
    menu.addEventListener("click", (event) => event.stopPropagation());

    for (const item of menu.querySelectorAll(".menu-item")) {
      item.addEventListener("click", () => {
        close();
        const run = actions[item.dataset.action];
        if (run) run();
      });
    }
    this._menuClosers.push(close);
  },

  _menuClosers: [],

  problemPaths() {
    return new Set(
      this.state.diagnostics.filter((d) => d.severity === "error")
                            .map((d) => d.location.parameter).filter(Boolean));
  },

  /* Which half of the page is showing: the tree, or the spreadsheet.  Both
     read the same state and both select into the same editor - the grid is a
     second way to LOOK at the list, never a second way to change it. */
  view: "tree",

  setView(view) {
    this.view = view;
    document.getElementById("btn-view-tree").classList.toggle("on", view === "tree");
    document.getElementById("btn-view-grid").classList.toggle("on", view === "grid");
    /* Both boxes live inside the ONE list pane, so the editor stays on screen
       in either view - which is what makes a grid row clickable AND editable. */
    document.getElementById("tree-view").hidden = view !== "tree";
    document.getElementById("grid-view").hidden = view !== "grid";
    /* the grid needs the width; the tree does not */
    document.getElementById("layout").classList.toggle("view-grid", view === "grid");
    document.getElementById("list-title").textContent =
      view === "grid" ? "Parameters — grid" : "Parameters";
    /* The filter box belongs to the tree; the grid filters per column. */
    document.getElementById("filter").hidden = view === "grid";
    /* start() sets the view before the first state has arrived, so there may
       be nothing to draw yet; the first refresh draws it. */
    if (this.state) this.paint(true);
    try {
      localStorage.setItem("pl-view", view);
    } catch (error) { /* storage blocked: the view just is not remembered */ }
  },

  /* Select a node by path and reveal it (used by the Problems panel and by
     the "edit them on <structure>" button of a field). */
  select(path) {
    if (!path) return;
    this.selected = path;
    expandTo(path);
    this.paint();
  },

  /* ------------------------------------------------------------ editing */
  async applyChanges(changes) {
    if (!this.selected) return;
    try {
      const answer = await api.update(this.selected, changes);
      if (answer.ok === false) {
        /* A refused edit redraws from the model, so the box springs back to
           the value that is really stored - and says why it did. */
        toast(answer.message || "That change was not accepted.", "bad");
        await this.refresh();
        setStatus("Not changed");
        return;
      }
      if (answer.selected) this.selected = answer.selected;
      await this.refresh();
      setStatus("Edited");
    } catch (error) { this.failed("The edit", error); }
  },

  async addNode(kind, intoStruct) {
    const parent = intoStruct ? this.selected : "";
    try {
      const answer = await api.add(parent, kind);
      this.selected = answer.selected;
      if (parent) treeView.collapsed.delete(parent);
      await this.refresh();
      setStatus(kind === "struct" ? "Structure added" : "Parameter added");
    } catch (error) { this.failed("Adding", error); }
  },

  /* --------------------------------------- the parameter lists of the project */
  /* A project is one parameter list split over several files. Which of them take
     part, and in what ORDER, decides the order of the indices in the generated
     code - so the choice is made here and written straight into
     codegen_config.json, which is the file run_generate.py reads. The editor and
     the command line then cannot disagree about what the project is. */
  async editListSelection() {
    let answer;
    try {
      answer = await api.lists();
    } catch (error) { this.failed("Reading the parameter lists", error); return; }
    /* the working copy the dialog edits; nothing is written until OK */
    let rows = answer.lists.map((item) => Object.assign({}, item));

    const render = () => {
      const chosen = rows.filter((r) => r.selected);
      const spare = rows.filter((r) => !r.selected);

      const line = (item, index, inOrder) => `
        <div class="list-row${item.selected ? " on" : ""}" data-path="${escapeHtml(item.path)}">
          <input type="checkbox" ${item.selected ? "checked" : ""} data-toggle>
          <div class="list-name">
            <b>${escapeHtml(item.name)}</b>
            <span class="hint mono">${escapeHtml(item.file)}${item.inFolder ? "" : "  (outside the folder)"}</span>
            ${item.exists ? "" : `<span class="hint">the file does not exist yet</span>`}
          </div>
          ${inOrder ? `<span class="count">#${index}</span>
            <button type="button" class="inline-btn" data-up ${index === 0 ? "disabled" : ""}>↑</button>
            <button type="button" class="inline-btn" data-down
                    ${index === chosen.length - 1 ? "disabled" : ""}>↓</button>` : ""}
          <button type="button" class="inline-btn danger" data-remove
                  title="Remove this list from the build, or delete its file">🗑</button>
        </div>`;

      document.getElementById("list-chosen").innerHTML =
        chosen.length ? chosen.map((item, index) => line(item, index, true)).join("")
                      : `<div class="problem-empty">Nothing is selected, so a build
                         would generate nothing.</div>`;
      document.getElementById("list-spare").innerHTML =
        spare.length ? spare.map((item) => line(item, 0, false)).join("")
                     : `<div class="problem-empty">Every list in the folder is in the build.</div>`;
      wire();
    };

    const wire = () => {
      for (const row of document.querySelectorAll(".list-row")) {
        const item = rows.find((r) => r.path === row.dataset.path);
        row.querySelector("[data-toggle]").addEventListener("change", (event) => {
          item.selected = event.target.checked;
          if (item.selected) { rows = rows.filter((r) => r !== item).concat([item]); }
          render();
        });
        const up = row.querySelector("[data-up]");
        const down = row.querySelector("[data-down]");
        if (up) up.addEventListener("click", () => { moveChosen(item, -1); render(); });
        if (down) down.addEventListener("click", () => { moveChosen(item, 1); render(); });
        row.querySelector("[data-remove]")
           .addEventListener("click", () => this.removeList(item));
      }
    };

    /* Only the selected rows have an order, so the move works on that subset and
       is written back into the full list. */
    const moveChosen = (item, offset) => {
      const chosen = rows.filter((r) => r.selected);
      const index = chosen.indexOf(item);
      const target = index + offset;
      if (target < 0 || target >= chosen.length) return;
      chosen.splice(index, 1);
      chosen.splice(target, 0, item);
      const spare = rows.filter((r) => !r.selected);
      rows = chosen.concat(spare);
    };

    showModal("Parameter lists",
      `<p class="modal-note">Every list of the project lives in
       <code>${escapeHtml(answer.directory)}</code>. The ones that are ticked are
       merged into one parameter list, <b>in the order shown</b> &mdash; that order
       is the order of the indices in the generated code. The choice is saved into
       <code>${escapeHtml(answer.config)}</code>, so
       <code>run_generate.py</code> builds exactly what you see here.</p>
       <button type="button" class="inline-btn" id="btn-new-list">+ New parameter list</button>
       <button type="button" class="inline-btn" id="btn-open-list">Open an existing file…</button>
       <label>In the build</label>
       <div class="list-box" id="list-chosen"></div>
       <label>In the folder, not in the build</label>
       <div class="list-box" id="list-spare"></div>`,
      async () => {
        try {
          const answer2 = await api.selectLists(rows.filter((r) => r.selected)
                                                    .map((r) => r.path));
          if (!answer2.ok) {
            toast(answer2.message || "Could not save the choice.", "bad");
            return;
          }
          await this.refresh();
          toast(`${answer2.paths.length} list(s) take part in the build.`, "good");
        } catch (error) { this.failed("Saving the choice", error); }
      });

    render();
    document.getElementById("btn-new-list").addEventListener("click", () => this.newList());
    document.getElementById("btn-open-list").addEventListener("click", () => this.openList());
  },

  /* Creating a list writes the file and puts it in the build straight away, so
     what the editor opens next is a file that really exists. */
  async newList(directory) {
    /* The folder is chosen by walking into it, the same way Open does - a
       browser cannot hand a page a real path, so the backend lists the folders
       and the page walks them. */
    let here = null;
    try {
      here = await api.browse(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!here.ok) { toast(here.message || "Could not open that folder.", "bad"); return; }

    const folders = here.folders.map((item) => `
      <div class="list-row" data-folder="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b></div>
      </div>`).join("");

    const up = here.parent
      ? `<div class="list-row" data-folder="${escapeHtml(here.parent)}">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b>
             <span class="hint mono">${escapeHtml(here.parent)}</span></div>
         </div>`
      : "";

    const existing = here.files.length
      ? here.files.map((item) => escapeHtml(item.name)).join(", ")
      : "none";

    showModal("New parameter list",
      `<p class="modal-note">A new, empty list is created here and added to the
       build. It starts with the same drop-down lists as the one open now.</p>
       <label>Name</label>
       <input type="text" id="new-list-name" class="mono" value="parameter_list_">
       <label>Folder</label>
       <div class="hint mono" style="margin-bottom:6px" id="new-list-dir-shown"
            >${escapeHtml(here.directory)}</div>
       <div class="list-box" id="new-list-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <p class="modal-note">Already here: <span class="mono">${existing}</span></p>
       <input type="hidden" id="new-list-dir" value="${escapeHtml(here.directory)}">`,
      async () => {
        const name = document.getElementById("new-list-name").value.trim();
        const directory = document.getElementById("new-list-dir").value.trim();
        try {
          const answer = await api.newList(name, directory);
          if (!answer.ok) {
            toast(answer.message || "Could not create the list.", "bad");
            return;
          }
          await api.open(answer.path);
          this.selected = "";
          await this.refresh();
          toast(`Created ${answer.path}`, "good");
          setStatus("New parameter list");
        } catch (error) { this.failed("Creating the list", error); }
      });

    /* walking into a folder re-opens the dialog there, keeping the name typed */
    for (const row of document.querySelectorAll("#new-list-folders [data-folder]")) {
      row.addEventListener("click", () => {
        const typed = document.getElementById("new-list-name").value;
        this.newList(row.dataset.folder).then(() => {
          const box = document.getElementById("new-list-name");
          if (box) box.value = typed;
        });
      });
    }
  },


  /* ------------------------------------------------- open an existing list */
  /* A browser cannot hand a page a real path: a file input gives a name and a
     blob, never a location the generator could write into its configuration.
     So the folders are listed by the backend, where the paths are real, and
     this walks them. A file is checked BEFORE it is added - an XML that is not
     a parameter list has to be refused here, with a reason, not discovered
     halfway through a build after the configuration was already rewritten. */
  async openList(directory) {
    let answer;
    try {
      answer = await api.browse(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!answer.ok) { toast(answer.message || "Could not open that folder.", "bad"); return; }

    const folders = answer.folders.map((item) => `
      <div class="list-row" data-folder="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b></div>
      </div>`).join("");

    const files = answer.files.map((item) => `
      <div class="list-row${item.inBuild ? " on" : ""}" data-file="${escapeHtml(item.path)}">
        <span class="node-icon prim">◆</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b>
          ${item.inBuild ? `<span class="hint">already in the build</span>` : ""}</div>
      </div>`).join("");

    const up = answer.parent
      ? `<div class="list-row" data-folder="${escapeHtml(answer.parent)}">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b>
             <span class="hint mono">${escapeHtml(answer.parent)}</span></div>
         </div>`
      : "";

    showModal("Open a parameter list",
      `<p class="modal-note">Pick an <code>.xml</code> file anywhere on this
       machine. It is checked before it is added: a file that is not a parameter
       list is refused with the reason, and nothing is written until then.</p>
       <label>Folder</label>
       <div class="hint mono" style="margin-bottom:6px">${escapeHtml(answer.directory)}</div>
       <label>Or type a path</label>
       <input type="text" id="open-list-path" class="mono"
              placeholder="C:\\project\\module\\parameter_list.xml">
       <div id="open-verdict"></div>
       <label>Folders</label>
       <div class="list-box" id="open-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <label>Parameter lists here</label>
       <div class="list-box" id="open-files">${files
         || `<div class="problem-empty">No .xml file in this folder.</div>`}</div>`,
      async () => {
        const typed = document.getElementById("open-list-path").value.trim();
        if (!typed) { toast("Pick a file, or type its path.", "bad"); return; }
        try {
          const added = await api.addExistingList(typed);
          if (!added.ok) { toast(added.message || "Could not add that file.", "bad"); return; }
          await api.open(added.path);
          this.selected = "";
          await this.refresh();
          toast(`'${added.path}' is now part of the build.`, "good");
          setStatus("List added");
        } catch (error) { this.failed("Adding the list", error); }
      });

    /* clicking a folder walks into it; clicking a file fills the box and
       says straight away whether the file fits */
    for (const row of document.querySelectorAll("#open-folders [data-folder]")) {
      row.addEventListener("click", () => this.openList(row.dataset.folder));
    }
    const box = document.getElementById("open-list-path");
    const verdict = document.getElementById("open-verdict");
    const inspect = async (path) => {
      verdict.innerHTML = `<p class="modal-note">Checking…</p>`;
      try {
        const report = await api.inspectList(path);
        verdict.innerHTML = report.ok
          ? `<div class="drift ok"><b>This is a parameter list.</b>
             <p>${report.values} value(s) in ${report.parameters} top level entry(ies),
             ${report.structures} structure(s).${report.templates.length
               ? ` Types: ${escapeHtml(report.templates.join(", "))}.` : ""}</p>
             ${report.notes.length ? `<p class="hint">${report.notes
               .map(escapeHtml).join("<br>")}</p>` : ""}</div>`
          : `<div class="drift bad"><b>This file cannot be added.</b>
             <p>${escapeHtml(report.reason || "It is not a parameter list.")}</p></div>`;
      } catch (error) {
        verdict.innerHTML = `<div class="drift bad"><b>Could not check the file.</b>
          <p>${escapeHtml(error.message)}</p></div>`;
      }
    };
    for (const row of document.querySelectorAll("#open-files [data-file]")) {
      row.addEventListener("click", () => {
        box.value = row.dataset.file;
        inspect(row.dataset.file);
      });
    }
    box.addEventListener("change", () => box.value.trim() && inspect(box.value.trim()));
  },

  /* ------------------------------------------- reusable structure types */
  /* A type is a shape, and a parameter made from one owns its copy: nothing
     links back, so editing the parameter never edits the type and editing the
     type never rewrites a parameter that was made earlier. */
  async useTemplate(path, name) {
    try {
      const answer = await api.useTemplate(path, name);
      if (!answer.ok) { toast(`No type called '${name}'.`, "bad"); return; }
      treeView.collapsed.delete(path);
      await this.refresh();
      toast(`'${path}' now holds a copy of the type '${name}'.`, "good");
      setStatus("Type applied");
    } catch (error) { this.failed("Applying the type", error); }
  },

  saveTemplate(node) {
    const existing = (this.state.templates || []).some((t) => t.name === node.name);
    showModal("Save as a reusable type",
      `<p class="modal-note">The structure is stored in the type library under this
       name and appears in the <b>Data type</b> list of every parameter.</p>
       <label>Type name</label>
       <input type="text" id="template-name" class="mono"
              value="${escapeHtml(node.name)}">
       ${existing ? `<p class="modal-note">A type called
         <code>${escapeHtml(node.name)}</code> already exists; saving replaces it.
         Parameters made from it earlier keep the fields they have.</p>` : ""}`,
      async () => {
        const name = document.getElementById("template-name").value.trim();
        if (!name) { toast("A type needs a name.", "bad"); return; }
        try {
          const answer = await api.saveTemplate(node.path, name);
          if (!answer.ok) {
            toast(answer.message || "Could not save the type.", "bad");
            return;
          }
          await this.refresh(true);
          toast(`'${answer.name}' is now in the Data type list.`, "good");
        } catch (error) { this.failed("Saving the type", error); }
      });
  },

  editTemplates() {
    const templates = this.state.templates || [];
    if (!templates.length) {
      showModal("Structure types",
        `<p class="modal-note">The library is empty. Build a structure, select it,
         and press <b>Save as a type</b> in its editor; it then appears in the
         <b>Data type</b> list of every parameter, next to
         <code>float32_t</code>.</p>`, null);
      return;
    }

    const rows = templates.map((template) => `
      <div class="template-row" data-name="${escapeHtml(template.name)}">
        <div>
          <b>${escapeHtml(template.name)}</b>
          <span class="count">${template.fields} value(s) per copy</span>
          ${template.description ? `<div class="hint">${escapeHtml(template.description)}</div>` : ""}
          <div class="hint mono">${(template.shape || []).map(escapeHtml).join("<br>")}</div>
        </div>
        <button type="button" class="inline-btn danger" data-delete="${escapeHtml(template.name)}">
          Remove</button>
      </div>`).join("");

    showModal("Structure types",
      `<p class="modal-note">These are offered in the <b>Data type</b> list of every
       parameter. Removing one here changes nothing that was already built from it:
       a parameter owns its copy of the fields.</p>
       <div class="template-list">${rows}</div>`, null);

    for (const button of document.querySelectorAll("[data-delete]")) {
      button.addEventListener("click", async () => {
        const name = button.dataset.delete;
        try {
          const answer = await api.deleteTemplate(name);
          if (!answer.ok) {
            /* a type another parameter list owns cannot be removed from here */
            toast(answer.message || `Could not remove the type '${name}'.`, "bad");
            return;
          }
          await this.refresh(true);
          toast(`Type '${name}' removed from the library.`, "good");
          this.editTemplates();
        } catch (error) { this.failed("Removing the type", error); }
      });
    }
  },

  /* ------------------------------------------------------------ toolbar */
  bindToolbar() {
    const on = (id, handler) => document.getElementById(id).addEventListener("click", handler);

    on("btn-save", () => this.save());
    on("btn-reload", async () => {
      if (this.state.dirty && !confirm("Discard the unsaved changes and reload?")) return;
      try {
        await api.open(null);
        this.selected = "";
        await this.refresh();
        setStatus("Reloaded");
      } catch (error) { this.failed("Reloading", error); }
    });

    document.getElementById("module-picker").addEventListener("change", async (event) => {
      const path = event.target.value;
      if (this.state.dirty &&
          !confirm("This module has unsaved changes. Switch anyway and lose them?")) {
        this.paint(true);   // put the picker back on the current module
        return;
      }
      try {
        if (path === ALL_LISTS) {
          /* Nothing is opened: the merged view reads every list of the build,
             including the one already open, exactly as the generator does. */
          this.allLists = true;
          this.selected = "";
          await this.refresh();
          setStatus("Every list, merged — read only");
          return;
        }
        this.allLists = false;
        await api.open(path);
        this.selected = "";
        await this.refresh();
        setStatus("Switched module");
      } catch (error) {
        this.failed("Opening the list", error);
        this.paint(true);   // put the picker back on the current module
      }
    });

    this.bindMenu("btn-add-menu", "menu-add", {
      "add": () => this.addNode("primitive", false),
      "add-struct": () => this.addNode("struct", false),
      "add-field": () => this.addNode("primitive", true),
      "add-substruct": () => this.addNode("struct", true),
    });
    this.bindMenu("btn-settings", "menu-settings", {
      "types": () => this.editTemplates(),
      "choices": () => this.editLists(),
      "theme": () => this.toggleTheme(),
    });
    /* one place that closes every menu: a click anywhere else, or Escape */
    document.addEventListener("click", () => {
      for (const close of this._menuClosers) close();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        for (const close of this._menuClosers) close();
      }
    });

    on("btn-duplicate", async () => {
      try {
        const answer = await api.duplicate(this.selected);
        if (answer.selected) this.selected = answer.selected;
        await this.refresh();
        setStatus("Duplicated");
      } catch (error) { this.failed("Duplicating", error); }
    });
    on("btn-delete", () => this.remove());
    on("btn-up", () => this.moveNode(-1));
    on("btn-down", () => this.moveNode(1));

    on("btn-undo", async () => {
      try { await api.undo(); await this.refresh(); setStatus("Undo"); }
      catch (error) { this.failed("Undo", error); }
    });
    on("btn-redo", async () => {
      try { await api.redo(); await this.refresh(); setStatus("Redo"); }
      catch (error) { this.failed("Redo", error); }
    });

    on("btn-view-tree", () => this.setView("tree"));
    on("btn-view-grid", () => this.setView("grid"));

    on("btn-lists-select", () => this.editListSelection());
    on("btn-generate", () => this.generate());

    document.getElementById("filter").addEventListener("input", (event) => {
      treeView.filter = event.target.value.trim();
      this.paint(true);
    });

    document.getElementById("btn-toggle-problems").addEventListener("click", (event) => {
      this.problemsPinned = true;      // from here on it is the user's choice
      event.stopPropagation();
      document.getElementById("problems-pane").classList.toggle("collapsed");
      this.sizeProblems();
    });
  },

  bindShortcuts() {
    document.addEventListener("keydown", (event) => {
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
      if (event.ctrlKey && event.key.toLowerCase() === "s") { event.preventDefault(); this.save(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "g") { event.preventDefault(); this.generate(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "n") { event.preventDefault(); this.addNode("primitive", false); }
      else if (event.ctrlKey && event.key.toLowerCase() === "d") { event.preventDefault(); document.getElementById("btn-duplicate").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "z") { event.preventDefault(); document.getElementById("btn-undo").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "y") { event.preventDefault(); document.getElementById("btn-redo").click(); }
      else if (event.key === "Delete" && !typing && this.selected) { this.remove(); }
    });
  },

  async remove() {
    if (!this.selected) return;
    if (!confirm(`Delete '${this.selected}'?`)) return;
    try {
      await api.remove(this.selected);
      this.selected = "";
      await this.refresh();
      setStatus("Deleted");
    } catch (error) { this.failed("Deleting", error); }
  },

  async moveNode(offset) {
    try {
      const answer = await api.move(this.selected, offset);
      await this.refresh();
      /* A move that could not happen used to do nothing at all and say nothing
         at all, which reads exactly like a broken button. */
      setStatus(answer.ok
        ? "Moved"
        : `Already ${offset < 0 ? "first" : "last"} among its siblings`);
    } catch (error) { this.failed("Moving", error); }
  },

  async save() {
    try {
      const answer = await api.save(null);
      await this.refresh(true);
      toast(`Saved to ${answer.path}`, "good");
      setStatus("Saved");
    } catch (error) { this.failed("Saving", error); }
  },

  /* ------------------------------------------------------------ actions */
  async generate() {
    setStatus("Generating…");
    let result;
    try {
      result = await api.generate();
    } catch (error) {
      /* Never leave the page sitting on "Generating…": a request that failed
         outright still has to say so. */
      toast(`Generation failed: ${error.message}`, "bad");
      setStatus("Generation failed");
      return;
    }
    await this.refresh(true);
    if (!result.success) {
      toast(result.message
        ? `Nothing was generated: ${result.message}`
        : "The model has errors - nothing was generated. See Problems.", "bad");
      document.getElementById("problems-pane").classList.remove("collapsed");
      setStatus("Generation aborted");
      return;
    }
    const files = result.files.map((f) => `<div>${escapeHtml(f)}</div>`).join("");
    const modules = (result.modules || []).length > 1
      ? `<p class="modal-note">Read from ${result.modules.length} sub-module(s):</p>
         <div class="file-list">${result.modules
           .map((m) => `<div>${escapeHtml(m)}</div>`).join("")}</div>` : "";
    const saved = result.saved
      ? `<p class="modal-note">The model was saved to
         <code>${escapeHtml(result.saved)}</code> first, so
         <code>python run_generate.py</code> now produces exactly the same code.</p>` : "";

    const drift = this.driftHtml(result.drift);

    showModal(result.drift && result.drift.breaksStoredData
                ? "Code generated - CHECK THE MEMORY LAYOUT"
                : "Code generated",
      `${drift}${saved}${modules}<p class="modal-note">${result.count} value(s) written into
       ${result.files.length} file(s):</p><div class="file-list">${files}</div>`,
      null);
    setStatus(result.drift && result.drift.breaksStoredData
      ? `Generated ${result.files.length} files - the memory layout MOVED`
      : `Generated ${result.files.length} files`);
  },

  /* --------------------------------------------- the memory layout warning */
  /* The offset of a reset-proof value is positional: it is the sum of the sizes
     of everything before it. So inserting a parameter in the middle, disabling
     one, moving one, or widening one moves EVERY parameter after it - and a
     board that already has data in flash then reads the wrong value at the old
     offset. None of that shows up in the generated code, which is why the
     editor says it here, before anything else in the dialog. */
  driftHtml(drift) {
    if (!drift || drift.firstRun) return "";

    if (drift.breaksStoredData) {
      const rows = drift.moved.slice(0, 14).map((m) => `
        <tr><td class="mono">${escapeHtml(m.parameter)}</td>
            <td class="mono">${escapeHtml(m.tag)}</td>
            <td class="c mono">${m.old}</td><td class="c mono">${m.new}</td></tr>`).join("");
      const more = drift.moved.length > 14
        ? `<p class="hint">... and ${drift.moved.length - 14} more.</p>` : "";
      return `<div class="drift bad">
        <b>The stored position of ${drift.moved.length} value(s) changed.</b>
        <p>A board that already has data in flash will read the <b>wrong value</b>
           at these offsets. Before flashing, erase the stored area, migrate it,
           or move the new parameters to the <b>end</b> of the list instead of
           the middle.</p>
        <div class="drift-table">
          <table><tr><th>parameter</th><th>tag</th><th class="c">was</th>
                     <th class="c">now</th></tr>${rows}</table>
        </div>${more}
      </div>`;
    }

    const bits = [];
    if (drift.added.length) bits.push(`${drift.added.length} added`);
    if (drift.removed.length) bits.push(`${drift.removed.length} removed`);
    if (drift.reindexed.length) bits.push(`${drift.reindexed.length} reindexed`);
    if (!bits.length) return "";
    return `<div class="drift ok">
      <b>The list changed, but nothing moved.</b>
      <p>${escapeHtml(bits.join(", "))} &mdash; every value that existed before is
         still at the same offset, so a board in the field keeps reading what it
         was reading.</p></div>`;
  },


  /* The four drop-down lists the editor offers, and the enums generated from them. */
  editLists() {
    const defines = this.state.defines;
    const keys = ["paramTypes", "systemNames", "paramModes", "valueTypes"];
    const labels = {
      paramTypes: "Parameter types (MONITORING, SETTING, COMMAND)",
      systemNames: "System names",
      paramModes: "Parameter modes",
      valueTypes: "Value types (float32_t, uint16_t, ...)",
    };

    let body = `<p class="modal-note">One value per line, in the order they should get
       their enum value. These are the choices the editor offers and the enumerations
       the generator writes into <code>cg_parameter_list_defines.h</code>.</p>
       <button type="button" class="inline-btn" id="btn-restore-lists">
         Restore the company defaults</button>`;
    for (const key of keys) {
      body += `<label>${labels[key]} <span class="count" id="count-${key}"></span></label>
        <textarea id="list-${key}">${escapeHtml((defines[key] || []).join("\n"))}</textarea>`;
    }

    showModal("Drop-down lists", body, async () => {
      try {
        for (const key of keys) {
          const values = document.getElementById(`list-${key}`).value
            .split("\n").map((v) => v.trim()).filter(Boolean);
          const answer = await api.setDefines(key, values);
          if (!answer.ok) {
            toast(answer.message || `Could not save the '${labels[key]}' list.`, "bad");
            return;
          }
        }
        await this.refresh();
        toast("Lists updated.", "good");
      } catch (error) { this.failed("Saving the lists", error); }
    });

    /* live count under each box, so a truncated list is obvious */
    const recount = () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").filter((v) => v.trim());
        document.getElementById(`count-${key}`).textContent = `(${values.length})`;
      }
    };
    for (const key of keys) {
      document.getElementById(`list-${key}`).addEventListener("input", recount);
    }
    recount();

    document.getElementById("btn-restore-lists").addEventListener("click", async () => {
      try {
        const defaults = await api.defaultDefines();
        for (const key of keys) {
          document.getElementById(`list-${key}`).value = (defaults[key] || []).join("\n");
        }
        recount();
      } catch (error) { this.failed("Reading the defaults", error); }
    });
  },
};

/* ---------------------------------------------------------------- helpers */
/* Everything below the top bar is positioned from --topbar-h, and the toolbar
   wraps to a second row on a narrow window, so that height cannot be a constant:
   it is measured here and republished whenever the bar changes size.  Without
   this the wrapped row lies on top of the parameter tree. */
function trackTopbarHeight() {
  const bar = document.querySelector(".topbar");
  if (!bar) return;
  const apply = () => document.documentElement.style.setProperty(
    "--topbar-h", `${Math.ceil(bar.getBoundingClientRect().height)}px`);
  if (window.ResizeObserver) new ResizeObserver(apply).observe(bar);
  else window.addEventListener("resize", apply);
  apply();
}

function findNode(nodes, path) {
  for (const node of nodes) {
    if (node.path === path) return node;
    const found = findNode(node.children || [], path);
    if (found) return found;
  }
  return null;
}

/* How many values these nodes put in the generated table.  An array of
   structures contributes one full set of values PER ELEMENT, which is what
   makes this different from simply counting the leaves of the tree - get it
   wrong and the count under the tree disagrees with PARAMETER_LIST_QTY. */
function countLeaves(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (!node.enable) continue;
    total += node.kind === "struct"
      ? countLeaves(node.children) * Math.max(1, node.arraySize || 1)
      : 1;
  }
  return total;
}

function countStructs(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === "struct") total += 1 + countStructs(node.children);
  }
  return total;
}

function expandTo(path) {
  const parts = path.split(".");
  for (let index = 1; index < parts.length; index++) {
    treeView.collapsed.delete(parts.slice(0, index).join("."));
  }
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

let toastTimer = null;
function toast(message, kind) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.className = "toast " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.add("hidden"), 4200);
}

function showModal(title, bodyHtml, onOk) {
  const modal = document.getElementById("modal");
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-body").innerHTML = bodyHtml;
  const okButton = document.getElementById("modal-ok");
  const cancelButton = document.getElementById("modal-cancel");
  okButton.textContent = onOk ? "OK" : "Close";
  cancelButton.style.display = onOk ? "" : "none";

  const close = () => { modal.classList.add("hidden"); };
  okButton.onclick = async () => { if (onOk) await onOk(); close(); };
  cancelButton.onclick = close;
  modal.classList.remove("hidden");
}

/* A dialog whose own content acts on the model - removing a list, say - has to
   be able to close itself before the screen is redrawn underneath it. */
function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

window.addEventListener("DOMContentLoaded", () => app.start());

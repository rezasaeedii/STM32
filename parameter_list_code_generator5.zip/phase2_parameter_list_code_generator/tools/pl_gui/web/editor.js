/* ==========================================================================
   editor.js - the form on the right.

   buildForm() writes the HTML of one parameter, top to bottom, and collect()
   reads it back.  Adding a field to the editor means adding one entry here.
   ========================================================================== */

/* A structure type is offered in the same list as float32_t and the other data
   types, so its options need a marker that cannot collide with a type name. */
const TEMPLATE_PREFIX = "struct:";

const editorView = {
  element: null,
  titleElement: null,
  pathElement: null,
  node: null,
  state: null,
  onChange: () => {},

  init(element, titleElement, pathElement, onChange) {
    this.element = element;
    this.titleElement = titleElement;
    this.pathElement = pathElement;
    this.onChange = onChange;
  },

  clear() {
    this.node = null;
    this.titleElement.textContent = "Nothing selected";
    this.pathElement.textContent = "";
    this.element.innerHTML =
      `<p class="empty">Select a parameter on the left, or add one with
       <b>+ Parameter</b>.</p>`;
  },

  show(node, state) {
    this.node = node;
    this.state = state;
    this.titleElement.textContent = node.kind === "struct"
      ? `Structure — ${node.name}` : `Parameter — ${node.name}`;
    this.pathElement.textContent = node.path;
    this.element.innerHTML = node.kind === "struct"
      ? this.structForm(node, state) : this.primitiveForm(node, state);
    this.wire();
  },

  /* ---------------------------------------------------------- structure */
  structForm(node, state) {
    let html = "";
    html += `<div class="field-group"><h3>Identity</h3><div class="grid">`;
    html += this.text("name", "Name", node.name, true);
    html += this.text("gs_name", "GS name", node.gsName);
    if (!node.isField) {
      html += this.select("param_type", "Type", node.paramType, state.defines.paramTypes, true);
    }
    /* The same selector the primitive form has, and for the same reason: a
       structure that was made by picking a type out of this list has to be able
       to leave it again.  Choosing a plain type discards the fields. */
    html += this.dataTypeSelect(node, state);
    html += this.number("array_size", "Array size", node.arraySize, 1);
    html += this.check("enable", "Enabled (a disabled structure is skipped)", node.enable);
    html += `</div>
      <p class="modal-note">An array size above 1 makes a real C array of the
      generated type &mdash; <code>${escapeHtml(node.name)}[0]</code>,
      <code>${escapeHtml(node.name)}[1]</code>, ... Each element is a separate
      set of values with its own index, its own offsets and its own log ids, so
      ${node.children.length} field(s) &times; the array size is how many
      parameters it produces.</p>
      </div>`;

    html += `<div class="field-group"><h3>Description</h3><div class="grid wide">`;
    html += this.area("description", "Description", node.description);
    html += `</div></div>`;

    html += node.isField
      ? this.inheritedGroup(node, state)
      : this.tagsGroup(node, state,
          "A structure is classified as one thing: every field and sub-structure " +
          "inside it gets these tags and this type.");

    html += `<div class="field-group"><h3>Fields</h3>
      <p class="modal-note">${node.children.length} field(s).
      Use <b>+ Field</b> or <b>+ Sub-structure</b> in the toolbar to add one while
      this structure is selected.</p>
      </div>`;

    html += `<div class="field-group"><h3>Reusable type</h3>
      <p class="modal-note">Put this structure into the type library and it appears
      in the <b>Data type</b> list of every parameter, next to <code>float32_t</code>.
      Only the shape is stored &mdash; the fields with their limits, units and
      descriptions. The type, the tags and the array size stay with each
      parameter that uses it, and a copy is free to differ from the type it came
      from.</p>
      <button type="button" class="inline-btn" id="btn-save-template">
        Save '${escapeHtml(node.name)}' as a type</button>
      </div>`;
    return html;
  },

  /* ---------------------------------------------------------- primitive */
  primitiveForm(node, state) {
    const isBool = (node.valueType || "").toLowerCase() === "bool_t";

    let html = "";
    html += `<div class="field-group"><h3>Identity</h3><div class="grid">`;
    html += this.text("name", "Name", node.name, true);
    html += this.text("gs_name", "GS name", node.gsName);
    if (!node.isField) {
      html += this.select("param_type", "Type", node.paramType, state.defines.paramTypes, true);
    }
    html += this.dataTypeSelect(node, state);
    html += this.number("array_size", "Array size", node.arraySize, 1);
    html += this.text("unit", "Unit", node.unit);
    html += this.check("enable", "Enabled (a disabled parameter is not generated)", node.enable);
    html += `</div></div>`;

    html += `<div class="field-group"><h3>Value</h3><div class="grid">`;
    if (isBool) {
      html += this.select("default_value", "Default value",
        node.defaultValue ? "true" : "false", ["false", "true"]);
      html += `<div class="field"><label>Range</label>
        <span class="hint">bool_t has no minimum, maximum or resolution.</span></div>`;
    } else {
      html += this.number("default_value", "Default value", node.defaultValue);
      html += this.number("minimum", "Minimum", node.minimum);
      html += this.number("maximum", "Maximum", node.maximum);
      html += this.number("resolution", "Resolution", node.resolution);
      html += `<div class="field"><label>&nbsp;</label>
        <span class="hint">Minimum and maximum both 0 disables the range check.</span></div>`;
    }
    html += `</div></div>`;

    html += node.isField ? this.inheritedGroup(node, state)
                         : this.tagsGroup(node, state, null);

    html += `<div class="field-group"><h3>Description</h3><div class="grid wide">`;
    html += this.area("description", "Description", node.description);
    html += `</div></div>`;
    return html;
  },

  /* ------------------------------------------------- the data type list */
  /* The structure types of the library sit in the same drop-down as float32_t
     and the rest, because "a Position" is the answer to the same question as
     "a float": what does this parameter hold?  Picking one turns the parameter
     into a structure with a *copy* of the type's fields, which it then owns -
     its limits, its unit and its tags are edited like any other parameter's. */
  dataTypeSelect(node, state) {
    const templates = state.templates || [];
    /* A structure has no value type of its own, so nothing is preselected and
       the list opens on the placeholder - picking an entry is a real choice
       rather than a re-confirmation of what is already there. */
    let options = optionList(state.defines.valueTypes || [], node.valueType, true);

    if (templates.length) {
      options += `<optgroup label="Structure types (copied in)">`;
      for (const template of templates) {
        const title = [template.description, ...(template.shape || [])]
          .filter(Boolean).join(" · ");
        // written on one line on purpose: the text of an <option> keeps every
        // space and newline it is given, and a wrapped literal would show up as
        // a ragged gap in the drop-down
        const label = `${template.name} — ${template.fields} value(s)`;
        options += `<option value="${escapeHtml(TEMPLATE_PREFIX + template.name)}"` +
                   ` title="${escapeHtml(title)}">${escapeHtml(label)}</option>`;
      }
      options += `</optgroup>`;
    }

    const hint = templates.length
      ? `<span class="hint">Choosing a structure type replaces this parameter's
         value with a copy of that type's fields.</span>`
      : `<span class="hint">Build a structure and press <b>Save as a type</b> on it
         to make it selectable here.</span>`;

    return `<div class="field"><label>Data type <span class="req">*</span></label>
      <select data-field="value_type_name" data-type-select="1">${options}</select>
      ${hint}</div>`;
  },

  /* ------------------------------------------- what a field inherits */
  /* A field has no tags and no type of its own: it is part of one structure,
     so it shares that structure's classification.  They are shown read-only
     here, with a button that jumps to the structure to change them. */
  inheritedGroup(node, state) {
    const owner = escapeHtml(node.owner || "");
    let rows = `<div class="inherited-row"><span class="k">Type</span>
      <span class="v">${escapeHtml(node.effectiveType || "—")}</span></div>`;

    for (const spec of state.tagSpecs) {
      const value = node.effectiveTags[spec.id];
      const shown = value === null || value === undefined ? "—"
                  : typeof value === "boolean" ? (value ? "TRUE" : "FALSE") : String(value);
      rows += `<div class="inherited-row"><span class="k">${escapeHtml(spec.label)}</span>
        <span class="v">${escapeHtml(shown)}</span></div>`;
    }

    /* The log id is not a tag, so it is shown after them rather than among
       them.  It shows the id this field's values ACTUALLY got - not "the block
       start plus an offset", which named a number and then refused to say it.
       The ids come from the same flatten() that writes the generated table, so
       what is on screen is what the firmware will see. */
    const own = node.logIds || [];
    const ownerLogId = node.effectiveLogId;
    let logIdShown = "—";
    let logIdNote = "";
    if (own.length === 1) {
      logIdShown = String(own[0]);
    } else if (own.length > 1) {
      logIdShown = `${own[0]}-${own[own.length - 1]}`;
      logIdNote = `<span class="note">${own.length} values, one id each</span>`;
    } else if (ownerLogId !== null && ownerLogId !== undefined) {
      logIdShown = String(ownerLogId);
      logIdNote = `<span class="note">the block of ${escapeHtml(node.owner || "")}
                   starts here</span>`;
    }
    rows += `<div class="inherited-row"><span class="k">${escapeHtml(state.logIdSpec.label)}</span>
      <span class="v">${escapeHtml(logIdShown)}</span>${logIdNote}</div>`;

    return `<div class="field-group"><h3>Classification &mdash; from ${owner}</h3>
      <p class="modal-note">Tags and the type belong to the structure, not to its
      fields: <b>${owner}</b> is one thing that belongs to one subsystem, is reset
      proof or is not, and is logged or is not. Everything inside it shares that.</p>
      <div class="inherited-table">${rows}</div>
      <button type="button" class="inline-btn" id="btn-goto-owner">
        Edit them on ${owner}</button>
      </div>`;
  },

  /* ---------------------------------------------------------- tags */
  tagsGroup(node, state, note) {
    let html = `<div class="field-group"><h3>Tags</h3>`;
    if (note) html += `<p class="modal-note">${note}</p>`;
    html += `<div class="grid">`;

    for (const spec of state.tagSpecs) {
      const value = node.tags[spec.id];
      const label = `${spec.label}${spec.mandatory ? ' <span class="req">*</span>' : ""}`;

      if (spec.kind === "boolean") {
        const current = value === null || value === undefined ? "" : (value ? "true" : "false");
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <select data-tag="${spec.id}" data-bool="1">
            <option value=""${current === "" ? " selected" : ""}>—</option>
            <option value="true"${current === "true" ? " selected" : ""}>TRUE</option>
            <option value="false"${current === "false" ? " selected" : ""}>FALSE</option>
          </select>
        </div>`;
        /* The log id belongs beside Tag Loggable, because that is the only
           thing that gives it a meaning: it is the id used WHEN this value is
           logged.  It used to sit in a section of its own further down, where
           the two had to be read a screen apart to make sense of either. */
        if (spec.id === "Loggable") html += this.logIdField(node, state);
      } else if (spec.kind === "enum") {
        const options = state.defines[
          spec.definesColumn === "SYSTEM NAMES" ? "systemNames" : "paramModes"] || [];
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <select data-tag="${spec.id}">${optionList(options, value, true)}</select>
        </div>`;
      } else {
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <input type="text" class="mono" data-tag="${spec.id}"
                 value="${escapeHtml(value == null ? "" : value)}">
        </div>`;
      }
    }
    html += `</div></div>`;
    return html;
  },

  /* One cell of the tags grid, sitting right after Tag Loggable. */
  logIdField(node, state) {
    const spec = state.logIdSpec;
    const loggable = node.tags.Loggable === true;
    const own = node.logIds || [];

    let note = "";
    if (!loggable) {
      note = `<span class="hint">Tag Loggable is FALSE, so this id is ignored
              and 0 is written into the table.</span>`;
    } else if (own.length > 1) {
      note = `<span class="hint">${own.length} values: ids <b>${own[0]}-${own[own.length - 1]}</b>,
              next free ${own[own.length - 1] + 1}</span>`;
    } else if (node.kind === "struct") {
      note = `<span class="hint">first id of the block; every value inside takes
              one consecutive id</span>`;
    }

    return `<div class="field${loggable ? "" : " dimmed"}">
      <label title="${escapeHtml(spec.description)}">${escapeHtml(spec.label)}</label>
      <div class="with-button">
        <input type="number" min="0" max="${spec.max}" data-field="log_id"
               value="${node.logId == null ? "" : node.logId}"
               placeholder="—">
        <button type="button" class="inline-btn" id="btn-next-log-id"
                title="The first id after everything already used">Next free</button>
      </div>
      ${note}
    </div>`;
  },

  /* ---------------------------------------------------------- the log id */
  /* Not a tag: it owns no offset area and it is a plain uint16_t in the
     descriptor, so it gets a field of its own instead of a row among the tags.
     It means nothing unless Tag Loggable is TRUE, and the form says so rather
     than hiding the field - a hidden field is a field nobody can fix. */

  /* ---------------------------------------------------------- widgets */
  text(name, label, value, required) {
    return `<div class="field"><label>${label}${required ? ' <span class="req">*</span>' : ""}</label>
      <input type="text" class="mono" data-field="${name}" value="${escapeHtml(value ?? "")}"></div>`;
  },
  number(name, label, value, min) {
    const minimum = min === undefined ? "" : `min="${min}"`;
    return `<div class="field"><label>${label}</label>
      <input type="number" class="mono" data-field="${name}" step="any" ${minimum}
             value="${value == null ? "" : value}"></div>`;
  },
  select(name, label, value, options, required, extra) {
    return `<div class="field"><label>${label}${required ? ' <span class="req">*</span>' : ""}</label>
      <select data-field="${name}">${optionList(options || [], value, true)}</select>${extra || ""}</div>`;
  },
  check(name, label, value) {
    return `<div class="field check">
      <input type="checkbox" id="field-${name}" data-field="${name}" ${value ? "checked" : ""}>
      <label for="field-${name}">${label}</label></div>`;
  },
  area(name, label, value) {
    return `<div class="field"><label>${label}</label>
      <textarea data-field="${name}">${escapeHtml(value ?? "")}</textarea></div>`;
  },

  /* ---------------------------------------------------------- reading back */
  wire() {
    for (const input of this.element.querySelectorAll("[data-field],[data-tag]")) {
      // the data type list has its own handler: one of its entries is not a
      // value to store but an action, so it must not go through collect()
      if (input.dataset.typeSelect) continue;
      const event = (input.tagName === "SELECT" || input.type === "checkbox")
        ? "change" : "blur";
      input.addEventListener(event, () => this.onChange(this.collect()));
      if (input.tagName !== "SELECT" && input.type !== "checkbox") {
        input.addEventListener("keydown", (keyEvent) => {
          if (keyEvent.key === "Enter" && input.tagName !== "TEXTAREA") input.blur();
        });
      }
    }
    const nextId = this.element.querySelector("#btn-next-log-id");
    if (nextId) {
      nextId.addEventListener("click", async () => {
        try {
          const answer = await api.nextLogId();
          const input = this.element.querySelector('[data-field="log_id"]');
          input.value = answer.value;
          this.onChange(this.collect());
        } catch (error) { app.failed("Reading the next free log id", error); }
      });
    }

    const typeSelect = this.element.querySelector("[data-type-select]");
    if (typeSelect) {
      typeSelect.addEventListener("change", () => {
        const value = typeSelect.value;
        if (value.startsWith(TEMPLATE_PREFIX)) {
          app.useTemplate(this.node.path, value.slice(TEMPLATE_PREFIX.length));
        } else {
          this.onChange(this.collect());
        }
      });
    }

    const saveTemplate = this.element.querySelector("#btn-save-template");
    if (saveTemplate) {
      saveTemplate.addEventListener("click", () => app.saveTemplate(this.node));
    }

    const gotoOwner = this.element.querySelector("#btn-goto-owner");
    if (gotoOwner) {
      gotoOwner.addEventListener("click", () => app.select(this.node.owner));
    }
  },

  collect() {
    const changes = {};
    const tags = Object.assign({}, this.node.tags);
    const isBool = (this.node.valueType || "").toLowerCase() === "bool_t";

    for (const input of this.element.querySelectorAll("[data-field]")) {
      const name = input.dataset.field;
      if (input.type === "checkbox") { changes[name] = input.checked; continue; }
      const raw = input.value.trim();

      // a structure type is an action, not a stored value; it is handled in
      // wire() and must never be written into 'valueType'
      if (raw.startsWith(TEMPLATE_PREFIX)) continue;

      if (name === "default_value" && isBool) { changes[name] = raw === "true"; continue; }
      if (name === "array_size") { changes[name] = raw === "" ? 1 : parseInt(raw, 10); continue; }
      // '??' would be wrong here: an empty box means "no id", which is null,
      // while 0 is a perfectly good log id that must survive.
      if (name === "log_id") { changes[name] = raw === "" ? null : parseInt(raw, 10); continue; }
      if (["default_value", "minimum", "maximum", "resolution"].includes(name)) {
        changes[name] = raw === "" ? null : Number(raw);
        continue;
      }
      changes[name] = raw === "" ? null : raw;
    }

    for (const input of this.element.querySelectorAll("[data-tag]")) {
      const id = input.dataset.tag;
      const raw = input.value.trim();
      if (raw === "") { tags[id] = null; continue; }
      if (input.dataset.bool) { tags[id] = raw === "true"; continue; }
      tags[id] = input.type === "number" ? parseInt(raw, 10) : raw;
    }

    changes.tags = tags;
    return changes;
  },
};

function optionList(values, selected, allowEmpty) {
  let html = allowEmpty ? `<option value=""${selected == null ? " selected" : ""}>—</option>` : "";
  for (const value of values) {
    const isSelected = String(value) === String(selected) ? " selected" : "";
    html += `<option value="${escapeHtml(value)}"${isSelected}>${escapeHtml(value)}</option>`;
  }
  return html;
}

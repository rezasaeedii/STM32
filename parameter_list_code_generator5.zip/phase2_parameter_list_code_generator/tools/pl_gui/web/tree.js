/* ==========================================================================
   tree.js - draws the parameter tree on the left and reports clicks.
   ========================================================================== */

const treeView = {
  element: null,
  onSelect: () => {},
  onToggle: () => {},
  collapsed: new Set(),
  filter: "",

  init(element, onSelect, onToggle) {
    this.element = element;
    this.onSelect = onSelect;
    if (onToggle) this.onToggle = onToggle;
  },

  /* nodes: the "tree" array of /api/state ; problems: dotted paths with errors */
  render(nodes, selectedPath, problemPaths) {
    const rows = [];
    const walk = (list, depth) => {
      for (const node of list) {
        const open = !this.collapsed.has(node.path);
        rows.push(this.row(node, depth, selectedPath, problemPaths, open));
        if (node.kind === "struct" && open) walk(node.children, depth + 1);
      }
    };
    walk(nodes, 0);

    this.element.innerHTML = rows.join("");
    for (const row of this.element.querySelectorAll(".tree-row")) {
      row.addEventListener("click", (event) => {
        if (event.target.classList.contains("twisty")) {
          const path = row.dataset.path;
          if (this.collapsed.has(path)) this.collapsed.delete(path);
          else this.collapsed.add(path);
          this.onSelect(path, true);
          return;
        }
        this.onSelect(row.dataset.path, false);
      });
    }
    /* The checkbox must not also select the row: clicking it means "toggle
       this", not "toggle this and move the editor somewhere else". */
    for (const box of this.element.querySelectorAll(".en-box")) {
      box.addEventListener("click", (event) => event.stopPropagation());
      box.addEventListener("change", () => this.onToggle(box.dataset.toggle, box.checked));
    }
  },

  row(node, depth, selectedPath, problemPaths, open) {
    const classes = ["tree-row"];
    if (node.path === selectedPath) classes.push("selected");
    /* Not in the build for ANY reason - its own flag, or a structure above it
       that is switched off.  Greying only the node whose flag changed left a
       whole disabled subtree looking perfectly healthy. */
    if (!node.effectiveEnable) classes.push("disabled");
    if (problemPaths.has(node.path)) classes.push("has-error");
    if (this.filter && !this.matches(node)) classes.push("hidden");

    const isStruct = node.kind === "struct";
    const twisty = isStruct
      ? `<span class="twisty">${open ? "▾" : "▸"}</span>`
      : `<span class="twisty leaf">•</span>`;
    const icon = isStruct
      ? `<span class="node-icon struct">▣</span>`
      : `<span class="node-icon prim">◆</span>`;

    const type = isStruct
      ? `struct (${node.children.length})`
      : escapeHtml(node.valueType || "—");
    const array = node.arraySize > 1 ? `<span class="node-badge">[${node.arraySize}]</span>` : "";

    /* A real checkbox, in its own column at the left: whether a parameter is
       built at all is the first thing about it, and it used to be legible only
       as a slightly greyer row, in the middle of its other properties. */
    /* The box shows the node's OWN flag - re-enabling the structure has to
       bring it back exactly as it was - but it cannot be ticked into a build it
       is not in, so it is disabled while an ancestor is off, and says why. */
    const blockedByParent = node.enable && !node.parentEnabled;
    const title = !node.parentEnabled
      ? "Its structure is disabled, so this is not generated either"
      : (node.enable ? "In the build" : "Skipped: not generated");
    const enabled = `<span class="col-en"><input type="checkbox"
      class="en-box${blockedByParent ? " blocked" : ""}"
      data-toggle="${escapeHtml(node.path)}" ${node.enable ? "checked" : ""}
      ${node.parentEnabled ? "" : "disabled"}
      title="${title}"></span>`;

    return `
      <div class="${classes.join(" ")}" data-path="${escapeHtml(node.path)}">
        ${enabled}
        <span class="name-cell" style="padding-left:${depth * 16}px">${twisty}${icon}
          <span class="node-name${isStruct ? " struct" : ""}"
                >${escapeHtml(node.name)}</span>${array}</span>
        <span class="col-vtype">${type}</span>
        <span class="col-ptype">${escapeHtml(node.paramType || "")}</span>
      </div>`;
  },

  matches(node) {
    const needle = this.filter.toLowerCase();
    if (node.path.toLowerCase().includes(needle)) return true;
    return (node.children || []).some((child) => this.matches(child));
  },
};

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

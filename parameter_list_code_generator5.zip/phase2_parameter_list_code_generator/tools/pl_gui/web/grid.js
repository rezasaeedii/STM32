/* ==========================================================================
   grid.js - the spreadsheet view of the parameter list.

   The tree on the left answers "what is inside this structure?".  This answers
   the other question, the one a spreadsheet was always good at: "show me every
   parameter that is loggable, sorted by nothing, and let me scroll".  People
   coming from a flat sheet think in columns, and a tree cannot be scanned down
   a column.

   It is a VIEW, not a second editor: clicking a row selects that node, and the
   form on the right is still where a value is changed.  One place to edit means
   one place for the rules to live.
   ========================================================================== */

const gridView = {
  element: null,
  onSelect: () => {},

  /* One entry per column: the key is what the cell reads out of a row, and
     'filter' is what the box under the heading matches against.  Adding a
     column is adding one entry here - the header, the cells, the filters and
     the CSS grid template are all derived from this list. */
  columns: [
    /* Enabled comes FIRST.  Whether a parameter is in the build at all is the
       thing you check before reading any other column of its row, and it used
       to sit nineteen columns to the right, between two tag flags. */
    { key: "enable",   label: "En",        width: "44px",  align: "center" },
    { key: "index",    label: "Index",     width: "76px",  align: "right", mono: true },
    { key: "name",     label: "Name",      width: "minmax(170px,1.6fr)", mono: true },
    { key: "owner",    label: "List",      width: "0px" },
    { key: "gsName",   label: "GS Name",   width: "minmax(110px,1fr)" },
    { key: "paramType", label: "Type",     width: "110px" },
    { key: "kind",     label: "Kind",      width: "78px" },
    { key: "valueType", label: "Value type", width: "104px", mono: true },
    { key: "array",    label: "Arr",       width: "54px",  align: "right" },
    { key: "unit",     label: "Unit",      width: "68px" },
    { key: "def",      label: "Default",   width: "82px",  align: "right", mono: true },
    { key: "min",      label: "Min",       width: "82px",  align: "right", mono: true },
    { key: "max",      label: "Max",       width: "82px",  align: "right", mono: true },
    { key: "res",      label: "Res",       width: "88px",  align: "right", mono: true },
    { key: "logId",    label: "LogID",     width: "80px",  align: "right", mono: true },
    /* The tag columns say so.  'SystemName' and 'Encrypt' read like properties
       of the parameter; they are tags, and the name is what the generated
       descriptor field is called. */
    { key: "system",   label: "Tag SystemName", width: "138px" },
    { key: "mode",     label: "Tag ParamMode",  width: "158px" },
    { key: "reset",    label: "Tag ResetProof", width: "104px" },
    { key: "log",      label: "Tag Loggable",   width: "96px" },
    { key: "crypt",    label: "Tag LogEncryption", width: "126px" },
    { key: "desc",     label: "Description", width: "minmax(160px,1.4fr)" },
  ],

  //: column key -> the text typed under its heading
  filters: {},

  //: declaration paths whose individual values are shown
  expanded: new Set(),

  init(element, onSelect) {
    this.element = element;
    this.onSelect = onSelect;
  },

  /* ---------------------------------------------------------------- rows */
  /* Every node of the tree, parents included, in document order - the same
     order as the tree and as the generated indices.  Structures are kept
     because somebody filtering by type wants to see the structure that owns
     the type, not only its fields. */
  rows(nodes) {
    const out = [];
    const walk = (list, depth, parentPath, parentOwner) => {
      for (const node of list) {
        const isStruct = node.kind === "struct";
        const tags = node.isField ? node.effectiveTags : node.tags;
        out.push({
          node,
          depth,
          parentPath,
          index: fmtIndices(node),
          indexTitle: (node.values || []).map((v) => v.index).join(", "),
          // every row this declaration owns, so the filter can find any of them
          indexSearch: (node.values || []).map((v) => v.index).join(" "),
          valueCount: (node.values || []).length,
          name: node.path,
          owner: ownerOf(node, parentOwner),
          gsName: node.gsName || "",
          paramType: (node.isField ? node.effectiveType : node.paramType) || "",
          kind: isStruct ? "struct" : "value",
          valueType: isStruct ? "" : (node.valueType || ""),
          array: node.arraySize > 1 ? String(node.arraySize) : "",
          unit: node.unit || "",
          def: fmtNumber(node.defaultValue),
          min: fmtNumber(node.minimum),
          max: fmtNumber(node.maximum),
          res: fmtNumber(node.resolution),
          logId: fmtLogIds(node),
          // same for the log ids: "301-315" must be found by typing 307
          logIdSearch: (node.values || [])
            .map((v) => v.logId).filter((v) => v != null).join(" "),
          system: tags.SystemName == null ? "" : String(tags.SystemName),
          mode: tags.ParamMode == null ? "" : String(tags.ParamMode),
          reset: fmtBool(tags.ResetProof),
          log: fmtBool(tags.Loggable),
          crypt: fmtBool(tags.LogEncryption),
          enable: node.enable ? "yes" : "no",
          desc: node.description || "",
        });
        /* An opened declaration lists its values underneath itself: one row
           per element, with the index that element really has. */
        if (!isStruct && this.expanded.has(node.path)) {
          for (const value of node.values || []) {
            out.push({
              node, depth: depth + 1, parentPath: node.path, isValue: true,
              index: String(value.index), indexTitle: "", valueCount: 0,
              indexSearch: String(value.index),
              logIdSearch: value.logId == null ? "" : String(value.logId),
              name: value.name, owner: ownerOf(node, parentOwner),
              gsName: "", paramType: "", kind: "value",
              valueType: node.valueType || "", array: "", unit: node.unit || "",
              def: "", min: "", max: "", res: "",
              logId: value.logId == null ? "" : String(value.logId),
              system: "", mode: "", reset: "", log: "", crypt: "",
              enable: "", desc: "",
            });
          }
        }
        if (isStruct) walk(node.children, depth + 1, node.path, ownerOf(node, parentOwner));
      }
    };
    walk(nodes, 0, "", "");
    return out;
  },

  matches(row) {
    for (const [key, needle] of Object.entries(this.filters)) {
      if (!needle) continue;
      /* Match against what the row MEANS, not against what the cell happens to
         say.  A declaration that holds sixteen values shows "3-18", and typing
         11 into the filter has to find it - the parameter really does own row
         11, the cell just had no space to say so.  `search` holds every number
         behind the cell; columns without one fall back to their own text. */
      const hay = row[key + "Search"] ?? row[key] ?? "";
      if (!String(hay).toLowerCase().includes(needle.toLowerCase())) {
        return false;
      }
    }
    return true;
  },

  /* -------------------------------------------------------------- render */
  render(nodes, selectedPath, problemPaths) {
    const template = this.columns.map((column) => column.width).join(" ");
    const all = this.rows(nodes);
    const shown = all.filter((row) => this.matches(row));

    const head = this.columns.map((column) => `
      <div class="grid-head" style="text-align:${column.align || "left"}">
        ${escapeHtml(column.label)}</div>`).join("");

    const filterRow = this.columns.map((column) => `
      <div class="grid-filter">
        <input type="text" data-filter="${column.key}"
               value="${escapeHtml(this.filters[column.key] || "")}"
               title="Filter by ${escapeHtml(column.label)}" spellcheck="false">
      </div>`).join("");

    const body = shown.map((row) => {
      const classes = ["grid-row"];
      /* A structure is scaffolding, a leaf is a real parameter.  Reading the
         table means telling those two apart before anything else, so they are
         the one thing the styling distinguishes. */
      if (row.kind === "struct") classes.push("struct-row");
      if (row.isValue) classes.push("value-row");
      if (row.node.path === selectedPath && !row.isValue) classes.push("selected");
      if (!row.node.effectiveEnable) classes.push("disabled");
      if (problemPaths.has(row.node.path)) classes.push("has-error");

      return `<div class="${classes.join(" ")}" data-path="${escapeHtml(row.node.path)}"
                   style="grid-template-columns:${template}">` +
        this.columns.map((column) => {
          /* the name keeps the tree's shape, so a field is still visibly
             inside its structure even in a flat table */
          const indent = column.key === "name" ? row.depth * 12 : 0;
          /* The name cell is marked by NAME, not by its position: styling it as
             "the third column" breaks silently the day a column is inserted
             before it. */
          let cls = "grid-cell" + (column.mono ? " mono" : "")
                  + (column.key === "name" ? " row-name" : "");
          let text = row[column.key];
          let title = "";
          if (column.key === "enable") {
            /* a mark, not the word "yes": the column is 44px wide and the eye
               is looking for the exception, not for text to read */
            /* ✓ only when the value really reaches the table; a node whose
               own flag is on but whose structure is off shows a hollow mark,
               because it is not generated either. */
            const own = row.node.enable;
            const real = row.node.effectiveEnable;
            cls += real ? " on" : (own ? " blocked" : " off");
            text = real ? "✓" : (own ? "◌" : "✗");
          } else if (column.key === "index") {
            if (row.indexTitle.includes(",")) {
              title = ` title="rows ${escapeHtml(row.indexTitle)}"`;
            }
            if (row.valueCount > 1) {
              /* the affordance sits in the # cell, because that is the column
                 whose answer is incomplete until it is opened */
              const open = gridView.expanded.has(row.node.path);
              return `<div class="${cls} idx-cell"${title} style="text-align:right">
                <button type="button" class="expander" data-expand="${escapeHtml(row.node.path)}"
                        title="${open ? "Hide" : "Show"} the ${row.valueCount} values and their indices"
                        >${open ? "⊟" : "⊞"}</button>${escapeHtml(text)}</div>`;
            }
          }
          return `<div class="${cls}"${title} style="text-align:${column.align || "left"};` +
                 `padding-left:${6 + indent}px">${escapeHtml(text)}</div>`;
        }).join("") + `</div>`;
    }).join("");

    this.element.innerHTML = `
      <div class="grid-scroll">
        <div class="grid-table" style="--grid-cols:${template}">
          <div class="grid-row grid-header" style="grid-template-columns:${template}">${head}</div>
          <div class="grid-row grid-filters" style="grid-template-columns:${template}">${filterRow}</div>
          ${body || `<div class="problem-empty">No row matches the filters.</div>`}
        </div>
      </div>
      <div class="grid-foot">${shown.length} of ${all.length} row(s)${
        Object.values(this.filters).some(Boolean)
          ? ` · <a href="#" id="grid-clear">clear the filters</a>` : ""}</div>`;

    this.wire();
  },

  /* Listeners are attached after every render, because the elements they were
     on have just been thrown away. */
  wire() {
    for (const box of this.element.querySelectorAll("[data-filter]")) {
      box.addEventListener("input", () => {
        this.filters[box.dataset.filter] = box.value;
        const key = box.dataset.filter;
        const at = box.selectionStart;
        this.onFilter();
        /* the box was re-created by the redraw, so put the caret back where
           the typist left it - otherwise every keystroke jumps to the end */
        const again = this.element.querySelector(`[data-filter="${key}"]`);
        if (again) { again.focus(); again.setSelectionRange(at, at); }
      });
    }
    for (const row of this.element.querySelectorAll(".grid-row[data-path]")) {
      row.addEventListener("click", () => this.onSelect(row.dataset.path));
    }
    for (const button of this.element.querySelectorAll("[data-expand]")) {
      button.addEventListener("click", (event) => {
        event.stopPropagation();          // opening is not selecting
        const path = button.dataset.expand;
        if (this.expanded.has(path)) this.expanded.delete(path);
        else this.expanded.add(path);
        this.onFilter();                  // redraw without touching the model
      });
    }
    const clear = this.element.querySelector("#grid-clear");
    if (clear) {
      clear.addEventListener("click", (event) => {
        event.preventDefault();
        this.filters = {};
        this.onFilter();
      });
    }
  },

  onFilter: () => {},
};

/* A number the way a sheet shows it: no trailing zeroes, no exponent for the
   sizes a parameter actually has, and an empty cell for "not set". */
function fmtNumber(value) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "boolean") return value ? "TRUE" : "FALSE";
  if (typeof value !== "number") return String(value);
  if (Number.isInteger(value)) return String(value);
  return String(Number(value.toPrecision(9)));
}

/* The ids a node's values actually got.  One value shows its id; several show
   the range they occupy.  The numbers come from the backend's flatten(), which
   is the same pass that writes them into the generated table. */
/* The rows this declaration occupies in the generated table.
   A structure is not a row, a disabled parameter is not in the table, and an
   array declaration is one declaration over several rows - so it reports the
   span rather than being expanded into one grid row per element.  The numbers
   come from the backend's merged flatten(), so they are the same indices the
   generated macros use. */
/* In the merged view a top level entry says which file it came from, and its
   fields inherit that. Elsewhere the column is empty and collapsed to 0px. */
function ownerOf(node, parentOwner) {
  return node.ownerList || parentOwner || "";
}

function fmtIndices(node) {
  const values = node.values || [];
  if (!values.length) return "";
  if (values.length === 1) return String(values[0].index);

  /* A run gets its range.  Anything else - a field of an array of structures,
     whose values are strided - gets a count, because a range would name rows
     that belong to other parameters. */
  const first = values[0].index;
  const last = values[values.length - 1].index;
  const isRun = last - first === values.length - 1;
  return isRun ? `${first}-${last}` : `${values.length}×`;
}

function fmtLogIds(node) {
  const ids = node.logIds || [];
  if (ids.length === 1) return String(ids[0]);
  if (ids.length > 1) return `${ids[0]}-${ids[ids.length - 1]}`;
  if (!node.isField && node.logId != null) return String(node.logId);
  return "";
}

function fmtBool(value) {
  if (value === null || value === undefined) return "";
  return value ? "TRUE" : "FALSE";
}

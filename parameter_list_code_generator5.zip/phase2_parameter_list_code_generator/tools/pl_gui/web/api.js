/* ==========================================================================
   api.js - the only place that talks to the Python backend.
   Every call is  await api.<action>({...})  and returns the JSON answer.
   ========================================================================== */

const api = {
  async call(action, payload = {}) {
    const response = await fetch(`/api/${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`${action} failed (${response.status}): ${text}`);
    }
    return response.json();
  },

  state(allLists)            { return this.call("state", { allLists: !!allLists }); },
  open(path)                 { return this.call("open", { path }); },
  save(path)                 { return this.call("save", { path }); },
  add(parent, kind)          { return this.call("add", { parent, kind }); },
  duplicate(path)            { return this.call("duplicate", { path }); },
  remove(path)               { return this.call("delete", { path }); },
  move(path, offset)         { return this.call("move", { path, offset }); },
  update(path, changes)      { return this.call("update", { path, changes }); },
  undo()                     { return this.call("undo"); },
  redo()                     { return this.call("redo"); },
  setDefines(list, values)   { return this.call("defines", { list, values }); },
  defaultDefines()           { return this.call("default_defines"); },
  generate()                 { return this.call("generate"); },
  nextLogId()                { return this.call("next_log_id"); },

  /* the parameter lists of the project */
  lists()                    { return this.call("lists"); },
  newList(name, directory)   { return this.call("new_list", { name, directory }); },
  selectLists(paths)         { return this.call("select_lists", { paths }); },
  browse(directory)          { return this.call("browse", { directory }); },
  inspectList(path)          { return this.call("inspect_list", { path }); },
  addExistingList(path)      { return this.call("add_existing_list", { path }); },
  removeList(path, del)      { return this.call("remove_list", { path, delete: del }); },

  /* the library of reusable structure types */
  saveTemplate(path, name)   { return this.call("save_template", { path, name }); },
  deleteTemplate(name)       { return this.call("delete_template", { name }); },
  useTemplate(path, name)    { return this.call("use_template", { path, name }); },
};

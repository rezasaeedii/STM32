"""The JSON API the browser talks to.

One method per action, all of them tiny.  Adding a button to the GUI means
adding one method here and one ``fetch`` call in ``web/app.js``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from common.pl_codegen import __tool_name__, __version__
from common.pl_codegen.errors import CodeGeneratorError, DiagnosticCollector
from common.pl_codegen.model.defines import (COLUMN_TYPES, COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES,
                                      COLUMN_VALUE_TYPES)
from common.pl_codegen.model.parameter import Parameter
from common.pl_codegen.model.parameter_list import PATH_SEPARATOR
from common.pl_codegen.naming import strip_array_indices
from common.pl_codegen.model.tags import (LOG_ID_FIELD, LOG_ID_LABEL, TAG_REGISTRY,
                                          TagKind)
from common.pl_codegen.validation.rules.tag_rules import LOG_ID_MAX
from common.pl_codegen.model.types import VALUE_TYPES

from common.pl_codegen.xml_model.xml_reader import read_xml

from .document import Document


class Api:
    """Every endpoint the front end can call."""

    def __init__(self, document: Document) -> None:
        self.document = document

    # -- dispatch ----------------------------------------------------------
    def handlers(self) -> Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]]:
        return {
            "state": self.state,
            "open": self.open_file,
            "save": self.save,
            "add": self.add,
            "duplicate": self.duplicate,
            "delete": self.delete,
            "move": self.move,
            "update": self.update,
            "undo": self.undo,
            "redo": self.redo,
            "defines": self.set_defines,
            "default_defines": self.default_defines,
            "generate": self.generate,
            "next_log_id": self.next_log_id,
            "lists": self.lists,
            "new_list": self.new_list,
            "select_lists": self.select_lists,
            "browse": self.browse,
            "inspect_list": self.inspect_list,
            "add_existing_list": self.add_existing_list,
            "remove_list": self.remove_list,
            "save_template": self.save_template,
            "delete_template": self.delete_template,
            "use_template": self.use_template,
        }

    # -- reading -------------------------------------------------------------
    def state(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Everything the front end needs to render one full screen.

        ``allLists`` asks for the whole build instead of the open list: every
        list, in build order, as one tree.  It is the view that answers "what
        does the generated table actually contain?", which no single list can.
        """
        document = self.document
        if request.get("allLists"):
            return self._all_lists_state()
        return {
            "tool": {"name": __tool_name__, "version": __version__},
            "file": str(document.path) if document.path else "",
            "dirty": document.dirty,
            "canUndo": document.can_undo,
            "canRedo": document.can_redo,
            "tree": [_node(child, child.name, {}, None,
                           log_ids=_log_ids_by_declaration(document),
                           indices=_indices_by_declaration(document))
                     for child in document.model.parameters],
            "diagnostics": document.validate(),
            "defines": {
                "paramTypes": document.model.defines.get(COLUMN_TYPES),
                "valueTypes": document.model.defines.get(COLUMN_VALUE_TYPES) or list(VALUE_TYPES),
                "systemNames": document.model.defines.get(COLUMN_SYSTEM_NAMES),
                "paramModes": document.model.defines.get(COLUMN_PARAM_MODES),
            },
            # the reusable structure types, offered next to the data types
            "templates": [{"name": template.name,
                           "description": template.description or "",
                           "fields": _leaf_count(template),
                           "shape": _shape(template)}
                          for template in document.templates()],
            "tagSpecs": [
                {
                    "id": spec.tag_id,
                    "label": spec.label,
                    "kind": spec.kind.value,
                    "mandatory": spec.mandatory,
                    "definesColumn": spec.defines_column,
                    "description": spec.description,
                }
                for spec in TAG_REGISTRY
            ],
            # The log id is described separately because it is not a tag: it has
            # no offset area and it is a plain uint16_t in the descriptor, so
            # the editor gives it its own field instead of a row among the tags.
            "logIdSpec": {"field": LOG_ID_FIELD, "label": LOG_ID_LABEL,
                          "max": LOG_ID_MAX,
                          "description": "Identifier the logging sub-system uses for "
                                         "this value. Only meaningful while Tag Loggable "
                                         "is TRUE."},
            "outputDirectory": str(document.config.output.code_directory),
            # every sub-module of the project; the editor works on one at a time
            "modules": [{"path": str(path), "name": path.stem,
                         "current": document.path is not None and path == document.path,
                         "exists": path.is_file()}
                        for path in document.config.inputs.model_files],
        }

    def _all_lists_state(self) -> Dict[str, Any]:
        """The whole build as one read-only tree, in build order.

        Read-only on purpose: a node here can come from any of the files, and an
        edit would have to decide which one to write back to.  Rather than guess,
        the view says which list each entry belongs to and sends you there.
        """
        document = self.document
        state = self.state({})

        merged = document.merged_model()
        owners: Dict[str, str] = {}
        for path in document.config.inputs.model_files:
            if not path.is_file():
                continue
            try:
                if document.path is not None and path.resolve() == document.path.resolve():
                    part = document.model
                else:
                    part = read_xml(path, DiagnosticCollector())
            except Exception:
                continue
            for parameter in part.parameters:
                owners.setdefault(parameter.name, path.name)

        indices = _indices_by_declaration(document)
        log_ids: Dict[str, List[int]] = {}
        for leaf in merged.flatten():
            if leaf.log_id is not None:
                log_ids.setdefault(strip_array_indices(leaf.name), []).append(leaf.log_id)

        tree = []
        for child in merged.parameters:
            node = _node(child, child.name, {}, None,
                         log_ids=log_ids, indices=indices)
            node["ownerList"] = owners.get(child.name, "")
            tree.append(node)

        state["tree"] = tree
        state["allLists"] = True
        state["readOnly"] = True
        state["file"] = f"{len(document.config.inputs.model_files)} list(s), merged"
        return state

    # -- file ------------------------------------------------------------------
    def open_file(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = request.get("path") or None
        diagnostics = self.document.load(Path(path) if path else None)
        return {"ok": True, "diagnostics": diagnostics}

    def save(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = request.get("path") or None
        target = self.document.save(Path(path) if path else None)
        return {"ok": True, "path": str(target)}

    # -- tree editing ------------------------------------------------------------
    def add(self, request: Dict[str, Any]) -> Dict[str, Any]:
        try:
            path = self.document.add_parameter(str(request.get("parent") or ""),
                                               str(request.get("kind") or "primitive"))
        except ValueError as error:
            return {"ok": False, "message": str(error)}
        return {"ok": True, "selected": path}

    def duplicate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.duplicate(str(request.get("path") or ""))
        return {"ok": path is not None, "selected": path}

    def delete(self, request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.delete(str(request.get("path") or ""))}

    def move(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.move(str(request.get("path") or ""),
                                  int(request.get("offset") or 0))
        return {"ok": path is not None, "selected": path}

    def update(self, request: Dict[str, Any]) -> Dict[str, Any]:
        changes = dict(request.get("changes") or {})
        try:
            path = self.document.update(str(request.get("path") or ""), changes)
        except ValueError as error:
            # A refused edit has to SAY why.  Coming back as ok:false with no
            # message would look exactly like the silent no-op this replaced.
            return {"ok": False, "message": str(error)}
        return {"ok": path is not None, "selected": path}

    def undo(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.undo() is not None}

    def redo(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.redo() is not None}

    def set_defines(self, request: Dict[str, Any]) -> Dict[str, Any]:
        column = {"paramTypes": COLUMN_TYPES, "systemNames": COLUMN_SYSTEM_NAMES,
                  "paramModes": COLUMN_PARAM_MODES, "valueTypes": COLUMN_VALUE_TYPES}
        key = str(request.get("list") or "")
        if key not in column:
            return {"ok": False, "message": f"Unknown list '{key}'."}
        self.document.set_defines(column[key], list(request.get("values") or []))
        return {"ok": True}

    def default_defines(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        """The company lists a new model starts with, for the 'restore' button."""
        from .document import DEFAULT_PARAMETER_TYPES, DEFAULT_PARAM_MODES, DEFAULT_SYSTEM_NAMES

        return {
            "ok": True,
            "paramTypes": list(DEFAULT_PARAMETER_TYPES),
            "systemNames": list(DEFAULT_SYSTEM_NAMES),
            "paramModes": list(DEFAULT_PARAM_MODES),
            "types": list(VALUE_TYPES),
        }

    # -- actions --------------------------------------------------------------
    def generate(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        """Generate the code, and turn a tool error into an answer, not a crash.

        The commonest one is a parameter list named in the configuration that is
        not on disk - a state the editor itself shows as "(new)".  Letting that
        become a 500 would leave the page sitting on "Generating..." with nothing
        to read, so it comes back as a failed result with the reason in it.
        """
        try:
            return self.document.generate()
        except (CodeGeneratorError, OSError) as error:
            return {"success": False, "files": [], "count": 0, "saved": "",
                    "modules": [str(path) for path in self.document.config.inputs.model_files],
                    "diagnostics": [], "message": str(error)}

    def next_log_id(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": True, "value": self.document.next_free_log_id()}

    # -- the parameter lists of the project ------------------------------------
    def lists(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "ok": True,
            "directory": str(self.document.list_directory()),
            "config": str(self.document.config.path),
            "lists": self.document.known_lists(),
        }

    def new_list(self, request: Dict[str, Any]) -> Dict[str, Any]:
        try:
            path = self.document.create_list(str(request.get("name") or ""),
                                             str(request.get("directory") or ""))
        except (ValueError, FileExistsError, OSError, CodeGeneratorError) as error:
            return {"ok": False, "message": str(error)}
        return {"ok": True, "path": str(path)}

    def browse(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """The folders and .xml files of one folder, for the Open dialog."""
        try:
            return self.document.browse(str(request.get("directory") or ""))
        except OSError as error:
            return {"ok": False, "message": str(error)}

    def inspect_list(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Whether a file is a parameter list, without adding it to anything."""
        try:
            return self.document.inspect_list(str(request.get("path") or ""))
        except (OSError, CodeGeneratorError) as error:
            return {"ok": False, "reason": str(error)}

    def add_existing_list(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Take a parameter list that already exists into the build."""
        try:
            path = self.document.add_existing_list(str(request.get("path") or ""))
        except (ValueError, OSError, CodeGeneratorError) as error:
            return {"ok": False, "message": str(error)}
        return {"ok": True, "path": str(path)}

    def remove_list(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Take a list out of the build; ``delete`` also removes the file."""
        try:
            result = self.document.remove_list(str(request.get("path") or ""),
                                               bool(request.get("delete")))
        except (ValueError, OSError, CodeGeneratorError) as error:
            return {"ok": False, "message": str(error)}
        return {"ok": True, **result}

    def select_lists(self, request: Dict[str, Any]) -> Dict[str, Any]:
        try:
            chosen = self.document.select_lists(
                [str(item) for item in (request.get("paths") or [])])
        except (OSError, CodeGeneratorError) as error:
            return {"ok": False, "message": str(error)}
        return {"ok": True, "paths": [str(path) for path in chosen]}

    # -- the library of reusable structure types -----------------------------
    def save_template(self, request: Dict[str, Any]) -> Dict[str, Any]:
        name = self.document.save_template(str(request.get("path") or ""),
                                           str(request.get("name") or ""))
        return {"ok": name is not None, "name": name or "",
                "message": "" if name else "Only a structure can become a type."}

    def delete_template(self, request: Dict[str, Any]) -> Dict[str, Any]:
        removed, message = self.document.delete_template(str(request.get("name") or ""))
        return {"ok": removed, "message": message}

    def use_template(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.apply_template(str(request.get("path") or ""),
                                            str(request.get("name") or ""))
        return {"ok": path is not None, "selected": path}


def _leaf_count(template: Parameter) -> int:
    """How many values one copy of *template* adds to the parameter list."""
    total = 0
    for child in template.children:
        total += _leaf_count(child) * max(1, child.array_size) if child.is_struct else 1
    return total


def _shape(template: Parameter) -> List[str]:
    """One line per field, for the tooltip of the type list."""
    lines: List[str] = []
    for child in template.children:
        suffix = f"[{child.array_size}]" if child.array_size > 1 else ""
        kind = "struct" if child.is_struct else (child.value_type_name or "?")
        lines.append(f"{child.name}{suffix} : {kind}")
    return lines


def _log_ids_by_declaration(document) -> Dict[str, List[int]]:
    """``dotted declaration path -> the log ids its values actually got``.

    ``flatten()`` is what hands the ids out, one per value, so this asks it
    rather than trying to work the arithmetic out again in the front end - the
    two could then disagree, and the one the firmware sees is this one.

    The element indices are stripped from the key, so ``Motor[0].Rpm`` and
    ``Motor[1].Rpm`` both answer for the declaration ``Motor.Rpm`` and the
    editor can say "this field holds these ids".
    """
    found: Dict[str, List[int]] = {}
    # the OPEN list, because that is the tree the editor is showing
    for leaf in document.model.flatten():
        if leaf.log_id is None:
            continue
        found.setdefault(strip_array_indices(leaf.name), []).append(leaf.log_id)
    return found


def _indices_by_declaration(document) -> Dict[str, List[Dict[str, Any]]]:
    """``dotted declaration path -> one entry per value it produces``.

    Each entry is ``{index, name, logId}``: the row it occupies in the generated
    table, the element it is (``Motor[2].Winding[1]``), and its log id.  The
    editor needs the individual values, not just their span - the values of one
    field of a struct array are NOT a contiguous run, so "13…25" would be a
    range that mostly belongs to other parameters.

    Taken from the MERGED model, because that is what the generator builds and
    therefore what the index macros count: a parameter's index depends on every
    list before it in the build, not only on its own list.  A list that is not
    part of the build has no indices at all, which is the honest answer - none
    of its parameters reach the generated table.

    A disabled parameter never appears, so it correctly gets no index.
    """
    found: Dict[str, List[Dict[str, Any]]] = {}
    try:
        merged = document.merged_model()
    except Exception:
        # A list elsewhere in the build that will not parse must not stop the
        # editor from drawing the one that is open.
        return found
    for index, leaf in enumerate(merged.flatten()):
        found.setdefault(strip_array_indices(leaf.name), []).append(
            {"index": index, "name": leaf.name, "logId": leaf.log_id})
    return found


def _node(parameter: Parameter, path: str,
          inherited: Dict[str, Any], inherited_type: Any,
          owner: str = "", inherited_log_id: Any = None,
          log_ids: Optional[Dict[str, List[int]]] = None,
          indices: Optional[Dict[str, List[Dict[str, Any]]]] = None,
          parent_enabled: bool = True) -> Dict[str, Any]:
    """One node of the tree, as the front end wants it.

    Tags, the type and the log id belong to the top level entry.  For a field,
    ``owner`` is the name of that entry and ``effectiveTags`` /
    ``effectiveGroup`` / ``effectiveLogId`` are its values - the editor shows
    them read-only instead of an editable form.
    """
    is_field = bool(owner)
    effective = dict(inherited) if is_field else {
        key: value for key, value in parameter.tags.items() if value is not None}
    effective_type = inherited_type if is_field else parameter.param_type

    return {
        "path": path,
        "isField": is_field,
        "owner": owner,
        "name": parameter.name,
        "kind": parameter.kind.value,
        "enable": parameter.enable,
        "gsName": parameter.gs_name,
        "paramType": parameter.param_type,
        "valueType": parameter.value_type_name,
        "arraySize": parameter.array_size,
        "defaultValue": parameter.default_value,
        "minimum": parameter.minimum,
        "maximum": parameter.maximum,
        "resolution": parameter.resolution,
        "unit": parameter.unit,
        "logId": parameter.log_id,
        "effectiveLogId": inherited_log_id if is_field else parameter.log_id,
        # The ids this node's values really got, straight from flatten().  A
        # scalar has one; an array, or a field of an array of structures, has
        # one per value.
        "logIds": (log_ids or {}).get(path, []),
        # The rows this declaration occupies in the generated table.  Empty for
        # a structure (it is not a row), for a disabled parameter, and for a
        # list that is not part of the build.
        # One entry per value this declaration produces: {index, name, logId}.
        # The editor can show the span when it is a run, and expand into the
        # individual values when it is not.
        "values": (indices or {}).get(path, []),
        # Whether this value reaches the generated table at all.  A field of a
        # disabled structure keeps its own enable flag - it is still ticked, and
        # re-enabling the structure brings it back exactly as it was - but it is
        # NOT in the build, and a tree that showed it as enabled was telling the
        # reader the opposite of what the generator does.
        "effectiveEnable": bool(parameter.enable) and parent_enabled,
        "parentEnabled": parent_enabled,
        "description": parameter.description,
        "tags": {spec.tag_id: parameter.tags.get(spec.tag_id) for spec in TAG_REGISTRY},
        "effectiveTags": {spec.tag_id: effective.get(spec.tag_id) for spec in TAG_REGISTRY},
        "effectiveType": effective_type,
        "children": [_node(child, f"{path}{PATH_SEPARATOR}{child.name}",
                           effective, effective_type, owner or parameter.name,
                           inherited_log_id if is_field else parameter.log_id,
                           log_ids, indices,
                           bool(parameter.enable) and parent_enabled)
                     for child in parameter.children],
    }

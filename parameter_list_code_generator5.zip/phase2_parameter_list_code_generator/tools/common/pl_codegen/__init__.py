"""Parameter-list code generator - the part that is the same in every phase.

This package reads a parameter list as XML, checks it, and writes the C files.
It knows nothing about where the XML came from, which is what lets every phase
share it: a phase puts its own front end in front of it - this one a graphical
editor (``tools/pl_gui``) - and the same model always produces the same C.
Same files, same classes, same API in every phase; only the wording of the
messages differs, because each one names the input its own users see.

Everything under here is deliberately split into small, single-responsibility
modules, so that changing one aspect of the generated code means finding and
editing exactly one file:

    config.py          -> how the tool is configured
    errors.py          -> how problems are reported
    naming.py          -> how C identifiers are derived from parameter names
    pipeline.py        -> the run: XML -> model -> checks -> offsets -> files
    model/             -> the in-memory description of a parameter list
    xml_model/         -> model  <-> XML (the source of truth on disk)
    validation/        -> model  -> diagnostics
    layout/            -> model  -> the MemoryOffset of every tag
    codegen/           -> model  -> C source/header files

Anything phase-specific belongs *outside* this package. A change made here has
to be copied to the other phase, so that both keep generating identical C.
"""

__version__ = "2.0.0"
__tool_name__ = "parameter_list_code_generator"

__all__ = ["__version__", "__tool_name__"]

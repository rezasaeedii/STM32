"""Loading and validating ``codegen_config.json``.

The configuration file is the one place that says what the project is: which
parameter lists it is made of, in what order they are merged, and where the
generated code goes.  All paths inside it are resolved relative to the
configuration file itself, so the tool can be run from any working directory.

Phase 2 supports exactly one input - the graphical editor - so there is no
setting that says which front end owns the list.
"""

from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .errors import CodeGeneratorError
from .logging_utils import get_logger

#: What a generated file name / include guard may be made of.
_NAME_SAFE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

#: An indent string may only be made of spaces and tabs.  Anything else is put
#: at the start of generated C lines and simply does not compile.
_INDENT_SAFE = re.compile(r"[ \t]+")

_TRAILING_COMMA = re.compile(r",(\s*[}\]])")
_LINE_COMMENT = re.compile(r"^\s*//.*$", re.MULTILINE)


def load_jsonc(path: Path) -> Dict[str, Any]:
    """Load a JSON file that may contain ``//`` comments and trailing commas.

    The company's ``c.json`` snippet file uses the VS Code JSON-with-comments
    dialect, and it is convenient to allow the same in our own config file.
    """
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        raise CodeGeneratorError(f"Cannot read '{path}': {exc}") from exc

    text = _LINE_COMMENT.sub("", text)
    text = _TRAILING_COMMA.sub(r"\1", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise CodeGeneratorError(f"'{path}' is not valid JSON: {exc}") from exc


@dataclass
class InputConfig:
    """Where the parameter list comes from.

    A project is usually split over several units, each owned by a different
    team.  All of their lists live in one folder and this says which of them
    take part in a build and in what order; the generator merges them into one
    list, exactly as if they had been one file.
    """

    #: the XML models, in order.  The first one is the one the editor opens by
    #: default; every one of them is a sub-module of the project.
    model_files: List[Path] = field(default_factory=lambda: [Path("../parameter_list.xml")])
    #: The folder that holds the parameter lists of the project.  A bare file
    #: name in ``model_files`` is looked up here, so a project keeps all of its
    #: lists in one place and the configuration only says which of them take
    #: part and in what order.  A path with a folder in it still works, so a
    #: sub-module that insists on keeping its list next to its own code can.
    model_directory: Path = Path("../parameter_lists")

    @property
    def model_file(self) -> Path:
        """The first model file - what a single-list project has."""
        return self.model_files[0]


@dataclass
class OutputConfig:
    code_directory: Path = Path("../cg_parameter_list")
    #: A copy of the merged model, written next to the generated code after
    #: every run.  It is what the next run compares against to see whether the
    #: memory layout moved, and it is never written over a list the editor owns.
    xml_file: Path = Path("../model_snapshot/parameter_list.xml")
    file_prefix: str = "cg_"
    base_name: str = "parameter_list"


@dataclass
class StyleConfig:
    snippet_file: Optional[Path] = None
    company: str = "FAS"
    indent: str = "    "


@dataclass
class CodegenConfig:
    emit_description: bool = True
    emit_unit: bool = True
    emit_generation_info: bool = True
    emit_timestamp: bool = True
    index_define_prefix: str = ""
    offset_define_prefix: str = "PARAMETER_LIST_"
    smart_data_prefix: str = "Cg_SmartData_"
    struct_type_prefix: str = "sCgStruct_"
    descriptor_symbol: str = "ParameterList"
    quantity_define: str = "PARAMETER_LIST_QTY"
    #: extra ``#include`` lines for the generated .c file.  A free tag
    #: (Tag1..Tag4) may hold an application constant such as ``APP_FLAG_X``;
    #: without the header that declares it the generated file will not compile.
    extra_includes: List[str] = field(default_factory=list)


@dataclass
class ValidationConfig:
    treat_warnings_as_errors: bool = False
    require_description: bool = False
    require_unit: bool = False


@dataclass
class Config:
    """Fully resolved configuration."""

    path: Path
    inputs: InputConfig = field(default_factory=InputConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    style: StyleConfig = field(default_factory=StyleConfig)
    codegen: CodegenConfig = field(default_factory=CodegenConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)

    # -- loading ---------------------------------------------------------
    @classmethod
    def load(cls, config_path: Union[str, Path]) -> "Config":
        # A plain string is what a caller reaches for first, and the bare
        # AttributeError it used to raise said nothing about the file at all.
        config_path = Path(config_path).expanduser().resolve()
        if not config_path.is_file():
            raise CodeGeneratorError(f"Configuration file '{config_path}' does not exist.")

        data = load_jsonc(config_path)
        root = config_path.parent

        def resolve(value: str) -> Path:
            candidate = Path(str(value)).expanduser()
            return candidate if candidate.is_absolute() else (root / candidate).resolve()

        _warn_unknown_sections(data)

        raw_inputs = data.get("inputs", {}) or {}
        _warn_unknown_keys("inputs", raw_inputs,
                           {"model_files", "model_file", "model_directory"})

        # 'model_files' is the list; 'model_file' is the one-file spelling of
        # the same thing, kept so a single-list config stays short.
        model_entries = raw_inputs.get("model_files") or []
        if not model_entries:
            model_entries = [raw_inputs.get("model_file", "../parameter_list.xml")]

        # A bare name such as "navigation.xml" means "the one in the project's
        # parameter-list folder"; anything with a folder in it keeps meaning
        # what it always meant, relative to this configuration file.
        model_directory = resolve(raw_inputs.get("model_directory", "../parameter_lists"))

        def resolve_model(entry: str) -> Path:
            candidate = Path(str(entry)).expanduser()
            if candidate.is_absolute() or candidate.parent != Path("."):
                return resolve(entry)
            return (model_directory / candidate).resolve()

        inputs = InputConfig(
            model_files=[resolve_model(entry) for entry in model_entries],
            model_directory=model_directory,
        )

        raw_output = data.get("output", {}) or {}
        _warn_unknown_keys("output", raw_output,
                           {"code_directory", "xml_file", "file_prefix", "base_name"})
        output = OutputConfig(
            code_directory=resolve(raw_output.get("code_directory", "../cg_parameter_list")),
            xml_file=resolve(raw_output.get("xml_file", "../model_snapshot/parameter_list.xml")),
            file_prefix=str(raw_output.get("file_prefix", "cg_")),
            base_name=str(raw_output.get("base_name", "") or inputs.model_file.stem),
        )

        raw_style = data.get("style", {}) or {}
        _warn_unknown_keys("style", raw_style, {"snippet_file", "company", "indent"})
        snippet = raw_style.get("snippet_file")
        style = StyleConfig(
            snippet_file=resolve(snippet) if snippet else None,
            company=str(raw_style.get("company", "FAS")),
            indent=str(raw_style.get("indent", "    ")),
        )

        codegen = _dataclass_from_dict(CodegenConfig, data.get("codegen") or {}, "codegen")
        validation = _dataclass_from_dict(ValidationConfig, data.get("validation") or {},
                                          "validation")
        codegen.extra_includes = [str(entry) for entry in (codegen.extra_includes or [])]

        config = cls(path=config_path, inputs=inputs, output=output, style=style,
                     codegen=codegen, validation=validation)
        config.validate()
        return config

    # -- checks ----------------------------------------------------------
    def validate(self) -> None:
        if self.style.snippet_file is not None and not self.style.snippet_file.is_file():
            raise CodeGeneratorError(
                f"Style snippet file '{self.style.snippet_file}' does not exist.")

        # 'indent' is written at the start of every indented line of generated
        # C.  Anything that is not whitespace turns into a syntax error in a
        # file the user never wrote, so it is refused here where the message can
        # still say which setting is at fault.
        if not self.style.indent or not _INDENT_SAFE.fullmatch(self.style.indent):
            shown = self.style.indent.replace("\t", "\\t")
            raise CodeGeneratorError(
                f"style.indent is '{shown}'. It is put at the start of every indented "
                f"line of the generated C code, so it may contain only spaces and tabs.\n"
                f"Set 'indent' in the 'style' section of {self.path.name} to spaces "
                f"(for example four of them) or to a tab.")

        # The file names become C include guards and #include lines, so they
        # have to survive being turned into identifiers.
        for key, value in (("output.base_name", self.output.base_name),
                           ("output.file_prefix", self.output.file_prefix)):
            if value and not _NAME_SAFE.fullmatch(value):
                raise CodeGeneratorError(
                    f"{key} is '{value}'. It becomes part of a file name and of a C "
                    f"include guard, so it may hold only letters, digits and '_'.\n"
                    f"Set '{key.split('.')[1]}' in the 'output' section of "
                    f"{self.path.name} to a plain name.")

    # -- helpers ---------------------------------------------------------
    def generated_file_name(self, suffix: str, extension: str) -> str:
        """``suffix='defines', extension='h'`` -> ``cg_parameter_list_defines.h``."""
        stem = f"{self.output.file_prefix}{self.output.base_name}"
        if suffix:
            stem = f"{stem}_{suffix}"
        return f"{stem}.{extension}"

    def smart_data_file_name(self, extension: str) -> str:
        return f"{self.output.file_prefix}smart_data.{extension}"


def _closest(key: str, candidates: Any) -> Optional[str]:
    """The known key closest to *key*, or ``None`` when nothing is close."""
    matches = difflib.get_close_matches(key, sorted(candidates), n=1, cutoff=0.7)
    return matches[0] if matches else None


def _warn_unknown_sections(data: Dict[str, Any]) -> None:
    """A whole section spelled wrongly does nothing at all - say so."""
    known = {"inputs", "output", "style", "codegen", "validation"}
    logger = get_logger()
    for key in sorted(key for key in data if key not in known):
        suggestion = _closest(key, known)
        hint = f" Did you mean '{suggestion}'?" if suggestion else ""
        logger.warning("Unknown configuration section '%s' - it is ignored.%s", key, hint)


def _warn_unknown_keys(section: str, data: Dict[str, Any], known: Any) -> None:
    """Same check for the sections that are not built from a dataclass."""
    logger = get_logger()
    for key in sorted(key for key in data if key not in known):
        suggestion = _closest(key, known)
        hint = f" Did you mean '{suggestion}'?" if suggestion else ""
        logger.warning("Unknown configuration key '%s.%s' - it is ignored.%s",
                       section, key, hint)


def _dataclass_from_dict(cls: type, data: Dict[str, Any], section: str = "") -> Any:
    """Build a dataclass from a dict, warning about keys it does not know.

    An unknown key is nearly always a typo - ``emit_timestemp`` instead of
    ``emit_timestamp``.  Silently dropping it means the user changes the setting,
    sees no effect, and has no way of finding out why, so it is reported.
    """
    known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    unknown = sorted(key for key in data if key not in known)
    if unknown:
        logger = get_logger()
        for key in unknown:
            suggestion = _closest(key, known)
            hint = f" Did you mean '{suggestion}'?" if suggestion else ""
            logger.warning("Unknown configuration key '%s%s' - it is ignored.%s",
                           f"{section}." if section else "", key, hint)
    return cls(**{key: value for key, value in data.items() if key in known})

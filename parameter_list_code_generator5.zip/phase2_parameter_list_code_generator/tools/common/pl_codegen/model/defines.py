"""The drop-down lists: the allowed values for the enum-like fields."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

#: Names of the drop-down lists.
COLUMN_TYPES = "TYPE"
COLUMN_VALUE_TYPES = "VALUE TYPES"
COLUMN_SYSTEM_NAMES = "SYSTEM NAMES"
COLUMN_PARAM_MODES = "PARAM MODES"
COLUMN_BOOLEANS = "BOOLEANS"

#: Columns that are turned into a generated C enumeration.
GENERATED_ENUMS: Dict[str, str] = {
    COLUMN_SYSTEM_NAMES: "eParameterListSystemName",
    COLUMN_PARAM_MODES: "eParameterListParamMode",
}


@dataclass
class Defines:
    """Allowed values collected from every parameter list of the project."""

    values: Dict[str, List[str]] = field(default_factory=dict)

    def add(self, column: str, value: str) -> None:
        bucket = self.values.setdefault(column.upper(), [])
        if value not in bucket:
            bucket.append(value)

    def get(self, column: str) -> List[str]:
        return self.values.get(column.upper(), [])

    def contains(self, column: str, value: str) -> bool:
        return value in self.get(column)

    def merge(self, other: "Defines") -> None:
        for column, entries in other.values.items():
            for entry in entries:
                self.add(column, entry)

    @property
    def param_types(self) -> List[str]:
        return self.get(COLUMN_TYPES)

    @property
    def types(self) -> List[str]:
        return self.get(COLUMN_VALUE_TYPES)

    @property
    def system_names(self) -> List[str]:
        return self.get(COLUMN_SYSTEM_NAMES)

    @property
    def param_modes(self) -> List[str]:
        return self.get(COLUMN_PARAM_MODES)


def type_enum_member(param_type: str) -> str:
    """``MONITORING`` -> ``ePARAMETER_TYPE_MONITORING`` (see parameter_descriptor.h)."""
    return f"ePARAMETER_TYPE_{param_type.strip().upper()}"

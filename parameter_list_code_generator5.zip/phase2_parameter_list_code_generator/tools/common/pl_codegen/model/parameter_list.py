"""The whole parameter list: a tree of parameters plus the allowed values."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Tuple

from dataclasses import replace

from ..errors import SourceLocation
from .defines import Defines
from .parameter import Parameter, ParameterKind, TagValue

#: separator between a struct and its field in a flattened name
PATH_SEPARATOR = "."

# The log id is not a tag and is not copied to the leaves: it is spread over
# them, one id per value.  See _distribute_log_ids.


@dataclass
class ParameterList:
    """All parameters of the project, as a tree."""

    parameters: List[Parameter] = field(default_factory=list)
    defines: Defines = field(default_factory=Defines)
    source_files: List[str] = field(default_factory=list)
    generator_version: str = ""
    generated_at: str = ""

    #: Reusable structure types, offered in the editor next to ``float32_t`` and
    #: the other data types.  A template is a structure node with fields but no
    #: tags and no type: picking one *copies* its fields into a new parameter,
    #: which then owns them - its limits and its tags are edited like any other
    #: parameter's.  Nothing in this list is generated; only the copies are.
    templates: List[Parameter] = field(default_factory=list)

    # -- collection behaviour -------------------------------------------
    def __iter__(self) -> Iterator[Parameter]:
        return iter(self.parameters)

    def __len__(self) -> int:
        return len(self.parameters)

    def add(self, parameter: Parameter) -> None:
        self.parameters.append(parameter)

    def extend(self, other: "ParameterList") -> None:
        """Append another sub-module's list to this one.

        The result is exactly what one big list would have been: the order of
        the modules decides the order of the indices, and the drop-down lists
        are merged.  Duplicate names or overlapping log ids across modules are
        found by the normal validation afterwards, which names the file each
        parameter came from.
        """
        self.parameters.extend(other.parameters)
        self.defines.merge(other.defines)
        for name in other.source_files:
            if name not in self.source_files:
                self.source_files.append(name)
        # The type library is shared by the whole project, so a template defined
        # in one sub-module is offered in all of them.  The first definition of a
        # name wins; a second one is a different structure with the same name,
        # and silently replacing the first would change what the other module
        # generates.
        taken = {template.name for template in self.templates}
        for template in other.templates:
            if template.name not in taken:
                self.templates.append(template)
                taken.add(template.name)

    # -- the tree ---------------------------------------------------------
    def walk(self) -> Iterator[Parameter]:
        """Every node of the tree, parents before children."""
        for parameter in self.parameters:
            yield from parameter.walk()

    @property
    def enabled(self) -> List[Parameter]:
        """Top level parameters that take part in code generation."""
        return [parameter for parameter in self.parameters if parameter.enable]

    @property
    def disabled(self) -> List[Parameter]:
        return [parameter for parameter in self.parameters if not parameter.enable]

    def find(self, dotted_name: str) -> Optional[Parameter]:
        """Look a node up by its dotted path, e.g. ``Position.Home.Lat``."""
        nodes = self.parameters
        found: Optional[Parameter] = None
        for part in dotted_name.split(PATH_SEPARATOR):
            found = next((node for node in nodes if node.name == part), None)
            if found is None:
                return None
            nodes = found.children
        return found

    def assign_paths(self) -> None:
        """Write the dotted path of every node into its ``source.parameter``.

        Diagnostics then always tell the user *which* parameter they are about,
        and the GUI can jump straight to it.
        """
        for parameter in self.parameters:
            _stamp(parameter, [])

    # -- flattening --------------------------------------------------------
    def flatten(self) -> List[Parameter]:
        """Every enabled *leaf*, with a dotted name and a C access expression.

        A struct contributes no entry of its own; only its fields do.  Every
        leaf of a top level entry gets **that entry's** tags and type - a
        structure is classified as one thing, and its fields inherit the
        classification without being able to contradict it.

        The log id is not copied, because it identifies a single value and is
        not a tag at all.  A structure's log id is the *first* id of a block,
        and the leaves take consecutive ids out of it, one per value - so an
        array takes one id per element and the data type plays no part at all
        (see :func:`_distribute_log_ids`).
        """
        self.assign_paths()
        leaves: List[Parameter] = []
        for parameter in self.enabled:
            first = len(leaves)
            _collect(parameter, [], dict(parameter.tags), parameter.param_type, leaves)
            _distribute_log_ids(leaves[first:], parameter)
        return leaves

    def struct_parameters(self) -> List[Tuple[str, Parameter]]:
        """Every enabled struct as ``(dotted path, node)``, deepest first.

        Deepest first is the order the C typedefs have to be emitted in: an
        inner structure must be declared before the structure that uses it.
        """
        found: List[Tuple[str, Parameter]] = []
        for parameter in self.enabled:
            _collect_structs(parameter, [], found)
        return found

    def array_nodes(self) -> List[Tuple[str, Parameter]]:
        """Every enabled node that is an array, as ``(dotted path, node)``.

        This is the list the ``..._ARRAY_SIZE`` macros are made from, and it is
        deliberately built from the *tree* rather than from the leaves: an array
        size describes a declaration.  ``Wheels[0].Samples`` and
        ``Wheels[1].Samples`` are two values of one declaration, so the tree
        holds ``Wheels.Samples`` once and one macro is emitted for it.
        Structures are included, because a struct array is a real C array.
        """
        found: List[Tuple[str, Parameter]] = []
        for parameter in self.enabled:
            _collect_arrays(parameter, [], found)
        return found

    # -- views used by the code generator ---------------------------------
    def used_data_type_suffixes(self) -> List[str]:
        suffixes: List[str] = []
        for leaf in self.flatten():
            value_type = leaf.value_type
            if value_type is not None and value_type.suffix not in suffixes:
                suffixes.append(value_type.suffix)
        return suffixes

    def has_array_parameters(self) -> bool:
        """Whether any *declaration* is an array.

        The leaves cannot answer this any more: every element of an array is
        its own leaf and every leaf is one value, so asking them would always
        say "no" - and the generated init function would then be missing the
        loop counter it declares up front.
        """
        return any(node.is_array
                   for parameter in self.enabled
                   for node in parameter.walk())

    def by_name(self) -> Dict[str, Parameter]:
        return {parameter.name: parameter for parameter in self.parameters}


def _collect(node: Parameter, path: List[str], tags: Dict[str, TagValue],
             param_type: Optional[str], leaves: List[Parameter]) -> None:
    """Walk one node and append its leaves to *leaves*.

    *path* is how the value is reached from the top level entry, written the way
    C writes it - ``['Wheels[1]', 'Speed']``.  *tags* and *param_type* come from
    the top level entry and are handed down unchanged: a field never overrides
    them.
    """
    if not node.enable:
        return

    count = max(1, node.array_size)

    if node.kind is ParameterKind.STRUCT:
        # An array of structures is expanded element by element: the same field
        # of two elements is not adjacent in memory (the elements are strided by
        # sizeof(struct)), so one entry could never describe them all.
        for index in range(count):
            element = path + [node.name if count == 1 else f"{node.name}[{index}]"]
            for child in node.children:
                _collect(child, element, tags, param_type, leaves)
        return

    # A primitive array is expanded the same way, and for the same reason the
    # descriptor no longer carries an ArraySize: **every row of the table is one
    # value**.  'PosDrone' with an array size of 4 is four rows - PosDrone[0] ..
    # PosDrone[3] - each with its own index, its own offsets and its own log id,
    # so a reader of the table never has to ask "how many values is this row?".
    # The C object stays a real array (Cg_SmartData_PosDrone[4]); it is only the
    # table that gained a row per element.
    for index in range(count):
        # The logical name and the C access expression are the same text on
        # purpose: a value is called what it is written as, so a diagnostic
        # about 'Wheels[1].Speed' names something the reader can paste straight
        # into a debugger.
        leaf_name = node.name if count == 1 else f"{node.name}[{index}]"
        dotted = PATH_SEPARATOR.join(path + [leaf_name])

        leaf = node.copy_as_leaf(dotted, dotted, tags)
        leaf.param_type = param_type
        # One row is one value.  The array size stays on the *declaration* (it
        # is what sizes the C object and what the size macro reports), but a row
        # that described N values would put the ArraySize field back in through
        # the side door.
        leaf.array_size = 1
        leaf.element_index = index if count > 1 else None
        leaf.declared_array_size = count
        leaves.append(leaf)


def _distribute_log_ids(block: List[Parameter], root: Parameter) -> None:
    """Give every leaf of one top level entry its own log id.

    The entry's ``log_id`` is the first id of the block; each leaf then takes
    one id per value - its array size - in tree order::

        Position          log_id = 400
          Home.Lat        float64_t     -> 400
          Home.Lon        float64_t     -> 401
          Alt             float32_t     -> 402
          Samples         int16_t[8]    -> 403 .. 410

    For a plain value the block holds a single leaf, so it simply keeps the id
    that was entered - exactly as before structures existed.
    """
    first = root.log_id
    if not isinstance(first, int) or isinstance(first, bool):
        return

    cursor = first
    for leaf in block:
        leaf.log_id = cursor
        # one id per value, exactly as for a plain parameter: a log id numbers a
        # value, not a byte, so the type plays no part
        cursor += max(1, leaf.array_size)


def _stamp(node: Parameter, path: List[str]) -> None:
    path = path + [node.name]
    node.source = replace(node.source, parameter=PATH_SEPARATOR.join(path))
    for child in node.children:
        _stamp(child, path)


def _collect_arrays(node: Parameter, path: List[str],
                    found: List[Tuple[str, Parameter]]) -> None:
    """Append every enabled array node below (and including) *node*."""
    if not node.enable:
        return
    path = path + [node.name]
    if node.is_array:
        found.append((PATH_SEPARATOR.join(path), node))
    for child in node.children:
        _collect_arrays(child, path, found)


def _collect_structs(node: Parameter, path: List[str],
                     found: List[Tuple[str, Parameter]]) -> None:
    """Append struct nodes as ``(dotted path, node)``, children before parent."""
    if not node.enable or node.kind is not ParameterKind.STRUCT:
        return
    path = path + [node.name]
    for child in node.children:
        _collect_structs(child, path, found)
    found.append((PATH_SEPARATOR.join(path), node))

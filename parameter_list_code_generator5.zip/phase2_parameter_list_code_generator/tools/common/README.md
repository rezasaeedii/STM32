# common/ — the shared core

This folder is the code generator itself: the data model, the XML reader and
writer, the validation rules, the tag-offset map and the C code builders.
**Every phase of the project has this same folder** — the same files, the same
classes, the same API — so that the same model always produces the same C.

It knows exactly one input: the XML model. Where that XML comes from is the
phase's business - in this phase it is the graphical editor in `../pl_gui/`,
and that is the only front-end folder here.

The copies of this folder in different phases are not quite byte-identical, and
the reason is worth knowing: **each phase supports exactly one input**, so the
wording of a message names the input that phase's users actually see. That is
the only difference. Nothing about the model, the offsets, the validation or
the generated C differs between phases.

**Do not change the behaviour of this folder in one phase only.** Make the
change once and carry it across, or the two phases stop agreeing.

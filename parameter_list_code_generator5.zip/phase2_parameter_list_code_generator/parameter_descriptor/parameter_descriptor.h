/**
  ******************************************************************************
  * @file    parameter_descriptor.h
  * @brief   Hand written description of one parameter of the parameter list.
  *
  * This file is NOT generated; it defines the shape of the table that the code
  * generator fills in. Whenever a field is added here, the field order in
  * tools/pl_codegen/codegen/descriptor_layout.py has to be updated as well,
  * because the generated initialiser uses designated initialisers in
  * declaration order (valid in C99 and in C++20).
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef PARAMETER_DESCRIPTOR_H
#define PARAMETER_DESCRIPTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

#include "smart_data.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief What a parameter is: a monitored value, a setting, or a command.
 *
 */
typedef enum {

    ePARAMETER_TYPE_MONITORING = 0,
    ePARAMETER_TYPE_SETTING,
    ePARAMETER_TYPE_COMMAND

} eParameterType;

/**
 * @brief One tag of a parameter.
 *
 * @note  Value is wide enough to hold a boolean flag and an enumerator of the
 *        generated enumerations.
 * @note  MemoryOffset is the byte offset of this parameter inside the area
 *        that belongs to this tag. Every tag owns an independent area whose
 *        cursor advances by sizeof(value) * ArraySize for every parameter
 *        carrying the tag, so the same parameter usually has a different
 *        offset per tag. The offsets are computed by the code generator and
 *        exported as macros in cg_parameter_list_defines.h.
 *
 */
typedef struct {

    uint32_t Value;

    uint32_t MemoryOffset;

} sParameterTag;

/**
 * @brief Full description of one parameter.
 *
 * @note  The fields must stay in this order; the generated table relies on it.
 * @note  One descriptor is exactly one value. An array declaration of N
 *        elements produces N descriptors - PosDrone[0] .. PosDrone[N-1] - each
 *        with its own index, its own tag offsets and its own log id. There is
 *        deliberately no ArraySize field: the size of the declaration is a
 *        compile time constant and lives in the generated
 *        <NAME>_ARRAY_SIZE macro, not in the table.
 * @note  The physical unit lives on the smart data object
 *        (pSmartData->_core.pUnit), not here, so a value carries its own unit
 *        wherever it is passed.
 *
 */
typedef struct {

    const char * pName;                         /*!< Name of the parameter, as it was written in the editor. */

    eParameterType Type;                        /*!< What the parameter IS: monitoring, a setting, or a command. */

    void * pSmartData;                          /*!< Smart data object holding this one value. An array declaration gives one descriptor per element, each pointing at its own element. */

    uint16_t LogId;                             /*!< Identifier the logging sub-system uses for this value. Meaningful only while TagLoggable is TRUE; 0 otherwise. An array takes one consecutive id per element. */

    sParameterTag TagSystemName;

    sParameterTag TagResetProof;

    sParameterTag TagLoggable;

    sParameterTag TagLogEncryption;

    sParameterTag TagParamMode;

    sParameterTag Tag1;

    sParameterTag Tag2;

    sParameterTag Tag3;

    sParameterTag Tag4;

    const char * pDescription;                  /*!< Free text description; "" when there is none, never NULL. */

} sParameterDescriptor;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* PARAMETER_DESCRIPTOR_H */

/* === Copyright (c) 2026 FAS === EOF === */

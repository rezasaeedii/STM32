"""Tests of the editor: the half of the tool that a person actually clicks.

Everything here goes through :class:`pl_gui.api.Api`, which is exactly what the
browser calls, so a test passing here means the button in the toolbar works.
The whole thing runs on a *copy* of the project in a temporary folder, so it can
create files, rewrite the configuration and reorder the build without ever
touching the project the user is working in.

Run it with::

    python tests/run_editor_test.py
"""

from __future__ import annotations

import ast
import shutil
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable, List, Tuple

#: The app folder: the editor, the generator, the templates, the manuals.
APP_DIR = Path(__file__).resolve().parent.parent
#: The folder holding app/ and the projects, for the whole-tree scans.
ROOT_DIR = APP_DIR.parent
sys.path.insert(0, str(APP_DIR / "src"))

from pl_codegen.config import Config          # noqa: E402
from pl_codegen.errors import DiagnosticCollector          # noqa: E402
from pl_codegen.xml_model.xml_reader import read_xml       # noqa: E402
from pl_codegen.xml_model.xml_writer import write_xml      # noqa: E402
from pl_codegen.logging_utils import (BOLD, BRIGHT_RED, GREEN,  # noqa: E402
                                            colour_supported, paint)
import pl_codegen.logging_utils as _logging_utils  # noqa: E402
from pl_codegen.app_home import (LIB_TEMPLATE_DIR, PROJECT_FILE_NAME,
                                 PROJECT_TEMPLATE)
from pl_codegen.model.struct_type import StructTypeLibrary
from pl_codegen.xml_model.types_xml import is_types_file
from pl_gui.api import Api
from pl_gui.workspace import Workspace                           # noqa: E402
from pl_gui.document import Document                 # noqa: E402
from pl_gui.config_file import rewrite_model_files   # noqa: E402

_logging_utils._colour_enabled = colour_supported()


class Failure(AssertionError):
    """One expectation that did not hold."""


def check(condition: bool, message: str) -> None:
    if not condition:
        raise Failure(message)


def equal(actual, expected, message: str) -> None:
    if actual != expected:
        raise Failure(f"{message}: expected {expected!r}, got {actual!r}")


# --------------------------------------------------------------- the fixture
def open_copy(work: Path, *, empty: bool = False) -> Tuple[Document, Api, Path]:
    """A Document on a throw-away copy of the project.

    With ``empty`` the document is emptied of parameters before the test starts,
    so a case can say exactly what the list contains without depending on what
    the project happens to hold today.  The drop-down lists are kept - a case
    that adds a parameter needs a type and a system name to give it.

    Emptying the open list is *not* enough on its own.  ``Api.state`` reports
    the type library of the whole project (``merged_model().templates``),
    because a type one list defines is offered in every other - so a structure
    somebody happened to save in another list would show up in a case that
    thought it had started from nothing.  The other lists are therefore emptied
    on disk as well, which is what makes ``empty`` mean empty.
    """
    config_path = _a_project(work / "project")
    _build_from_the_list_folder(config_path)
    document = Document(Config.load(config_path))
    document.load()
    if empty:
        _empty_the_other_lists(document)
        document.model.parameters.clear()
        document.model.struct_types = StructTypeLibrary()

    # The Api works for a workspace - the editor opens one project at a time -
    # so the copy is handed to one directly.  Opening it the ordinary way
    # would put a temp folder into the user's recent-projects list, and it
    # would be gone before they ever saw it.
    workspace = Workspace()
    workspace.adopt(document)
    return document, Api(workspace), config_path


#: Three small lists, so the cases about several lists have something real to
#: work on.  The first is the one the tests edit.
_FIXTURE_LISTS = ("main", "navigation", "power")


def _a_project(root: Path) -> Path:
    """Build a throw-away project and return its project file.

    Written from scratch every time, in the temp folder the case was given.
    It used to COPY the demo project out of the user's own tree - which meant
    the tests read whatever happened to be in it that day, and one of them
    reached far enough to write into it.  A test must never be able to touch
    somebody's work, and a fixture it builds itself is also the only fixture
    that says, in one place, exactly what the cases are standing on.
    """
    (root / "parameter_lists").mkdir(parents=True, exist_ok=True)
    for name in _FIXTURE_LISTS:
        (root / "parameter_lists" / f"{name}.xml").write_text(
            _FIXTURE_LIST, encoding="utf-8")
    shutil.copytree(LIB_TEMPLATE_DIR, root / "lib", dirs_exist_ok=True)

    settings = PROJECT_TEMPLATE.read_text(encoding="utf-8").replace("{{NAME}}", "Fixture")
    settings = settings.replace(
        '"model_files": [],',
        '"model_files": [' + ", ".join(f'"{name}.xml"' for name in _FIXTURE_LISTS) + '],')
    target = root / PROJECT_FILE_NAME
    target.write_text(settings, encoding="utf-8")
    return target


_FIXTURE_LIST = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Parameters>
    <Parameter name="Airspeed" kind="primitive" enable="true" gsName="Airspeed"
               type="MONITORING" valueType="float32_t" arraySize="1" unit="m/s"
               logId="100">
      <Source />
      <Limits default="0" minimum="0" maximum="120" resolution="0.01" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="false" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Description>How fast the air is going past.</Description>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""


def _build_from_the_list_folder(config_path: Path) -> None:
    """Point the copy's build at the lists in ``parameter_lists/``.

    A test must measure the editor, not the configuration the user happens to
    have open.  Working on one list, at a path of your own choosing, outside the
    list folder, is a supported thing to do - so a suite that asserted "every
    list is in the folder" against the live configuration was reporting the
    user's working state as a failure of the tool.

    The copy is therefore put into the state the project ships in, and the cases
    that care about several lists, or about the folder, have something stable to
    stand on.  The rewrite goes through the same JSONC editor the GUI uses, so
    the comments in the configuration survive - which one of the cases checks.
    """
    lists = sorted(path for path
                   in (config_path.parent / "parameter_lists").glob("*.xml")
                   if not is_types_file(path))
    if lists:
        rewrite_model_files(config_path, [path.name for path in lists])


def _empty_the_other_lists(document: Document) -> None:
    """Strip every list of the build except the open one, on disk."""
    for path in document.config.inputs.model_files:
        if path == document.path or not path.is_file():
            continue
        other = read_xml(path, DiagnosticCollector())
        other.parameters.clear()
        other.struct_types = StructTypeLibrary()
        write_xml(other, path, emit_timestamp=False)


# --------------------------------------------------------------- the cases
def test_structure_types(work: Path) -> None:
    """A structure is OF a type, and editing the type reaches every one of them.

    The old behaviour this replaces: a "type" was a copy, so a parameter built
    from one went its own way the moment it was made.  Now the type owns the
    shape and the parameter owns the limits, and there is a case for each half.
    """
    document, api, _config = open_copy(work, empty=True)

    made = api.new_type({"name": "sPosition", "description": "Where something is."})
    check(made["ok"], f"the type was not declared: {made}")
    check(api.update_type({"name": "sPosition", "changes": {"fields": [
        {"name": "Lat", "valueType": "float64_t", "arraySize": 1, "unit": "deg"},
        {"name": "Samples", "valueType": "int16_t", "arraySize": 4},
    ]}})["ok"], "the type's fields were not set")

    listed = api.state({})["structTypes"]
    equal([item["name"] for item in listed], ["sPosition"], "the type list")
    equal(len(listed[0]["fields"]), 2, "how many fields it has")

    # a structure picks its type from a list holding only structure types
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Target"})
    check(api.use_type({"path": "Target", "name": "sPosition"})["ok"],
          "the type could not be applied")

    target = document.find("Target")
    equal(target.kind.value, "struct", "it is a structure")
    equal([child.name for child in target.children], ["Lat", "Samples"], "the fields")
    equal(target.children[0].unit, "deg", "the unit comes from the type")
    check(target.param_type is not None, "the parameter keeps its own type")
    check(target.tags.get("SystemName") is not None, "and its own tags")

    # the limits belong to the parameter, not to the type
    document.update("Target.Lat", {"maximum": 45.0})
    equal(document.find("Target").children[0].maximum, 45.0, "the limit was written")
    equal(len(document.find_struct_type("sPosition").fields), 2,
          "and the type is unchanged by it")

    # editing the type reaches the parameter
    check(api.update_type({"name": "sPosition", "changes": {"fields": [
        {"name": "Lat", "valueType": "float64_t", "arraySize": 1, "unit": "deg"},
        {"name": "Alt", "valueType": "float32_t", "arraySize": 1, "unit": "m"},
        {"name": "Samples", "valueType": "int16_t", "arraySize": 4},
    ]}})["ok"], "the type could not be edited")
    equal([child.name for child in document.find("Target").children],
          ["Lat", "Alt", "Samples"], "the parameter grew the new field, in place")
    equal(document.find("Target.Lat").maximum, 45.0, "and kept the limit it had")

    # the type survives a save and a reload, in the file beside the list
    saved = document.save()
    again = Document(document.config)
    again.load(saved)
    equal(again.model.struct_types.names(), ["sPosition"], "the types after a reload")
    equal([child.name for child in again.find("Target").children],
          ["Lat", "Alt", "Samples"], "and the parameter still has its fields")

    # a type still in use is not deleted, and says so
    refused = api.delete_type({"name": "sPosition"})
    equal(refused["ok"], False, "a type in use was deleted")
    check("still used" in refused["message"], "and it did not say why")

    check(document.delete("Target"), "the parameter was not deleted")
    check(api.delete_type({"name": "sPosition"})["ok"], "an unused type was not removed")
    equal(api.state({})["structTypes"], [], "the type list after removing the only type")


def test_structure_arrays(work: Path) -> None:
    """An array of structures produces one set of values per element."""
    document, _api, _config = open_copy(work, empty=True)

    # A structure is of a TYPE, and the type says what fields it has.
    document.create_struct_type("Wheel")
    document.update_struct_type("Wheel", {"fields": [
        {"name": "Speed", "valueType": "float32_t", "arraySize": 1}]})

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Wheels", "array_size": 3,
                                  # log_id is a field of its own, not a tag
                                  "log_id": 900,
                                  "tags": {"Loggable": True,
                                           "SystemName": "SYS_NAV",
                                           "ParamMode": "PARAM_MODE_USER",
                                           "ResetProof": False, "LogEncryption": False}})
    document.use_struct_type("Wheels", "Wheel")
    document.update("Wheels.Speed",
                    {"minimum": 0, "maximum": 0, "resolution": 0.001, "default_value": 0.0})

    leaves = document.model.flatten()
    equal([leaf.name for leaf in leaves],
          ["Wheels[0].Speed", "Wheels[1].Speed", "Wheels[2].Speed"], "the expanded leaves")
    equal([leaf.log_id for leaf in leaves], [900, 901, 902], "one log id per value")

    # A log id counts values, never bytes: a float32_t[10] takes ten ids, and so
    # would a uint8_t[10].  Every element is a value in its own right - its own
    # row, its own index, its own id - so three struct elements each holding an
    # array of 10 produce thirty values numbered 900..929.
    # The array size of a field is the TYPE's, so this is where it changes -
    # and it changes for every parameter of that type at once.
    document.update_struct_type("Wheel", {"fields": [
        {"name": "Speed", "valueType": "float32_t", "arraySize": 10}]})
    expanded = document.model.flatten()
    equal(len(expanded), 30, "three elements of ten values each")
    equal([leaf.name for leaf in expanded[:2]],
          ["Wheels[0].Speed[0]", "Wheels[0].Speed[1]"], "every element is its own value")
    equal([expanded[0].log_id, expanded[10].log_id, expanded[20].log_id],
          [900, 910, 920], "each struct element starts a block of ten ids")
    equal([leaf.log_id for leaf in expanded], list(range(900, 930)),
          "the ids run without a gap, one per value")

    # 'the next free id' is a property of the whole project, not of this list:
    # the other lists of the build reserve ids too, and an id that is free here
    # but taken in another list is not free.
    free = document.next_free_log_id()
    check(free >= 930, f"the next free id must be past this list's block, got {free}")
    for leaf in document.merged_model().flatten():
        log_id = leaf.log_id
        if isinstance(log_id, int) and not isinstance(log_id, bool):
            check(free > log_id, f"id {free} is not free: '{leaf.name}' already uses {log_id}")


def test_parameter_lists(work: Path) -> None:
    """Creating, choosing and ordering the parameter lists of the project."""
    document, api, config_path = open_copy(work)
    before = config_path.read_text(encoding="utf-8")
    check("//" in before, "the fixture configuration has no comments to preserve")

    listed = api.lists({})
    equal(Path(listed["directory"]).name, "parameter_lists", "the parameter list folder")
    check(all(item["inFolder"] for item in listed["lists"]),
          "every list of the project should live in the one folder")
    selected = [item["file"] for item in listed["lists"] if item["selected"]]
    check(len(selected) >= 1, "no list takes part in the build")

    # a name is sanitised into something that cannot leave the folder
    answer = api.new_list({"name": "../../gimbal telemetry!"})
    check(answer["ok"], f"the list was not created: {answer}")
    created = Path(answer["path"])
    equal(created.name, "gimbal_telemetry.xml", "the file name made from the typed name")
    equal(created.parent, document.list_directory(), "the new list is in the folder")
    check(created.is_file(), "the new list was not written to disk")
    check(created in document.config.inputs.model_files,
          "the new list did not join the build")

    # a name that is already taken is refused rather than overwriting a list
    check(not api.new_list({"name": "gimbal_telemetry"})["ok"],
          "creating a list twice overwrote the first one")

    # The order chosen here is the order the generator merges in, so the check
    # below needs two lists that actually hold parameters - reversed, so that
    # "the order was kept" cannot pass by accident.
    directory = document.list_directory()
    filled = [path for path in sorted(directory.glob("*.xml"))
              if not is_types_file(path) and _parameter_names(path)]
    check(len(filled) >= 2,
          "the project needs two non-empty parameter lists to test the order with")
    chosen = list(reversed(filled[:2]))
    answer = api.select_lists({"paths": [str(path) for path in chosen]})
    check(answer["ok"], f"the choice was not saved: {answer}")

    after = config_path.read_text(encoding="utf-8")
    check("//" in after, "rewriting the configuration deleted its comments")
    equal([line for line in before.splitlines() if line.strip().startswith("//")],
          [line for line in after.splitlines() if line.strip().startswith("//")],
          "the comments of the configuration file")

    reloaded = Config.load(config_path)
    equal([path.name for path in reloaded.inputs.model_files],
          [path.name for path in chosen],
          "what run_generate.py reads after the editor saved the choice")

    # ... and the indices of the generated code really follow that order: the
    # values of the first list come first, then the values of the second.
    expected = [name for path in chosen for name in _parameter_names(path)]
    document = Document(reloaded)
    document.load(reloaded.inputs.model_files[0])
    equal([leaf.name for leaf in document.merged_model().flatten()], expected,
          "the order of the values in the merged model")


def test_list_selection_edge_cases(work: Path) -> None:
    """The ways a hand-edited configuration can be odd, and what happens then."""
    document, api, config_path = open_copy(work)
    directory = document.list_directory()
    first = document.config.inputs.model_files[0]

    # The same list twice would be merged twice and every name in it would
    # collide with itself; the first mention wins so the chosen order survives.
    answer = api.select_lists({"paths": [str(first), str(directory / "power.xml"),
                                         str(first)]})
    check(answer["ok"], f"the choice was not saved: {answer}")
    equal([Path(p).name for p in answer["paths"]], [first.name, "power.xml"],
          "the duplicate should have been dropped")
    equal([path.name for path in Config.load(config_path).inputs.model_files],
          [first.name, "power.xml"], "what the configuration file says")

    # A configuration that already names a list twice still gives the dialog one
    # row per file - two rows with the same path would bind to the same object.
    document.config.inputs.model_files = [first, first]
    paths = [item["path"] for item in document.known_lists()]
    equal(len(paths), len(set(paths)), "the dialog was given a duplicated row")

    # Generating with a list that is not on disk is reported, not raised: the
    # editor shows that state as "(new)", so it is reachable by just clicking.
    document.config.inputs.model_files = [directory / "does_not_exist.xml"]
    result = api.generate({})
    check(not result["success"], "generating from a missing list reported success")
    check(bool(result.get("message")), "the failure came back with nothing to read")


def test_template_of_another_list(work: Path) -> None:
    """A type another parameter list owns is offered, but not deleted from here."""
    document, api, _config = open_copy(work)
    # Put a type into another list that takes part in the build - a list that
    # is not in the build contributes nothing, its types included.
    others = [path for path in document.config.inputs.model_files
              if path != document.path]
    check(bool(others), "the project needs a second list in the build for this case")
    other = others[0]
    document.load(other)
    check(api.new_type({"name": "sNavShape"})["ok"], "the type was not declared")
    check(api.update_type({"name": "sNavShape", "changes": {"fields": [
        {"name": "Fix", "valueType": "uint8_t", "arraySize": 1}]}})["ok"],
        "the type's fields were not set")
    document.save()

    # now edit the first list: the type is offered, because the types of the
    # whole project are, not only this file's
    document.load(document.config.inputs.model_files[0])
    names = [item["name"] for item in api.state({})["structTypes"]]
    check("sNavShape" in names,
          f"a type defined in another list is not offered here: {names}")

    # ... but deleting it from here would silently do nothing, so it says so
    answer = api.delete_type({"name": "sNavShape"})
    check(not answer["ok"], "deleting another list's type reported success")
    check(other.stem in answer["message"],
          f"the message should name the list that owns it: {answer['message']}")
    check("sNavShape" in [item["name"] for item in api.state({})["structTypes"]],
          "the type disappeared even though the answer said it had not")

    # using it here copies it in, so this list still makes sense on its own
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Nav"})
    check(api.use_type({"path": "Nav", "name": "sNavShape"})["ok"],
          "the borrowed type could not be used")
    check("sNavShape" in document.model.struct_types,
          "using a borrowed type did not copy it into this list")


def _parameter_names(path: Path) -> List[str]:
    """The values one parameter list contributes, in order."""
    from pl_codegen.errors import DiagnosticCollector
    from pl_codegen.xml_model.xml_reader import read_xml

    return [leaf.name for leaf in read_xml(path, DiagnosticCollector()).flatten()]


def test_layout_warning(work: Path) -> None:
    """Generating must say when it moved a value a board may already store.

    The offset of a reset-proof value is positional, so inserting, disabling,
    moving or widening a parameter shifts everything after it - and none of that
    shows up in the generated code.  This is the check that it never happens
    quietly.

    The case builds its own parameters rather than using whatever the project
    holds today.  Every step here has to *generate*, and a project someone is
    halfway through editing may legitimately not - a duplicate name while two
    lists are being merged, say.  Depending on that would turn "your draft has
    an error" into "the memory layout warning is broken", which is a different
    and much more alarming thing to read.
    """
    document, api, _config = open_copy(work, empty=True)

    for name in ("Alpha", "Beta", "Gamma"):
        path = document.add_parameter("", "primitive")
        document.update(path, {"name": name, "gs_name": name})
    document.save()

    # the copy carries the project's last build; drop it so the first generate
    # here really is a first build
    previous = document.config.output.xml_file
    if previous.is_file():
        previous.unlink()

    first = api.generate({})
    check(first["success"], f"the first build failed: {first.get('message')}")
    check(first["drift"]["firstRun"], "the very first build has nothing to compare with")

    # generating again without touching anything must be silent
    again = api.generate({})
    check(not again["drift"]["breaksStoredData"], "an unchanged model reported a move")
    equal(again["drift"]["moved"], [], "an unchanged model moved something")

    # ... and moving a parameter to the front must not be
    names = [node.name for node in document.model.parameters]
    check(len(names) >= 2, "the project needs two parameters for this case")
    document.move(names[-1], -(len(names) - 1))
    moved = api.generate({})
    check(moved["success"], "generating after the move failed")
    drift = moved["drift"]
    check(drift["breaksStoredData"],
          "moving a parameter to the front did not warn about the memory layout")
    check(bool(drift["moved"]), "the warning named no parameter")
    check("MOVED" in drift["summary"], f"the summary is not loud enough: {drift['summary']}")
    for entry in drift["moved"]:
        check(entry["old"] != entry["new"],
              f"'{entry['parameter']}' is listed as moved but did not move")

    # Appending to the END of the LAST list in the build changes nothing that
    # already exists - and that is the whole point of the advice the warning
    # gives, so it has to actually hold.
    api.open_file({"path": str(document.config.inputs.model_files[-1])})
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "AppendedAtTheEnd"})
    appended = api.generate({})
    check(appended["success"], "generating after the append failed")
    equal(appended["drift"]["moved"], [],
          "appending at the end of the last list moved something that existed")
    check("AppendedAtTheEnd" in appended["drift"]["added"],
          "the appended parameter was not reported as added")


def test_no_external_dependency(_project: Path) -> None:
    """The tool must run on a machine that has never seen the internet.

    The company machines are offline, so `pip install` is not a step anybody can
    take: an import that is not in the Python standard library does not fail at
    the point where it was added, it fails on somebody else's desk, on the day
    they first open the editor.

    This is checked by reading the imports rather than by trying them, so it
    fails on the machine that ADDED the dependency - which is the only machine
    where fixing it is cheap.
    """
    standard = set(sys.stdlib_module_names)
    ours = {"pl_codegen", "pl_gui", "tests", "setup_environment"}

    offenders = []
    for path in sorted(APP_DIR.rglob("*.py")):
        # docs/ is the manual build. It runs on a developer's machine once a
        # release, not on the offline machines the tool has to work on, so it
        # is allowed the browser driver and the PDF reader it needs.
        if "__pycache__" in path.parts or "docs" in path.parts:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as error:
            raise Failure(f"{path.relative_to(APP_DIR)} does not parse: {error}")

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                root = name.split(".")[0]
                if root not in standard and root not in ours:
                    offenders.append(f"{path.relative_to(APP_DIR)}: {name}")

    equal(sorted(set(offenders)), [], "imports that are not in the standard library")


def test_every_pane_redraws(_project: Path) -> None:
    """A mutation must never redraw only half the screen.

    The editor keeps no state of its own: the model is the truth and every pane
    is drawn from it.  ``refresh(true)`` is the one exception - it leaves the
    form on the right alone so that typing is not interrupted mid-word - and it
    is safe ONLY where the action cannot have changed the selected node.

    Ticking Enabled in the tree broke exactly that rule once: the model and the
    tree moved, the form did not, and the two halves of the screen then
    disagreed about the same parameter with nothing to say which was right.

    So: any method that calls ``api.update`` - the one action that changes a
    node's fields - must redraw the form as well.  A DOM test could catch this
    too, but it would need a browser; this reads the source and needs nothing.
    """
    # the real source, not the temporary fixture copy: this reads the code the
    # project ships, and the fixture has no web/ folder
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")

    # Comments are stripped first, or the rule catches the comment that explains
    # the rule - "NOT refresh(true), because ..." reads as a call to it.
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)

    # split into methods: "  name(args) {" or "  async name(args) {" at one indent
    methods = re.split(r"\n  (?=(?:async )?[A-Za-z_]\w*\s*\()", code)
    offenders = []
    for body in methods:
        name = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if not name:
            continue
        if "api.update(" not in body:
            continue
        if re.search(r"refresh\(\s*true\s*\)", body):
            offenders.append(name.group(1))

    equal(offenders, [],
          "methods that change a node but keep the stale form (use refresh(), "
          "not refresh(true))")

    # and the checkbox in the tree has to go through that same update action,
    # rather than poking the model or the DOM behind its back
    bodies = {}
    for body in methods:
        found = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if found:
            bodies.setdefault(found.group(1), body)

    check("setEnabled" in bodies, "app.js still has a setEnabled method")
    check("api.update(" in bodies["setEnabled"],
          "the tree's Enabled tick goes through the normal update action")

    # The form is allowed to skip its own redraw while somebody is typing in it
    # - it already shows what they typed - but ONLY for a change the form
    # itself made.  The caret can be parked in a box while the reader ticks
    # something in the tree, and that change has to reach the form like any
    # other; getting this wrong is how the two halves of the screen last
    # disagreed.  So exactly one method may raise the flag.
    raisers = sorted(name for name, body in bodies.items()
                     if "editorView.ownEdit = true" in body)
    equal(raisers, ["applyChanges"],
          "methods that let the editor skip its redraw (only the form's own "
          "edits may)")

    editor_js = (APP_DIR / "src" / "pl_gui" / "web" / "editor.js").read_text(encoding="utf-8")
    check("this.ownEdit && this.isBeingTypedIn()" in editor_js,
          "editor.js must gate the skip on BOTH the flag and the caret")

    # and the flag has to be put down again, or the form stops redrawing for
    # good after the first edit
    check("finally" in bodies["applyChanges"]
          and "editorView.ownEdit = false" in bodies["applyChanges"],
          "applyChanges must clear ownEdit in a finally block")


def test_one_name_for_one_thing(_project: Path) -> None:
    """A concept must be called the same thing everywhere.

    Renaming something across a project is the change most likely to be left
    half done: the compiler catches the identifiers, the tests catch the keys,
    and nothing at all catches a heading in a generated comment, a label in a
    dialog, or a sentence in a docstring.  Every one of those was missed once.

    So the banned words are listed here.  If a rename is ever reversed, or a new
    name is chosen, this list is the one place that decides it - and the suite
    says exactly which files still disagree.
    """
    # word that must not appear -> what it is called now, and why
    BANNED = {
        "eParameterListDescriptorGroup": "eParameterType",
        "sParameterListDescriptorTag": "sParameterTag",
        "ePARAMETER_GROUP_": "ePARAMETER_TYPE_",
        "DEFAULT_GROUPS": "DEFAULT_PARAMETER_TYPES",
        "GroupRule": "ParameterTypeRule",
        "COLUMN_GROUPS": "COLUMN_TYPES",
        "data_type_name": "value_type_name",
        "PARAMETER_LIST_OFFSET_": "PARAMETER_LIST_TAG_<TAG>_<NAME>_OFFSET",
        "PARAMETER_LIST_SIZE_": "PARAMETER_LIST_TAG_<TAG>_SIZE",
        "TagLogId": "LogId (it is not a tag)",
        "fParameterList_GetLogIdSize": "removed with the LogId offset area",
        "ArraySize;": "removed: one descriptor is one value",
        "DataTypeRule": "ValueTypeRule",
        # the heading of the generated overview table
        '"DataType"': '"ValueType"',
    }
    # the old smart-data macro spelling, before the file_Function_ convention
    for old in ("fSmartDataRead_", "fSmartDataWrite_", "fSmartDataSetMinimum_",
                "fSmartDataGetMaximum_", "fSmartDataUserRead_"):
        BANNED[old] = old.replace("fSmartData", "fSmartData_")

    # The documentation is searched too.  It is the place a stale name survives
    # longest, because nothing compiles it and nobody greps it - and a manual
    # that calls a button by a name it no longer has is worse than no manual.
    searched = []
    for pattern in ("*.py", "*.js", "*.c", "*.h", "*.json", "*.html"):
        searched += [p for p in ROOT_DIR.rglob(pattern)
                     if "__pycache__" not in p.parts and ".dist" not in p.parts]

    offences = []
    for path in searched:
        # this file names the banned words on purpose
        if path.name == "run_editor_test.py":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        # A manual that explains a rename has to name the old thing; those
        # sections are marked, and only those are exempt.
        text = re.sub(r"<!-- HISTORY-BLOCK.*?/HISTORY-BLOCK -->", "", text, flags=re.S)
        for banned, instead in BANNED.items():
            if banned in text:
                offences.append(f"{path.relative_to(ROOT_DIR)}: '{banned}' "
                                f"(now: {instead})")

    equal(sorted(offences), [], "old names still in the source")

    # The manuals name the controls of the editor.  A label that was renamed in
    # index.html and not in the manual sends the reader looking for something
    # that is not on screen, so the two are checked against each other.
    labels = (APP_DIR / "src" / "pl_gui" / "web" / "index.html").read_text(encoding="utf-8")
    grid = (APP_DIR / "src" / "pl_gui" / "web" / "grid.js").read_text(encoding="utf-8")
    for shown, gone in (("Value type", "Data type"),
                        ("Tag ParamMode", "ParamMode column"),
                        ("Structure types…", "Save as a type"),
                        ("Structure type", "the mixed Data type list")):
        if shown in labels or shown in grid:
            continue
        raise Failure(f"the editor no longer shows '{shown}'; the manuals still "
                      f"describe it, so update them and this list together "
                      f"(it replaced '{gone}')")


def test_changing_the_value_type(work: Path) -> None:
    """Changing the type must leave nothing the new type cannot hold.

    The minimum, the maximum, the resolution and the default value only mean
    anything in terms of the value type, so a type change has to bring them
    along.  Left behind they are not merely untidy - turning a float32_t into a
    bool_t used to keep its 0..120 range, and the boolean form has no minimum
    or maximum box, so the warning that followed could be read and could not be
    acted on from the editor at all.

    Every pair of types is walked here, in both directions, and the model has
    to come out clean each time.
    """
    from pl_codegen.model.types import VALUE_TYPES

    document, api, _config = open_copy(work, empty=True)
    document.add_parameter("", "primitive")
    document.update("NewParameter", {
        "name": "Probe", "param_type": "MONITORING",
        "tags": {"SystemName": "SYS_NAV", "ParamMode": "PARAM_MODE_USER",
                 "ResetProof": False, "Loggable": False, "LogEncryption": False}})

    names = list(VALUE_TYPES)
    for start in names:
        for target in names:
            # a plausible starting point for the first type
            document.update("Probe", {"value_type_name": start})
            if start == "bool_t":
                document.update("Probe", {"default_value": True})
            elif start.startswith("float"):
                # FRACTIONS on purpose: an integer type can hold none of these,
                # and a value merely inside the new type's range is not yet a
                # value it can carry - C would quietly make 10.5 into 10.
                document.update("Probe", {"minimum": -10.5, "maximum": 10.5,
                                          "default_value": 7.25, "resolution": 0.25})
            else:
                document.update("Probe", {"minimum": 0, "maximum": 100,
                                          "default_value": 7, "resolution": 1})

            document.update("Probe", {"value_type_name": target})

            # only what this test is about: an empty description or GS name is
            # a house-style notice and has nothing to do with the type change
            complaints = [item for item in api.state({})["diagnostics"]
                          if str(item.get("location", {}).get("parameter", "")) == "Probe"
                          and item["code"][:3] in ("RNG", "TYP", "VAL")]
            equal([f"{c['code']}: {c['message']}" for c in complaints], [],
                  f"{start} -> {target} left the parameter in a state the editor "
                  f"cannot repair")

            node = document.find("Probe")
            value_type = node.value_type
            if value_type is not None and not value_type.is_float and not value_type.is_bool:
                for field in ("minimum", "maximum", "default_value", "resolution"):
                    value = getattr(node, field)
                    if value is None or isinstance(value, bool):
                        continue
                    check(float(value).is_integer(),
                          f"{start} -> {target} left {field}={value} on an integer type")
            if target == "bool_t":
                equal(isinstance(node.default_value, bool), True,
                      f"{start} -> bool_t left a non-boolean default")
            else:
                check(not isinstance(node.default_value, bool),
                      f"{start} -> {target} left a boolean default on a number")


def test_a_boolean_keeps_its_shape(work: Path) -> None:
    """A boolean must hold 0 / 1 / 1 and a real boolean default, always.

    Its form shows no minimum, maximum or resolution box, so a number written
    into one of those could never be seen and never be corrected.  The values
    were normalised when the TYPE changed, which left two ways in that skipped
    it: an update already in flight when the type became bool_t, and a
    structure converted straight to bool_t.
    """
    document, api, _config = open_copy(work, empty=True)
    document.add_parameter("", "primitive")
    document.update("NewParameter", {
        "name": "Flag", "param_type": "MONITORING",
        "tags": {"SystemName": "SYS_NAV", "ParamMode": "PARAM_MODE_USER",
                 "ResetProof": False, "Loggable": False, "LogEncryption": False}})

    def shape():
        node = document.find("Flag")
        return (node.minimum, node.maximum, node.resolution,
                isinstance(node.default_value, bool))

    document.update("Flag", {"value_type_name": "bool_t"})
    equal(shape(), (0, 1, 1, True), "a fresh boolean")

    # numbers written straight at it, as a stale page would
    document.update("Flag", {"minimum": 100, "maximum": -128,
                             "default_value": -1, "resolution": 0.5})
    equal(shape(), (0, 1, 1, True), "a boolean after nonsense was written at it")

    # A STRUCTURE cannot be turned into a boolean at all now: a structure is
    # of a structure type and holds fields, and the two are kept apart rather
    # than one silently becoming the other.
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Shape"})
    refused = api.update({"path": "Shape", "changes": {"value_type_name": "bool_t"}})
    equal(refused["ok"], False, "a structure was allowed to become a boolean")
    check("structure type" in refused["message"],
          f"the refusal should say what a structure needs: {refused['message']}")
    equal(document.find("Shape").kind.value, "struct", "and it is still a structure")
    check(document.delete("Shape"), "the structure could not be deleted")

    # Errors and warnings only: an info is the tool telling you what it did,
    # not something wrong with the model.
    complaints = [item["code"] for item in api.state({})["diagnostics"]
                  if item["code"][:3] in ("RNG", "TYP", "VAL")
                  and item["severity"] != "info"]
    equal(complaints, [], "a normalised boolean should report nothing")



def test_only_a_project_file_opens(work: Path) -> None:
    """A JSON file that is not a project must not open as one.

    Nothing in a project file is mandatory, so an empty object used to load as
    "a project with all the defaults" - and any JSON file on the machine with
    it.  Opening one made ITS folder the project root, so the next Generate
    would have written the parameter list into somebody's home directory, and
    the only clue was a screenful of "unknown configuration section".
    """
    from pl_codegen.config import Config
    from pl_codegen.errors import CodeGeneratorError

    stranger = work / "not_a_project.json"
    stranger.write_text('{"editor": {"theme": "dark"}, "recent": []}',
                        encoding="utf-8")
    try:
        Config.load(stranger)
    except CodeGeneratorError as error:
        message = str(error)
        assert "not a project file" in message, message
        assert "editor" in message, f"it says what the file does have: {message}"
    else:
        raise AssertionError("a settings file opened as a project")

    # ...and one section is enough to be a project, because a real project file
    # may leave every other section out and take the defaults.
    thin = work / "thin.json"
    thin.write_text('{"project": {"name": "Thin"}}', encoding="utf-8")
    config = Config.load(thin)
    assert config.project.name == "Thin", config.project.name


CASES: List[Tuple[str, Callable[[Path], None]]] = [
    ("structure types (the template library)", test_structure_types),
    ("arrays of structures", test_structure_arrays),
    ("the parameter lists of the project", test_parameter_lists),
    ("odd list selections", test_list_selection_edge_cases),
    ("a type another list owns", test_template_of_another_list),
    ("the memory layout warning", test_layout_warning),
    ("no external dependency", test_no_external_dependency),
    ("every pane redraws after a change", test_every_pane_redraws),
    ("one name for one thing", test_one_name_for_one_thing),
    ("changing the value type", test_changing_the_value_type),
    ("a boolean keeps its shape", test_a_boolean_keeps_its_shape),
    ("only a project file opens", test_only_a_project_file_opens),
]


def main() -> int:
    failures = 0
    width = max(len(name) for name, _case in CASES)
    for name, case in CASES:
        with tempfile.TemporaryDirectory(prefix="pl_editor_test_") as raw:
            try:
                case(Path(raw))
            except Failure as error:
                print(f"  [{paint('FAIL', BOLD + BRIGHT_RED)}] "
                      f"{name.ljust(width)}  {paint(str(error), BRIGHT_RED)}")
                failures += 1
                continue
            except Exception as error:               # noqa: BLE001 - report and go on
                print(f"  [ERROR] {name.ljust(width)}  {type(error).__name__}: {error}")
                failures += 1
                continue
        print(f"  [{paint('PASS', GREEN)}] {name}")

    print()
    if failures:
        print(paint(f"{failures} of {len(CASES)} editor case(s) FAILED.",
                    BOLD + BRIGHT_RED))
        return 1
    print(paint(f"All {len(CASES)} editor cases passed.", GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""End-to-end test: generate the code and compile it with a real C/C++ compiler.

The test
  1. runs the generator on ``parameter_list.xml`` into a temporary folder,
  2. compiles the generated files together with ``smart_data.c`` as **C99** and
     compiles the generated headers as **C++**,
  3. links and runs a small program that calls ``fParameterList_Init()``,
     walks the descriptor table and exercises the usage example.

Run it with::

    python tests/run_compile_test.py

It needs ``gcc`` and ``g++`` on the PATH; on Windows a MinGW or WSL toolchain
works.  The test never touches the files under ``cg_parameter_list`` of the
project: everything is generated into a temporary folder.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional

#: The app folder.  The C library, the usage example and the templates all
#: ship with the app, so they are all found from here; a *project* is
#: somewhere else entirely and this test makes its own.
APP_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(APP_DIR / "src"))

from pl_codegen.app_home import (DOCS_DIR, LIB_TEMPLATE_DIR,  # noqa: E402
                                 SNIPPET_FILE)
from pl_codegen.cli import main as generator_main  # noqa: E402
from pl_codegen.logging_utils import (BOLD, BRIGHT_RED, CYAN,  # noqa: E402
                                            GREEN, YELLOW, colour_supported, paint)
import pl_codegen.logging_utils as _logging_utils  # noqa: E402

_logging_utils._colour_enabled = colour_supported()

C_COMPILER = "gcc"
CXX_COMPILER = "g++"

def _run(command: List[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def have_compiler(name: str) -> bool:
    return shutil.which(name) is not None



#: A parameter table, as the older firmware wants it.  Two sub-systems, so the
#: generated header has two #if blocks and the indices restart - and every type
#: the format supports, because a table is exactly where a bad literal hides.
_PARAM_TABLE_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Parameters>
    <Parameter name="PR_GSM_TABLE_NUM" kind="primitive" enable="true"
               gsName="GSM_TABLE_NUM" type="SETTING" valueType="uint8_t" arraySize="1">
      <Source />
      <Limits default="31" minimum="0" maximum="255" resolution="1" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_GS_MANAGER" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="false" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_READ_ONLY" />
        <Tag id="Tag1" kind="free" value="400" />
      </Tags>
      <Description>GSM_TABLE_NUM returns last parameter number</Description>
    </Parameter>
    <Parameter name="PR_GSM_PINOUT_TYPE" kind="primitive" enable="true"
               gsName="GSM_PINOUT_TYPE" type="SETTING" valueType="int8_t" arraySize="1">
      <Source />
      <Limits default="-1" minimum="-1" maximum="100" resolution="1" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_GS_MANAGER" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="false" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_READ_ONLY" />
      </Tags>
      <Description>-1: Unknown, 2:GSV2, 3:GSV3R1</Description>
    </Parameter>
    <Parameter name="PR_GSM_INITIAL_LOCK_SIZE" kind="primitive" enable="true"
               gsName="INITIAL_LOCK_SIZE" type="SETTING" valueType="float32_t" arraySize="1">
      <Source />
      <Limits default="0.04" minimum="0.01" maximum="0.3" resolution="0.01" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_GS_MANAGER" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="false" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Description>Lock Box Size Parameter</Description>
    </Parameter>
    <Parameter name="PR_GSM_VIRTUAL_CORRUPTION" kind="primitive" enable="true"
               gsName="Virtual Corruption" type="SETTING" valueType="uint64_t" arraySize="1">
      <Source />
      <Limits default="0" minimum="0" maximum="0" resolution="1" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_GS_MANAGER" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="false" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_FACTORY" />
      </Tags>
      <Description>NO_VC:0
LOW_FREQUENCY:1</Description>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

_PARAM_TABLE_RHS_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Parameters>
    <Parameter name="PR_RHS_GAIN" kind="primitive" enable="true" gsName="RHS_GAIN"
               type="SETTING" valueType="float64_t" arraySize="1">
      <Source />
      <Limits default="1.5" minimum="0" maximum="10" resolution="0.001" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_RHS" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="false" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_CALIB" />
      </Tags>
      <Description>loop gain</Description>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

#: What the firmware does with the table: define ADD_PARAM, pick a sub-system,
#: include the header.  Counting the rows proves the macro really expanded.
_PARAM_TABLE_MAIN = """
#include <stdio.h>
#include <stdint.h>

#define SYS_GS_MANAGER 2
#define SYS_RHS        19
#define SYS_ALL        255
#define DESIRED_SUB_SYSTEM SYS_ALL

typedef enum {
    TYPE_UINT8, TYPE_INT8, TYPE_UINT16, TYPE_INT16,
    TYPE_UINT32, TYPE_INT32, TYPE_UINT64, TYPE_INT64,
    TYPE_FLOAT, TYPE_DOUBLE
} eParamType;

static int gRows = 0;
static int gAddress = 0;

#define ADD_PARAM(type_, enum_, name_, gs_, sys_, index_, def_, min_, max_, \
                  res_, mode_, addr_, note_)                                \
    do {                                                                     \
        type_ value_ = (type_)(def_);                                        \
        eParamType kind_ = enum_;                                            \
        const char *shown_ = (gs_);                                          \
        const char *why_ = (note_);                                          \
        (void)value_; (void)kind_; (void)shown_; (void)why_;                 \
        (void)(min_); (void)(max_); (void)(res_); (void)(mode_);             \
        (void)(sys_); (void)(index_);                                        \
        if ((addr_) != 0) { gAddress = (addr_); }                            \
        gRows++;                                                             \
    } while (0);

int main(void)
{
#include "nsrParamTables.h"

    printf("rows=%d address=%d\\n", gRows, gAddress);
    if (gRows != 5) {
        printf("expected 5 rows\\n");
        return 1;
    }
    if (gAddress != 400) {
        printf("the address column did not arrive\\n");
        return 1;
    }
    return 0;
}
"""


def write_config(work_dir: Path, inputs: dict, name: str = "project.json",
                 output_format: str = "smart_data") -> Path:
    """Write a configuration that generates into *work_dir*."""
    config = {
        "project": {"name": "compile test"},
        "inputs": inputs,
        "output": {
            "format": output_format,
            "code_directory": str(work_dir / "generated"),
            "xml_file": str(work_dir / "model.xml"),
            "file_prefix": "cg_",
            "base_name": "parameter_list",
        },
        "style": {"snippet_file": str(SNIPPET_FILE), "company": "FAS",
                  "indent": "    "},
        "codegen": {"emit_description": True, "emit_unit": True,
                    "emit_generation_info": True, "emit_timestamp": False},
        "validation": {"treat_warnings_as_errors": False},
    }
    path = work_dir / name
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return path


#: The three ways a project can feed the generator; all three must compile.
def input_variants() -> List[dict]:
    # The project's own lists, taken from its configuration rather than from
    # hard coded paths: the editor is free to add lists and to reorder them, and
    # the test has to keep testing whatever the project actually builds.
    project = [path for path in _project_lists() if path.is_file()]

    # The usage example is written against the demo parameters (Airspeed,
    # Position.Home.Lat, Position.Samples), so it only compiles against the
    # list that actually holds them.  Picking "the first list in the
    # configuration" instead would make this test fail the moment somebody
    # reorders the build in the editor - which is a supported thing to do, and
    # not a reason to call the tool broken.
    single = _list_holding_the_example(project)

    variants: List[dict] = []
    if single is not None:
        variants.append(
            {"label": f"one parameter list ({single.name})",
             "inputs": {"model_files": [str(single)]}})
    elif project:
        variants.append(
            {"label": f"one parameter list ({project[0].name}, without the example)",
             "inputs": {"model_files": [str(project[0])]},
             "with_example": False})
    if len(project) > 1:
        # The merged build needs the same guard as the single one.  It used to
        # compile the example unconditionally, on the assumption that merging
        # every list can only ever ADD parameters - true of the set, but not of
        # the configuration: the moment somebody unticks the demo list in the
        # editor, the merged model no longer holds Airspeed or Position and the
        # suite failed with a wall of "undeclared identifier" that said nothing
        # about the real cause.  Unticking a list is a supported thing to do.
        merged_names = _names_in(project)
        variants.append(
            {"label": f"{len(project)} parameter lists, merged",
             "inputs": {"model_files": [str(path) for path in project]},
             "with_example": all(needed in merged_names for needed in _EXAMPLE_NEEDS)})

    # The usage example, against a model of its own.  It is a shipped
    # deliverable and the reference for how firmware uses the generated code, so
    # it is compiled and run on every test run rather than only when the
    # project's configuration happens to hold the parameters it names.
    variants.append(
        {"label": "the usage example",
         "fixture": _EXAMPLE_XML,
         "with_example": True})

    # A fixture the editor could have written, kept small on purpose: it is the
    # only place where an array of structures - and an array *inside* one - is
    # compiled and run, so the generated strides are checked by the compiler
    # rather than by eye.
    variants.append(
        {"label": "an array of structures",
         "fixture": _STRUCT_ARRAY_XML,
         "with_example": False,
         "extra_checks": _STRUCT_ARRAY_CHECKS})

    # A model whose ONLY array is a structure array, and nothing else.  It
    # exists because of a bug it would have caught: the init function declared
    # its loop counter whenever the model "had an array", but a struct array is
    # expanded field by field and needs no loop - so the counter sat there
    # unused and the generated file failed the company's own -Werror.  Every
    # other fixture happens to hold a primitive array too, which is exactly why
    # nothing noticed.
    variants.append(
        {"label": "a structure array and no other array",
         "fixture": _STRUCT_ONLY_XML,
         "with_example": False})

    # The other output format: one header of ADD_PARAM lines, compiled with a
    # macro of the test's own.  Nothing about smart data is involved.
    variants.append(
        {"label": "the parameter table (two sub-systems)",
         "format": "param_table",
         "files": {"sys_gs_manager_paramTable.xml": _PARAM_TABLE_XML,
                   "sys_rhs_paramTable.xml": _PARAM_TABLE_RHS_XML}})

    return variants


#: The values example/parameter_list_usage_example.c reaches for by name.  A
#: list that has all of them can compile the example; any other cannot.
_EXAMPLE_NEEDS = ("Airspeed", "Position")


def _names_in(paths: List[Path]) -> set:
    """Every top level parameter name across *paths*, skipping unreadable ones."""
    from pl_codegen.errors import DiagnosticCollector
    from pl_codegen.xml_model.xml_reader import read_xml

    names = set()
    for path in paths:
        try:
            model = read_xml(path, DiagnosticCollector())
        except Exception:                 # a list that will not even parse
            continue
        names.update(parameter.name for parameter in model.parameters)
    return names


def _list_holding_the_example(candidates: List[Path]) -> Optional[Path]:
    """The project list the usage example fits, or ``None`` if no list does."""
    for path in candidates:
        if all(needed in _names_in([path]) for needed in _EXAMPLE_NEEDS):
            return path
    return None


def _project_lists() -> List[Path]:
    """The parameter lists of a real project, in build order.

    The app has no project of its own any more, so this asks for the one that
    was opened last - the one somebody is actually working on.  With none, the
    test simply runs its own fixtures, which is the whole of what it needs.
    """
    from pl_codegen.config import Config

    # Deliberately nothing.  This used to build whatever project the user had
    # open last, which made the result depend on somebody's working state and
    # let a test reach into their files.  The fixtures below are the whole of
    # what this suite needs, and they are written from scratch every run.
    return []



#: One structure array, one scalar, and not a single primitive array.
_STRUCT_ONLY_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Defines>
    <DefineGroup name="TYPE"><Value value="MONITORING" /></DefineGroup>
    <DefineGroup name="PARAM MODES"><Value value="PARAM_MODE_USER" /></DefineGroup>
    <DefineGroup name="SYSTEM NAMES"><Value value="SYS_NAV" /></DefineGroup>
    <DefineGroup name="VALUE TYPES">
      <Value value="float32_t" /><Value value="int16_t" />
    </DefineGroup>
  </Defines>
  <Parameters>
    <Parameter name="Azimuth" kind="primitive" enable="true" gsName="Azimuth"
               type="MONITORING" valueType="float32_t" arraySize="1" unit="deg"
               logId="700" description="A plain scalar.">
      <Source />
      <Limits default="0" minimum="-180" maximum="180" resolution="0.01" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="false" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
    </Parameter>
    <Parameter name="Motor" kind="struct" enable="true" gsName="Motor"
               type="MONITORING" arraySize="2" logId="710" description="Both motors.">
      <Source /><Limits />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="false" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Fields>
        <Parameter name="Rpm" kind="primitive" enable="true" gsName="Rpm"
                   valueType="int16_t" arraySize="1" unit="rpm"
                   description="Speed of one motor.">
          <Source />
          <Limits default="0" minimum="-5000" maximum="5000" resolution="1" />
          <Tags />
        </Parameter>
      </Fields>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

#: The model the usage example is written against.  It holds exactly the
#: parameters the example names and nothing else, so a change to the example
#: and a change to this fixture stay next to each other.
_EXAMPLE_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Defines>
    <DefineGroup name="TYPE"><Value value="MONITORING" /></DefineGroup>
    <DefineGroup name="PARAM MODES"><Value value="PARAM_MODE_USER" /></DefineGroup>
    <DefineGroup name="SYSTEM NAMES"><Value value="SYS_NAV" /></DefineGroup>
    <DefineGroup name="VALUE TYPES">
      <Value value="float32_t" /><Value value="float64_t" /><Value value="int16_t" />
    </DefineGroup>
  </Defines>
  <Parameters>
    <Parameter name="Airspeed" kind="primitive" enable="true" gsName="Airspeed"
               type="MONITORING" valueType="float32_t" arraySize="1" unit="m/s"
               logId="100" description="Indicated airspeed.">
      <Source />
      <Limits default="0" minimum="0" maximum="120" resolution="0.1" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="false" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
    </Parameter>
    <Parameter name="Position" kind="struct" enable="true" gsName="Position"
               type="MONITORING" arraySize="1" logId="200" description="Where it is.">
      <Source /><Limits />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Fields>
        <Parameter name="Home" kind="struct" enable="true" gsName="Home"
                   arraySize="1" description="The home point.">
          <Source /><Limits /><Tags />
          <Fields>
            <Parameter name="Lat" kind="primitive" enable="true" gsName="Lat"
                       valueType="float64_t" arraySize="1" unit="deg">
              <Source />
              <Limits default="0" minimum="-90" maximum="90" resolution="0.0000001" />
              <Tags />
            </Parameter>
            <Parameter name="Lon" kind="primitive" enable="true" gsName="Lon"
                       valueType="float64_t" arraySize="1" unit="deg">
              <Source />
              <Limits default="0" minimum="-180" maximum="180" resolution="0.0000001" />
              <Tags />
            </Parameter>
          </Fields>
        </Parameter>
        <Parameter name="Alt" kind="primitive" enable="true" gsName="Alt"
                   valueType="float32_t" arraySize="1" unit="m">
          <Source />
          <Limits default="0" minimum="-500" maximum="10000" resolution="0.01" />
          <Tags />
        </Parameter>
        <Parameter name="Samples" kind="primitive" enable="true" gsName="Samples"
                   valueType="int16_t" arraySize="8">
          <Source />
          <Limits default="0" minimum="-100" maximum="100" resolution="1" />
          <Tags />
        </Parameter>
        <Parameter name="Heading" kind="primitive" enable="true" gsName="Heading"
                   valueType="float32_t" arraySize="1" unit="deg">
          <Source />
          <Limits default="0" minimum="0" maximum="360" resolution="0.01" />
          <Tags />
        </Parameter>
      </Fields>
    </Parameter>
  </Parameters>
  <StructTemplates />
</ParameterListModel>
"""

#: A parameter list with a struct array whose elements hold an array field.
_STRUCT_ARRAY_XML = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Defines>
    <DefineGroup name="TYPE"><Value value="MONITORING" /></DefineGroup>
    <DefineGroup name="PARAM MODES"><Value value="PARAM_MODE_USER" /></DefineGroup>
    <DefineGroup name="SYSTEM NAMES"><Value value="SYS_NAV" /></DefineGroup>
    <DefineGroup name="VALUE TYPES">
      <Value value="float32_t" /><Value value="int16_t" /><Value value="uint32_t" />
    </DefineGroup>
  </Defines>
  <Parameters>
    <Parameter name="Car" kind="struct" enable="true" gsName="Car"
               type="MONITORING" arraySize="1" logId="600" description="One vehicle.">
      <Source /><Limits />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="true" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Fields>
        <Parameter name="Wheels" kind="struct" enable="true" gsName="Wheels"
                   arraySize="2" description="One entry per wheel.">
          <Source /><Limits /><Tags />
          <Fields>
            <Parameter name="Speed" kind="primitive" enable="true" gsName="Speed"
                       valueType="float32_t" arraySize="1" unit="m/s">
              <Source />
              <Limits default="0" minimum="0" maximum="120" resolution="0.001" />
              <Tags />
            </Parameter>
            <Parameter name="Samples" kind="primitive" enable="true" gsName="Samples"
                       valueType="int16_t" arraySize="4">
              <Source />
              <Limits default="0" minimum="0" maximum="0" resolution="1" />
              <Tags />
            </Parameter>
          </Fields>
        </Parameter>
        <Parameter name="Vin" kind="primitive" enable="true" gsName="Vin"
                   valueType="uint32_t" arraySize="1">
          <Source />
          <Limits default="7" minimum="0" maximum="0" resolution="1" />
          <Tags />
        </Parameter>
      </Fields>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""

#: What the struct array must produce, checked by the compiler and at run time.
_STRUCT_ARRAY_CHECKS = """
    /* The array sizes are declarations, so every element shares one macro. */
    if (CAR_WHEELS_ARRAY_SIZE != 2U || CAR_WHEELS_SAMPLES_ARRAY_SIZE != 4U) {
        printf("array size macros are wrong\\n");
        return 1;
    }
    /* Two elements of one struct array are two separate values. */
    if ((void *)&Cg_SmartData_Car.Wheels[0].Speed
        == (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the elements of the struct array alias each other\\n");
        return 1;
    }
    /* Each element has its own row, pointing inside that element. */
    if (ParameterList[CAR_WHEELS_1_SPEED].pSmartData
        != (void *)&Cg_SmartData_Car.Wheels[1].Speed) {
        printf("the descriptor does not point at the element\\n");
        return 1;
    }
    /* One row per VALUE: Samples[4] is four rows, not one row of four, and the
       four of them are consecutive indices starting at the element-0 macro. */
    if (CAR_WHEELS_0_SAMPLES_1 != CAR_WHEELS_0_SAMPLES_0 + 1
        || CAR_WHEELS_0_SAMPLES_3 != CAR_WHEELS_0_SAMPLES_0 + 3
        || CAR_WHEELS_1_SPEED != CAR_WHEELS_0_SAMPLES_3 + 1) {
        printf("the elements of an array are not consecutive rows\\n");
        return 1;
    }
    /* Each of those rows points at its own element of the one C array. */
    if (ParameterList[CAR_WHEELS_0_SAMPLES_2].pSmartData
        != (void *)&Cg_SmartData_Car.Wheels[0].Samples[2]) {
        printf("an array element row does not point at its element\\n");
        return 1;
    }
    /* A log id counts values, never bytes: Samples[4] takes four of them.
       It is a plain uint16_t field and not a tag, so there is no .Value and no
       .MemoryOffset behind it. */
    if (ParameterList[CAR_WHEELS_0_SPEED].LogId != 600U
        || ParameterList[CAR_WHEELS_0_SAMPLES_0].LogId != 601U
        || ParameterList[CAR_WHEELS_0_SAMPLES_3].LogId != 604U
        || ParameterList[CAR_WHEELS_1_SPEED].LogId != 605U
        || ParameterList[CAR_VIN].LogId != 610U) {
        printf("the log ids of the struct array are wrong\\n");
        return 1;
    }
    /* The unit lives on the smart data object, not on the descriptor. */
    if (Cg_SmartData_Car.Wheels[0].Speed.pUnit == NULL
        || strcmp(Cg_SmartData_Car.Wheels[0].Speed.pUnit, "m/s") != 0) {
        printf("the unit did not reach the smart data object\\n");
        return 1;
    }
    if (Cg_SmartData_Car.Vin.pUnit == NULL
        || Cg_SmartData_Car.Vin.pUnit[0] != '\\0') {
        printf("a value with no unit should carry nothing\\n");
        return 1;
    }
    /* Writing one element leaves its neighbour alone.  There is one Read and
       one Write per type; nothing is reached through a vtable any more. */
    {
        float32_t written = 12.5F;
        float32_t readBack = 1.0F;
        if (fSmartData_F32_Write(&Cg_SmartData_Car.Wheels[1].Speed, &written)
            != eSMART_DATA_OK) {
            printf("writing an element of the struct array failed\\n");
            return 1;
        }
        (void)fSmartData_F32_Read(&Cg_SmartData_Car.Wheels[0].Speed, &readBack);
        if (readBack != 0.0F) {
            printf("writing one element disturbed its neighbour\\n");
            return 1;
        }
        (void)fSmartData_F32_Read(&Cg_SmartData_Car.Wheels[1].Speed, &readBack);
        if (readBack != 12.5F) {
            printf("the element did not keep the value that was written\\n");
            return 1;
        }
    }

    /* A write tells EVERY reader there is something new; each reader consumes
       that notification on its own, without affecting the others. */
    {
        float32_t value = 1.0F;
        float32_t got = 0.0F;

        (void)fSmartData_F32_Write(&Cg_SmartData_Car.Wheels[0].Speed, &value);

        if (fSmartData_F32_ReadIfIsNewForId(&Cg_SmartData_Car.Wheels[0].Speed,
                                            &got, eSMART_DATA_USER_ID_1)
            != eSMART_DATA_OK || got != 1.0F) {
            printf("the first reader did not get the new value\\n");
            return 1;
        }
        if (fSmartData_F32_ReadIfIsNewForId(&Cg_SmartData_Car.Wheels[0].Speed,
                                            &got, eSMART_DATA_USER_ID_1)
            != eSMART_DATA_ERROR_NO_NEW_DATA) {
            printf("a reader was told twice about one write\\n");
            return 1;
        }
        if (fSmartData_F32_ReadIfIsNewForId(&Cg_SmartData_Car.Wheels[0].Speed,
                                            &got, eSMART_DATA_USER_ID_2)
            != eSMART_DATA_OK) {
            printf("one reader consumed another reader notification\\n");
            return 1;
        }

        /* A write the range check refuses changes nothing at all - not the
           value, and not the readers. */
        value = -1.0F;
        if (fSmartData_F32_Write(&Cg_SmartData_Car.Wheels[0].Speed, &value)
            == eSMART_DATA_OK) {
            printf("an out of range write was accepted\\n");
            return 1;
        }
        (void)fSmartData_F32_Read(&Cg_SmartData_Car.Wheels[0].Speed, &got);
        if (got != 1.0F) {
            printf("a refused write changed the value anyway\\n");
            return 1;
        }
        if (fSmartData_F32_ReadIfIsNewForId(&Cg_SmartData_Car.Wheels[0].Speed,
                                            &got, eSMART_DATA_USER_ID_3)
            != eSMART_DATA_OK) {
            printf("a refused write consumed a reader notification\\n");
            return 1;
        }
    }

    /* The second way to write: through the descriptor, which does the same
       range checked write and THEN raises the change event. */
    {
        float32_t got = 0.0F;
        sParameterDescriptor *pRow =
            (sParameterDescriptor *)fParameterList_GetByIndex(CAR_WHEELS_0_SPEED);

        gWriteEventCount = 0U;
        if (fParameterDescriptor_WriteF32(pRow, 7.5F) != ePARAMETER_DESCRIPTOR_OK) {
            printf("the descriptor write failed\\n");
            return 1;
        }
        (void)fSmartData_F32_Read(&Cg_SmartData_Car.Wheels[0].Speed, &got);
        if (got != 7.5F) {
            printf("the descriptor write did not reach the smart data\\n");
            return 1;
        }
        if (gWriteEventCount != 1U) {
            printf("the descriptor write did not raise the change event\\n");
            return 1;
        }

        /* A refused write must report the failure AND leave the event
           unraised: nothing changed, so nobody is told. */
        if (fParameterDescriptor_WriteF32(pRow, -1.0F) == ePARAMETER_DESCRIPTOR_OK) {
            printf("the descriptor accepted an out of range write\\n");
            return 1;
        }
        if (gWriteEventCount != 1U) {
            printf("a refused descriptor write still raised the event\\n");
            return 1;
        }
        (void)fSmartData_F32_Read(&Cg_SmartData_Car.Wheels[0].Speed, &got);
        if (got != 7.5F) {
            printf("a refused descriptor write changed the value\\n");
            return 1;
        }
    }

"""


# smart_data.c includes the project's chrono.h. When the firmware's real
# chrono module is not reachable from here, this stub stands in for it; the
# stub folder is searched LAST, so a real chrono.h always wins.
_CHRONO_STUB_H = """
#ifndef CHRONO_H
#define CHRONO_H
#include <stdint.h>
static uint64_t fChrono_GetContinuousTickUs(void) { return 0U; }
#endif
"""

_LOG_STUB_C = """
#include "parameter_list_usage_example.h"

void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset) {
    (void)logId; (void)pValue; (void)memoryOffset;
}

uint8_t fExample_UseHome(const sCgStruct_Position_Home *pHome) {
    return (pHome == NULL) ? 1U : 0U;
}
"""


def compile_c(work_dir: Path, includes: List[str], with_example: bool = True) -> bool:
    """The example uses the demo parameters, so it only fits the XML model."""
    (work_dir / "log_stub.c").write_text(_LOG_STUB_C, encoding="utf-8")
    sources = [
        LIB_TEMPLATE_DIR / "smart_data" / "smart_data.c",
        # the second write path - the one that raises the change event - lives
        # here, so it belongs in every build the test makes
        LIB_TEMPLATE_DIR / "parameter_descriptor" / "parameter_descriptor.c",
        work_dir / "generated" / "cg_smart_data.c",
        work_dir / "generated" / "cg_parameter_list.c",
    ]
    if with_example:
        sources += [DOCS_DIR / "example" / "parameter_list_usage_example.c",
                    work_dir / "log_stub.c"]
    sources.append(work_dir / "main.c")
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Wpedantic",
               *includes, *[str(path) for path in sources],
               "-o", str(work_dir / "parameter_list_test")]
    result = _run(command)
    if result.returncode != 0:
        print(paint("C compilation FAILED:", BOLD + BRIGHT_RED) + "\n" + result.stderr)
        return False
    if result.stderr.strip():
        print("C compiler warnings:\n" + result.stderr)
    return True


def compile_cxx(work_dir: Path, includes: List[str]) -> bool:
    """The generated headers must be usable from C++ as well."""
    source = work_dir / "cxx_include_test.cpp"
    source.write_text(
        '#include "cg_parameter_list.h"\n'
        '#include "cg_smart_data.h"\n'
        '#include "cg_parameter_list_defines.h"\n'
        '#include "cg_parameter_list_table.h"\n'
        '#include "cg_parameter_list_types.h"\n'
        "int main() { return ParameterList[0].pSmartData == 0; }\n",
        encoding="utf-8")
    command = [CXX_COMPILER, "-std=c++11", "-Wall", "-Wextra", "-c",
               *includes, str(source), "-o", str(work_dir / "cxx_include_test.o")]
    result = _run(command)
    if result.returncode != 0:
        print(paint("C++ compilation FAILED:", BOLD + BRIGHT_RED) + "\n" + result.stderr)
        return False
    return True


_MAIN_HEAD = """
#include <stdio.h>
#include <string.h>
#include "cg_parameter_list.h"
#include "cg_smart_data.h"
#include "cg_parameter_list_table.h"
#include "parameter_descriptor.h"

/* The change event is a weak callback, so the test overrides it and counts the
   calls. That is the only way to prove it fires on an accepted write and stays
   quiet on a refused one. */
static unsigned gWriteEventCount = 0U;
void fParameterDescriptor_ParameterWriteCompletedCallback(sParameterDescriptor *sender,
                                                          void *pEv) {
    (void)sender;
    (void)pEv;
    gWriteEventCount++;
}
"""

_MAIN_HEAD_WITH_EXAMPLE = _MAIN_HEAD + '#include "parameter_list_usage_example.h"\n'

_MAIN_BODY = """
int main(void) {
    uint16_t index = 0U;
    uint8_t result = fParameterList_Init();
    if (result != 0U) {
        printf("fParameterList_Init failed with %u\\n", (unsigned)result);
        return 1;
    }
    if (fParameterList_GetQuantity() != PARAMETER_LIST_QTY) {
        printf("wrong quantity\\n");
        return 1;
    }
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL || pDescriptor->pName == NULL) {
            printf("descriptor %u is broken\\n", (unsigned)index);
            return 1;
        }
        if (fParameterList_GetByName(pDescriptor->pName) != pDescriptor) {
            printf("lookup by name failed for %s\\n", pDescriptor->pName);
            return 1;
        }
        if (pDescriptor->pSmartData == NULL) {
            printf("no smart data for %s\\n", pDescriptor->pName);
            return 1;
        }
    }
    if (fParameterList_GetByIndex(PARAMETER_LIST_QTY) != NULL) {
        printf("out of range index was accepted\\n");
        return 1;
    }
    EXAMPLE_CALLS
    EXTRA_CHECKS
    printf("OK: %u parameters initialised and verified" EXAMPLE_NOTE "\\n",
           (unsigned)PARAMETER_LIST_QTY);
    return 0;
}
"""

_EXAMPLE_CALLS = """
    /* The usage example must work as well. */
    fExample_DirectAccess();
    if (fExample_CheckedAccess() != eSMART_DATA_OK) {
        printf("fExample_CheckedAccess failed\\n");
        return 1;
    }
    if (fExample_DescriptorAccess() != 0U) {
        printf("fExample_DescriptorAccess failed\\n");
        return 1;
    }
    if (fExample_StructAccess() != 0U) {
        printf("fExample_StructAccess failed\\n");
        return 1;
    }
    fExample_ArrayAccess();
    if (fExample_ReadIfNew() != TRUE || fExample_ReadIfNew() != FALSE) {
        printf("fExample_ReadIfNew failed\\n");
        return 1;
    }
"""


def main_source(with_example: bool, extra_checks: str = "") -> str:
    head = _MAIN_HEAD_WITH_EXAMPLE if with_example else _MAIN_HEAD
    calls = _EXAMPLE_CALLS if with_example else ""
    note = '", usage example runs"' if with_example else '""'
    return (head + f"#define EXAMPLE_NOTE {note}\n"
            + _MAIN_BODY.replace("    EXAMPLE_CALLS", calls)
                        .replace("    EXTRA_CHECKS", extra_checks))


def _check_param_table(variant: dict, work_dir: Path) -> bool:
    """Generate the ADD_PARAM table, compile it, run it.

    The firmware defines what ADD_PARAM means and includes the header inside a
    function, so that is what the test does.  Counting the rows it expanded is
    what proves the file is really C and not merely the right shape.
    """
    lists = work_dir / "lists"
    lists.mkdir(exist_ok=True)
    for name, text in variant["files"].items():
        (lists / name).write_text(text, encoding="utf-8")

    print("  1/3 generating the table ...")
    config_path = write_config(
        work_dir, {"model_files": [str(lists / name) for name in variant["files"]]},
        output_format="param_table")
    exit_code = generator_main(["--config", str(config_path), "--quiet"])
    if exit_code != 0:
        print(f"  FAILED: the generator returned {exit_code} on the test's own "
              f"fixture, so the tool is at fault.")
        return False

    header = work_dir / "generated" / "nsrParamTables.h"
    if not header.is_file():
        print(f"  FAILED: no {header.name} was written.")
        return False

    (work_dir / "table_main.c").write_text(_PARAM_TABLE_MAIN, encoding="utf-8")

    print("  2/3 compiling as C99 ...")
    binary = work_dir / "param_table_test"
    result = _run([C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Werror",
                   f"-I{work_dir / 'generated'}",
                   str(work_dir / "table_main.c"), "-o", str(binary)])
    if result.returncode != 0:
        print("  FAILED: the generated table does not compile.")
        print(result.stderr.strip()[:2000])
        return False

    print("  3/3 running it ...")
    result = _run([str(binary)])
    if result.returncode != 0:
        print("  FAILED: the table did not expand as expected.")
        print((result.stdout + result.stderr).strip()[:1000])
        return False
    print(f"        OK: {result.stdout.strip()}")
    return True


def main() -> int:
    for compiler in (C_COMPILER, CXX_COMPILER):
        if not have_compiler(compiler):
            print(paint(f"SKIPPED: '{compiler}' was not found on the PATH.", YELLOW))
            return 0

    variants = input_variants()
    print(f"Checking {len(variants)} input variant(s).\n")

    for number, variant in enumerate(variants, start=1):
        label = variant["label"]
        with_example = variant.get("with_example", True)
        print(paint(f"=== {number}/{len(variants)}  {label} ===", CYAN))
        if not check_one(variant, with_example):
            return 1
        print()

    print(paint("All checks passed.", GREEN))
    return 0


def check_one(variant: dict, with_example: bool) -> bool:
    """Generate from *variant*, compile the result and run it."""
    with tempfile.TemporaryDirectory(prefix="pl_codegen_test_") as raw_dir:
        work_dir = Path(raw_dir)

        # A variant either points at a file of the project or brings its own
        # model along; a fixture keeps the test independent of what the user
        # happens to have in the editor.
        if variant.get("format") == "param_table":
            return _check_param_table(variant, work_dir)

        inputs = variant.get("inputs")
        if inputs is None:
            fixture = work_dir / "fixture.xml"
            fixture.write_text(variant["fixture"], encoding="utf-8")
            inputs = {"model_files": [str(fixture)]}

        print("  1/4 generating the code ...")
        config_path = write_config(work_dir, inputs)
        exit_code = generator_main(["--config", str(config_path), "--quiet"])
        if exit_code != 0:
            # Two very different things end up here and they need different
            # answers from the reader, so the message says which one it is: the
            # tool may be broken, or this project's own parameter lists may
            # simply not be valid right now.  Only the second is fixed in the
            # editor rather than in the code.
            if variant.get("inputs") is not None:
                print(f"  FAILED: the generator refused this project's parameter "
                      f"list(s) (exit {exit_code}).\n"
                      f"          The diagnostics above are about the MODEL, not "
                      f"about the tool - fix them in the editor and run again.")
            else:
                print(f"  FAILED: the generator returned {exit_code} on the "
                      f"test's own fixture, so the tool is at fault.")
            return False

        (work_dir / "main.c").write_text(
            main_source(with_example, variant.get("extra_checks", "")),
            encoding="utf-8")
        stub_dir = work_dir / "stubs"
        stub_dir.mkdir(exist_ok=True)
        (stub_dir / "chrono.h").write_text(_CHRONO_STUB_H, encoding="utf-8")
        includes = [f"-I{DOCS_DIR / 'example'}",
                    f"-I{LIB_TEMPLATE_DIR / 'smart_data'}",
                    f"-I{LIB_TEMPLATE_DIR / 'parameter_descriptor'}",
                    f"-I{work_dir / 'generated'}",
                    f"-I{stub_dir}"]

        print("  2/4 compiling as C99 ...")
        if not compile_c(work_dir, includes, with_example):
            return False

        print("  3/4 compiling the headers as C++ ...")
        if not compile_cxx(work_dir, includes):
            return False

        print("  4/4 running the generated parameter list ...")
        result = _run([str(work_dir / "parameter_list_test")])
        print("        " + result.stdout.strip())
        if result.returncode != 0:
            print(paint("  FAILED: the test program returned a non-zero exit code.",
                        BOLD + BRIGHT_RED))
            return False
    return True


if __name__ == "__main__":
    raise SystemExit(main())

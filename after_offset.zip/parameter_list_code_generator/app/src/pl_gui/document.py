"""The document the GUI edits: the parameter list plus its file and undo stack.

Everything the front end does goes through this class, so the rules about what
a valid edit is live in one place.
"""

from __future__ import annotations

import copy
import os
import re
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from pl_codegen.choices import load_choices, save_choices
from pl_codegen.codegen.files.param_table_h import READ_ONLY_TAGS
from pl_codegen.config import FORMAT_PARAM_TABLE, Config
from pl_codegen.errors import CodeGeneratorError, DiagnosticCollector, Severity
from pl_codegen.layout.tag_offset import reserved_log_ids
from pl_codegen.model.defines import (COLUMN_TYPES, COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES,
                                      COLUMN_VALUE_TYPES, Defines)
from pl_codegen.model.parameter import Parameter, ParameterKind
from pl_codegen.model.parameter_list import PATH_SEPARATOR, ParameterList
from pl_codegen.model.struct_sync import apply_types
from pl_codegen.model.struct_type import StructField, StructType
from pl_codegen.model.types import resolve_value_type
from pl_codegen.naming import is_valid_c_identifier
from pl_codegen.xml_model.types_xml import (is_types_file, read_types,
                                            types_file_for)
from pl_codegen.model.tags import TAG_REGISTRY
from pl_codegen.model.types import VALUE_TYPES, resolve_value_type
from pl_codegen.pipeline import Pipeline
from pl_codegen.validation.validator import Validator
from pl_codegen.xml_model.xml_reader import read_xml
from pl_codegen.xml_model.xml_writer import write_xml

from .config_file import rewrite_model_files

#: how many steps of undo the GUI keeps
UNDO_DEPTH = 60

#: Every field of :class:`~pl_codegen.model.parameter.Parameter` the
#: editor form is allowed to write, i.e. every ``data-field`` in ``editor.js``.
#: ``tags``, ``name`` and the tree structure are handled separately; ``kind``
#: and ``children`` are deliberately absent, because a wrong value in either
#: crashes validation - and validation runs inside ``/api/state``, so it would
#: take the whole editor down rather than show a diagnostic.
EDITABLE_FIELDS = frozenset({
    "gs_name", "param_type", "value_type_name", "array_size", "unit", "enable",
    "default_value", "minimum", "maximum", "resolution", "log_id", "description",
})

# The drop-down lists a brand new model starts with - the company's lists.
# Edit them here, or per model with the "Choices..." button in the editor.
DEFAULT_PARAMETER_TYPES = [
    "MONITORING",
    "COMMAND",
    "SETTING",
]

DEFAULT_SYSTEM_NAMES = [
    "SYS_UNKNOWN",
    "SYS_GS_COMPUTER",
    "SYS_GS_MANAGER",
    "SYS_GS_POWER",
    "SYS_ANTENNA_TRACKER",
    "SYS_AC_MANAGER",
    "SYS_AC_POWER",
    "SYS_AC_AUTOPILOT",
    "SYS_GIMBAL",
    "SYS_LOCK_TRACK",
    "SYS_LINK_GS",
    "SYS_GS_USB2CAN",
    "SYS_LINK_AIR",
    "SYS_BOOTLOADER",
    "SYS_LINK_BOX",
    "SYS_GOVERNOR",
    "SYS_NAV",
    "SYS_AND",
    "SYS_VNS",
    "SYS_RHS",
    "SYS_AUP",
]

DEFAULT_PARAM_MODES = [
    "PARAM_MODE_USER",
    "PARAM_MODE_READ_ONLY",
    "PARAM_MODE_PRODUCT_TYPE",
    "PARAM_MODE_FACTORY",
    "PARAM_MODE_CALIB",
    "PARAM_MODE_TEMPORARY",
]


class Document:
    """The in-memory parameter list plus everything the GUI needs around it."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.model = ParameterList()
        self.path: Optional[Path] = config.inputs.model_file
        self.dirty = False
        #: what the READER said about the open file, kept until it is written
        #: again.  These do not come back from re-validating the model: the
        #: reader has already dropped the value it could not use, so the model
        #: in memory looks clean while the file on disk is still wrong - and
        #: the generator reads the file.
        self.load_problems: List[Dict[str, object]] = []
        #: what the last structure-type edit wants to tell the user, if
        #: anything - a rename that could only reach this list, say
        self.last_type_note = ""
        self._undo: List[Tuple[str, ParameterList]] = []
        self._redo: List[Tuple[str, ParameterList]] = []

    # -- loading and saving ------------------------------------------------
    def reread_project(self) -> Optional[str]:
        """Pick up a project file that was changed outside the editor.

        The editor used to hold the ``Config`` it loaded when the project was
        opened, so an edit made in a text editor - a different output folder,
        a stricter validation setting - was simply invisible.  Reload said
        nothing had changed and Generate wrote to the old place, which is a
        very hard thing to explain to somebody looking at the file they just
        saved.

        Returns the reason when the file cannot be read, and keeps the working
        configuration in that case: a project file with a typo in it must not
        take the editor down, and the message goes to the Problems panel like
        any other.
        """
        if self.config.path is None or not self.config.path.is_file():
            return None
        try:
            self.config = Config.load(self.config.path)
        except CodeGeneratorError as error:
            return str(error)
        return None

    def load(self, path: Optional[Path] = None) -> List[Dict[str, object]]:
        """Read the XML model, and the project file around it.

        Both, because "Reload" means the project as it is on disk - not the
        parameter list on disk inside the settings this session started with.
        """
        broken_project = self.reread_project()
        target = Path(path) if path else self.path
        diagnostics = DiagnosticCollector()
        if target is not None and target.is_file():
            self.model = read_xml(target, diagnostics)
            self.path = target
        else:
            self.model = ParameterList()
            self.path = target
        self._ensure_defines()
        self.dirty = False
        self._undo.clear()
        self._redo.clear()
        self.load_problems = diagnostics.to_list()
        if broken_project:
            self.load_problems.insert(0, {
                "severity": "error", "code": "CFG001", "message": broken_project,
                "location": {"file": str(self.config.path), "sheet": None, "row": None,
                             "column": None, "parameter": None},
                "hint": "The settings from before the edit are still in use.",
            })
        return self.load_problems

    def save(self, path: Optional[Path] = None) -> Path:
        target = Path(path) if path else self.path
        if target is None:
            raise ValueError("No file name given.")
        write_xml(self.model, target,
                  emit_timestamp=self.config.codegen.emit_timestamp)
        self.path = target
        self.dirty = False
        # The file now says what the model says, so whatever the reader
        # complained about on the way in is no longer true of it.
        self.load_problems = []
        return target

    def _ensure_defines(self) -> None:
        """The machine's drop-down lists, which are never empty.

        They come from the app rather than from this project, so an empty list
        is not a state a project can be in: at worst the machine has never had
        one and gets the shipped defaults.
        """
        self.model.defines = load_choices()

    # -- undo / redo --------------------------------------------------------
    def snapshot(self, label: str) -> None:
        """Remember the current state before changing it."""
        self._undo.append((label, copy.deepcopy(self.model)))
        del self._undo[:-UNDO_DEPTH]
        self._redo.clear()
        self.dirty = True

    def undo(self) -> Optional[str]:
        if not self._undo:
            return None
        label, state = self._undo.pop()
        self._redo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    def redo(self) -> Optional[str]:
        if not self._redo:
            return None
        label, state = self._redo.pop()
        self._undo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    # -- finding nodes ------------------------------------------------------
    def find(self, path: str) -> Optional[Parameter]:
        return self.model.find(path) if path else None

    def parent_of(self, path: str) -> Tuple[Optional[Parameter], List[Parameter]]:
        """Return ``(parent node or None, the list the node lives in)``."""
        parts = path.split(PATH_SEPARATOR)
        if len(parts) == 1:
            return None, self.model.parameters
        parent = self.model.find(PATH_SEPARATOR.join(parts[:-1]))
        return parent, parent.children if parent else self.model.parameters

    # -- editing ------------------------------------------------------------
    def add_parameter(self, parent_path: str = "", kind: str = "primitive") -> str:
        """Add a parameter (or a struct) under *parent_path*; return its path."""
        if kind == "struct" and self.config.output.format == FORMAT_PARAM_TABLE:
            raise ValueError(
                "This project generates a parameter table, which has no "
                "structures - every row is one value. Add parameters instead, "
                "or set output.format to 'smart_data' in the project file.")

        self.snapshot("add")
        parent = self.find(parent_path) if parent_path else None
        siblings = parent.children if parent is not None and parent.is_struct \
            else self.model.parameters
        prefix = parent_path if (parent is not None and parent.is_struct) else ""

        node = Parameter(
            name=_unique_name("NewStruct" if kind == "struct" else "NewParameter", siblings),
            kind=ParameterKind.STRUCT if kind == "struct" else ParameterKind.PRIMITIVE)
        if node.is_primitive:
            node.value_type_name = "uint8_t"
            node.default_value = 0
            node.minimum = 0
            node.maximum = 0
            node.resolution = _default_resolution(node.value_type_name)
        if prefix == "":
            node.param_type = self.model.defines.get(COLUMN_TYPES)[0] \
                if self.model.defines.get(COLUMN_TYPES) else "MONITORING"
            node.tags = {spec.tag_id: _default_tag(spec, self.model.defines)
                         for spec in TAG_REGISTRY}
        siblings.append(node)
        return f"{prefix}{PATH_SEPARATOR}{node.name}" if prefix else node.name

    def duplicate(self, path: str) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("duplicate")
        _parent, siblings = self.parent_of(path)
        clone = copy.deepcopy(node)
        clone.name = _unique_name(node.name, siblings)
        _clear_log_ids(clone)
        siblings.insert(siblings.index(node) + 1, clone)
        prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
        return f"{prefix}{PATH_SEPARATOR}{clone.name}" if prefix else clone.name

    def delete(self, path: str) -> bool:
        node = self.find(path)
        if node is None:
            return False
        self.snapshot("delete")
        _parent, siblings = self.parent_of(path)
        siblings.remove(node)
        return True

    def move(self, path: str, offset: int) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        _parent, siblings = self.parent_of(path)
        index = siblings.index(node)
        target = index + offset
        if not 0 <= target < len(siblings):
            return None
        self.snapshot("move")
        siblings.pop(index)
        siblings.insert(target, node)
        return path

    def update(self, path: str, changes: Dict[str, object]) -> Optional[str]:
        """Apply the values coming from the editor form.  Returns the new path.

        Only the fields the form actually offers are written.  The browser
        chooses the names (``data-field``), so without this list a stale page -
        or a typo - could set ``kind`` to a string or ``children`` to something
        that is not a list, and the next validation run would die inside
        ``/api/state``, which takes the whole editor down with it.
        """
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("edit")
        previous_type = node.value_type_name

        # A parameter table has one value per row and no structures at all.
        # Refused here as well as hidden in the form, so a page left open from
        # before the format was changed cannot write one either.
        if self.config.output.format == FORMAT_PARAM_TABLE:
            wanted = changes.get("array_size")
            if wanted is not None and int(wanted) > 1:
                raise ValueError(
                    f"This project generates a parameter table, where every row "
                    f"is one value, so an array size of {int(wanted)} has "
                    f"nowhere to go. Write that many parameters instead, or set "
                    f"output.format to 'smart_data' in the project file.")

        # Tags and the type belong to the top level entry.  A field inside a
        # structure cannot set them, so drop them here as well as in the form -
        # that way a stale page can never write them either.
        if PATH_SEPARATOR in path:
            changes.pop("tags", None)
            changes.pop("param_type", None)

            # ...and the SHAPE of a field belongs to its structure type: its
            # name, what it holds, how many of it there are, its unit and its
            # description.  Writing one here looked like it worked and was then
            # thrown away by the next thing that re-applied the type - the edit
            # simply vanished, with nothing anywhere to say why.  Refusing it
            # and pointing at the type is the honest answer.
            owned = [key for key in ("name", "value_type_name", "array_size",
                                     "unit", "description") if key in changes]
            if owned:
                owner = self.find(path.split(PATH_SEPARATOR)[0])
                type_name = owner.value_type_name if owner is not None else ""
                shown = {"name": "name", "value_type_name": "data type",
                         "array_size": "array size", "unit": "unit",
                         "description": "description"}
                named = f"'{type_name}'" if type_name else "of its structure"
                raise ValueError(
                    f"The {', '.join(shown[key] for key in owned)} of a field "
                    f"belongs to the structure type {named}, not to this "
                    f"parameter - every parameter of that type has the same "
                    f"fields. Change it in 'Structure types…' and it changes "
                    f"everywhere at once.")

        new_path = path
        if "name" in changes:
            name = str(changes.pop("name") or "").strip()
            _reject_path_characters(name)
            self._reject_duplicate_name(path, node, name)
            if name and name != node.name:
                node.name = name
                prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
                new_path = f"{prefix}{PATH_SEPARATOR}{name}" if prefix else name

        tags = changes.pop("tags", None)
        if isinstance(tags, dict):
            tags = dict(tags)
            # A parameter table has no column for the sub-system tag (the file
            # name says it), for reset-proof, or for the two logging tags, so
            # the form shows them read-only - and a form with no field for a
            # tag sends no value for it, which through the line below would
            # DELETE it.  The parameter list is shared: a smart-data project
            # opening the same file decides real things with those tags, and
            # losing them here would break that build with nothing to show for
            # it.  So in this format they keep whatever they had.
            if self.config.output.format == FORMAT_PARAM_TABLE:
                for tag_id in READ_ONLY_TAGS:
                    if tag_id in node.tags:
                        tags[tag_id] = node.tags[tag_id]
                    else:
                        tags.pop(tag_id, None)
            node.tags = tags

        for key, value in changes.items():
            if key in EDITABLE_FIELDS:
                setattr(node, key, value)

        # The two worlds are kept apart here as well as in the form: a
        # structure IS of a structure type and a parameter IS of a data type,
        # and neither may be given the other's.  The drop-down never offers the
        # wrong ones, so this only ever catches a stale page - but silently
        # converting one into the other is how a parameter list used to end up
        # generating something nobody asked for.
        chosen = str(changes.get("value_type_name") or "")
        if chosen and node.is_struct and resolve_value_type(chosen) is not None:
            node.value_type_name = previous_type
            raise ValueError(
                f"'{node.name}' is a structure, so its type has to be a structure "
                f"type - '{chosen}' is a data type. Give '{chosen}' to one of its "
                f"fields, or delete this and add a parameter instead.")
        if chosen and node.is_primitive and self.find_struct_type(chosen) is not None:
            node.value_type_name = previous_type
            raise ValueError(
                f"'{node.name}' is a parameter, so it holds one value - "
                f"'{chosen}' is a structure type. Add a structure instead.")

        # A structure that was given a type it really may have is reshaped by
        # that type, right away: the fields are what the parameter now has.
        if chosen and node.is_struct and chosen != previous_type:
            self._resync()
            return new_path

        # The value type decides what the range, the resolution and the default
        # value even MEAN, so changing it has to bring them along.
        if "value_type_name" in changes:
            self._retune_for_type(node, previous_type)

        # ... and a boolean is held to its shape on EVERY edit, not only when
        # the type changed.  Its form has no minimum, maximum or resolution box,
        # so a number written into one of those - by a stale page, or by an
        # update that was already in flight when the type became bool_t - could
        # never be seen or corrected.  Every other type shows its fields, so a
        # wrong value there is visible and gets a diagnostic instead.
        self._hold_boolean_shape(node)

        return new_path

    @staticmethod
    def _hold_boolean_shape(node: Parameter) -> None:
        """Keep a boolean at the only shape a boolean can have.

        0 / 1 / 1 is the triple the range rule accepts in silence - it simply
        restates what a boolean is - and the default value has to be a real
        boolean rather than a number that happens to be truthy.
        """
        value_type = resolve_value_type(node.value_type_name)
        if node.is_struct or value_type is None or not value_type.is_bool:
            return

        node.minimum = 0
        node.maximum = 1
        node.resolution = 1
        if not isinstance(node.default_value, bool):
            node.default_value = bool(node.default_value)

    def _reject_duplicate_name(self, path: str, node: Parameter, name: str) -> None:
        """Refuse a name another node at the same level already has.

        A node is addressed by its dotted path, so two siblings sharing a name
        share a path - and every lookup then finds the first of the two.  The
        validator did report the clash, but by then delete, move and edit were
        all acting on the wrong node: renaming a new parameter to match an
        existing one and then deleting it took the ORIGINAL away, with nothing
        on screen to say so.

        Uniqueness is therefore enforced where the name is typed, not where the
        model is checked.
        """
        if not name or name == node.name:
            return
        _parent, siblings = self.parent_of(path)
        for other in siblings:
            if other is not node and other.name == name:
                raise ValueError(
                    f"'{name}' is already used here. Two parameters at the same "
                    f"level cannot share a name - they would have the same path, "
                    f"and the editor could no longer tell them apart."
                )

    @staticmethod
    def _retune_for_type(node: Parameter, previous_type: Optional[str]) -> None:
        """Bring the type-dependent fields to values the NEW type can hold.

        Three of them depend on the type: the minimum, the maximum and the
        resolution describe a range in that type's units, and the default value
        has to be a value of it.  Left alone across a type change they become
        either meaningless or impossible:

        * ``float32_t`` -> ``bool_t`` kept a 0..120 range and a 0.1 resolution.
          A boolean has none of the three, so the form does not show them - and
          a value you cannot see is a value you cannot correct.  This was a
          dead end: the tool warned about something the editor gave no way to
          fix.
        * ``bool_t`` -> ``uint8_t`` kept ``DefaultValue = True``.
        * ``int32_t`` -> ``int8_t`` kept limits that do not fit in a byte.

        Only what is actually wrong for the new type is touched.  A limit that
        still fits was somebody's decision and stays.
        """
        if node.value_type_name == previous_type:
            return

        new_type = resolve_value_type(node.value_type_name)
        old_type = resolve_value_type(previous_type)

        # -- the resolution ------------------------------------------------
        # Per type: 1 for the integers, 0.001 for float32_t, 0.000001 for
        # float64_t.  1 on a float is not a rounding detail - it quantises
        # every value to whole numbers.  A resolution somebody chose is kept.
        old_default = _default_resolution(previous_type)
        if node.resolution is None or node.resolution == old_default:
            node.resolution = _default_resolution(node.value_type_name)

        # -- becoming a boolean --------------------------------------------
        if new_type is not None and new_type.is_bool:
            # A boolean has no range and no resolution, and the form has no box
            # for any of them, so they are cleared rather than left invisible.
            # 0 / 1 / 1 is the one triple that simply restates what a boolean
            # is; the range rule accepts it in silence, where 0 / 0 / 1 would
            # be reported as odd - and reported is exactly what this parameter
            # can no longer be fixed from.
            node.minimum = 0
            node.maximum = 1
            node.resolution = 1
            node.default_value = bool(node.default_value)
            return

        # -- leaving a boolean ---------------------------------------------
        if old_type is not None and old_type.is_bool:
            node.default_value = 1 if node.default_value else 0
            # "no range" - the generated code then uses the type's own limits
            node.minimum = 0
            node.maximum = 0
            return

        # -- number to number ----------------------------------------------
        if new_type is None or new_type.native_min is None:
            return
        low, high = new_type.native_min, new_type.native_max
        whole_only = not new_type.is_float

        def fits(value) -> bool:
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                return False
            if not (low <= value <= high):
                return False
            # An integer type cannot hold 10.5 either.  C takes the literal and
            # quietly makes it 10, so a value that is merely IN RANGE is not yet
            # a value the new type can carry.
            return not whole_only or float(value).is_integer()

        # A limit the new type cannot express is reset to "no range" - both
        # zero - rather than clamped to a boundary nobody chose.  Resetting
        # only one of the two would leave a half range that reads like a
        # decision, so they go together.
        if not fits(node.minimum) or not fits(node.maximum):
            node.minimum = 0
            node.maximum = 0
        if not fits(node.default_value):
            node.default_value = 0

        # The resolution is a step in the units of the type, so a fractional one
        # means nothing on an integer - it would be written into the generated
        # code as a whole number the author never asked for.  A step somebody
        # chose that the new type CAN hold is left alone.
        if whole_only and node.resolution is not None:
            try:
                fractional = not float(node.resolution).is_integer()
            except (TypeError, ValueError):
                fractional = False
            if fractional:
                node.resolution = _default_resolution(node.value_type_name)

    # -- the parameter lists of the project --------------------------------------
    #
    # A project is one parameter list split over several files, one per
    # sub-module.  They all live in one folder (``inputs.model_directory``), and
    # the configuration says which of them take part in a build and in what
    # order - that order is the order of the indices in the generated code, so
    # it is a real decision and not a detail.  The editor writes that choice back
    # into project.json, because that file is what run_generate.py reads:
    # if the two could disagree, the code someone generates from the command line
    # would not be the code they saw in the editor.

    def list_directory(self) -> Path:
        return self.config.inputs.model_directory

    def known_lists(self) -> List[Dict[str, object]]:
        """Every parameter list of the project, selected ones first, in order.

        A file in the folder that no configuration mentions is still shown -
        that is how somebody finds the list a colleague added - it is simply not
        selected, so it takes no part in the build until someone says so.
        """
        # A configuration edited by hand can name the same file twice; the rows
        # are what the dialog binds its checkboxes to, so each file appears once
        # here and 'select_lists' drops the duplicate when it writes back.
        chosen: List[Path] = []
        for path in self.config.inputs.model_files:
            if path not in chosen:
                chosen.append(path)

        directory = self.list_directory()
        # A "_structures.xml" is a list's structure types, not a list.
        found = sorted(path for path in directory.glob("*.xml")
                       if not is_types_file(path)) if directory.is_dir() else []

        entries: List[Dict[str, object]] = []
        for order, path in enumerate(chosen):
            entries.append(self._list_entry(path, selected=True, order=order))
        for path in found:
            if path not in chosen:
                entries.append(self._list_entry(path, selected=False, order=-1))
        return entries

    def _list_entry(self, path: Path, *, selected: bool, order: int) -> Dict[str, object]:
        return {
            "path": str(path),
            "name": path.stem,
            "file": path.name,
            "selected": selected,
            "order": order,
            "exists": path.is_file(),
            "current": self.path is not None and path == self.path,
            "inFolder": path.parent == self.list_directory(),
        }

    def create_list(self, name: str, directory: str = "") -> Path:
        """Make a new, empty parameter list and add it to the build.

        It is written to disk straight away, so the file the editor is about to
        open really exists and ``run_generate.py`` sees the same project the
        editor does.

        *directory* is where to put it; empty means the project's own
        parameter-list folder, which is the usual case.  A sub-module that
        keeps its list next to its own code passes its own folder instead - the
        configuration then records a relative path and the build works exactly
        the same.
        """
        stem = _safe_stem(name)
        if not stem:
            raise ValueError("A parameter list needs a name.")

        target_directory = Path(directory).expanduser() if directory.strip() \
            else self.list_directory()
        try:
            target_directory = target_directory.resolve()
            target_directory.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            raise ValueError(f"Cannot use the folder '{target_directory}': {error}") from error

        target = target_directory / f"{stem}.xml"
        if target.exists():
            raise FileExistsError(f"'{target.name}' already exists in {target_directory}.")

        fresh = ParameterList()
        fresh.defines = copy.deepcopy(self.model.defines)
        write_xml(fresh, target, emit_timestamp=self.config.codegen.emit_timestamp)

        self.select_lists([str(path) for path in self.config.inputs.model_files]
                          + [str(target)])
        return target

    def inspect_list(self, path: str) -> Dict[str, object]:
        """Ask whether *path* is a parameter list this tool can build.

        This is the gate in front of "add an existing file": the editor lets
        somebody point at any XML on the machine, and an XML that is not a
        parameter list has to be refused *here*, with a reason - not accepted
        and then discovered halfway through a build, when the configuration has
        already been rewritten.

        Returns what the dialog needs to show: whether it fits, why not if it
        does not, and a short summary of what is inside if it does.
        """
        candidate = Path(path).expanduser()
        if not str(path).strip():
            return {"ok": False, "reason": "No file name given."}
        try:
            candidate = candidate.resolve()
        except OSError as error:
            return {"ok": False, "reason": f"Cannot read that path: {error}"}

        if not candidate.is_file():
            return {"ok": False, "reason": f"'{candidate}' does not exist."}
        if is_types_file(candidate):
            return {"ok": False,
                    "reason": f"'{candidate.name}' holds the structure types of "
                              f"'{candidate.name[:-len('_structures.xml')]}.xml', not a "
                              f"parameter list. Open that file instead."}
        if candidate.suffix.lower() != ".xml":
            return {"ok": False,
                    "reason": f"'{candidate.name}' is not an .xml file."}

        diagnostics = DiagnosticCollector()
        try:
            model = read_xml(candidate, diagnostics)
        except CodeGeneratorError as error:
            # read_xml raises for the two things that mean "this is not one of
            # ours at all": unparsable XML, and a different root element.
            return {"ok": False, "path": str(candidate), "reason": str(error)}

        structures = sum(1 for node in model.walk() if node.is_struct)
        return {
            "ok": True,
            "path": str(candidate),
            "name": candidate.stem,
            "values": len(model.flatten()),
            "parameters": len(model.parameters),
            "structures": structures,
            "types": model.struct_types.names(),
            # A file that parses can still have something to say about itself -
            # an unknown tag, a field carrying a type it should not.  It is
            # not a reason to refuse the file, but the dialog shows it.
            "notes": [item["message"] for item in diagnostics.to_list()][:5],
        }

    def add_existing_list(self, path: str) -> Path:
        """Take an existing parameter list into the build - copying it in.

        A list from another project is **copied** into this one, together with
        the structures file beside it.  That is what keeps a project a folder
        you can move: every list it builds lives inside it, so its project file
        never has to point at somewhere else on the machine, and the two
        projects go on being independent - editing this copy cannot change what
        the other project generates.

        A list already inside this project is simply added to the build; there
        is nothing to copy.
        """
        verdict = self.inspect_list(path)
        if not verdict.get("ok"):
            raise ValueError(str(verdict.get("reason") or "That file is not a parameter list."))

        source = Path(str(verdict["path"]))
        if any(_same_file(source, item) for item in self.config.inputs.model_files):
            raise ValueError(f"'{source.name}' is already part of the build.")

        target = self._bring_into_the_project(source)
        self.select_lists([str(item) for item in self.config.inputs.model_files]
                          + [str(target)])
        return target

    def _bring_into_the_project(self, source: Path) -> Path:
        """Copy *source* (and its structures) into the project's list folder.

        A file already under the project root stays where it is: somebody who
        keeps a list in a sub-folder of their project meant to.
        """
        root = self.config.path.parent.resolve()
        try:
            source.resolve().relative_to(root)
            return source            # already ours
        except ValueError:
            pass

        directory = self.list_directory()
        directory.mkdir(parents=True, exist_ok=True)

        target = directory / source.name
        if target.exists() and not _same_file(target, source):
            # Never write over a list this project already has: two different
            # lists of one name is exactly the mess the copy is meant to avoid.
            stem, suffix = source.stem, source.suffix
            index = 2
            while (directory / f"{stem}_{index}{suffix}").exists():
                index += 1
            target = directory / f"{stem}_{index}{suffix}"

        shutil.copy2(source, target)
        structures = types_file_for(source)
        if structures.is_file():
            shutil.copy2(structures, types_file_for(target))
        return target

    def remove_list(self, path: str, delete_file: bool = False) -> Dict[str, object]:
        """Take a list out of the build, and optionally delete its file.

        Removing the list that is currently open leaves the editor with nothing
        to show, so the caller is told which list to open instead - the first
        one still in the build, or none at all.

        Deleting the file is a separate flag rather than the same action: one is
        a change of mind about the build and is undone by adding the list back,
        the other is not undoable at all.
        """
        target = Path(path).expanduser()
        try:
            target = target.resolve()
        except OSError:
            pass

        remaining = [item for item in self.config.inputs.model_files
                     if not _same_file(item, target)]
        if len(remaining) == len(self.config.inputs.model_files) and not delete_file:
            raise ValueError(f"'{target.name}' is not part of the build.")

        if remaining:
            self.select_lists([str(item) for item in remaining])
        else:
            # An empty build would leave the generator with no input at all;
            # the configuration keeps its list rather than being emptied.
            raise ValueError("The build needs at least one parameter list.")

        deleted = False
        if delete_file and target.is_file():
            target.unlink()
            # ...and the structures beside it.  A list's structures describe
            # that list and nothing else, so one left behind is a file nobody
            # will ever open again - and the thing most likely to be copied
            # somewhere later and clash with a type that is still in use.
            structures = types_file_for(target)
            if structures.is_file():
                structures.unlink()
            deleted = True

        was_open = self.path is not None and _same_file(self.path, target)
        return {"removed": str(target), "deleted": deleted, "wasOpen": was_open,
                "openInstead": str(remaining[0]) if was_open else ""}

    def browse(self, directory: str = "") -> Dict[str, object]:
        """List the sub-folders and the .xml files of one folder.

        The editor runs in a browser, and a browser cannot hand a page a real
        path - a file input gives a name and a blob, never a location the
        generator could put in its configuration.  So the browsing is done
        here, where the paths are real.
        """
        if str(directory).strip():
            here = Path(directory).expanduser()
        else:
            here = self.path.parent if self.path is not None else self.list_directory()
        try:
            here = here.resolve()
        except OSError as error:
            return {"ok": False, "message": f"Cannot open that folder: {error}"}

        if not here.is_dir():
            return {"ok": False, "message": f"'{here}' is not a folder."}

        try:
            entries = sorted(here.iterdir(), key=lambda item: item.name.lower())
        except OSError as error:
            return {"ok": False, "message": f"Cannot list '{here}': {error}"}

        folders, files = [], []
        for entry in entries:
            try:
                if entry.is_dir():
                    if not entry.name.startswith("."):
                        folders.append({"name": entry.name, "path": str(entry)})
                elif entry.suffix.lower() == ".xml" and not is_types_file(entry):
                    files.append({"name": entry.name, "path": str(entry)})
            except OSError:
                continue        # a folder we are not allowed to stat

        chosen = {str(item) for item in self.config.inputs.model_files}
        for item in files:
            item["inBuild"] = item["path"] in chosen

        parent = here.parent
        return {
            "ok": True,
            "directory": str(here),
            "parent": str(parent) if parent != here else "",
            "folders": folders,
            "files": files,
        }

    def select_lists(self, paths: List[str]) -> List[Path]:
        """Set which lists take part in a build, in this order.

        The choice is written into the configuration file *and* into the
        configuration this session is using, so the change takes effect at once
        without a restart.
        """
        directory = self.list_directory()

        # The same list twice would be merged twice, and every parameter in it
        # would collide with itself - a screenful of NAME003 errors about names
        # the user only wrote once.  The first mention wins, so the order the
        # user chose is kept.
        chosen: List[Path] = []
        for item in paths:
            if not str(item).strip():
                continue
            path = Path(item).expanduser().resolve()
            if path not in chosen:
                chosen.append(path)

        # A list that lives in the project's folder is written as a bare file
        # name, which is what makes the folder the one place lists live in; one
        # kept elsewhere keeps a path relative to the configuration file.
        names: List[str] = []
        for path in chosen:
            if path.parent == directory:
                names.append(path.name)
            else:
                names.append(_relative_to(path, self.config.path.parent))

        rewrite_model_files(self.config.path, names)
        self.config.inputs.model_files = chosen
        return chosen

    # -- structure types ---------------------------------------------------
    #
    # A structure type is a C++ ``struct`` declaration: a name and the fields
    # inside it.  A parameter *names* one, so editing the type edits every
    # parameter that names it - add a field and every one of them grows it, in
    # the right place, with the log ids after it shifted along.
    #
    # The types of the whole project are offered, because a structure defined
    # in one parameter list is a type the others may use.  Using one copies it
    # into this list's own types file, so the list keeps working when it is
    # opened somewhere else.

    def struct_types(self) -> List[Dict[str, object]]:
        """Every type the project knows, as the Structure types panel shows it."""
        library = self.merged_model().struct_types
        rows: List[Dict[str, object]] = []
        for struct_type in library.all():
            rows.append({
                "name": struct_type.name,
                "description": struct_type.description,
                "fields": [{"name": member.name,
                            "valueType": member.value_type_name,
                            "arraySize": member.array_size,
                            "unit": member.unit or "",
                            "description": member.description or ""}
                           for member in struct_type.fields],
                "mine": struct_type.name in self.model.struct_types,
                "usedHere": self._uses_of_type(struct_type.name),
            })
        return rows

    def _uses_of_type(self, name: str) -> List[str]:
        """The parameters of the open list that are of type *name*."""
        found: List[str] = []

        def walk(node: Parameter, prefix: str) -> None:
            dotted = f"{prefix}{PATH_SEPARATOR}{node.name}" if prefix else node.name
            if node.is_struct and node.value_type_name == name:
                found.append(dotted)
            for child in node.children:
                walk(child, dotted)

        for parameter in self.model.parameters:
            walk(parameter, "")
        return found

    def find_struct_type(self, name: str) -> Optional[StructType]:
        return self.merged_model().struct_types.get(name)

    def create_struct_type(self, name: str, description: str = "") -> str:
        """Declare a new, empty structure type.  Returns its name."""
        name = str(name).strip()
        if not name:
            raise ValueError("A structure type needs a name.")
        if not is_valid_c_identifier(name):
            raise ValueError(f"'{name}' is not a valid C identifier. It becomes a "
                             f"typedef, so use letters, digits and '_', and do not "
                             f"start with a digit.")
        if resolve_value_type(name) is not None:
            raise ValueError(f"'{name}' is a data type already. Choose another name.")
        if self.find_struct_type(name) is not None:
            raise ValueError(f"A structure type called '{name}' already exists.")

        self.snapshot("new type")
        self.model.struct_types.put(StructType(name=name, description=description))
        return name

    def update_struct_type(self, name: str, changes: Dict[str, object]) -> str:
        """Change a type, and reshape every parameter that names it.

        ``changes`` may hold ``name``, ``description`` and ``fields``.  A field
        is ``{name, valueType, arraySize, unit, description}``, and the list is
        taken as the whole truth: what is not in it has been removed, and the
        order given is the order of the C members.
        """
        struct_type = self.model.struct_types.get(name)
        if struct_type is None:
            other = self.find_struct_type(name)
            if other is not None:
                # A type this list only borrows.  Editing it here would change
                # what another list generates without that list being open, so
                # it is copied in first and edited as this list's own.
                self.snapshot("edit type")
                struct_type = other.copy()
                self.model.struct_types.put(struct_type)
            else:
                raise ValueError(f"There is no structure type called '{name}'.")
        else:
            self.snapshot("edit type")

        if "fields" in changes:
            struct_type.fields = [self._field_from(raw) for raw in changes["fields"] or []]
        if "description" in changes:
            struct_type.description = str(changes["description"] or "")

        new_name = str(changes.get("name", name)).strip()
        self.last_type_note = ""
        if new_name != name:
            if not is_valid_c_identifier(new_name):
                raise ValueError(f"'{new_name}' is not a valid C identifier.")
            if resolve_value_type(new_name) is not None:
                raise ValueError(f"'{new_name}' is a data type already.")
            if self.find_struct_type(new_name) is not None:
                raise ValueError(f"A structure type called '{new_name}' already exists.")

            # A type another list also declares keeps its old name THERE: this
            # document is not open on that file and must not rewrite it behind
            # somebody's back.  Both lists then generate perfectly well - which
            # is exactly why it has to be said out loud, or the rename looks
            # like it reached everywhere and did not.
            elsewhere = self._lists_declaring(name)
            old_name = name
            self._rename_struct_type(name, new_name)
            name = new_name
            if elsewhere:
                self.last_type_note = (
                    f"Renamed to '{new_name}' in this list only - "
                    f"{', '.join(elsewhere)} still declare(s) it as '{old_name}'. "
                    f"Open each of those lists to rename it there too.")

        self._resync()
        return name

    def _lists_declaring(self, name: str) -> List[str]:
        """Which other parameter lists of this project declare *name*."""
        found: List[str] = []
        for path in self.config.inputs.model_files:
            if self.path is not None and _same_file(path, self.path):
                continue
            try:
                if name in read_types(types_file_for(path)):
                    found.append(path.stem)
            except CodeGeneratorError:
                continue
        return found

    def _field_from(self, raw: Dict[str, object]) -> StructField:
        field_name = str(raw.get("name") or "").strip()
        if not field_name:
            raise ValueError("Every field of a structure type needs a name.")
        if not is_valid_c_identifier(field_name):
            raise ValueError(f"'{field_name}' is not a valid C identifier; it becomes "
                             f"a C member name.")
        value_type = str(raw.get("valueType") or "").strip()
        try:
            array_size = max(1, int(raw.get("arraySize") or 1))
        except (TypeError, ValueError):
            array_size = 1
        return StructField(name=field_name, value_type_name=value_type,
                           array_size=array_size,
                           unit=str(raw.get("unit") or "") or None,
                           description=str(raw.get("description") or "") or None)

    def _rename_struct_type(self, old: str, new: str) -> None:
        """Rename a type here, and every mention of it in this list."""
        self.model.struct_types.rename(old, new)
        for struct_type in self.model.struct_types.all():
            for member in struct_type.fields:
                if member.value_type_name == old:
                    member.value_type_name = new
        for node in self.model.walk():
            if node.is_struct and node.value_type_name == old:
                node.value_type_name = new

    def delete_struct_type(self, name: str) -> Tuple[bool, str]:
        """Remove a type.  ``(removed, why not)``.

        A type still used by a parameter is not removed: the parameters would
        lose their shape, and "it is in use" is the answer somebody needs.
        """
        used = self._uses_of_type(name)
        if used:
            shown = ", ".join(used[:4]) + (" …" if len(used) > 4 else "")
            return False, (f"'{name}' is still used by {len(used)} parameter(s): "
                           f"{shown}. Change them to another type, or delete them.")

        holders = self.model.struct_types.uses_of(name)
        if holders:
            return False, (f"'{name}' is a field of the structure type(s) "
                           f"{', '.join(holders)}. Remove those fields first.")

        if name not in self.model.struct_types:
            owner = self._list_defining_type(name)
            if owner:
                return False, (f"'{name}' belongs to the parameter list '{owner}'. "
                               f"Open that list to remove it.")
            return False, f"There is no structure type called '{name}'."

        self.snapshot("delete type")
        self.model.struct_types.remove(name)
        return True, ""

    def _list_defining_type(self, name: str) -> str:
        """Which other parameter list declares *name*, if any."""
        for path in self.config.inputs.model_files:
            if self.path is not None and path == self.path:
                continue
            try:
                if name in read_types(types_file_for(path)):
                    return path.stem
            except CodeGeneratorError:
                continue
        return ""

    def use_struct_type(self, path: str, name: str) -> Optional[str]:
        """Make the parameter at *path* a structure of type *name*."""
        node = self.find(path)
        struct_type = self.find_struct_type(name)
        if node is None or struct_type is None:
            return None

        self.snapshot("set type")
        # Borrowed from another list: copy it in, so this list still describes
        # its own parameters when it is opened on its own.
        if name not in self.model.struct_types:
            self.model.struct_types.put(struct_type.copy())
            for needed in self._types_needed_by(struct_type):
                if needed.name not in self.model.struct_types:
                    self.model.struct_types.put(needed.copy())

        node.kind = ParameterKind.STRUCT
        node.value_type_name = name
        # A structure holds fields, not a value: whatever this parameter was
        # when it held one has no meaning any more.
        node.unit = None
        node.default_value = None
        node.minimum = None
        node.maximum = None
        node.resolution = None
        self._resync()
        return path

    def _types_needed_by(self, struct_type: StructType) -> List[StructType]:
        """The types *struct_type* has as fields, and the ones those have."""
        library = self.merged_model().struct_types
        found: List[StructType] = []
        seen = {struct_type.name}
        queue = [struct_type]
        while queue:
            current = queue.pop()
            for member in current.fields:
                nested = library.get(member.value_type_name)
                if nested is not None and nested.name not in seen:
                    seen.add(nested.name)
                    found.append(nested)
                    queue.append(nested)
        return found

    def _resync(self) -> None:
        """Make every structure in the open list match its type again."""
        apply_types(self.model.parameters, self.merged_model().struct_types)

    # -- defines -------------------------------------------------------------
    def set_defines(self, column: str, values: List[str]) -> None:
        """Change one of the machine's drop-down lists.

        Not an edit of this project: the lists belong to the app, so this is
        written to ``app/var/choices.json`` and every project on the machine
        sees it.  It is deliberately NOT on the undo stack for that reason -
        undoing an edit to this parameter list must not quietly change the
        company's list of sub-systems back.
        """
        self.model.defines.values[column.upper()] = [str(v).strip()
                                                     for v in values if str(v).strip()]
        save_choices(self.model.defines)

    # -- validation and generation -------------------------------------------
    def merged_model(self, diagnostics: Optional[DiagnosticCollector] = None
                     ) -> ParameterList:
        """This module as it is being edited, plus the others as they are on disk.

        The project is one parameter list even when it is split over several
        files, so a name or a log id clashing with another sub-module has to
        show up while editing, not at the end.

        Built in the order of ``inputs.model_files``, which is the order the
        generator merges them in - so the position of a parameter here is the
        index it gets in the generated table.  Appending the edited list first
        and the rest after would give the right *set* and the wrong *numbers*.
        """
        # Resolved, because the same file reached by two different paths is one
        # file: opening '../parameter_lists/power.xml' while the configuration
        # holds the absolute path used to merge that list twice, which doubled
        # every index and invented name clashes with itself.
        open_path = self.path.resolve() if self.path else None

        # Problems the READER finds in the other lists - a resolution of "1.1"
        # on an int8_t, a number that will not parse - used to be thrown away
        # here, so the editor showed a clean model and then Generate refused it
        # with a message about a file the reader never mentioned.  Pass a
        # collector in and they reach the Problems panel like everything else.
        quiet = diagnostics if diagnostics is not None else DiagnosticCollector()
        merged: Optional[ParameterList] = None
        seen = False
        for path in self.config.inputs.model_files:
            if open_path is not None and path.resolve() == open_path:
                part, seen = copy.deepcopy(self.model), True
            elif path.is_file():
                part = read_xml(path, quiet)
            else:
                continue
            if merged is None:
                merged = part
            else:
                merged.extend(part)

        if merged is None:
            return self.model
        if not seen:
            # The open list is not part of the build; it still has to be
            # validated against the rest, it just contributes no indices.
            merged.extend(copy.deepcopy(self.model))
        return merged

    def validate(self) -> List[Dict[str, object]]:
        """Every problem in the whole build, as the Problems panel shows them.

        Both halves are collected: what the READER says about the other lists
        on disk, and what the RULES say about the merged model.  Leaving the
        first half out is how the editor came to report a clean model that the
        generator then refused.
        """
        diagnostics = DiagnosticCollector()
        model = self.merged_model(diagnostics)
        Validator(self.config).validate(model, diagnostics)
        # ... plus what the reader said about the open file itself.  A value it
        # refused - a resolution of "1.1" on an int8_t - is gone from the model,
        # so re-validating can never find it again; but it is still in the file,
        # and the file is what the generator reads.
        return self.load_problems + diagnostics.to_list()

    def validate_codes(self, code: str) -> int:
        """How many problems of one code the open list has.

        A small thing the tests lean on constantly: "is this reported, and only
        once?" is the question almost every rule needs answered.
        """
        return sum(1 for item in self.validate() if item["code"] == code)

    def generate(self) -> Dict[str, object]:
        """Save the model, then generate the code from every configured module.

        Saving first is not a convenience - it is what keeps the editor and
        ``run_generate.py`` from ever disagreeing.  If the editor generated from the
        model in its memory while the file on disk still held the previous
        version, the next command line run would silently produce different
        code.  So the file is written first, and the generator then reads the
        same files the command line reads.
        """
        # The project file is read again first, so that generating from the
        # editor and running run_generate.py can never write to two different
        # places.  Both read the same file at the moment they run.
        broken_project = self.reread_project()
        if broken_project:
            return {"success": False, "message": broken_project, "files": [],
                    "count": 0, "saved": "", "modules": [], "diagnostics": [],
                    "drift": None}

        diagnostics = DiagnosticCollector()
        pipeline = Pipeline(self.config)

        saved = None
        if self.path is not None:
            saved = self.save()

        # Every other sub-module is read from disk and merged in, so the editor
        # generates exactly what "python run_generate.py" would.
        model = pipeline.load_model(diagnostics) if saved is not None else self.model

        result = pipeline.generate(model, diagnostics)
        drift = result.drift
        return {
            "success": result.success,
            # Always present, so that "why did nothing happen?" is answered by
            # the same field whether the run was refused by the validator or
            # blew up in the tool.  Without it a failed build came back with no
            # message at all and every caller had to invent one.
            "message": "" if result.success else _refusal(diagnostics),
            "files": [str(path) for path in result.generated_files],
            "count": result.parameter_count,
            "saved": str(saved) if saved else "",
            "modules": [str(path) for path in self.config.inputs.model_files],
            "diagnostics": diagnostics.to_list(),
            # What this build moved relative to the last one.  A value that
            # changed byte offset is a value a board already in the field will
            # read wrongly, so the editor shows this before anything else.
            "drift": {
                "breaksStoredData": drift.breaks_stored_data,
                "summary": drift.summary(),
                "report": drift.report(),
                "moved": [{"parameter": m.parameter, "tag": m.tag_id,
                           "old": m.old, "new": m.new} for m in drift.moved],
                "reindexed": [{"parameter": n, "old": o, "new": w}
                              for n, o, w in drift.reindexed],
                "resystemed": [{"parameter": n, "old": o, "new": w}
                               for n, o, w in drift.resystemed],
                "added": list(drift.added),
                "removed": list(drift.removed),
                "firstRun": drift.first_run,
                # Which question was asked: a parameter table has no stored
                # offsets, so the dialog has to say something else entirely.
                "table": drift.table,
            } if drift is not None else None,
        }

    def next_free_log_id(self) -> int:
        """The first log id no parameter has reserved yet.

        ``flatten()`` has already spread every structure's block over its
        leaves, so looking at the leaves covers structures too.  A leaf reserves
        one id per *value* - ``reserved_log_ids``, not its size in bytes: a
        ``float64_t[10]`` at 410 ends at 419 and the next free id is 420.

        The other sub-modules count as well: the log ids of a project have to be
        unique across all of them, so an id that is free here but taken in
        another file is not free.
        """
        highest = 0
        for leaf in self.merged_model().flatten():
            log_id = leaf.log_id
            if isinstance(log_id, int) and not isinstance(log_id, bool):
                highest = max(highest, log_id + reserved_log_ids(leaf))
        return highest

    # -- what the front end renders -------------------------------------------
    def error_count(self) -> int:
        return sum(1 for item in self.validate()
                   if item["severity"] == Severity.ERROR.label)


def _refusal(diagnostics: DiagnosticCollector) -> str:
    """Why a build wrote nothing, in one line.

    The Problems panel has the full list; this is what a toast can show, so it
    names the first error and counts the rest instead of repeating them.
    """
    errors = [item for item in diagnostics.to_list()
              if item["severity"] == Severity.ERROR.label]
    if not errors:
        return "The model has errors - nothing was generated. See Problems."
    first = f"{errors[0]['code']}: {errors[0]['message']}"
    if len(errors) == 1:
        return first
    return f"{first} (and {len(errors) - 1} more error(s) - see Problems)"


#: The characters the dotted path syntax is built from.  A name containing one
#: of them cannot be addressed: "A.B" reads as the field B of a structure A, and
#: "A[0]" as an element of an array A.
_PATH_CHARACTERS = (PATH_SEPARATOR, "[", "]")


def _reject_path_characters(name: str) -> None:
    """Refuse a name that the path syntax could never address again.

    This is checked when the name is *set*, not when the model is validated,
    because by validation time it is already too late: the node is in the tree
    under a path that does not resolve, so the editor can no longer find it to
    edit, rename or even delete.  The only way out was to edit the XML by hand.
    """
    for character in _PATH_CHARACTERS:
        if character in name:
            raise ValueError(
                f"A name cannot contain '{character}'. Parameters are addressed "
                f"by their dotted path - Position.Home.Lat - so a name with "
                f"'{character}' in it could not be found again."
            )


def _default_resolution(type_name: Optional[str]) -> float:
    """The resolution a parameter of this type starts with.

    It comes from the type table, never from a constant here: 1 is right for
    the integers and wrong for the floats, where it would quantise every value
    to whole numbers.  An unknown type keeps 1, which is what the integers use.
    """
    value_type = resolve_value_type(type_name)
    return value_type.default_resolution if value_type is not None else 1


def _default_tag(spec, defines: Defines):
    from pl_codegen.model.tags import TagKind
    if spec.kind is TagKind.BOOLEAN:
        return False
    if spec.kind is TagKind.ENUM and spec.defines_column:
        values = defines.get(spec.defines_column)
        return values[0] if values else None
    return None


def _safe_stem(name: str) -> str:
    """Turn what somebody typed into a file name that cannot surprise them.

    Only letters, digits, ``_`` and ``-`` survive, so a name can never walk out
    of the project's folder with a ``..`` or a slash, and never collides with a
    shell or a path separator on any of the three platforms this runs on.
    """
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", str(name).strip()).strip("_-")
    return cleaned[:64]


def _relative_to(path: Path, root: Path) -> str:
    """*path* written relative to *root* when it can be, else in full."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        pass
    try:
        return Path(os.path.relpath(path, root)).as_posix()
    except ValueError:
        return path.as_posix()


def _same_file(left: Path, right: Path) -> bool:
    """Whether two paths name the same file, resolving both first.

    The configuration stores absolute paths and the browser sends back whatever
    it was given, so a plain ``==`` would call the same file two different
    files.
    """
    try:
        return left.resolve() == right.resolve()
    except OSError:
        return left == right


def _unique_name(base: str, siblings: List[Parameter]) -> str:
    taken = {node.name for node in siblings}
    if base not in taken:
        return base
    index = 2
    while f"{base}{index}" in taken:
        index += 1
    return f"{base}{index}"


def _clear_log_ids(node: Parameter) -> None:
    """A copy must not reuse the log ids of the original."""
    node.log_id = None
    for child in node.children:
        _clear_log_ids(child)

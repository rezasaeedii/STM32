/* ==========================================================================
   app.js - wires the toolbar, the grid, the editor and the problems panel
   together.  This is the only file that knows about all of them.
   ========================================================================== */

/* The picker's value for "every list": '*' and '?' are illegal in a Windows
   path and in a POSIX file name here, so this can never collide with a real
   one.  A NUL byte would have been shorter and does not survive being written
   into an HTML attribute - the parser turns it into U+FFFD, and the comparison
   then never matches. */
const ALL_LISTS = "*?all-lists?*";

const app = {
  state: null,
  selected: "",
  allLists: false,

  async start() {
    /* One view. The grid shows every parameter in columns, with a filter per
       column, and a row opens it in the editor beside it - so looking at the
       list and changing it are the same place.  The tree that used to sit next
       to it showed the same rows with less of them visible. */
    gridView.init(document.getElementById("grid"), (path) => {
      /* In the merged view a row belongs to one of the project's files.
         Clicking it opens THAT list and selects the row there, so "show me
         everything" is a way in rather than a dead end - the merged model
         itself can never be written back to, because a node in it may have
         come from any of six files. */
      if (this.allLists) { this.editWhereItLives(path); return; }
      this.selected = path;
      this.paint();
    }, (path, enabled) => this.setEnabled(path, enabled));
    /* Typing in a filter box only changes what is SHOWN, so the model is not
       touched and only the grid is redrawn. */
    gridView.onFilter = () => gridView.render(
      this.state.tree, this.selected, this.problemPaths());
    editorView.init(
      document.getElementById("editor"),
      document.getElementById("editor-title"),
      document.getElementById("editor-path"),
      (changes) => this.applyChanges(changes));

    this.bindToolbar();
    this.bindSeverityFilters();
    this.bindShortcuts();
    this.paintThemeLabel();
    trackTopbarHeight();
    if (await this.reload()) setStatus("Ready");
  },

  /* Every action ends up here when its request throws.  A request that failed
     has to SAY so: the page redraws itself from the model after every change,
     so an action that dies silently leaves the screen showing the old model
     and the user believing the change landed.  Saving is the dangerous one - a
     file the tool cannot write used to look exactly like a successful save. */
  failed(what, error) {
    toast(`${what} failed: ${error.message}`, "bad");
    setStatus(`${what} failed`);
    return null;
  },

  /* ------------------------------------------------------------ loading */
  async refresh(keepEditor) {
    this.state = await api.state(this.allLists);
    this.paint(keepEditor);
  },

  /* refresh() that reports instead of throwing; for the places where nothing
     else is going to catch. */
  async reload(keepEditor) {
    try {
      await this.refresh(keepEditor);
      return true;
    } catch (error) {
      this.failed("Reading the model", error);
      return false;
    }
  },

  paint(keepEditor) {
    const state = this.state;

    /* No project open is not an error - it is where the editor starts on a
       machine that has just had the app copied onto it. */
    this.paintProject(state);
    if (!state.project) {
      /* The file name and the counts belong to a project. Left as they were
         they would describe the one that was just closed, which is worse than
         saying nothing. */
      const name = document.getElementById("file-name");
      name.textContent = "no project open";
      name.classList.remove("dirty");
      document.getElementById("status-counts").textContent = "";
      setStatus("No project open");
      return;
    }

    document.getElementById("file-name").textContent = state.file || "(no file)";
    document.getElementById("file-name").classList.toggle("dirty", state.dirty);
    this.paintModules(state);

    /* The 'List' column only earns its width in the merged view. */
    const owner = gridView.columns.find((column) => column.key === "owner");
    owner.width = this.allLists ? "132px" : "0px";

    gridView.render(state.tree, this.selected, this.problemPaths());
    this.paintAddMenu();

    const node = findNode(state.tree, this.selected);
    if (!node) { this.selected = ""; editorView.clear(); }
    else if (!keepEditor) editorView.show(node, state);

    this.paintProblems(state.diagnostics);
    this.paintCounts(state);
    this.updateButtons(node);
  },

  /* Which project is open: the name in the bar, the recent list in both
     places that show one, and which of the two screens is up. */
  paintProject(state) {
    const open = !!state.project;
    document.getElementById("start-screen").hidden = open;
    document.getElementById("layout").hidden = !open;
    document.querySelector(".bar-edit").hidden = !open;
    document.getElementById("problems-pane").hidden = !open;
    for (const element of document.querySelectorAll(".needs-project")) {
      element.hidden = !open;
    }

    document.getElementById("project-name").textContent =
      open ? state.project.name : "No project";
    document.getElementById("btn-project").title = open
      ? `${state.project.file}
${this.formatName()}`
      : "Open, create or close a project";

    /* A parameter table has no structures and no arrays, so the buttons that
       make them are turned off rather than left to fail at the end.  The badge
       says which format is on, because the two look identical otherwise. */
    const table = this.isParamTable();
    const badge = document.getElementById("format-badge");
    badge.hidden = !open || !table;
    badge.textContent = "parameter table";
    badge.title = "This project generates one nsrParamTables.h. Structures and "
                + "arrays are not part of that format.";
    const noStructures = "A parameter table has no structures - "
                      + "every row is one value.";
    const button = document.getElementById("btn-types");
    button.disabled = table;
    button.title = table ? noStructures
                         : "Declare, edit and delete structure types";

    /* The menu item is dimmed rather than disabled: a disabled item swallows
       the click and says nothing, and "nothing happened" is the one answer a
       guard rail must never give.  Clicking it explains itself. */
    const addStruct = document.querySelector('[data-action="add-struct"]');
    addStruct.classList.toggle("off", table);
    addStruct.title = table ? noStructures : "";

    const rows = (state.recent || []);
    const menu = rows.map((item) => `
      <button type="button" class="menu-item${item.current ? " on" : ""}"
              data-project="${escapeHtml(item.path)}"
              title="${escapeHtml(item.path)}">
        ${escapeHtml(item.name)}</button>`).join("");
    document.getElementById("menu-recent").innerHTML =
      menu || `<div class="menu-empty">Nothing yet</div>`;

    document.getElementById("start-recent").innerHTML = rows.length ? rows.map((item) => `
      <div class="list-row" data-project="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b>
          <span class="hint mono">${escapeHtml(item.folder)}</span>
        </div>
      </div>`).join("") : `<div class="problem-empty">No project has been opened yet.</div>`;

    /* Both lists open a project the same way, so they are bound the same way. */
    for (const row of document.querySelectorAll("[data-project]")) {
      row.addEventListener("click", () => this.openProject(row.dataset.project));
    }
  },

  /* Which output format the open project wants. */
  isParamTable() {
    return !!(this.state && this.state.project
              && this.state.project.format === "param_table");
  },

  formatName() {
    return this.isParamTable()
      ? "Generates: one nsrParamTables.h"
      : "Generates: the cg_ smart-data files";
  },

  async openProject(path) {
    try {
      const answer = await api.openProject(path);
      if (!answer.ok) { toast(answer.message, "bad"); return; }
      this.allLists = false;
      this.selected = "";
      await this.refresh();
      toast(`Opened '${answer.project.name}'`, "good");
      setStatus(answer.project.name);
    } catch (error) { this.failed("Opening the project", error); }
  },

  async closeProject() {
    if (this.state.dirty &&
        !confirm("This list has unsaved changes. Close the project anyway?")) return;
    try {
      await api.closeProject();
      this.selected = "";
      await this.refresh();
      setStatus("No project open");
    } catch (error) { this.failed("Closing the project", error); }
  },

  /* The project can be split over several files, one per sub-module. The
     editor works on one of them; the others are still validated against, so a
     clash between two sub-modules shows up here and not at the end. */
  paintModules(state) {
    const picker = document.getElementById("module-picker");
    const modules = state.modules || [];
    picker.hidden = modules.length < 2;
    if (picker.hidden) return;

    /* One entry per list, plus the whole build as one tree.  Editing one list
       at a time is what you do; seeing all of them together is how you answer
       "what is actually in the generated table?", which no single list can. */
    const all = `<option value="${ALL_LISTS}"${this.allLists ? " selected" : ""}
                 >— every list, merged —</option>`;
    picker.innerHTML = all + modules.map((module) => {
      const label = escapeHtml(module.name) + (module.exists ? "" : " (new)");
      const selected = module.current && !this.allLists;
      return `<option value="${escapeHtml(module.path)}"` +
             `${selected ? " selected" : ""}>${label}</option>`;
    }).join("");
  },

  paintCounts(state) {
    const leaves = countLeaves(state.tree);
    const structs = countStructs(state.tree);
    document.getElementById("tree-count").textContent =
      `${leaves} value(s)` + (structs ? ` in ${structs} structure(s)` : "");
    const by = countBySeverity(state.diagnostics);
    const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;
    document.getElementById("status-counts").textContent =
      `${plural(leaves, "value")} · ${plural(by.error, "error")}`
      + ` · ${plural(by.warning, "warning")} · ${by.info} info`;
  },

  paintProblems(diagnostics) {
    /* A panel with nothing in it should not hold the window open.  It collapses
       to its title bar on its own when the model is clean, and opens again the
       moment there is something to read - unless the user has taken it over by
       clicking the twisty, in which case their choice wins. */
    const pane = document.getElementById("problems-pane");
    if (!this.problemsPinned) {
      pane.classList.toggle("collapsed", diagnostics.length === 0);
    }
    this.sizeProblems();

    /* Each severity gets its own count, and each count is a filter.  A number
       that lumps three severities together answers neither "can I generate?"
       nor "what should I read first?". */
    const by = countBySeverity(diagnostics);
    for (const severity of SEVERITIES) {
      const button = document.querySelector(`.sev-count[data-severity="${severity}"]`);
      document.getElementById(`count-${severity}`).textContent = by[severity];
      /* "1 warnings" is the kind of thing that makes a tool feel unfinished.
         'info' is already both singular and plural. */
      const label = document.getElementById(`label-${severity}`);
      if (label) label.textContent = by[severity] === 1 ? ` ${severity}` : ` ${severity}s`;
      button.classList.toggle("empty", by[severity] === 0);
      button.classList.toggle("off", this.hidden.has(severity));
    }

    const shown = diagnostics.filter((item) => !this.hidden.has(item.severity));
    const list = document.getElementById("problems");

    if (!diagnostics.length) {
      list.innerHTML = `<div class="problem-empty">No problems. The model is ready to generate.</div>`;
      return;
    }
    if (!shown.length) {
      /* There ARE problems; they are only hidden.  Saying "no problems" here
         would be a lie the reader themselves caused. */
      list.innerHTML = `<div class="problem-empty">${diagnostics.length} problem(s),
        all hidden by the filter above.</div>`;
      return;
    }

    const order = { error: 0, warning: 1, info: 2 };
    const sorted = shown.slice().sort((a, b) => order[a.severity] - order[b.severity]);

    /* Where the problem is. A parameter is the useful answer and the row can
       jump to it; a problem in the Defines or in the file itself has no
       parameter, and there the file name is the answer - a build is several
       lists, so "which file?" is a real question. */
    const where = (item) => {
      if (item.location.parameter) return item.location.parameter;
      const file = item.location.file || "";
      return file ? file.split(/[\\/]/).pop() : "";
    };

    list.innerHTML = sorted.map((item) => `
      <div class="problem ${item.severity}${item.location.parameter ? " goes" : ""}"
           data-path="${escapeHtml(item.location.parameter || "")}">
        <span class="sev">${item.severity}</span>
        <span class="code">${escapeHtml(item.code)}</span>
        <span class="msg">${escapeHtml(item.message)}
          ${where(item) ? `<span class="where">→ ${escapeHtml(where(item))}</span>` : ""}
          ${item.hint ? `<span class="hint">${escapeHtml(item.hint)}</span>` : ""}
        </span>
      </div>`).join("");

    /* Only a row that has somewhere to go is clickable: a row that looks
       clickable and does nothing is worse than one that does not. */
    for (const row of list.querySelectorAll(".problem.goes")) {
      row.addEventListener("click", () => this.select(row.dataset.path));
    }
  },

  //: severities the reader has switched off; nothing is hidden by default
  hidden: new Set(),

  bindSeverityFilters() {
    for (const button of document.querySelectorAll(".sev-count")) {
      button.addEventListener("click", () => {
        const severity = button.dataset.severity;
        if (this.hidden.has(severity)) this.hidden.delete(severity);
        else this.hidden.add(severity);
        this.paintProblems(this.state.diagnostics);
      });
    }
  },

  /* Open the list a merged-view row came from, and select the row in it. */
  async editWhereItLives(path) {
    const node = findNode(this.state.tree, path);
    const owner = node && node.ownerList;
    if (!owner) { toast("That row does not say which list it comes from.", "bad"); return; }

    const module = (this.state.modules || []).find((m) => m.name + ".xml" === owner
                                                       || m.path.endsWith(owner));
    if (!module) { toast(`'${owner}' is not part of this build.`, "bad"); return; }
    try {
      const answer = await api.open(module.path);
      if (answer && answer.ok === false) { toast(answer.message, "bad"); return; }
      this.allLists = false;
      this.selected = path;
      await this.refresh();
      expandTo(path);
      this.paint();
      setStatus(`${owner} — ${path}`);
    } catch (error) { this.failed("Opening the list", error); }
  },

  updateButtons(node) {
    /* The merged view cannot be written to - an entry there can come from any
       of the files - so its buttons are off.  Clicking a row is still useful:
       it opens the list that owns it, where everything works. */
    const frozen = !!this.allLists;
    for (const id of ["btn-duplicate", "btn-delete", "btn-up", "btn-down"]) {
      document.getElementById(id).disabled = !node || frozen;
    }
    /* Assigned, never only set: a button switched off by the merged view has
       to switch back on when a single list is opened again. */
    document.getElementById("btn-add-menu").disabled = frozen;
    document.getElementById("btn-save").disabled = frozen;
    document.getElementById("btn-undo").disabled = frozen || !this.state.canUndo;
    document.getElementById("btn-redo").disabled = frozen || !this.state.canRedo;
    document.getElementById("editor").classList.toggle("read-only", frozen);
  },

  /* The two "into the selected structure" entries only mean something on a
     structure.  They are greyed rather than hidden, so the menu keeps the same
     shape and the reader can see what they would need to select first. */
  /* A field is not added to a parameter any more - it is added to a TYPE, and
     every parameter of that type grows it.  So the Add menu has two entries
     and the field table lives in the structure-type dialog. */
  paintAddMenu() {},

  /* Removing a list is two questions, asked separately: taking it out of the
     build is a change of mind and can be undone by adding it back, while
     deleting the file cannot be undone at all.  So the second one is never
     implied by the first. */
  async removeList(item) {
    const fromBuild = confirm(
      `Remove '${item.name}' from the build?

` +
      `The generated code will no longer contain its parameters, and every ` +
      `index after them will move.

The file itself is kept.`);
    if (!fromBuild) return;

    let alsoDelete = false;
    if (item.exists) {
      alsoDelete = confirm(
        `Also DELETE the file from the disk?

${item.file}

` +
        `This cannot be undone. Choose Cancel to keep the file and only take ` +
        `it out of the build.`);
    }

    try {
      const answer = await api.removeList(item.path, alsoDelete);
      if (!answer.ok) { toast(answer.message, "bad"); return; }
      closeModal();
      if (answer.wasOpen && answer.openInstead) await api.open(answer.openInstead);
      await this.reload();
      setStatus(answer.deleted
        ? `Removed '${item.name}' and deleted its file`
        : `Removed '${item.name}' from the build; the file is kept`);
    } catch (error) { this.failed("Removing the list", error); }
  },

  /* Ticking the box in the grid is an ordinary edit: it goes through the same
     update action the form does, so it lands on the undo stack and is
     validated like anything else. */
  async setEnabled(path, enabled) {
    try {
      await api.update(path, { enable: enabled });
      /* NOT refresh(true): keeping the editor would leave the form on the right
         still showing the old Enabled tick, so the two halves of the screen
         would disagree about the same parameter.  Every pane redraws from the
         model, always - that is the whole reason the model is the only state. */
      await this.refresh();
      setStatus(enabled ? "Enabled" : "Disabled (it will not be generated)");
    } catch (error) { this.failed("Changing the parameter", error); }
  },

  /* Tell the layout how tall the Problems panel is right now, so the body can
     take back the space a collapsed panel is not using.  Measured rather than
     assumed, because the panel's height is a CSS variable somebody may change. */
  sizeProblems() {
    const pane = document.getElementById("problems-pane");
    document.documentElement.style.setProperty(
      "--problems-now", `${Math.ceil(pane.getBoundingClientRect().height)}px`);
  },

  /* The theme is a per-machine preference, not part of the model, so it is
     the one thing the editor keeps in the browser rather than on disk. */
  toggleTheme() {
    const root = document.documentElement;
    const next = root.dataset.theme === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    this.paintThemeLabel();
    try {
      localStorage.setItem("pl-theme", next);
    } catch (error) {
      /* private window, or site data blocked: the theme still switches, it
         just will not be remembered. Not worth interrupting anyone over. */
    }
    setStatus(next === "dark" ? "Dark theme" : "Light theme");
  },

  paintThemeLabel() {
    document.getElementById("theme-label").textContent =
      document.documentElement.dataset.theme === "dark"
        ? "Switch to the light theme" : "Switch to the dark theme";
  },

  /* ------------------------------------------------------------- menus */
  /* A menu is a button plus a box: the box opens on click, closes on the next
     click anywhere else or on Escape, and closes after it is used.  Two of
     them, so it is worth the twenty lines rather than a library. */
  bindMenu(buttonId, menuId, actions) {
    const button = document.getElementById(buttonId);
    const menu = document.getElementById(menuId);

    const close = () => {
      menu.hidden = true;
      button.setAttribute("aria-expanded", "false");
    };
    const open = () => {
      /* only one menu at a time */
      for (const other of document.querySelectorAll(".menu")) other.hidden = true;
      menu.hidden = false;
      button.setAttribute("aria-expanded", "true");
    };

    button.addEventListener("click", (event) => {
      event.stopPropagation();
      menu.hidden ? open() : close();
    });
    menu.addEventListener("click", (event) => event.stopPropagation());

    for (const item of menu.querySelectorAll(".menu-item")) {
      item.addEventListener("click", () => {
        close();
        const run = actions[item.dataset.action];
        if (run) run();
      });
    }
    this._menuClosers.push(close);
  },

  _menuClosers: [],

  problemPaths() {
    return new Set(
      this.state.diagnostics.filter((d) => d.severity === "error")
                            .map((d) => d.location.parameter).filter(Boolean));
  },

  /* Select a node by path and reveal it (used by the Problems panel and by
     the "edit them on <structure>" button of a field). */
  select(path) {
    if (!path) return;
    this.selected = path;
    expandTo(path);
    this.paint();
  },

  /* ------------------------------------------------------------ editing */
  async applyChanges(changes) {
    if (!this.selected) return;
    try {
      const answer = await api.update(this.selected, changes);
      if (answer.ok === false) {
        /* A refused edit redraws from the model, so the box springs back to
           the value that is really stored - and says why it did.  This one is
           NOT flagged as the form's own: the form is showing a value the model
           rejected, which is exactly what has to be replaced. */
        toast(answer.message || "That change was not accepted.", "bad");
        await this.refresh();
        setStatus("Not changed");
        return;
      }
      if (answer.selected) this.selected = answer.selected;

      /* The form is the author of this change, so it already shows the new
         value and must not be rebuilt under the reader's hands. */
      editorView.ownEdit = true;
      try {
        await this.refresh();
      } finally {
        editorView.ownEdit = false;
      }
      setStatus("Edited");
    } catch (error) { this.failed("The edit", error); }
  },

  /* Adding a structure asks the one question a structure cannot do without:
     which type is it?  Either an existing one or a new one declared right
     here, fields and all - going out to another dialog, declaring a type,
     coming back and picking it is three steps for one thought. */
  addStructure() {
    const types = this.state.structTypes || [];
    const options = types.map((type) =>
      `<option value="${escapeHtml(type.name)}">${escapeHtml(type.name)}` +
      ` — ${type.fields.length} field(s)</option>`).join("");

    showModal("Add a structure",
      `<p class="modal-note">A structure is <b>of</b> a structure type, the way
       <code>Position home;</code> is in C++. Pick one, or declare a new one here.</p>
       <label>Name</label>
       <input type="text" id="add-struct-name" class="mono" placeholder="Home">
       <label>Structure type</label>
       <div class="row-inline">
         <select id="add-struct-type">
           <option value="">— declare a new type below —</option>${options}</select>
       </div>
       <div id="add-struct-new">
         <label>New type name</label>
         <input type="text" id="add-struct-type-name" class="mono" placeholder="Position">
         <label>Its fields</label>
         <div class="type-fields-box">
         <table class="type-fields">
           <tr><th style="width:22%">Name</th><th style="width:24%">Data type</th>
               <th style="width:12%">Array</th><th style="width:14%">Unit</th>
               <th>Description</th><th style="width:12%"></th></tr>
           <tbody id="type-fields"></tbody>
         </table></div>
         <button type="button" class="inline-btn" id="btn-add-field">+ Add field</button>
       </div>`,
      async () => {
        const name = document.getElementById("add-struct-name").value.trim();
        const chosen = document.getElementById("add-struct-type").value;
        try {
          let typeName = chosen;
          if (!typeName) {
            readFields();
            typeName = document.getElementById("add-struct-type-name").value.trim();
            if (!typeName) { toast("The new type needs a name.", "bad"); return; }
            const made = await api.newType(typeName, "");
            if (!made.ok) { toast(made.message, "bad"); return; }
            const given = await api.updateType(typeName, {
              name: typeName, description: "", fields: this.draftFields});
            if (!given.ok) { toast(given.message, "bad"); return; }
          }

          const added = await api.add("", "struct");
          let path = added.selected;
          if (name) {
            const renamed = await api.update(path, {name});
            if (!renamed.ok) { toast(renamed.message, "bad"); return; }
            path = renamed.selected || path;
          }
          const used = await api.useType(path, typeName);
          if (!used.ok) { toast(used.message, "bad"); return; }
          this.selected = path;
          await this.refresh();
          setStatus("Structure added");
        } catch (error) { this.failed("Adding the structure", error); }
      });

    /* the draft fields of the new type, edited in place */
    this.draftFields = [{name: "", valueType:
      (this.state.defines.valueTypes || ["uint8_t"])[0], arraySize: 1,
      unit: "", description: ""}];
    const readFields = () => this.readDraftFields();
    const showNew = () => {
      document.getElementById("add-struct-new").hidden =
        !!document.getElementById("add-struct-type").value;
    };
    document.getElementById("add-struct-type")
            .addEventListener("change", () => { readFields(); showNew(); });
    document.getElementById("btn-add-field").addEventListener("click", () => {
      readFields();
      this.draftFields.push({name: "", valueType:
        (this.state.defines.valueTypes || ["uint8_t"])[0], arraySize: 1,
        unit: "", description: ""});
      this.renderDraftFields();
    });
    this.renderDraftFields();
    showNew();
    document.getElementById("add-struct-name").focus();
  },

  /* The field table shared by "Add a structure" and "Structure types". */
  renderDraftFields() {
    const valueTypes = this.state.defines.valueTypes || [];
    const structs = (this.state.structTypes || []).map((type) => type.name);
    const body = document.getElementById("type-fields");
    if (!body) return;
    body.innerHTML = this.draftFields.map((field, index) => {
      const option = (value, group) =>
        `<option value="${escapeHtml(value)}"` +
        `${value === field.valueType ? " selected" : ""}>${escapeHtml(value)}</option>`;
      const nested = structs.length
        ? `<optgroup label="Structure types">${structs.map(option).join("")}</optgroup>` : "";
      return `<tr data-field-row="${index}">
        <td><input type="text" class="mono" data-f="name" value="${escapeHtml(field.name || "")}"></td>
        <td><select data-f="valueType">${valueTypes.map(option).join("")}${nested}</select></td>
        <td><input type="number" min="1" data-f="arraySize" value="${field.arraySize || 1}"></td>
        <td><input type="text" data-f="unit" value="${escapeHtml(field.unit || "")}"></td>
        <td><input type="text" data-f="description" value="${escapeHtml(field.description || "")}"></td>
        <td>
          <button type="button" class="inline-btn" data-up-field="${index}">↑</button>
          <button type="button" class="inline-btn" data-down-field="${index}">↓</button>
          <button type="button" class="inline-btn danger" data-remove-field="${index}">🗑</button>
        </td></tr>`;
    }).join("") || `<tr><td colspan="6" class="problem-empty">No fields yet.</td></tr>`;

    const move = (from, to) => {
      this.readDraftFields();
      if (to < 0 || to >= this.draftFields.length) return;
      this.draftFields.splice(to, 0, this.draftFields.splice(from, 1)[0]);
      this.renderDraftFields();
    };
    for (const button of body.querySelectorAll("[data-remove-field]")) {
      button.addEventListener("click", () => {
        this.readDraftFields();
        this.draftFields.splice(Number(button.dataset.removeField), 1);
        this.renderDraftFields();
      });
    }
    for (const button of body.querySelectorAll("[data-up-field]")) {
      const i = Number(button.dataset.upField);
      button.addEventListener("click", () => move(i, i - 1));
    }
    for (const button of body.querySelectorAll("[data-down-field]")) {
      const i = Number(button.dataset.downField);
      button.addEventListener("click", () => move(i, i + 1));
    }
  },

  readDraftFields() {
    for (const tr of document.querySelectorAll("[data-field-row]")) {
      const index = Number(tr.dataset.fieldRow);
      if (!this.draftFields[index]) continue;
      for (const input of tr.querySelectorAll("[data-f]")) {
        this.draftFields[index][input.dataset.f] =
          input.dataset.f === "arraySize" ? Number(input.value) || 1 : input.value;
      }
    }
  },

  async addNode(kind, intoStruct) {
    const parent = intoStruct ? this.selected : "";
    try {
      const answer = await api.add(parent, kind);
      this.selected = answer.selected;
      await this.refresh();
      setStatus(kind === "struct" ? "Structure added" : "Parameter added");
    } catch (error) { this.failed("Adding", error); }
  },

  /* --------------------------------------- the parameter lists of the project */
  /* A project is one parameter list split over several files. Which of them take
     part, and in what ORDER, decides the order of the indices in the generated
     code - so the choice is made here and written straight into
     project.json, which is the file run_generate.py reads. The editor and
     the command line then cannot disagree about what the project is. */
  async editListSelection() {
    let answer;
    try {
      answer = await api.lists();
    } catch (error) { this.failed("Reading the parameter lists", error); return; }
    /* the working copy the dialog edits; nothing is written until OK */
    let rows = answer.lists.map((item) => Object.assign({}, item));

    const render = () => {
      const chosen = rows.filter((r) => r.selected);
      const spare = rows.filter((r) => !r.selected);

      const line = (item, index, inOrder) => `
        <div class="list-row${item.selected ? " on" : ""}" data-path="${escapeHtml(item.path)}">
          <input type="checkbox" ${item.selected ? "checked" : ""} data-toggle>
          <div class="list-name">
            <b>${escapeHtml(item.name)}</b>
            <span class="hint mono">${escapeHtml(item.file)}</span>
            ${item.exists ? "" : `<span class="hint">the file does not exist yet</span>`}
          </div>
          ${inOrder ? `<span class="count">#${index}</span>
            <button type="button" class="inline-btn" data-up ${index === 0 ? "disabled" : ""}>↑</button>
            <button type="button" class="inline-btn" data-down
                    ${index === chosen.length - 1 ? "disabled" : ""}>↓</button>` : ""}
          <button type="button" class="inline-btn danger" data-remove
                  title="Remove this list from the build, or delete its file">🗑</button>
        </div>`;

      document.getElementById("list-chosen").innerHTML =
        chosen.length ? chosen.map((item, index) => line(item, index, true)).join("")
                      : `<div class="problem-empty">Nothing is selected, so a build
                         would generate nothing.</div>`;
      document.getElementById("list-spare").innerHTML =
        spare.length ? spare.map((item) => line(item, 0, false)).join("")
                     : `<div class="problem-empty">Every list in the folder is in the build.</div>`;
      wire();
    };

    const wire = () => {
      /* Only THIS dialog's rows. A document-wide ".list-row" also caught the
         recent-projects rows on the start screen - hidden, but still in the
         page - and those have no checkbox, so wiring threw on the first one
         and the dialog's own buttons were never bound. */
      for (const row of document.querySelectorAll(
             "#list-chosen .list-row, #list-spare .list-row")) {
        const item = rows.find((r) => r.path === row.dataset.path);
        row.querySelector("[data-toggle]").addEventListener("change", (event) => {
          item.selected = event.target.checked;
          if (item.selected) { rows = rows.filter((r) => r !== item).concat([item]); }
          render();
        });
        const up = row.querySelector("[data-up]");
        const down = row.querySelector("[data-down]");
        if (up) up.addEventListener("click", () => { moveChosen(item, -1); render(); });
        if (down) down.addEventListener("click", () => { moveChosen(item, 1); render(); });
        row.querySelector("[data-remove]")
           .addEventListener("click", () => this.removeList(item));
      }
    };

    /* Only the selected rows have an order, so the move works on that subset and
       is written back into the full list. */
    const moveChosen = (item, offset) => {
      const chosen = rows.filter((r) => r.selected);
      const index = chosen.indexOf(item);
      const target = index + offset;
      if (target < 0 || target >= chosen.length) return;
      chosen.splice(index, 1);
      chosen.splice(target, 0, item);
      const spare = rows.filter((r) => !r.selected);
      rows = chosen.concat(spare);
    };

    showModal("Parameter lists",
      `<p class="modal-note">Every list of the project lives in
       <code>${escapeHtml(answer.directory)}</code>. The ones that are ticked are
       merged into one parameter list, <b>in the order shown</b> &mdash; that order
       is the order of the indices in the generated code. The choice is saved into
       <code>${escapeHtml(answer.config)}</code>, so
       <code>run_generate.py</code> builds exactly what you see here.</p>
       <button type="button" class="inline-btn" id="btn-new-list">+ New parameter list</button>
       <button type="button" class="inline-btn" id="btn-open-list">Open an existing file…</button>
       <label>In the build</label>
       <div class="list-box" id="list-chosen"></div>
       <label>In the folder, not in the build</label>
       <div class="list-box" id="list-spare"></div>`,
      async () => {
        try {
          const answer2 = await api.selectLists(rows.filter((r) => r.selected)
                                                    .map((r) => r.path));
          if (!answer2.ok) {
            toast(answer2.message || "Could not save the choice.", "bad");
            return;
          }
          await this.refresh();
          toast(`${answer2.paths.length} list(s) take part in the build.`, "good");
        } catch (error) { this.failed("Saving the choice", error); }
      });

    render();
    document.getElementById("btn-new-list").addEventListener("click", () => this.newList());
    document.getElementById("btn-open-list").addEventListener("click", () => this.openList());
  },

  /* Creating a list writes the file and puts it in the build straight away, so
     what the editor opens next is a file that really exists. */
  async newList(directory) {
    /* The folder is chosen by walking into it, the same way Open does - a
       browser cannot hand a page a real path, so the backend lists the folders
       and the page walks them. */
    let here = null;
    try {
      here = await api.browse(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!here.ok) { toast(here.message || "Could not open that folder.", "bad"); return; }

    const folders = here.folders.map((item) => `
      <div class="list-row" data-folder="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b></div>
      </div>`).join("");

    const up = here.parent
      ? `<div class="list-row" data-folder="${escapeHtml(here.parent)}">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b>
             <span class="hint mono">${escapeHtml(here.parent)}</span></div>
         </div>`
      : "";

    const existing = here.files.length
      ? here.files.map((item) => escapeHtml(item.name)).join(", ")
      : "none";

    showModal("New parameter list",
      `<p class="modal-note">A new, empty list is created here and added to the
       build. It starts with the same drop-down lists as the one open now.</p>
       <label>Name</label>
       <input type="text" id="new-list-name" class="mono" value="parameter_list_">
       <label>Folder</label>
       <div class="hint mono" style="margin-bottom:6px" id="new-list-dir-shown"
            >${escapeHtml(here.directory)}</div>
       <div class="list-box" id="new-list-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <p class="modal-note">Already here: <span class="mono">${existing}</span></p>
       <input type="hidden" id="new-list-dir" value="${escapeHtml(here.directory)}">`,
      async () => {
        const name = document.getElementById("new-list-name").value.trim();
        const directory = document.getElementById("new-list-dir").value.trim();
        try {
          const answer = await api.newList(name, directory);
          if (!answer.ok) {
            toast(answer.message || "Could not create the list.", "bad");
            return;
          }
          await api.open(answer.path);
          this.selected = "";
          await this.refresh();
          toast(`Created ${answer.path}`, "good");
          setStatus("New parameter list");
        } catch (error) { this.failed("Creating the list", error); }
      });

    /* walking into a folder re-opens the dialog there, keeping the name typed */
    for (const row of document.querySelectorAll("#new-list-folders [data-folder]")) {
      row.addEventListener("click", () => {
        const typed = document.getElementById("new-list-name").value;
        this.newList(row.dataset.folder).then(() => {
          const box = document.getElementById("new-list-name");
          if (box) box.value = typed;
        });
      });
    }
  },


  /* ------------------------------------------------- open an existing list */
  /* A browser cannot hand a page a real path: a file input gives a name and a
     blob, never a location the generator could write into its configuration.
     So the folders are listed by the backend, where the paths are real, and
     this walks them. A file is checked BEFORE it is added - an XML that is not
     a parameter list has to be refused here, with a reason, not discovered
     halfway through a build after the configuration was already rewritten. */
  /* ------------------------------------------------------- the project */
  /* Both dialogs browse with the same call and show the same two boxes; what
     differs is what a click MEANS. Opening wants a folder that already holds a
     project file; creating wants a folder that does not. */

  async openProjectDialog(directory) {
    let answer;
    try {
      answer = await api.browseProjects(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!answer.ok) { toast(answer.message || "Could not open that folder.", "bad"); return; }

    const folders = answer.folders.map((item) => `
      <div class="list-row${item.isProject ? " on" : ""}"
           data-folder="${escapeHtml(item.path)}"
           data-project-file="${escapeHtml(item.projectFile || "")}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b>
          ${item.isProject ? `<span class="hint">a project — click to open it</span>` : ""}
        </div>
      </div>`).join("");

    const files = answer.files.map((item) => `
      <div class="list-row" data-file="${escapeHtml(item.path)}">
        <span class="node-icon prim">◆</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b></div>
      </div>`).join("");

    const up = answer.parent
      ? `<div class="list-row" data-folder="${escapeHtml(answer.parent)}"
              data-project-file="">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b>
             <span class="hint mono">${escapeHtml(answer.parent)}</span></div>
         </div>`
      : "";

    showModal("Open a project",
      `<p class="modal-note">A project is a folder with a <code>project.json</code>
       in it. A folder that has one is marked; clicking it opens the project.</p>
       <label>Folder</label>
       <div class="hint mono" style="margin-bottom:6px">${escapeHtml(answer.directory)}</div>
       <label>Or type the path of a project file</label>
       <input type="text" id="open-project-path" class="mono"
              placeholder="C:\\work\\my_project\\project.json">
       <label>Folders</label>
       <div class="list-box" id="project-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <label>Project files here</label>
       <div class="list-box" id="project-files">${files
         || `<div class="problem-empty">No .json file in this folder.</div>`}</div>`,
      async () => {
        const typed = document.getElementById("open-project-path").value.trim();
        if (!typed) { toast("Pick a project, or type its path.", "bad"); return; }
        await this.openProject(typed);
      });

    /* A folder that IS a project opens it; any other folder is walked into. */
    for (const row of document.querySelectorAll("#project-folders [data-folder]")) {
      row.addEventListener("click", () => {
        const file = row.dataset.projectFile;
        if (file) { closeModal(); this.openProject(file); }
        else this.openProjectDialog(row.dataset.folder);
      });
    }
    for (const row of document.querySelectorAll("#project-files [data-file]")) {
      row.addEventListener("click", () => {
        document.getElementById("open-project-path").value = row.dataset.file;
      });
    }
  },

  async newProjectDialog(directory) {
    let answer;
    try {
      answer = await api.browseProjects(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!answer.ok) { toast(answer.message || "Could not open that folder.", "bad"); return; }

    const folders = answer.folders.map((item) => `
      <div class="list-row${item.isProject ? " on" : ""}"
           data-folder="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b>
          ${item.isProject ? `<span class="hint">already a project</span>` : ""}</div>
      </div>`).join("");

    const up = answer.parent
      ? `<div class="list-row" data-folder="${escapeHtml(answer.parent)}">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b></div></div>`
      : "";

    showModal("New project",
      `<p class="modal-note">A folder is made for the project, holding a
       <code>project.json</code> and an empty <code>parameter_lists</code> folder.
       Nothing else is written, and an existing project is never overwritten.</p>
       <label>Name</label>
       <input type="text" id="new-project-name" placeholder="Ground station">
       <label>What it generates</label>
       <select id="new-project-format">
         <option value="smart_data" selected>Smart data &mdash; the cg_ files</option>
         <option value="param_table">Parameter table &mdash; nsrParamTables.h</option>
       </select>
       <span class="hint" id="new-project-format-note"></span>
       <label>Inside this folder</label>
       <div class="hint mono" style="margin-bottom:6px">${escapeHtml(answer.directory)}</div>
       <label>Folders</label>
       <div class="list-box" id="new-project-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <label>The project folder will be</label>
       <div class="hint mono" id="new-project-preview">${escapeHtml(answer.directory)}\\…</div>`,
      async () => {
        const name = document.getElementById("new-project-name").value.trim();
        if (!name) { toast("A project needs a name.", "bad"); return; }
        const format = document.getElementById("new-project-format").value;
        try {
          const made = await api.newProject(
            folderFor(answer.directory, name), name, format);
          if (!made.ok) { toast(made.message || "Could not create the project.", "bad"); return; }
          this.allLists = false;
          this.selected = "";
          await this.refresh();
          toast(`Created '${made.project.name}'`, "good");
          setStatus(made.project.name);
        } catch (error) { this.failed("Creating the project", error); }
      });

    const name = document.getElementById("new-project-name");
    const preview = document.getElementById("new-project-preview");
    const showPath = () => {
      preview.textContent = folderFor(answer.directory, name.value.trim() || "…");
    };
    name.addEventListener("input", showPath);
    name.focus();

    /* The format decides what the folder even needs, so it is said here rather
       than found out later: only smart data has a C library underneath it. */
    const format = document.getElementById("new-project-format");
    const formatNote = document.getElementById("new-project-format-note");
    const showFormat = () => {
      formatNote.innerHTML = format.value === "param_table"
        ? `One <code>nsrParamTables.h</code> of <code>ADD_PARAM()</code> lines and
           an <code>nsrParamOffsets.h</code> note beside it. <b>No <code>lib</code>
           folder</b> &mdash; the firmware expands the macros itself, so there is
           no library to copy.`
        : `The seven <code>cg_</code> files, plus a <code>lib</code> with this
           project's own copy of the C library they plug into.`;
    };
    format.addEventListener("change", showFormat);
    showFormat();

    /* Walking into a folder keeps the name that has been typed. */
    for (const row of document.querySelectorAll("#new-project-folders [data-folder]")) {
      row.addEventListener("click", () => {
        const typed = name.value;
        this.newProjectDialog(row.dataset.folder).then(() => {
          const again = document.getElementById("new-project-name");
          if (again) { again.value = typed; again.dispatchEvent(new Event("input")); }
        });
      });
    }
  },

  async openList(directory) {
    let answer;
    try {
      answer = await api.browse(directory || "");
    } catch (error) { return this.failed("Reading the folder", error); }
    if (!answer.ok) { toast(answer.message || "Could not open that folder.", "bad"); return; }

    const folders = answer.folders.map((item) => `
      <div class="list-row" data-folder="${escapeHtml(item.path)}">
        <span class="node-icon struct">▣</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b></div>
      </div>`).join("");

    const files = answer.files.map((item) => `
      <div class="list-row${item.inBuild ? " on" : ""}" data-file="${escapeHtml(item.path)}">
        <span class="node-icon prim">◆</span>
        <div class="list-name"><b>${escapeHtml(item.name)}</b>
          ${item.inBuild ? `<span class="hint">already in the build</span>` : ""}</div>
      </div>`).join("");

    const up = answer.parent
      ? `<div class="list-row" data-folder="${escapeHtml(answer.parent)}">
           <span class="node-icon struct">▣</span>
           <div class="list-name"><b>..</b>
             <span class="hint mono">${escapeHtml(answer.parent)}</span></div>
         </div>`
      : "";

    showModal("Open a parameter list",
      `<p class="modal-note">Pick an <code>.xml</code> file anywhere on this
       machine &mdash; another project's list included. It is checked first, and
       then <b>copied into this project</b> together with the structures file
       beside it, so this project stays a folder you can move and the other
       project goes on unchanged.</p>
       <label>Folder</label>
       <div class="hint mono" style="margin-bottom:6px">${escapeHtml(answer.directory)}</div>
       <label>Or type a path</label>
       <input type="text" id="open-list-path" class="mono"
              placeholder="C:\\project\\module\\parameter_list.xml">
       <div id="open-verdict"></div>
       <label>Folders</label>
       <div class="list-box" id="open-folders">${up}${folders
         || `<div class="problem-empty">No sub-folders.</div>`}</div>
       <label>Parameter lists here</label>
       <div class="list-box" id="open-files">${files
         || `<div class="problem-empty">No .xml file in this folder.</div>`}</div>`,
      async () => {
        const typed = document.getElementById("open-list-path").value.trim();
        if (!typed) { toast("Pick a file, or type its path.", "bad"); return; }
        try {
          const added = await api.addExistingList(typed);
          if (!added.ok) { toast(added.message || "Could not add that file.", "bad"); return; }
          await api.open(added.path);
          this.selected = "";
          await this.refresh();
          toast(`'${added.path}' is now part of the build.`, "good");
          setStatus("List added");
        } catch (error) { this.failed("Adding the list", error); }
      });

    /* clicking a folder walks into it; clicking a file fills the box and
       says straight away whether the file fits */
    for (const row of document.querySelectorAll("#open-folders [data-folder]")) {
      row.addEventListener("click", () => this.openList(row.dataset.folder));
    }
    const box = document.getElementById("open-list-path");
    const verdict = document.getElementById("open-verdict");
    const inspect = async (path) => {
      verdict.innerHTML = `<p class="modal-note">Checking…</p>`;
      try {
        const report = await api.inspectList(path);
        verdict.innerHTML = report.ok
          ? `<div class="drift ok"><b>This is a parameter list.</b>
             <p>${report.values} value(s) in ${report.parameters} top level entry(ies),
             ${report.structures} structure(s).${report.templates.length
               ? ` Types: ${escapeHtml(report.templates.join(", "))}.` : ""}</p>
             ${report.notes.length ? `<p class="hint">${report.notes
               .map(escapeHtml).join("<br>")}</p>` : ""}</div>`
          : `<div class="drift bad"><b>This file cannot be added.</b>
             <p>${escapeHtml(report.reason || "It is not a parameter list.")}</p></div>`;
      } catch (error) {
        verdict.innerHTML = `<div class="drift bad"><b>Could not check the file.</b>
          <p>${escapeHtml(error.message)}</p></div>`;
      }
    };
    for (const row of document.querySelectorAll("#open-files [data-file]")) {
      row.addEventListener("click", () => {
        box.value = row.dataset.file;
        inspect(row.dataset.file);
      });
    }
    box.addEventListener("change", () => box.value.trim() && inspect(box.value.trim()));
  },

  /* ------------------------------------------- reusable structure types */
  /* A type is a shape, and a parameter made from one owns its copy: nothing
     links back, so editing the parameter never edits the type and editing the
     type never rewrites a parameter that was made earlier. */
  /* --------------------------------------------------- structure types */
  /* A structure type is a C++ struct declaration: a name and the fields inside
     it.  A parameter NAMES one, so editing the type here reaches every
     parameter of that type - add a field and they all grow it, in the right
     place, with the log ids after it shifted along.

     What is deliberately not here: minimum, maximum, default and resolution.
     Those are the range one particular value may take, and two parameters of
     the same type routinely want different ones - so they belong to the
     parameter, exactly as they do in C++. */

  async useType(path, name) {
    try {
      const answer = await api.useType(path, name);
      if (!answer.ok) { toast(answer.message || `No type called '${name}'.`, "bad"); return; }
      await this.refresh();
      setStatus(`Type ${name}`);
    } catch (error) { this.failed("Setting the type", error); }
  },

  /* The panel: every type of the project, and what uses it here. */
  editTypes(openOn) {
    const types = this.state.structTypes || [];
    const rows = types.map((type) => {
      const shape = type.fields.map((f) =>
        `${escapeHtml(f.name)}${f.arraySize > 1 ? `[${f.arraySize}]` : ""} : ` +
        `${escapeHtml(f.valueType || "?")}${f.unit ? ` [${escapeHtml(f.unit)}]` : ""}`
      ).join("<br>");
      const used = (type.usedHere || []).length;
      return `
      <div class="template-row" data-type="${escapeHtml(type.name)}">
        <div>
          <b>${escapeHtml(type.name)}</b>
          <span class="count">${type.fields.length} field(s)</span>
          ${used ? `<span class="count">used by ${used} here</span>`
                 : `<span class="hint">not used in this list</span>`}
          ${type.description ? `<div class="hint">${escapeHtml(type.description)}</div>` : ""}
          <div class="hint mono">${shape || "no fields yet"}</div>
        </div>
        <span>
          <button type="button" class="inline-btn" data-edit-type="${escapeHtml(type.name)}">Edit…</button>
          <button type="button" class="inline-btn danger" data-delete-type="${escapeHtml(type.name)}">Delete</button>
        </span>
      </div>`;
    }).join("");

    showModal("Structure types",
      `<p class="modal-note">A structure type is a <code>struct</code> declaration:
       a name and the fields inside it. A parameter is <b>of</b> a type, so editing
       one here changes every parameter of that type &mdash; a field added appears
       in all of them, and the log ids after it move along.</p>
       <p class="modal-note">Limits are <b>not</b> part of a type: two parameters of
       one type usually want different ones, so each keeps its own.</p>
       <button type="button" class="inline-btn" id="btn-new-type">+ New structure type</button>
       <div class="template-list">${rows
         || `<div class="problem-empty">No structure types yet.</div>`}</div>`, null);

    document.getElementById("btn-new-type").addEventListener("click", () => this.newType());
    for (const button of document.querySelectorAll("[data-edit-type]")) {
      button.addEventListener("click", () => this.editOneType(button.dataset.editType));
    }
    for (const button of document.querySelectorAll("[data-delete-type]")) {
      button.addEventListener("click", async () => {
        const name = button.dataset.deleteType;
        try {
          const answer = await api.deleteType(name);
          if (!answer.ok) { toast(answer.message, "bad"); return; }
          await this.refresh(true);
          toast(`Structure type '${name}' deleted.`, "good");
          this.editTypes();
        } catch (error) { this.failed("Deleting the type", error); }
      });
    }
    if (openOn) this.editOneType(openOn);
  },

  newType() {
    this.draftFields = [{name: "", valueType:
      (this.state.defines.valueTypes || ["uint8_t"])[0], arraySize: 1,
      unit: "", description: ""}];

    showModal("New structure type",
      `<p class="modal-note">The name becomes a C <code>typedef</code>, so it has to
       be a name C can use. Its fields are right here &mdash; there is no second
       dialog to go to.</p>
       <label>Name</label>
       <input type="text" id="new-type-name" class="mono" placeholder="Position">
       <label>Description</label>
       <input type="text" id="new-type-description" placeholder="What this holds.">
       <label>Fields</label>
       <div class="type-fields-box">
       <table class="type-fields">
         <tr><th style="width:22%">Name</th><th style="width:24%">Data type</th>
             <th style="width:12%">Array</th><th style="width:14%">Unit</th>
             <th>Description</th><th style="width:12%"></th></tr>
         <tbody id="type-fields"></tbody>
       </table></div>
       <button type="button" class="inline-btn" id="btn-add-field">+ Add field</button>`,
      async () => {
        this.readDraftFields();
        const name = document.getElementById("new-type-name").value.trim();
        const description = document.getElementById("new-type-description").value.trim();
        try {
          const answer = await api.newType(name, description);
          if (!answer.ok) { toast(answer.message, "bad"); return; }
          const given = await api.updateType(answer.name, {
            name: answer.name, description, fields: this.draftFields});
          if (!given.ok) { toast(given.message, "bad"); return; }
          await this.refresh(true);
          toast(`Structure type '${answer.name}' declared.`, "good");
          this.editTypes();
        } catch (error) { this.failed("Declaring the type", error); }
      });

    this.renderDraftFields();
    document.getElementById("btn-add-field").addEventListener("click", () => {
      this.readDraftFields();
      this.draftFields.push({name: "", valueType:
        (this.state.defines.valueTypes || ["uint8_t"])[0], arraySize: 1,
        unit: "", description: ""});
      this.renderDraftFields();
    });
    document.getElementById("new-type-name").focus();
  },

  /* One type's fields, edited as a table.  The whole list is sent back on OK,
     so removing a row removes the field and dragging the order is the order of
     the C members. */
  editOneType(name) {
    const type = (this.state.structTypes || []).find((t) => t.name === name);
    if (!type) { toast(`No structure type called '${name}'.`, "bad"); return; }

    this.draftFields = type.fields.map((f) => Object.assign({}, f));
    const used = (type.usedHere || []).length;

    showModal(`Structure type ${name}`,
      `${used ? `<p class="modal-note"><b>${used} parameter(s) of this list are of this
         type.</b> Every change here reaches all of them.</p>` : ""}
       <label>Name</label>
       <input type="text" id="type-name" class="mono" value="${escapeHtml(type.name)}">
       <label>Description</label>
       <input type="text" id="type-description" value="${escapeHtml(type.description || "")}">
       <label>Fields</label>
       <div class="type-fields-box">
       <table class="type-fields">
         <tr><th style="width:22%">Name</th><th style="width:24%">Data type</th>
             <th style="width:12%">Array</th><th style="width:14%">Unit</th>
             <th>Description</th><th style="width:12%"></th></tr>
         <tbody id="type-fields"></tbody>
       </table></div>
       <button type="button" class="inline-btn" id="btn-add-field">+ Add field</button>`,
      async () => {
        this.readDraftFields();
        try {
          const answer = await api.updateType(name, {
            name: document.getElementById("type-name").value.trim(),
            description: document.getElementById("type-description").value.trim(),
            fields: this.draftFields,
          });
          if (!answer.ok) { toast(answer.message, "bad"); return; }
          await this.refresh(true);
          /* A rename that could only reach this list has something to say, and
             it is not an error - so it is shown for longer, as a warning. */
          if (answer.note) toast(answer.note, "warn");
          else toast(`Structure type '${answer.name}' updated.`, "good");
        } catch (error) { this.failed("Updating the type", error); }
      });

    this.renderDraftFields();
    document.getElementById("btn-add-field").addEventListener("click", () => {
      this.readDraftFields();
      this.draftFields.push({name: "", valueType:
        (this.state.defines.valueTypes || ["uint8_t"])[0], arraySize: 1,
        unit: "", description: ""});
      this.renderDraftFields();
    });
  },

  /* ------------------------------------------------------------ toolbar */
  bindToolbar() {
    const on = (id, handler) => document.getElementById(id).addEventListener("click", handler);

    on("btn-save", () => this.save());
    on("btn-reload", async () => {
      if (this.state.dirty && !confirm("Discard the unsaved changes and reload?")) return;
      try {
        await api.open(null);
        this.selected = "";
        await this.refresh();
        setStatus("Reloaded");
      } catch (error) { this.failed("Reloading", error); }
    });

    document.getElementById("module-picker").addEventListener("change", async (event) => {
      const path = event.target.value;
      if (this.state.dirty &&
          !confirm("This module has unsaved changes. Switch anyway and lose them?")) {
        this.paint(true);   // put the picker back on the current module
        return;
      }
      try {
        if (path === ALL_LISTS) {
          /* Nothing is opened: the merged view reads every list of the build,
             including the one already open, exactly as the generator does. */
          this.allLists = true;
          this.selected = "";
          await this.refresh();
          setStatus("Every list, merged — read only");
          return;
        }
        this.allLists = false;
        await api.open(path);
        this.selected = "";
        await this.refresh();
        setStatus("Switched module");
      } catch (error) {
        this.failed("Opening the list", error);
        this.paint(true);   // put the picker back on the current module
      }
    });

    this.bindMenu("btn-project", "menu-project", {
      "open-project": () => this.openProjectDialog(),
      "new-project": () => this.newProjectDialog(),
      "close-project": () => this.closeProject(),
    });
    on("btn-start-open", () => this.openProjectDialog());
    on("btn-start-new", () => this.newProjectDialog());

    this.bindMenu("btn-add-menu", "menu-add", {
      "add": () => this.addNode("primitive", false),
      "add-struct": () => {
        if (this.isParamTable()) {
          toast("A parameter table has no structures - every row is one value.",
                "bad");
          return;
        }
        this.addStructure();
      },
    });
    this.bindMenu("btn-settings", "menu-settings", {
      "choices": () => this.editLists(),
      "theme": () => this.toggleTheme(),
    });
    /* one place that closes every menu: a click anywhere else, or Escape */
    document.addEventListener("click", () => {
      for (const close of this._menuClosers) close();
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        for (const close of this._menuClosers) close();
      }
    });

    on("btn-duplicate", async () => {
      try {
        const answer = await api.duplicate(this.selected);
        if (answer.selected) this.selected = answer.selected;
        await this.refresh();
        setStatus("Duplicated");
      } catch (error) { this.failed("Duplicating", error); }
    });
    on("btn-delete", () => this.remove());
    on("btn-up", () => this.moveNode(-1));
    on("btn-down", () => this.moveNode(1));

    on("btn-undo", async () => {
      try { await api.undo(); await this.refresh(); setStatus("Undo"); }
      catch (error) { this.failed("Undo", error); }
    });
    on("btn-redo", async () => {
      try { await api.redo(); await this.refresh(); setStatus("Redo"); }
      catch (error) { this.failed("Redo", error); }
    });

    on("btn-types", () => this.editTypes());
    on("btn-clear-filters", () => {
      gridView.filters = {};
      document.getElementById("filter").value = "";
      gridView.search = "";
      this.paint(true);
    });

    on("btn-lists-select", () => this.editListSelection());
    on("btn-generate", () => this.generate());

    /* One box that looks in every column, next to the per-column filters -
       the two narrow the same list together. */
    document.getElementById("filter").addEventListener("input", (event) => {
      gridView.search = event.target.value.trim();
      this.paint(true);
    });

    document.getElementById("btn-toggle-problems").addEventListener("click", (event) => {
      this.problemsPinned = true;      // from here on it is the user's choice
      event.stopPropagation();
      document.getElementById("problems-pane").classList.toggle("collapsed");
      this.sizeProblems();
    });
  },

  bindShortcuts() {
    document.addEventListener("keydown", (event) => {
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
      if (event.ctrlKey && event.key.toLowerCase() === "s") { event.preventDefault(); this.save(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "g") { event.preventDefault(); this.generate(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "n") { event.preventDefault(); this.addNode("primitive", false); }
      else if (event.ctrlKey && event.key.toLowerCase() === "d") { event.preventDefault(); document.getElementById("btn-duplicate").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "z") { event.preventDefault(); document.getElementById("btn-undo").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "y") { event.preventDefault(); document.getElementById("btn-redo").click(); }
      else if (event.key === "Delete" && !typing && this.selected) { this.remove(); }
    });
  },

  async remove() {
    if (!this.selected) return;
    if (!confirm(`Delete '${this.selected}'?`)) return;
    try {
      await api.remove(this.selected);
      this.selected = "";
      await this.refresh();
      setStatus("Deleted");
    } catch (error) { this.failed("Deleting", error); }
  },

  async moveNode(offset) {
    try {
      const answer = await api.move(this.selected, offset);
      await this.refresh();
      /* A move that could not happen used to do nothing at all and say nothing
         at all, which reads exactly like a broken button. */
      setStatus(answer.ok
        ? "Moved"
        : `Already ${offset < 0 ? "first" : "last"} among its siblings`);
    } catch (error) { this.failed("Moving", error); }
  },

  async save() {
    try {
      const answer = await api.save(null);
      await this.refresh(true);
      toast(`Saved to ${answer.path}`, "good");
      setStatus("Saved");
    } catch (error) { this.failed("Saving", error); }
  },

  /* ------------------------------------------------------------ actions */
  async generate() {
    setStatus("Generating…");
    let result;
    try {
      result = await api.generate();
    } catch (error) {
      /* Never leave the page sitting on "Generating…": a request that failed
         outright still has to say so. */
      toast(`Generation failed: ${error.message}`, "bad");
      setStatus("Generation failed");
      return;
    }
    await this.refresh(true);
    if (!result.success) {
      toast(result.message
        ? `Nothing was generated: ${result.message}`
        : "The model has errors - nothing was generated. See Problems.", "bad");
      document.getElementById("problems-pane").classList.remove("collapsed");
      setStatus("Generation aborted");
      return;
    }
    const files = result.files.map((f) => `<div>${escapeHtml(f)}</div>`).join("");
    const modules = (result.modules || []).length > 1
      ? `<p class="modal-note">Read from ${result.modules.length} sub-module(s):</p>
         <div class="file-list">${result.modules
           .map((m) => `<div>${escapeHtml(m)}</div>`).join("")}</div>` : "";
    const saved = result.saved
      ? `<p class="modal-note">The model was saved to
         <code>${escapeHtml(result.saved)}</code> first, so
         <code>run.bat generate</code> now produces exactly the same code.</p>` : "";

    const drift = this.driftHtml(result.drift);

    showModal(result.drift && result.drift.breaksStoredData
                ? "Code generated - CHECK THE MEMORY LAYOUT"
                : "Code generated",
      `${drift}${saved}${modules}<p class="modal-note">${result.count} value(s) written into
       ${result.files.length} file(s):</p><div class="file-list">${files}</div>`,
      null);
    setStatus(result.drift && result.drift.breaksStoredData
      ? `Generated ${result.files.length} files - the memory layout MOVED`
      : `Generated ${result.files.length} files`);
  },

  /* --------------------------------------------- the memory layout warning */
  /* The offset of a reset-proof value is positional: it is the sum of the sizes
     of everything before it. So inserting a parameter in the middle, disabling
     one, moving one, or widening one moves EVERY parameter after it - and a
     board that already has data in flash then reads the wrong value at the old
     offset. None of that shows up in the generated code, which is why the
     editor says it here, before anything else in the dialog. */
  driftHtml(drift) {
    if (!drift || drift.firstRun) return "";
    if (drift.table) return this.tableDriftHtml(drift);

    if (drift.breaksStoredData) {
      const rows = drift.moved.slice(0, 14).map((m) => `
        <tr><td class="mono">${escapeHtml(m.parameter)}</td>
            <td class="mono">${escapeHtml(m.tag)}</td>
            <td class="c mono">${m.old}</td><td class="c mono">${m.new}</td></tr>`).join("");
      const more = drift.moved.length > 14
        ? `<p class="hint">... and ${drift.moved.length - 14} more.</p>` : "";
      return `<div class="drift bad">
        <b>The stored position of ${drift.moved.length} value(s) changed.</b>
        <p>A board that already has data in flash will read the <b>wrong value</b>
           at these offsets. Before flashing, erase the stored area, migrate it,
           or move the new parameters to the <b>end</b> of the list instead of
           the middle.</p>
        <div class="drift-table">
          <table><tr><th>parameter</th><th>tag</th><th class="c">was</th>
                     <th class="c">now</th></tr>${rows}</table>
        </div>${more}
      </div>`;
    }

    const bits = [];
    if (drift.added.length) bits.push(`${drift.added.length} added`);
    if (drift.removed.length) bits.push(`${drift.removed.length} removed`);
    if (drift.reindexed.length) bits.push(`${drift.reindexed.length} reindexed`);
    if (!bits.length) return "";
    return `<div class="drift ok">
      <b>The list changed, but nothing moved.</b>
      <p>${escapeHtml(bits.join(", "))} &mdash; every value that existed before is
         still at the same offset, so a board in the field keeps reading what it
         was reading.</p></div>`;
  },

  /* The same question, asked of the other format. A parameter table stores
     nothing by byte offset - there is no offset in it anywhere - so talking
     about flash would be nonsense here. What can break a board is a parameter's
     NUMBER inside its sub-system, because that is what the ground station asks
     for. Reordering the lists themselves changes neither: the blocks swap
     places in the file and every number stays where it was. */
  tableDriftHtml(drift) {
    const rows = (list) => list.slice(0, 14).map((m) => `
      <tr><td class="mono">${escapeHtml(m.parameter)}</td>
          <td class="c mono">${escapeHtml(String(m.old))}</td>
          <td class="c mono">${escapeHtml(String(m.new))}</td></tr>`).join("");

    if (drift.breaksStoredData) {
      const moved = drift.reindexed.concat(drift.resystemed || []);
      const more = moved.length > 14
        ? `<p class="hint">... and ${moved.length - 14} more.</p>` : "";
      return `<div class="drift bad">
        <b>${moved.length} parameter(s) changed their number in the table.</b>
        <p>The ground station and the firmware ask for a parameter <b>by that
           number</b>, so anything not rebuilt with this file reads the
           <b>wrong parameter</b>. That is what the warning at the top of
           <code>nsrParamTables.h</code> means: add a new item at the
           <b>end</b> of its sub-system, never between old ones.</p>
        <div class="drift-table">
          <table><tr><th>parameter</th><th class="c">was</th>
                     <th class="c">now</th></tr>${rows(moved)}</table>
        </div>${more}
      </div>`;
    }

    const bits = [];
    if (drift.added.length) bits.push(`${drift.added.length} added`);
    if (drift.removed.length) bits.push(`${drift.removed.length} removed`);
    if (!bits.length) return "";
    return `<div class="drift ok">
      <b>The table changed, but no number moved.</b>
      <p>${escapeHtml(bits.join(", "))} &mdash; every parameter that existed
         before still has the same number in its sub-system, so a ground station
         that was not rebuilt keeps asking for the right one.</p></div>`;
  },


  /* The four drop-down lists the editor offers, and the enums generated from them. */
  editLists() {
    const defines = this.state.defines;
    const keys = ["paramTypes", "systemNames", "paramModes", "valueTypes"];
    const labels = {
      paramTypes: "Parameter types (MONITORING, SETTING, COMMAND)",
      systemNames: "System names",
      paramModes: "Parameter modes",
      valueTypes: "Value types (float32_t, uint16_t, ...)",
    };

    let body = `<p class="modal-note">One value per line, in the order they should get
       their enum value. These are the choices the editor offers and the enumerations
       the generator writes into <code>cg_parameter_list_defines.h</code>.</p>
       <button type="button" class="inline-btn" id="btn-restore-lists">
         Restore the company defaults</button>`;
    for (const key of keys) {
      body += `<label>${labels[key]} <span class="count" id="count-${key}"></span></label>
        <textarea id="list-${key}">${escapeHtml((defines[key] || []).join("\n"))}</textarea>`;
    }

    showModal("Drop-down lists", body, async () => {
      try {
        for (const key of keys) {
          const values = document.getElementById(`list-${key}`).value
            .split("\n").map((v) => v.trim()).filter(Boolean);
          const answer = await api.setDefines(key, values);
          if (!answer.ok) {
            toast(answer.message || `Could not save the '${labels[key]}' list.`, "bad");
            return;
          }
        }
        await this.refresh();
        toast("Lists updated.", "good");
      } catch (error) { this.failed("Saving the lists", error); }
    });

    /* live count under each box, so a truncated list is obvious */
    const recount = () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").filter((v) => v.trim());
        document.getElementById(`count-${key}`).textContent = `(${values.length})`;
      }
    };
    for (const key of keys) {
      document.getElementById(`list-${key}`).addEventListener("input", recount);
    }
    recount();

    document.getElementById("btn-restore-lists").addEventListener("click", async () => {
      try {
        const defaults = await api.defaultDefines();
        for (const key of keys) {
          document.getElementById(`list-${key}`).value = (defaults[key] || []).join("\n");
        }
        recount();
      } catch (error) { this.failed("Reading the defaults", error); }
    });
  },
};

/* ---------------------------------------------------------------- helpers */
/* Everything below the top bar is positioned from --topbar-h, and the toolbar
   wraps to a second row on a narrow window, so that height cannot be a constant:
   it is measured here and republished whenever the bar changes size.  Without
   this the wrapped row lies on top of the parameter tree. */
function trackTopbarHeight() {
  const bar = document.querySelector(".topbar");
  if (!bar) return;
  const apply = () => document.documentElement.style.setProperty(
    "--topbar-h", `${Math.ceil(bar.getBoundingClientRect().height)}px`);
  if (window.ResizeObserver) new ResizeObserver(apply).observe(bar);
  else window.addEventListener("resize", apply);
  apply();
}

//: the three severities, in the order they are shown and counted
const SEVERITIES = ["error", "warning", "info"];

/* How many of each.  One place, so the status bar and the panel can never
   disagree about how bad the model is. */
function countBySeverity(diagnostics) {
    const counts = { error: 0, warning: 0, info: 0 };
    for (const item of diagnostics) {
      if (counts[item.severity] !== undefined) counts[item.severity]++;
    }
    return counts;
}

function findNode(nodes, path) {
  for (const node of nodes) {
    if (node.path === path) return node;
    const found = findNode(node.children || [], path);
    if (found) return found;
  }
  return null;
}

/* How many values these nodes put in the generated table.  An array of
   structures contributes one full set of values PER ELEMENT, which is what
   makes this different from simply counting the leaves of the model - get it
   wrong and the count under the grid disagrees with PARAMETER_LIST_QTY. */
function countLeaves(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (!node.enable) continue;
    total += node.kind === "struct"
      ? countLeaves(node.children) * Math.max(1, node.arraySize || 1)
      : 1;
  }
  return total;
}

function countStructs(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === "struct") total += 1 + countStructs(node.children);
  }
  return total;
}

function expandTo(path) {
  /* The grid opens every structure on the way to a row, so a Problems row
     always lands on something visible. */
  const parts = path.split(".");
  for (let index = 1; index < parts.length; index++) {
    gridView.open(parts.slice(0, index).join("."));
  }
}

/* The folder a project called *name* gets, inside *parent*.  Spaces and the
   like become underscores: it is a folder name on Windows, and the project
   keeps its real name inside its own file. */
function folderFor(parent, name) {
  const safe = name.replace(/[\\/:*?"<>|]/g, "").trim().replace(/\s+/g, "_");
  const sep = parent.includes("\\") ? "\\" : "/";
  return parent.replace(/[\\/]+$/, "") + sep + (safe || "project");
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

let toastTimer = null;
function toast(message, kind) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.className = "toast " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.add("hidden"), 4200);
}

function showModal(title, bodyHtml, onOk) {
  const modal = document.getElementById("modal");
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-body").innerHTML = bodyHtml;
  const okButton = document.getElementById("modal-ok");
  const cancelButton = document.getElementById("modal-cancel");
  okButton.textContent = onOk ? "OK" : "Close";
  cancelButton.style.display = onOk ? "" : "none";

  const close = () => { modal.classList.add("hidden"); };
  okButton.onclick = async () => { if (onOk) await onOk(); close(); };
  cancelButton.onclick = close;
  modal.classList.remove("hidden");
}

/* A dialog whose own content acts on the model - removing a list, say - has to
   be able to close itself before the screen is redrawn underneath it. */
function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

window.addEventListener("DOMContentLoaded", () => app.start());

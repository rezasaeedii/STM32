"""Rules that only apply to the ``param_table`` format.

The older firmware's table is a flat list of single values.  It has no
structures, no arrays and no boolean type, and nothing in it is logged or
encrypted - so a parameter list that uses any of those is fine in a
``smart_data`` project and wrong in this one.

Every rule here begins by asking the project's format and does nothing at all
unless it is ``param_table``.  That is the whole mechanism behind "the same
list, opened by two projects, is judged by two different sets of rules": the
list is not the thing that changed, the project reading it is.
"""

from __future__ import annotations

from pathlib import Path
from typing import Set

from ...config import FORMAT_PARAM_TABLE
from ...codegen.files.param_table_h import (ADDRESS_TAG, IGNORED_TAGS,
                                             system_of)
from ...errors import DiagnosticCollector, SourceLocation
from ...model.defines import COLUMN_SYSTEM_NAMES
from ...model.parameter_list import ParameterList
from .rule_base import ValidationRule, declared_values, enabled_nodes


class ParamTableRule(ValidationRule):
    """Base class: does nothing unless the project wants a parameter table."""

    @property
    def wanted(self) -> bool:
        return self.config.output.format == FORMAT_PARAM_TABLE


class ParamTableShapeRule(ParamTableRule):
    """No structures and no arrays: every row is one value."""

    rule_id = "PARAM_TABLE_SHAPE"
    description = "The parameter-table format has no structures and no arrays."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        if not self.wanted:
            return

        for parameter in enabled_nodes(model):
            if parameter.is_struct:
                diagnostics.error(
                    "PTB001",
                    f"'{parameter.name}' is a structure, and this project "
                    f"generates a parameter table, which has none.",
                    parameter.source,
                    hint="Every row of the table is one value. Replace the "
                         "structure with one parameter per field, or set "
                         "output.format to 'smart_data' in the project file.")
            elif parameter.array_size > 1:
                diagnostics.error(
                    "PTB002",
                    f"'{parameter.name}' has array size {parameter.array_size}, "
                    f"and a parameter table holds one value per row.",
                    parameter.source,
                    hint=f"Write {parameter.array_size} parameters instead, or "
                         f"set output.format to 'smart_data' in the project "
                         f"file.")


class ParamTableTypeRule(ParamTableRule):
    """The table's type enum has no boolean."""

    rule_id = "PARAM_TABLE_TYPE"
    description = "The parameter-table format has no boolean type."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        if not self.wanted:
            return

        for parameter in declared_values(model):
            value_type = parameter.value_type
            if value_type is not None and value_type.is_bool:
                diagnostics.error(
                    "PTB006",
                    f"'{parameter.name}' is a bool_t, and the parameter table "
                    f"has no boolean type.",
                    parameter.source,
                    hint="Use uint8_t with minimum 0 and maximum 1, which is "
                         "what the table's own rows do.")


#: What to say about each tag that has no column in an ``ADD_PARAM`` row: its
#: diagnostic code, what the tag claims, and what the format actually has.
#: Switching one of them on in a parameter-table project is not an error - the
#: file keeps it, and a smart-data project reading the same list still uses it -
#: but it does nothing here, and silently doing nothing is what a warning is for.
WHAT_IT_MEANS = {
    "ResetProof": ("PTB007", "is marked reset-proof",
                   "a parameter table stores nothing itself"),
    "Loggable": ("PTB003", "is marked loggable",
                 "a parameter table has no log"),
    "LogEncryption": ("PTB004", "is marked log-encrypted",
                      "a parameter table has no log to encrypt"),
}


class ParamTableTagRule(ParamTableRule):
    """Tags the older firmware has nowhere to put."""

    rule_id = "PARAM_TABLE_TAGS"
    description = ("Reset-proof and the logging tags mean nothing in the "
                   "parameter-table format.")

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        if not self.wanted:
            return

        for parameter in declared_values(model):
            for tag_id in IGNORED_TAGS:
                if parameter.tags.get(tag_id) is not True:
                    continue
                code, claim, reality = WHAT_IT_MEANS[tag_id]
                diagnostics.warning(
                    code,
                    f"'{parameter.name}' {claim}, and {reality} - the tag has "
                    f"no column in ADD_PARAM.",
                    parameter.source,
                    hint="Look at the generated file: the tag is nowhere in "
                         "it. It is kept in the parameter list on purpose - a "
                         "project generating smart data from the same file "
                         "does use it - which is why this project shows it "
                         "read-only. To turn it off, open the list in the "
                         "project that uses it.")


class ParamTableSystemRule(ParamTableRule):
    """In this format the file name says which sub-system a list belongs to."""

    rule_id = "PARAM_TABLE_SYSTEM"
    description = "Each list's file name must name a known sub-system."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        if not self.wanted:
            return

        known = {name.upper() for name in model.defines.get(COLUMN_SYSTEM_NAMES)}
        seen: Set[str] = set()
        for path in self.config.inputs.model_files:
            if str(path) in seen:
                continue
            seen.add(str(path))

            system = system_of(path)
            if system in known:
                continue
            diagnostics.error(
                "PTB005",
                f"'{path.name}' does not name a sub-system: '{system}' is not "
                f"in the 'SYSTEM NAMES' list.",
                SourceLocation(file=str(path)),
                hint=f"In this format the file name says which sub-system the "
                     f"list is - name it '<system>_paramTable.xml', in any "
                     f"case. Known: {', '.join(sorted(known)) or 'none'}.")

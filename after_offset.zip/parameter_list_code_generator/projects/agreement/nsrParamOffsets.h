/**
  ******************************************************************************
  * @file    nsrParamOffsets.h
  * @brief   Where each parameter sits in memory - a note, not code.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v1.0.0
  * Generated at   : 2026-09-12 07:35:29 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\parameter_list_code_generator\projects\agreement\sys_gs_manager_paramTable.xml
  *                   C:\Users\Admin\Desktop\com\parameter_list_code_generator\projects\agreement\sys_rhs_paramTable.xml
  * Parameters     : 5 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 Fds.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/*
  Every line of this file is a comment: including it compiles to
  nothing.  It is here to be read.

  The values of one sub-system are laid out one after another, so a
  parameter's offset is the sum of the sizes of the ones above it in
  its own sub-system.  Each sub-system starts again at 0, the same way
  the index column of nsrParamTables.h does.

  A DISABLED parameter is not here and is not in the table either: it
  takes no index and no byte, so switching one off moves the index and
  the offset of everything after it in its sub-system.

  No padding is added between values: the offsets are a plain running
  total of the sizes.
*/

/* ---- SYS_GS_MANAGER -------------------------------------------------
     index  offset  size     type  parameter
         0       0     1  uint8_t  PR_GSM_TABLE_NUM
         1       1     1   int8_t  PR_GSM_PINOUT_TYPE
         2       2     4    float  PR_GSM_INITIAL_LOCK_SIZE

     3 parameter(s), 6 byte(s) in total
*/

/* ---- SYS_RHS --------------------------------------------------------
     index  offset  size     type  parameter
         0       0     8   double  PR_RHS_GAIN
         1       8     1  uint8_t  table

     2 parameter(s), 9 byte(s) in total
*/


# -*- coding: utf-8 -*-
NOTES = {}

NOTES["src/pl_codegen/codegen/__init__.py"] = {"fa": "<p>چند <code>import</code> برای راحتی.</p>", "when": "به‌ندرت."}

NOTES["src/pl_codegen/codegen/literals.py"] = {
 "fa": """<p><b>هر عددی و هر رشته‌ای که در کد C ظاهر می‌شود از این فایل رد شده است.</b> هیچ
جای دیگری عدد را با دست به متن تبدیل نمی‌کند. این تمرکز عمدی است: قواعد لیترالِ C
ریزه‌کاری زیاد دارند و پخش کردنشان در ده فایل یعنی نُه جا اشتباه می‌شود.</p>""",
 "when": "وقتی تایپ تازه‌ای اضافه می‌کنید یا شکل یک لیترال باید عوض شود.",
 "sym": {
  "FLOAT32_DIGITS": "تعداد رقم بامعنایی که یک <code>float</code> را دقیقاً برمی‌گرداند (۹).",
  "FLOAT64_DIGITS": "همان برای <code>double</code> (۱۷).",
  "escape_string": "رشته‌ی C، یا <code>NULL</code> برای خالی. علاوه بر <code>\\\\</code> و <code>\"</code>، کاراکتر <code>?</code> را هم escape می‌کند چون <code>??/</code> در C99 یک «تری‌گراف» است و به <code>\\\\</code> تبدیل می‌شود.",
  "safe_comment": "متن را برای قرار گرفتن داخل <code>/* … */</code> بی‌خطر می‌کند: <code>*/</code> به <code>* /</code> و خط جدید به فاصله.",
  "bool_literal": "<code>TRUE</code> یا <code>FALSE</code>.",
  "unsigned_literal": "عدد با پسوند <code>U</code>.",
  "float_literal": "لیترال اعشاری با پسوند درست؛ کوتاه‌ترین متنی که <b>دقیقاً</b> همان مقدار را برمی‌گرداند.",
  "integer_literal": "لیترال صحیح با پسوند درست، و شکل قابل‌حمل برای منفی‌ترین مقدار یک تایپ علامت‌دار.",
  "numeric_literal": "بر اساس تایپ، یکی از سه تابع بالا را صدا می‌زند؛ سلول خالی مقدار <code>fallback</code> می‌گیرد.",
  "constructor_arguments": "چهار آرگومان <code>fSmartData_XX_Ctor</code>. برای «بازه‌ی غیرفعال» ماکروهای استاندارد (<code>INT32_MIN</code>، <code>-DBL_MAX</code> …) را می‌نویسد نه عدد، و برای <code>Resolution</code>ی خالی از <code>default_resolution</code> همان تایپ استفاده می‌کند.",
  "limit_headers": "هدرهای استانداردی که ماکروهای حدِ این پارامترها لازم دارند. فقط همان‌هایی که واقعاً استفاده شده‌اند — پروژه‌ای بدون پارامتر اعشاری، <code>&lt;float.h&gt;</code> نمی‌گیرد.",
  "tag_value_literal": "مقدار تگ برای فیلد <code>uint32_t Value</code>؛ شناسه‌ی آزاد را <code>(uint32_t)NAME</code> می‌نویسد.",
  "_as_float32": "مقدار را به نزدیک‌ترین <code>float</code> ۳۲ بیتی گِرد می‌کند.",
  "_shortest_exact": "کوتاه‌ترین نمایش اعشاری که دوباره خوانده شود و همان مقدار دربیاید.",
 },
 "after": """<div class="warn">
<b>سه تله‌ای که این فایل برایشان کد دارد</b>
<ol>
  <li><b>گِرد کردن با تعداد رقم اعشار.</b> <code>round(v, 9)</code> برای
      <code>1.602176634e-19</code> صفر می‌دهد و برای <code>2.5e-9</code> عدد
      <code>3.0e-9</code> — بی‌صدا. جایگزینش <code>_shortest_exact()</code> است که چند
      نمایش نامزد می‌سازد، هرکدام را دوباره می‌خواند و فقط آنهایی را نگه می‌دارد که
      دقیقاً همان مقدار را برمی‌گردانند.</li>
  <li><b>منفی‌ترین مقدار.</b> <code>-9223372036854775808LL</code> در C یک لیترال نیست،
      بلکه «منهای» است روی عددی که در <code>long long</code> جا نمی‌شود. شکل درست
      <code>(-9223372036854775807LL - 1)</code> است.</li>
  <li><b>متن کاربر.</b> یک <code>*/</code> در ستون Description کل فایل تولیدی را خراب
      می‌کند، و یک <code>?</code> می‌تواند تری‌گراف بسازد.</li>
</ol>
</div>""",
}

NOTES["src/pl_codegen/codegen/c_style.py"] = {
 "fa": """<p>اسکلت فایل C را از <code>c.json</code> — فایل اسنیپت VS Code شرکت — بیرون
می‌کشد. به‌جای اینکه قالب شرکت در پایتون hard-code شود، از همان فایلی خوانده می‌شود که
خود توسعه‌دهنده‌ها هنگام زدن <code>h-file</code>/<code>c-file</code> در VS Code
می‌گیرند. پس اگر قالب شرکت عوض شود، هیچ کد پایتونی دست نمی‌خورد.</p>
<p>خطوط بخش با یک الگوی منظم شناسایی می‌شوند:</p>
<pre><code>_MARKER = re.compile(r"^\\s*/\\*\\s*(?P&lt;name&gt;[A-Za-z][A-Za-z ]*?)\\s*-{2,}\\s*\\*/\\s*$")</code></pre>
<p>یعنی «خطی که با <code>/*</code> شروع شود، چند حرف داشته باشد، بعد دست‌کم دو خط تیره و
بعد <code>*/</code>». نامِ داخلش همان کلیدی است که <code>marker("Includes")</code> با آن
جست‌وجو می‌کند — پس بخش تازه در قالب شرکت، بدون تغییر پایتون قابل استفاده است.</p>
<p>اگر <code>c.json</code> خوانده نشود، یک نسخه‌ی داخلی از همان قالب به کار می‌رود تا
ابزار همیشه کار کند.</p>""",
 "when": "وقتی قالب فایل‌های C شرکت عوض می‌شود. معمولاً فقط <code>c.json</code> کافی است؛ بعدش <code>run_compile_test.py</code> را بزنید.",
 "sym": {
  "CStyle": "قالب فایل C، خوانده‌شده از اسنیپت شرکت.",
  "CStyle.load": "<code>c.json</code> را می‌خواند و یک <code>CStyle</code> می‌سازد؛ در صورت شکست، قالب پیش‌فرض داخلی.",
  "CStyle.banner_lines": "خطوط بلوک doxygen بالای فایل، با <code>$TM_FILENAME</code> و <code>$CURRENT_YEAR</code> جایگزین‌شده.",
  "CStyle.marker": "یک خط بخش، مثل <code>/* Includes ------- */</code> — عیناً همان رشته‌ای که در <code>c.json</code> است.",
  "CStyle.footer_line": "خط پایانی کپی‌رایت/EOF.",
  "_snippet_body": "بدنه‌ی یک اسنیپت را از ساختار <code>c.json</code> بیرون می‌کشد.",
  "_extract_banner": "بلوک سربرگ را از بدنه‌ی اسنیپت جدا می‌کند.",
 },
}

NOTES["src/pl_codegen/codegen/descriptor_layout.py"] = {
 "fa": """<p>فقط نام و <b>ترتیب</b> فیلدهای <code>sParameterDescriptor</code>. ترتیب اهمیت
دارد: مقداردهی با نام فیلد (<code>.pName = …</code>) در C99 آزاد است ولی در C++20 باید
به همان ترتیب اعلان باشد، و کد تولیدی باید هر دو را راضی کند.</p>""",
 "when": "هر بار که <code>parameter_descriptor.h</code> عوض می‌شود. این فایل باید با آن هماهنگ بماند.",
 "sym": {
  "FIELD_NAME": "نام فیلد <code>pName</code>.", "FIELD_TYPE": "نام فیلد گروه.",
  "FIELD_SMART_DATA": "نام فیلد اشاره‌گر smart data.",
"FIELD_UNIT": "نام فیلد واحد.",
  "FIELD_DESCRIPTION": "نام فیلد توضیحات.",
  "descriptor_field_order": "ترتیب کامل فیلدها، شامل فیلدهای تگ که از <code>TAG_REGISTRY</code> می‌آیند.",
 },
}

NOTES["src/pl_codegen/codegen/blocks/__init__.py"] = {
 "fa": "<p>هر سیزده کلاس بلوک را <code>import</code> می‌کند تا بقیه بنویسند <code>from ..blocks import Comment</code>.</p>",
 "when": "وقتی بلوک تازه‌ای می‌سازید — اسمش را این‌جا اضافه کنید."}

_BLOCK_WHEN = "وقتی سازه‌ی C تازه‌ای لازم دارید یا شکل این یکی باید عوض شود."

NOTES["src/pl_codegen/codegen/blocks/comment.py"] = {
 "fa": "<p>همه‌ی شکل‌های کامنت در فایل‌های تولیدی. <b>هر مسیری که متن کاربر را داخل کامنت می‌گذارد از <code>safe_comment()</code> رد می‌شود</b> — اگر بلوک تازه‌ای اضافه کردید، همین کار را بکنید.</p>",
 "when": _BLOCK_WHEN,
 "sym": {"Comment": "تولیدکننده‌ی کامنت‌ها.",
   "Comment.generate_line": "<code>/* متن */</code> یک‌خطی.",
   "Comment.generate_doc": "بلوک doxygen با <code>@brief</code>، <code>@param</code>، <code>@note</code> و <code>@return</code>.",
   "Comment.generate_separator": "جداکننده‌ی بزرگ پیش از بدنه‌ی توابع در فایل <code>.c</code>.",
   "Comment.generate_block": "بلوک <code>/* … */</code> آزاد، برای جدول‌ها."}}

NOTES["src/pl_codegen/codegen/blocks/include.py"] = {
 "fa": "<p>یک خط <code>#include</code>.</p>", "when": _BLOCK_WHEN,
 "sym": {"Include": "تولیدکننده‌ی <code>#include</code>.",
   "Include.generate": "<code>standard=True</code> ⟵ <code>&lt;stdint.h&gt;</code>؛ وگرنه <code>\"x.h\"</code>."}}

NOTES["src/pl_codegen/codegen/blocks/include_guard.py"] = {
 "fa": "<p>گاردِ <code>#ifndef</code>/<code>#define</code>/<code>#endif</code> هر هدر.</p>", "when": _BLOCK_WHEN,
 "sym": {"IncludeGuard": "تولیدکننده‌ی include guard.",
   "IncludeGuard.generate_begin": "دو خط ابتدای هدر.",
   "IncludeGuard.generate_end": "<code>#endif</code> با کامنت نام گارد."}}

NOTES["src/pl_codegen/codegen/blocks/cpp_guard.py"] = {
 "fa": "<p><code>extern \"C\"</code> تا هدر از C++ هم قابل استفاده باشد. تست کامپایل همین را با <code>g++</code> می‌سنجد.</p>", "when": _BLOCK_WHEN,
 "sym": {"CppGuard": "تولیدکننده‌ی گارد C++.",
   "CppGuard.generate_begin": "<code>#ifdef __cplusplus / extern \"C\" {</code>.",
   "CppGuard.generate_end": "بستن همان بلوک."}}

NOTES["src/pl_codegen/codegen/blocks/define.py"] = {
 "fa": "<p><code>#define</code>، با کامنت اختیاری و ستون‌بندی تا فایل مرتب دربیاید.</p>", "when": _BLOCK_WHEN,
 "sym": {"Define": "تولیدکننده‌ی <code>#define</code>.",
   "Define.generate": "یک <code>#define</code> با مقدار و کامنت اختیاری.",
}}

NOTES["src/pl_codegen/codegen/blocks/enum.py"] = {
 "fa": "<p><code>typedef enum { … } eName;</code> — همان چیزی که از لیست‌های کشویی ساخته می‌شود.</p>", "when": _BLOCK_WHEN,
 "sym": {"Enum": "تولیدکننده‌ی enum.", "Enum.generate": "یک <code>typedef enum</code> کامل با اعضای شماره‌گذاری‌شده."}}

NOTES["src/pl_codegen/codegen/blocks/variable.py"] = {
 "fa": "<p>اعلان (<code>extern</code>) و تعریف متغیرها — همان چیزی که اشیاء smart data با آن نوشته می‌شوند.</p>", "when": _BLOCK_WHEN,
 "sym": {"Variable": "تولیدکننده‌ی متغیرها.",
   "Variable.generate_declaration": "<code>extern sSmartDataU8 X;</code> برای هدر.",
   "Variable.generate_definition": "تعریف واقعی متغیر برای فایل <code>.c</code>."}}

NOTES["src/pl_codegen/codegen/blocks/function.py"] = {
 "fa": "<p>پروتوتایپ و بدنه‌ی توابع، با تورفتگی درست.</p>", "when": _BLOCK_WHEN,
 "sym": {"Function": "تولیدکننده‌ی توابع.",
   "Function.generate_prototype": "یک پروتوتایپ برای هدر.",
   "Function.generate_begin": "امضا و <code>{</code>.",
   "Function.generate_body": "بدنه، با تورفتگی اعمال‌شده روی هر خط.",
   "Function.generate_end": "<code>}</code> پایانی."}}

NOTES["src/pl_codegen/codegen/blocks/file_banner.py"] = {
 "fa": "<p>سربرگ doxygen بالای هر فایل تولیدی؛ متنش از <code>CStyle</code> می‌آید.</p>", "when": _BLOCK_WHEN,
 "sym": {"FileBanner": "تولیدکننده‌ی سربرگ.",
   "FileBanner.generate": "سربرگ کامل با نام فایل، شرح کوتاه و خطوط شناسنامه."}}

NOTES["src/pl_codegen/codegen/blocks/file_footer.py"] = {
 "fa": "<p>آخرین خط هر فایل تولیدی.</p>", "when": _BLOCK_WHEN,
 "sym": {"FileFooter": "تولیدکننده‌ی خط پایانی.", "FileFooter.generate": "خط کپی‌رایت/EOF از <code>CStyle</code>."}}

NOTES["src/pl_codegen/codegen/blocks/section_marker.py"] = {
 "fa": "<p>خطوط <code>/* Private variables ----- */</code> که ساختار فایل شرکت را می‌سازند.</p>", "when": _BLOCK_WHEN,
 "sym": {"SectionMarker": "تولیدکننده‌ی خط بخش.", "SectionMarker.generate": "خط بخش با نام داده‌شده، عیناً از <code>c.json</code>."}}

NOTES["src/pl_codegen/codegen/blocks/table.py"] = {
 "fa": "<p>جدول ASCII، برای کشیدن لیست پارامتر داخل یک بلوک کامنت در <code>cg_parameter_list_table.h</code>.</p>", "when": _BLOCK_WHEN,
 "sym": {"Table": "تولیدکننده‌ی جدول ASCII.", "Table.generate": "جدول با ستون‌های هم‌عرض و سرستون."}}

NOTES["src/pl_codegen/codegen/files/__init__.py"] = {
 "fa": """<p><code>FILE_BUILDERS</code>: فهرست شش سازنده‌ی فایل، <b>به ترتیب تولید</b>.</p>
<div class="ok"><b>افزودن یک فایل خروجی = یک کلاس تازه + یک سطر در این لیست.</b></div>""",
 "when": "وقتی فایل خروجی تازه‌ای می‌خواهید.",
 "sym": {"FILE_BUILDERS": "کلاس‌های سازنده‌ی فایل، به ترتیب اجرا."}}

NOTES["src/pl_codegen/codegen/files/file_builder.py"] = {
 "fa": """<p>کلاس پایه‌ی هر شش سازنده. سه کار می‌کند و نه بیشتر: مدل و کانفیگ و آفست‌ها را
در دسترس نگه می‌دارد، از هر کلاس بلوک یک نمونه می‌سازد
(<code>self.include</code>، <code>self.comment</code>، …)، و متن حاصل از
<code>generate()</code> را ذخیره می‌کند.</p>
<p>کمک‌متدهایش نام فایل‌ها و شناسه‌ها را می‌دهند تا <b>هیچ سازنده‌ای خودش اسم نسازد</b>.</p>""",
 "when": "وقتی همه‌ی سازنده‌ها به امکان تازه‌ای نیاز دارند.",
 "sym": {
  "FileBuilder": "کلاس پایه‌ی هر فایل تولیدی.",
  "FileBuilder.file_name": "نام فایل تولیدی — هر سازنده باید بنویسدش.",
  "FileBuilder.generate": "متن کامل فایل — هر سازنده باید بنویسدش.",
  "FileBuilder.save": "متن را در پوشه‌ی مقصد می‌نویسد (با <code>newline=\"\\n\"</code> تا روی ویندوز هم یکسان باشد).",
  "FileBuilder.parameters": "پارامترهای فعال، به ترتیب ویرایشگر.",
  "FileBuilder.guard_name": "نام include guard این فایل.",
  "FileBuilder.generation_notes": "خطوط «شناسنامه» سربرگ: نام ابزار، نسخه، زمان، فایل‌های ورودی، تعداد پارامترها. فایل‌های ورودی با <code>relative_to_root()</code> از ریشه‌ی پروژه نوشته می‌شوند، نه با مسیر کامل این ماشین — وگرنه همان تولید روی ماشین دیگر همه‌ی فایل‌ها را در git عوض می‌کرد.",
  "FileBuilder.defines_header": "نام فایل هدر defines.",
  "FileBuilder.list_header": "نام هدر اصلی لیست.",
  "FileBuilder.list_source": "نام فایل <code>.c</code> اصلی.",
  "FileBuilder.table_header": "نام هدر جدول ASCII.",
  "FileBuilder.smart_data_header": "نام هدر smart data تولیدی.",
  "FileBuilder.smart_data_source": "نام فایل <code>.c</code> smart data.",
  "FileBuilder.index_of": "ماکروی ایندکس یک پارامتر.",
  "FileBuilder.array_size_of": "ماکروی سایز آرایه. سایز آرایه فقط به شکل همین ماکرو تولید می‌شود؛ در جدول descriptor فیلدی برایش نیست، چون هر ردیف دقیقاً یک مقدار است.",
  "FileBuilder.smart_data_of": "نام شیء smart data.",
  "FileBuilder.offset_of": "ماکروی آفست یک زوج «تگ + پارامتر».",
  "FileBuilder.offset_total_of": "ماکروی مجموع بایت‌های یک تگ.",
  "FileBuilder.unit_of": "واحد پارامتر — همیشه یک رشته، هیچ‌وقت <code>None</code>. سلول خالی <code>\"\"</code> می‌شود، نه <code>NULL</code>.",
  "FileBuilder.description_of": "توضیح پارامتر — همان قاعده: رشته‌ی خالی به‌جای <code>NULL</code>.",
  "FileBuilder.tag_size_function_of": "نام تابع گتر اندازه‌ی یک تگ.",
  "FileBuilder.sized_tags": "تگ‌هایی که دست‌کم یک پارامتر فعال حملشان می‌کند. تگ بی‌استفاده گتر نمی‌گیرد.",
  "FileBuilder.quantity": "ماکروی تعداد پارامترها.",
  "FileBuilder.descriptor_symbol": "نام آرایه‌ی descriptor.",
 },
}

_FILES_WHEN = "وقتی محتوای این فایل تولیدی باید عوض شود. <code>generate()</code> را از بالا تا پایین بخوانید — همان چیزی است که تولید می‌شود."

NOTES["src/pl_codegen/codegen/files/parameter_list_defines_h.py"] = {
 "fa": "<p><code>cg_parameter_list_defines.h</code>: ماکروهای ایندکس، سایز آرایه، آفست‌ها و مجموع‌ها، به‌علاوه‌ی <code>enum</code>هایی که از لیست‌های کشویی ساخته می‌شوند.</p>",
 "when": _FILES_WHEN,
 "sym": {"ParameterListDefinesHeader": "سازنده‌ی هدر ماکروها و enumها.",
   "ParameterListDefinesHeader.file_name": "نام فایل تولیدی.",
   "ParameterListDefinesHeader.generate": "فایل را از بالا تا پایین می‌نویسد."}}

NOTES["src/pl_codegen/codegen/files/smart_data_h.py"] = {
 "fa": "<p><code>cg_smart_data.h</code>: اعلان <code>extern</code> هر شیء smart data و پروتوتایپ <code>fCgSmartData_Init()</code>.</p>",
 "when": _FILES_WHEN,
 "sym": {"SmartDataHeader": "سازنده‌ی هدر smart data.",
   "SmartDataHeader.file_name": "نام فایل تولیدی.", "SmartDataHeader.generate": "فایل را می‌نویسد.",
   "INIT_FUNCTION": "نام تابع مقداردهی اولیه‌ی smart data — از این‌جا import می‌شود تا در دو فایل یکسان بماند."}}

NOTES["src/pl_codegen/codegen/files/smart_data_c.py"] = {
 "fa": "<p><code>cg_smart_data.c</code>: تعریف واقعی اشیاء، و تابع <code>fCgSmartData_Init()</code> که همه‌ی سازنده‌ها را صدا می‌زند و اولین خطا را برمی‌گرداند. پارامترهای آرایه‌ای در یک حلقه ساخته می‌شوند.</p>",
 "when": _FILES_WHEN,
 "sym": {"SmartDataSource": "سازنده‌ی فایل <code>.c</code> smart data.",
   "SmartDataSource.file_name": "نام فایل تولیدی.", "SmartDataSource.generate": "فایل را می‌نویسد."}}

NOTES["src/pl_codegen/codegen/files/parameter_list_h.py"] = {
 "fa": "<p><code>cg_parameter_list.h</code>: پروتوتایپ پنج تابع صادرشده و اعلان جدول descriptor.</p>",
 "when": _FILES_WHEN,
 "sym": {"ParameterListHeader": "سازنده‌ی هدر اصلی.",
   "ParameterListHeader.file_name": "نام فایل تولیدی.", "ParameterListHeader.generate": "فایل را می‌نویسد.",
   "DESCRIPTOR_TYPE": "نوع برگشتی توابع جست‌وجو.",
   "INIT_FUNCTION": "نام تابع <code>fParameterList_Init</code>.",
   "INIT_CALLBACK": "نام هوک ضعیفِ پس از مقداردهی اولیه.",
   "GET_QUANTITY_FUNCTION": "نام تابع تعداد.",
   "GET_BY_INDEX_FUNCTION": "نام تابع جست‌وجو با ایندکس.",
   "GET_BY_NAME_FUNCTION": "نام تابع جست‌وجو با نام.",
   "WEAK_MACRO": "ماکروی <code>weak</code> که هوک با آن تعریف می‌شود."}}

NOTES["src/pl_codegen/codegen/files/parameter_list_c.py"] = {
 "fa": """<p><code>cg_parameter_list.c</code>: جدول <code>const</code> descriptor و بدنه‌ی پنج
تابع. مهم‌ترین قسمتش <code>_table_entry()</code> است که یک ردیف جدول را می‌سازد و روی
<code>TAG_REGISTRY</code> حلقه می‌زند — برای همین افزودن یک تگ، این فایل را عوض
نمی‌کند.</p>""",
 "when": _FILES_WHEN,
 "sym": {"ParameterListSource": "سازنده‌ی فایل <code>.c</code> اصلی.",
   "ParameterListSource.file_name": "نام فایل تولیدی.",
   "ParameterListSource.generate": "فایل را از بالا تا پایین می‌نویسد.",
   "ParameterListSource._generate_extra_includes": "هدرهای <code>codegen.extra_includes</code>؛ لازم وقتی یک تگ آزاد مقدارش یک ماکروی اپلیکیشن است.",
   "ParameterListSource._generate_table": "کل جدول <code>const sParameterDescriptor[]</code>.",
   "ParameterListSource._table_entry": "مقداردهی‌های یک ردیف، <b>به ترتیب اعلان</b> — چون C++20 ترتیب را الزام می‌کند.",
   "ParameterListSource._generate_init": "بدنه‌ی <code>fParameterList_Init()</code>.",
   "ParameterListSource._generate_init_callback": "هوک ضعیف پس از مقداردهی اولیه.",
   "ParameterListSource._generate_get_quantity": "بدنه‌ی تابع تعداد.",
   "ParameterListSource._generate_get_by_index": "جست‌وجو با ایندکس، با چک محدوده.",
   "ParameterListSource._generate_get_by_name": "جست‌وجو با نام، با <code>strcmp</code>.",
   "ParameterListSource._generate_tag_sizes": "یک تابع <code>fParameterList_GetXxxSize()</code> برای هر تگ استفاده‌شده، که ماکروی مجموع همان تگ را برمی‌گرداند.",
   "BRIEF": "شرح کوتاهی که در سربرگ فایل می‌آید."}}

NOTES["src/pl_codegen/codegen/files/parameter_list_table_h.py"] = {
 "fa": "<p><code>cg_parameter_list_table.h</code>: تصویر لیست پارامتر به‌صورت یک جدول ASCII داخل کامنت. کد اجرایی ندارد؛ هست تا کسی که فرم‌ور را می‌خواند بدون باز کردن ویرایشگر بفهمد چه چیزی تعریف شده.</p>",
 "when": _FILES_WHEN,
 "sym": {"ParameterListTableHeader": "سازنده‌ی هدر جدول ASCII.",
   "ParameterListTableHeader.file_name": "نام فایل تولیدی.",
   "ParameterListTableHeader.generate": "جدول را می‌سازد و در کامنت می‌گذارد."}}

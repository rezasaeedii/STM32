# -*- coding: utf-8 -*-
NOTES = {}

NOTES["src/pl_codegen/model/__init__.py"] = {
 "fa": "<p>فقط چند <code>import</code> تا بقیه‌ی کد بتواند بنویسد <code>from ..model import Parameter</code> به‌جای مسیر کامل.</p>",
 "when": "وقتی کلاس تازه‌ای به مدل اضافه می‌کنید و می‌خواهید از خود پکیج قابل import باشد.",
}

NOTES["src/pl_codegen/model/types.py"] = {
 "fa": """<p>رجیستری یازده تایپ پشتیبانی‌شده. هر تایپ یک <code>CValueType</code> است و
<b>همه‌چیزِ</b> آن تایپ از همین یک ورودی مشتق می‌شود: نام ساختار smart data، نام سازنده،
اندازه به بایت (که آفست تگ‌ها را تعیین می‌کند — و نه تعداد شناسه‌های لاگ؛ آن‌ها مقدار می‌شمارند نه بایت)، بازه‌ی طبیعی و پسوند لیترال.</p>
<p>به همین دلیل افزودن یک تایپ تازه فقط یک سطر است — نه گشتن در ده فایل.</p>""",
 "when": "وقتی ماژول smart data تایپ تازه‌ای اضافه می‌کند. یک ورودی به <code>VALUE_TYPES</code> بدهید و نامش را در لیست کشویی <code>TYPES</code> بنویسید.",
 "sym": {
  "VALUE_TYPES": "نگاشت «نام C ⟵ توصیف تایپ». منبع حقیقت برای همه‌ی تایپ‌ها.",
  "TYPE_ALIASES": "نام‌های مستعار پذیرفته‌شده: <code>u8</code>، <code>float</code>، <code>double</code>، <code>bool</code> و مانند آن.",
  "CValueType": "هرچه ابزار درباره‌ی یک تایپ C باید بداند.",
  "CValueType.c_name": "نام تایپ در C، مثل <code>uint16_t</code>.",
  "CValueType.suffix": "پسوند smart data، مثل <code>U16</code> — نام ساختار و سازنده از این ساخته می‌شود.",
  "CValueType.kind": "دسته: <code>int</code> / <code>float</code> / <code>bool</code>.",
  "CValueType.signed": "علامت‌دار بودن.",
  "CValueType.bits": "تعداد بیت.",
  "CValueType.literal_suffix": "پسوند لیترال C: <code>U</code>، <code>LL</code>، <code>F</code> و … .",
  "CValueType.native_min": "کمینه‌ی طبیعی تایپ، به‌صورت عدد (برای اعتبارسنجی).",
  "CValueType.limit_min_macro": "نام ماکروی استاندارد همان کمینه در C: <code>INT32_MIN</code>، <code>0U</code>، <code>-DBL_MAX</code> و … . برای «بازه‌ی غیرفعال» <b>این</b> در کد نوشته می‌شود، نه عدد.",
  "CValueType.limit_max_macro": "نام ماکروی بیشینه: <code>UINT16_MAX</code>، <code>FLT_MAX</code> و … .",
  "CValueType.limit_header": "هدری که آن ماکروها را تعریف می‌کند: <code>stdint.h</code> یا <code>float.h</code>.",
  "CValueType.default_resolution": "گامی که وقتی کاربر <code>Resolution</code> را خالی بگذارد به‌کار می‌رود: ۱ برای صحیح، <code>0.001</code> برای <code>float32_t</code> و <code>0.000001</code> برای <code>float64_t</code>.",
  "CValueType.has_limit_macros": "آیا این تایپ ماکروی حد استاندارد دارد (بولین ندارد).",
  "CValueType.native_max": "بیشینه‌ی طبیعی تایپ.",
  "CValueType.smart_data_struct": "نام ساختار، مثل <code>sSmartDataU16</code>.",
  "CValueType.constructor": "نام سازنده، مثل <code>fSmartData_U16_Ctor</code>.",
  "CValueType.enum_name": "نام عضو enum تایپ در کد تولیدی.",
  "CValueType.value_size": "اندازه‌ی <b>مقدار</b> به بایت. مبنای محاسبه‌ی آفست تگ‌هاست و <b>بس</b> — تعداد شناسه‌های لاگِ رزروشده به تایپ کاری ندارد.",
  "CValueType.has_range": "آیا این تایپ min/max/resolution دارد — برای <code>bool_t</code> نه.",
  "CValueType.is_float": "آیا اعشاری است.",
  "CValueType.is_bool": "آیا بولین است.",
  "resolve_value_type": "نام تایپ (با هر املای پذیرفته‌شده) را به <code>CValueType</code> نگاشت می‌کند؛ برای نام ناشناس <code>None</code>.",
  "supported_type_names": "فهرست نام تایپ‌ها با کاما — برای متن پیام‌های خطا.",
  "_int": "سازنده‌ی کمکی که یک تایپ صحیح را با بازه‌ی طبیعی درست می‌سازد.",
 },
}

NOTES["src/pl_codegen/model/tags.py"] = {
 "fa": """<p>رجیستری تگ‌ها. مهم‌ترین فیلد هر <code>TagSpec</code>، فیلد
<code>descriptor_field</code> است: نام فیلد متناظر در
<code>sParameterDescriptor</code>. همین است که تولید کد را <b>داده‌محور</b> می‌کند —
حلقه‌ی نوشتن جدول descriptor روی <code>TAG_REGISTRY</code> می‌چرخد و هیچ نام تگی در
کد تولیدکننده hard-code نشده.</p>
<p><b>شناسه‌ی لاگ در این رجیستری نیست</b> و عمداً هم نیست: تگ نیست، چون نه ناحیه‌ی
آفست دارد و نه جفت <code>{Value, MemoryOffset}</code>. یک <code>uint16_t</code> ساده
در شناسنامه است و روی <code>Parameter.log_id</code> می‌نشیند، نه داخل
<code>Parameter.tags</code>.</p>""",
 "when": "وقتی تگ تازه‌ای اضافه می‌شود. سناریوی کاملش در فصل «افزودن یک تگ» آمده.",
 "sym": {
  "TAG_REGISTRY": "فهرست مرتبِ تگ‌ها. ترتیبش همان ترتیب فیلدهای تگ در descriptor است. <b>LogID اینجا نیست</b> — تگ نیست، چون نه ناحیه‌ی آفست دارد و نه جفت <code>{Value, MemoryOffset}</code>؛ یک <code>uint16_t</code> ساده در شناسنامه است.",
  "TAGS_BY_ID": "نگاشت «شناسه‌ی تگ ⟵ TagSpec» برای جست‌وجوی سریع.",
  
  "LOG_ID_FIELD": "نام فیلد شناسه‌ی لاگ در descriptor. تنها فیلدی است که پیشوند <code>Tag</code> نمی‌گیرد، چون تگ نیست.",
  "LOG_ID_LABEL": "چیزی که ویرایشگر شناسه‌ی لاگ را با آن صدا می‌زند.",
  "LOGGABLE_TAG": "شناسه‌ی تگ Loggable — همانی که معنادار بودن شناسه‌ی لاگ را تعیین می‌کند.",
  "TagKind": "شکل نوشته شدن مقدار یک تگ.",
  "TagKind.BOOLEAN": "TRUE/FALSE.",
  "TagKind.ENUM": "یکی از مقادیر یک لیست کشویی.",
    "TagKind.FREE": "عدد یا یک شناسه‌ی C دلخواه (تگ‌های آزاد).",
  "TagSpec": "توصیف ایستای یک تگ.",
  "TagSpec.tag_id": "شناسه‌ی داخلی تگ؛ در XML هم همین می‌آید.",
  "TagSpec.descriptor_field": "نام فیلد متناظر در <code>sParameterDescriptor</code>.",
  "TagSpec.kind": "نوع مقدار (<code>TagKind</code>).",
  "TagSpec.mandatory": "آیا پر کردنش اجباری است.",
  "TagSpec.defines_column": "برای تگ enum: کدام لیست کشویی مقادیر مجازش را دارد.",
  "TagSpec.description": "توضیح یک‌خطی، برای پیام‌ها و مستندات.",
  "TagSpec.is_boolean": "میان‌بر برای <code>kind is TagKind.BOOLEAN</code>.",
  "mandatory_tags": "فقط تگ‌های اجباری.",
  "optional_tags": "فقط تگ‌های اختیاری.",
 },
}

NOTES["src/pl_codegen/model/defines.py"] = {
 "fa": """<p>لیست‌های کشویی به شکل یک دیکشنریِ «نام لیست ⟵ فهرست مقادیر»، با
<code>merge()</code> برای وقتی که چند لیست پارامتر با هم ادغام می‌شوند.</p>
<p><code>GENERATED_ENUMS</code> می‌گوید کدام ستون‌ها واقعاً به <code>enum</code> C تبدیل
می‌شوند. همین ثابت است که <code>DefinesSheetRule</code> بر اساسش مقادیر را به‌عنوان
شناسه‌ی C اعتبارسنجی می‌کند.</p>""",
 "when": "وقتی لیست کشویی تازه‌ای قرار است به enum تبدیل شود.",
 "sym": {
  "COLUMN_TYPES": "نام لیست کشویی گروه‌ها.",
  "COLUMN_VALUE_TYPES": "نام ستون تایپ‌ها.",
  "COLUMN_SYSTEM_NAMES": "نام ستون نام زیرسیستم‌ها.",
  "COLUMN_PARAM_MODES": "نام ستون حالت‌های دسترسی.",
  "GENERATED_ENUMS": "«ستون ⟵ نام enum تولیدی». فقط این ستون‌ها به کد C تبدیل می‌شوند.",
  "Defines": "مقادیر مجاز جمع‌آوری‌شده از لیست‌های کشویی همه‌ی لیست‌های پارامتر.",
  "Defines.values": "دیکشنری «ستون ⟵ فهرست مقادیر».",
  "Defines.add": "یک مقدار به یک ستون اضافه می‌کند؛ تکراری را دور می‌ریزد.",
  "Defines.get": "فهرست مقادیر یک ستون (خالی اگر نبود).",
  "Defines.contains": "آیا این مقدار در آن ستون هست — مبنای چک تگ‌های enum.",
  "Defines.merge": "لیست‌های کشویی یک لیست پارامتر دیگر را با این یکی ادغام می‌کند.",
  "Defines.groups": "میان‌بر به مقادیر ستون GROUP.",
  "Defines.types": "میان‌بر به ستون TYPES.",
  "Defines.system_names": "میان‌بر به ستون SYSTEM NAMES.",
  "Defines.param_modes": "میان‌بر به ستون PARAM MODES.",
  "type_enum_member": "<code>MONITORING</code> ⟵ <code>ePARAMETER_TYPE_MONITORING</code>، مطابق <code>parameter_descriptor.h</code>.",
 },
}

NOTES["src/pl_codegen/model/parameter.py"] = {
 "fa": """<p>کلاس <code>Parameter</code> — یک گره‌ی درخت پارامترها، به‌علاوه‌ی
<code>tags</code> (دیکشنری) و <code>source</code> (مکان در فایل، برای پیام‌ها).</p>
<p>مهم‌ترین چیز در این فایل، تفاوت میان مقدارِ <b>نوشته‌شده</b> و مقدارِ <b>مؤثر</b> است.
سه <code>@property</code> این تفاوت را پیاده می‌کنند و بقیه‌ی ابزار باید همیشه نسخه‌ی
مؤثر را بخواند.</p>""",
 "when": "وقتی فیلد تازه‌ای به پارامتر اضافه می‌کنید، یا قاعده‌ی «مقدار مؤثر» عوض می‌شود.",
 "sym": {
  "TagValue": "چیزی که یک تگ می‌تواند نگه دارد: bool، int، str یا None.",
  "NumericValue": "مقدار عددی یک پارامتر: int، float، bool یا None.",
  "Parameter": "یک گره‌ی درخت پارامترها — یک مقدار یا یک استراکچر.",
  "Parameter.name": "نام پارامتر؛ باید شناسه‌ی معتبر C و در همه‌ی لیست‌های پارامتر یکتا باشد.",
  "Parameter.enable": "<code>False</code> یعنی این ردیف کلاً از تولید کد حذف می‌شود.",
  "Parameter.gs_name": "نامی که کاربر می‌بیند — در ایستگاه زمینی، لاگ و سندها.",
  "Parameter.address": "ستون آدرسِ جدول پارامتر؛ ۰ یعنی خودکار. در هر دو فرمت در XML نوشته می‌شود.",
  "Parameter.param_type": "گروه؛ به <code>eParameterType</code> تبدیل می‌شود.",
  "Parameter.value_type_name": "نام تایپ همان‌طور که کاربر انتخابش کرده (هنوز حل‌نشده).",
  "Parameter.array_size": "۱ یعنی اسکالر؛ بیشتر یعنی آرایه. این عدد مالِ <b>اعلان</b> است: بعد از <code>flatten()</code> هر عنصر یک برگِ مستقل با <code>array_size = 1</code> می‌شود، و تعداد اعلان در <code>declared_array_size</code> می‌ماند.",
  "Parameter.element_index": "این برگ چندمین عنصر اعلان است، یا <code>None</code> برای یک اسکالر. همین است که <code>Cg_SmartData_PosDrone</code> را به <code>...PosDrone[2]</code> تبدیل می‌کند.",
  "Parameter.declared_array_size": "اعلانی که این برگ از آن آمده چند عنصر داشت. همه‌ی عنصرهای یک اعلان همین عدد را گزارش می‌کنند — سایز آرایه مالِ اعلان است، نه مقدار.",
  "Parameter.default_value": "مقدار اولیه.",
  "Parameter.minimum": "کمینه‌ی <b>نوشته‌شده</b> — نه لزوماً آنچه در کد می‌آید.",
  "Parameter.maximum": "بیشینه‌ی نوشته‌شده.",
  "Parameter.resolution": "گام تغییر مقدار.",
  "Parameter.unit": "رشته‌ی واحد.",
  "Parameter.tags": "دیکشنری «شناسه‌ی تگ ⟵ مقدار».",
  "Parameter.description": "متن آزاد. متنِ <b>اعلان</b>: هر مقداری که توضیحِ خودش را نداشته باشد همین را می‌گیرد. در ویرایشگر روی سطرِ بدونِ کروشه نوشته می‌شود، و عنصرهایی که متنِ خودشان را دارند با عوض شدنش دست نمی‌خورند.",
  "Parameter.element_descriptions": "توضیحاتی که مالِ <b>یک مقدار</b>اند نه مالِ اعلان، با کلیدِ «مسیرِ عنصر»: <code>3</code> یعنی <code>Speed[3]</code>، <code>1</code> یعنی <code>Wheels[1].Speed</code> و <code>1.5</code> یعنی <code>Wheels[1].Samples[5]</code>. ایندکس است و نه نام، پس تغییر نامِ پارامتر آن‌ها را بی‌صاحب نمی‌کند.",
  "Parameter.description_at": "توضیحِ مقداری که در آن مسیرِ عنصر است: مالِ خودش اگر داشته باشد، وگرنه <code>description</code>ِ اعلان. <code>flatten()</code> همین را روی هر برگ می‌گذارد.",
  "element_key": "ایندکس‌هایی را که <code>_collect()</code> پیموده به «مسیرِ عنصر» تبدیل می‌کند — کلیدِ <code>element_descriptions</code>.",
  "Parameter.source": "لیست پارامتری که این گره از آن آمده.",
  "Parameter.value_type": "<code>CValueType</code>ی حل‌شده از <code>value_type_name</code>؛ <code>None</code> اگر تایپ ناشناس باشد.",
  "Parameter.is_array": "<code>array_size &gt; 1</code>.",
  "Parameter.range_disabled": "هر دو حد صفر یا خالی ⟵ «این پارامتر بازه‌ی محدودکننده ندارد».",
  "Parameter.effective_minimum": "کمینه‌ای که <b>واقعاً</b> به سازنده‌ی C داده می‌شود: بازه‌ی طبیعی تایپ اگر بازه غیرفعال باشد، وگرنه مقدار سلول (و خانه‌ی خالی = صفر).",
  "Parameter.effective_maximum": "همان برای بیشینه.",
  "Parameter._effective_limit": "پیاده‌سازی مشترک دو مورد بالا.",
  "Parameter.tag": "مقدار خام یک تگ، همان‌طور که در سلول بود.",
  "Parameter.effective_tag": "مقدار تگ آن‌طور که <b>کد تولیدی</b> می‌بیند.",
  "Parameter.log_id": "شناسه‌ی لاگ. تگ نیست: در descriptor یک <code>uint16_t</code> ساده است و ناحیه‌ی آفست ندارد.",
  "Parameter.effective_log_id": "شناسه‌ی لاگ آن‌طور که <b>کد تولیدی</b> می‌بیند: اگر <code>Tag Loggable</code> برقرار نباشد <code>None</code> برمی‌گردد، و ابزار در جدول <code>0</code> می‌نویسد.",
  "Parameter.has_active_tag": "آیا این پارامتر آن تگ را «حمل می‌کند» — همانی که تعیین می‌کند در ناحیه‌ی آفست آن تگ جا بگیرد یا نه.",
  "_is_zero_or_empty": "سلول خالی و صفر برای یک حد، یک معنی دارند.",
 },
 "after": """<div class="warn">
<b>چرا <code>effective_minimum</code> جدا از <code>minimum</code> است</b>
<p>
<code>fSmartData_XX_Ctor</code> همیشه مقدار پیش‌فرض را با دو حدی که می‌گیرد مقایسه
می‌کند و راهی برای گفتن «بازه ندارم» ندارد. اگر <code>0, 0</code> بنویسیم، هر پارامتری با
مقدار پیش‌فرض غیرصفر در <b>زمان اجرا</b> رد می‌شود و
<code>fParameterList_Init()</code> شکست می‌خورد — بدون اینکه هیچ‌کجای کد پایتون خطایی
داده باشد. پس «بازه‌ی غیرفعال» در لحظه‌ی تولید لیترال به بازه‌ی کامل تایپ ترجمه می‌شود.
</p>
<p class="small">
<b>قاعده:</b> هر کد تازه‌ای که حدها را می‌خواند باید از <code>effective_*</code>
استفاده کند، نه از <code>minimum</code>/<code>maximum</code> خام.
</p>
</div>
<div class="warn">
<b><code>bool</code> در پایتون زیرکلاس <code>int</code> است</b>
<p>
<code>isinstance(False, int)</code> برابر <code>True</code> است. در
<code>has_active_tag()</code> اول <code>bool</code> چک می‌شود و بعد <code>int</code>؛
اگر ترتیب برعکس شود، یک تگ بولینِ <code>FALSE</code> مثل «عدد صفر» تفسیر می‌شود و
«تگ فعال» به حساب می‌آید. به همین دلیل عدد <code>0</code> یک مقدار enum کاملاً
معتبر است، ولی <code>FALSE</code> یعنی «تگ را ندارد».
</p>
</div>""",
}

NOTES["src/pl_codegen/model/parameter_list.py"] = {
 "fa": """<p>ظرف نهایی: فهرست <code>Parameter</code>ها به‌علاوه‌ی <code>Defines</code> و فهرست
فایل‌های منبع. چند لیست پارامتر این‌جا به یک لیست واحد تبدیل می‌شوند.</p>
<p><code>enabled</code> و <code>disabled</code> دو <code>@property</code>اند و
<b>ترتیب ویرایشگر را حفظ می‌کنند</b> — همان ترتیبی که ایندکس‌های C از آن ساخته می‌شود،
پس جابه‌جا کردن دو پارامتر در ویرایشگر یعنی جابه‌جا شدن دو ایندکس در فرم‌ور.</p>""",
 "when": "وقتی به یک نمای تازه از کل لیست نیاز دارید (مثلاً «همه‌ی پارامترهای آرایه‌ای»).",
 "sym": {
  "ParameterList.struct_types_in_use": "تایپ‌های استراکچریِ در حال استفاده، هرکدام یک بار و درونی اول — برای هرکدام یک typedef.",
  "ParameterList.structures_by_type": "هر تایپ ⟵ استراکچرهای فعالِ آن تایپ.",
  "ParameterList.array_declarations": "هر اعلانِ آرایه: آرایه‌ی خودِ یک پارامتر، یا فیلدِ آرایه‌ایِ یک تایپ که مالِ همان تایپ است.",
  "ParameterList": "همه‌ی پارامترهای همه‌ی لیست‌ها، به‌عنوان یک لیست واحد.",
  "ParameterList.parameters": "همه‌ی پارامترها، فعال و غیرفعال، به ترتیب ویرایشگر.",
  "ParameterList.defines": "لیست‌های کشویی ادغام‌شده.",
  "ParameterList.source_files": "فهرست فایل‌های ورودی؛ در سربرگ فایل‌های تولیدی می‌آید. در حافظه مسیر کامل‌اند؛ در سربرگ‌ها و در full parameter list از ریشه‌ی پروژه نوشته می‌شوند.",
  "ParameterList.generator_version": "نسخه‌ی ابزاری که این مدل را ساخته.",
  "ParameterList.generated_at": "زمان ساخت مدل (اگر <code>emit_timestamp</code> روشن باشد).",
  "ParameterList.add": "یک پارامتر به لیست اضافه می‌کند.",
  "ParameterList.enabled": "پارامترهایی که در تولید کد شرکت می‌کنند، به ترتیب ویرایشگر.",
  "ParameterList.disabled": "ردیف‌های <code>Enable = FALSE</code>؛ فقط برای گزارش.",
  "ParameterList.index_of": "ایندکس یک پارامتر بر اساس نامش — همان عددی که ماکروی ایندکس می‌گیرد.",
  "ParameterList.by_name": "دیکشنری «نام ⟵ پارامتر» برای جست‌وجوی سریع.",
  "ParameterList.used_data_type_suffixes": "پسوندهای smart data که واقعاً استفاده شده‌اند؛ به تولیدکننده می‌گوید کدام سازنده‌ها لازم است.",
 },
 "after": """<div class="warn">
<b>یک توضیح برای هر <i>مقدار</i>، نه برای هر اعلان</b>
<p>
<code>flatten()</code> جایی است که این حل می‌شود، چون همان پاسی است که جدول تولیدی از
رویش نوشته می‌شود. <code>_collect()</code> ایندکس‌هایی را که می‌پیماید با خودش
پایین می‌برد — و فقط ایندکسِ آرایه‌های <b>واقعی</b> را، یعنی جایی که
<code>array_size &gt; 1</code> است — و برای هر برگ
<code>description_at(indices)</code> را صدا می‌زند. پس <code>Speed[3]</code> می‌تواند
متنِ خودش را داشته باشد در حالی که بقیه متنِ اعلان را می‌گیرند، و هیچ‌کدام از
مصرف‌کننده‌های پایین‌دست عوض نشدند: <code>parameter_list_c.py</code> از قبل هم
به‌ازای هر مقدار <code>description_of(leaf)</code> را می‌خواند.
</p>
<p class="small">
<code>struct_sync._apply_field()</code> نیمه‌ی خودِ پارامتر را دست نمی‌زند، پس
توضیحاتِ عنصرهای یک فیلد از اعمالِ دوباره‌ی تایپ جان سالم به در می‌برند — همین است
که حالتِ استراکچری را کار می‌اندازد.
</p>
</div>""",
}

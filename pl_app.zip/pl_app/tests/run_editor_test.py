"""Tests of the editor: the half of the tool that a person actually clicks.

Everything here goes through :class:`pl_gui.api.Api`, which is exactly what the
browser calls, so a test passing here means the button in the toolbar works.
The whole thing runs on a *copy* of the project in a temporary folder, so it can
create files, rewrite the configuration and reorder the build without ever
touching the project the user is working in.

Run it with::

    python tests/run_editor_test.py
"""

from __future__ import annotations

import ast
import copy
import os
import shutil
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable, List, Tuple

#: The app folder: the editor, the generator, the templates, the manuals.
APP_DIR = Path(__file__).resolve().parent.parent
#: The folder holding pl_app/ and the projects, for the whole-tree scans.
ROOT_DIR = APP_DIR.parent
sys.path.insert(0, str(APP_DIR / "src"))

from pl_codegen.config import Config          # noqa: E402
from pl_codegen.errors import DiagnosticCollector          # noqa: E402
from pl_codegen.xml_model.xml_reader import read_xml       # noqa: E402
from pl_codegen.xml_model.xml_writer import write_xml      # noqa: E402
from pl_codegen.logging_utils import (BOLD, BRIGHT_RED, GREEN,  # noqa: E402
                                            colour_supported, paint)
import pl_codegen.logging_utils as _logging_utils  # noqa: E402
from pl_codegen.app_home import (LEGACY_PROJECT_FILE_NAME, LIB_TEMPLATE_DIR,
                                 PROJECT_FILE_NAME, PROJECT_TEMPLATE,
                                 project_file_in)
from pl_codegen.cli import resolve_config_path
from pl_codegen.model.struct_type import StructTypeLibrary
from pl_codegen.model.tags import TAG_REGISTRY, TagKind
from pl_codegen.xml_model.types_xml import is_types_file, types_file_for
from pl_gui.api import Api
from pl_gui.workspace import Workspace                           # noqa: E402
from pl_gui.document import Document, machine_roots  # noqa: E402
from pl_gui.config_file import rewrite_model_files   # noqa: E402

_logging_utils._colour_enabled = colour_supported()


class Failure(AssertionError):
    """One expectation that did not hold."""


def check(condition: bool, message: str) -> None:
    if not condition:
        raise Failure(message)


def equal(actual, expected, message: str) -> None:
    if actual != expected:
        raise Failure(f"{message}: expected {expected!r}, got {actual!r}")


# --------------------------------------------------------------- the fixture
def open_copy(work: Path, *, empty: bool = False) -> Tuple[Document, Api, Path]:
    """A Document on a throw-away copy of the project.

    With ``empty`` the document is emptied of parameters before the test starts,
    so a case can say exactly what the list contains without depending on what
    the project happens to hold today.  The drop-down lists are kept - a case
    that adds a parameter needs a type and a system name to give it.

    Emptying the open list is *not* enough on its own.  The problems and the
    indices ``Api.state`` reports come from the whole build
    (``merged_model()``), so a parameter somebody happened to save in another
    list would show up in a case that thought it had started from nothing.
    The other lists are therefore emptied on disk as well, which is what makes
    ``empty`` mean empty.
    """
    config_path = _a_project(work / "project")
    _build_from_the_list_folder(config_path)
    document = Document(Config.load(config_path))
    document.load()
    if empty:
        _empty_the_other_lists(document)
        document.model.parameters.clear()
        document.model.struct_types = StructTypeLibrary()

    # The Api works for a workspace - the editor opens one project at a time -
    # so the copy is handed to one directly.  Opening it the ordinary way
    # would put a temp folder into the user's recent-projects list, and it
    # would be gone before they ever saw it.  Its settings file is its own for
    # the same reason: listing the recent projects rewrites the file.
    workspace = Workspace(work / "settings.json")
    workspace.adopt(document)
    return document, Api(workspace), config_path


#: Three small lists, so the cases about several lists have something real to
#: work on.  The first is the one the tests edit.
_FIXTURE_LISTS = ("main", "navigation", "power")


def _a_project(root: Path) -> Path:
    """Build a throw-away project and return its project file.

    Written from scratch every time, in the temp folder the case was given.
    It used to COPY the demo project out of the user's own tree - which meant
    the tests read whatever happened to be in it that day, and one of them
    reached far enough to write into it.  A test must never be able to touch
    somebody's work, and a fixture it builds itself is also the only fixture
    that says, in one place, exactly what the cases are standing on.
    """
    (root / "parameter_lists").mkdir(parents=True, exist_ok=True)
    for name in _FIXTURE_LISTS:
        (root / "parameter_lists" / f"{name}.xml").write_text(
            _FIXTURE_LIST, encoding="utf-8")
    shutil.copytree(LIB_TEMPLATE_DIR, root / "lib", dirs_exist_ok=True)

    settings = PROJECT_TEMPLATE.read_text(encoding="utf-8").replace("{{NAME}}", "Fixture")
    settings = settings.replace(
        '"model_files": [],',
        '"model_files": [' + ", ".join(f'"{name}.xml"' for name in _FIXTURE_LISTS) + '],')
    target = root / PROJECT_FILE_NAME
    target.write_text(settings, encoding="utf-8")
    return target


_FIXTURE_LIST = """<?xml version='1.0' encoding='utf-8'?>
<ParameterListModel schemaVersion="1.0" generator="parameter_list_code_generator"
                    generatorVersion="1.0.0">
  <SourceFiles />
  <Parameters>
    <Parameter name="Airspeed" kind="primitive" enable="true" gsName="Airspeed"
               type="MONITORING" valueType="float32_t" arraySize="1" unit="m/s"
               logId="100">
      <Source />
      <Limits default="0" minimum="0" maximum="120" resolution="0.01" />
      <Tags>
        <Tag id="SystemName" kind="enum" value="SYS_NAV" />
        <Tag id="ResetProof" kind="boolean" value="false" />
        <Tag id="Loggable" kind="boolean" value="true" />
        <Tag id="LogEncryption" kind="boolean" value="false" />
        <Tag id="ParamMode" kind="enum" value="PARAM_MODE_USER" />
      </Tags>
      <Description>How fast the air is going past.</Description>
    </Parameter>
  </Parameters>
</ParameterListModel>
"""


def _build_from_the_list_folder(config_path: Path) -> None:
    """Point the copy's build at the lists in ``parameter_lists/``.

    A test must measure the editor, not the configuration the user happens to
    have open.  Working on one list, at a path of your own choosing, outside the
    list folder, is a supported thing to do - so a suite that asserted "every
    list is in the folder" against the live configuration was reporting the
    user's working state as a failure of the tool.

    The copy is therefore put into the state the project ships in, and the cases
    that care about several lists, or about the folder, have something stable to
    stand on.  The rewrite goes through the same JSONC editor the GUI uses, so
    the comments in the configuration survive - which one of the cases checks.
    """
    lists = sorted(path for path
                   in (config_path.parent / "parameter_lists").glob("*.xml")
                   if not is_types_file(path))
    if lists:
        rewrite_model_files(config_path, [path.name for path in lists])


def _empty_the_other_lists(document: Document) -> None:
    """Strip every list of the build except the open one, on disk."""
    for path in document.config.inputs.model_files:
        if path == document.path or not path.is_file():
            continue
        other = read_xml(path, DiagnosticCollector())
        other.parameters.clear()
        other.struct_types = StructTypeLibrary()
        write_xml(other, path, emit_timestamp=False)


# --------------------------------------------------------------- the cases
def test_structure_types(work: Path) -> None:
    """A structure is OF a type, and editing the type reaches every one of them.

    The old behaviour this replaces: a "type" was a copy, so a parameter built
    from one went its own way the moment it was made.  Now the type owns the
    shape and the parameter owns the limits, and there is a case for each half.
    """
    document, api, _config = open_copy(work, empty=True)

    made = api.new_type({"name": "sPosition"})
    check(made["ok"], f"the type was not declared: {made}")
    check(api.update_type({"name": "sPosition", "changes": {"fields": [
        {"name": "Lat", "valueType": "float64_t", "arraySize": 1},
        {"name": "Samples", "valueType": "int16_t", "arraySize": 4},
    ]}})["ok"], "the type's fields were not set")

    listed = api.state({})["structTypes"]
    equal([item["name"] for item in listed], ["sPosition"], "the type list")
    equal(len(listed[0]["fields"]), 2, "how many fields it has")

    # a structure picks its type from a list holding only structure types
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Target"})
    check(api.use_type({"path": "Target", "name": "sPosition"})["ok"],
          "the type could not be applied")

    target = document.find("Target")
    equal(target.kind.value, "struct", "it is a structure")
    equal([child.name for child in target.children], ["Lat", "Samples"], "the fields")
    check(not target.children[0].unit, "a field starts with no unit: the type has none")
    document.update("Target.Lat", {"unit": "deg"})
    equal(document.find("Target.Lat").unit, "deg",
          "the unit is set on the parameter's own field")
    check(target.param_type is not None, "the parameter keeps its own type")
    check(target.tags.get("SystemName") is not None, "and its own tags")

    # the limits belong to the parameter, not to the type
    document.update("Target.Lat", {"maximum": 45.0})
    equal(document.find("Target").children[0].maximum, 45.0, "the limit was written")
    equal(len(document.find_struct_type("sPosition").fields), 2,
          "and the type is unchanged by it")

    # editing the type reaches the parameter
    check(api.update_type({"name": "sPosition", "changes": {"fields": [
        {"name": "Lat", "valueType": "float64_t", "arraySize": 1},
        {"name": "Alt", "valueType": "float32_t", "arraySize": 1},
        {"name": "Samples", "valueType": "int16_t", "arraySize": 4},
    ]}})["ok"], "the type could not be edited")
    equal([child.name for child in document.find("Target").children],
          ["Lat", "Alt", "Samples"], "the parameter grew the new field, in place")
    equal(document.find("Target.Lat").unit, "deg",
          "and the unit this parameter gave its field survived the type edit")
    equal(document.find("Target.Lat").maximum, 45.0, "and kept the limit it had")

    # the type survives a save and a reload, in the file beside the list
    saved = document.save()
    again = Document(document.config)
    again.load(saved)
    equal(again.model.struct_types.names(), ["sPosition"], "the types after a reload")
    equal([child.name for child in again.find("Target").children],
          ["Lat", "Alt", "Samples"], "and the parameter still has its fields")

    # a type still in use is not deleted, and says so
    refused = api.delete_type({"name": "sPosition"})
    equal(refused["ok"], False, "a type in use was deleted")
    check("still used" in refused["message"], "and it did not say why")

    check(document.delete("Target"), "the parameter was not deleted")
    check(api.delete_type({"name": "sPosition"})["ok"], "an unused type was not removed")
    equal(api.state({})["structTypes"], [], "the type list after removing the only type")


def test_structure_arrays(work: Path) -> None:
    """An array of structures produces one set of values per element."""
    document, _api, _config = open_copy(work, empty=True)

    # A structure is of a TYPE, and the type says what fields it has.
    document.create_struct_type("Wheel")
    document.update_struct_type("Wheel", {"fields": [
        {"name": "Speed", "valueType": "float32_t", "arraySize": 1}]})

    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Wheels", "array_size": 3,
                                  # log_id is a field of its own, not a tag
                                  "log_id": 900,
                                  "tags": {"Loggable": True,
                                           "SystemName": "SYS_NAV",
                                           "ParamMode": "PARAM_MODE_USER",
                                           "ResetProof": False, "LogEncryption": False}})
    document.use_struct_type("Wheels", "Wheel")
    document.update("Wheels.Speed",
                    {"minimum": 0, "maximum": 0, "resolution": 0.001, "default_value": 0.0})

    leaves = document.model.flatten()
    equal([leaf.name for leaf in leaves],
          ["Wheels[0].Speed", "Wheels[1].Speed", "Wheels[2].Speed"], "the expanded leaves")
    equal([leaf.log_id for leaf in leaves], [900, 901, 902], "one log id per value")

    # A log id counts values, never bytes: a float32_t[10] takes ten ids, and so
    # would a uint8_t[10].  Every element is a value in its own right - its own
    # row, its own index, its own id - so three struct elements each holding an
    # array of 10 produce thirty values numbered 900..929.
    # The array size of a field is the TYPE's, so this is where it changes -
    # and it changes for every parameter of that type at once.
    document.update_struct_type("Wheel", {"fields": [
        {"name": "Speed", "valueType": "float32_t", "arraySize": 10}]})
    expanded = document.model.flatten()
    equal(len(expanded), 30, "three elements of ten values each")
    equal([leaf.name for leaf in expanded[:2]],
          ["Wheels[0].Speed[0]", "Wheels[0].Speed[1]"], "every element is its own value")
    equal([expanded[0].log_id, expanded[10].log_id, expanded[20].log_id],
          [900, 910, 920], "each struct element starts a block of ten ids")
    equal([leaf.log_id for leaf in expanded], list(range(900, 930)),
          "the ids run without a gap, one per value")

    # 'the next free id' is a property of the whole project, not of this list:
    # the other lists of the build reserve ids too, and an id that is free here
    # but taken in another list is not free.
    free = document.next_free_log_id()
    check(free >= 930, f"the next free id must be past this list's block, got {free}")
    for leaf in document.merged_model().flatten():
        log_id = leaf.log_id
        if isinstance(log_id, int) and not isinstance(log_id, bool):
            check(free > log_id, f"id {free} is not free: '{leaf.name}' already uses {log_id}")


def test_parameter_lists(work: Path) -> None:
    """Creating, choosing and ordering the parameter lists of the project."""
    document, api, config_path = open_copy(work)
    # The file the app makes is plain JSON now, but an older project came with
    # a page of comments and somebody may write a note of their own: a change
    # of lists must never throw them away.
    config_path.write_text(config_path.read_text(encoding="utf-8").replace(
        "{", "{\n  // a note somebody wrote - no button may throw it away", 1),
        encoding="utf-8")
    before = config_path.read_text(encoding="utf-8")
    check("//" in before, "the fixture configuration has no comments to preserve")

    listed = api.lists({})
    equal(Path(listed["directory"]).name, "parameter_lists", "the parameter list folder")
    check(all(item["inFolder"] for item in listed["lists"]),
          "every list of the project should live in the one folder")
    selected = [item["file"] for item in listed["lists"] if item["selected"]]
    check(len(selected) >= 1, "no list takes part in the build")

    # a name is sanitised into something that cannot leave the folder
    answer = api.new_list({"name": "../../gimbal telemetry!"})
    check(answer["ok"], f"the list was not created: {answer}")
    created = Path(answer["path"])
    equal(created.name, "gimbal_telemetry.xml", "the file name made from the typed name")
    equal(created.parent, document.list_directory(), "the new list is in the folder")
    check(created.is_file(), "the new list was not written to disk")
    check(created in document.config.inputs.model_files,
          "the new list did not join the build")

    # a name that is already taken is refused rather than overwriting a list
    check(not api.new_list({"name": "gimbal_telemetry"})["ok"],
          "creating a list twice overwrote the first one")

    # The order chosen here is the order the generator merges in, so the check
    # below needs two lists that actually hold parameters - reversed, so that
    # "the order was kept" cannot pass by accident.
    directory = document.list_directory()
    filled = [path for path in sorted(directory.glob("*.xml"))
              if not is_types_file(path) and _parameter_names(path)]
    check(len(filled) >= 2,
          "the project needs two non-empty parameter lists to test the order with")
    chosen = list(reversed(filled[:2]))
    answer = api.select_lists({"paths": [str(path) for path in chosen]})
    check(answer["ok"], f"the choice was not saved: {answer}")

    after = config_path.read_text(encoding="utf-8")
    check("//" in after, "rewriting the configuration deleted its comments")
    equal([line for line in before.splitlines() if line.strip().startswith("//")],
          [line for line in after.splitlines() if line.strip().startswith("//")],
          "the comments of the configuration file")

    reloaded = Config.load(config_path)
    equal([path.name for path in reloaded.inputs.model_files],
          [path.name for path in chosen],
          "what run_generate.py reads after the editor saved the choice")

    # ... and the indices of the generated code really follow that order: the
    # values of the first list come first, then the values of the second.
    expected = [name for path in chosen for name in _parameter_names(path)]
    document = Document(reloaded)
    document.load(reloaded.inputs.model_files[0])
    equal([leaf.name for leaf in document.merged_model().flatten()], expected,
          "the order of the values in the merged model")


def test_list_selection_edge_cases(work: Path) -> None:
    """The ways a hand-edited configuration can be odd, and what happens then."""
    document, api, config_path = open_copy(work)
    directory = document.list_directory()
    first = document.config.inputs.model_files[0]

    # The same list twice would be merged twice and every name in it would
    # collide with itself; the first mention wins so the chosen order survives.
    answer = api.select_lists({"paths": [str(first), str(directory / "power.xml"),
                                         str(first)]})
    check(answer["ok"], f"the choice was not saved: {answer}")
    equal([Path(p).name for p in answer["paths"]], [first.name, "power.xml"],
          "the duplicate should have been dropped")
    equal([path.name for path in Config.load(config_path).inputs.model_files],
          [first.name, "power.xml"], "what the configuration file says")

    # A configuration that already names a list twice still gives the dialog one
    # row per file - two rows with the same path would bind to the same object.
    document.config.inputs.model_files = [first, first]
    paths = [item["path"] for item in document.known_lists()]
    equal(len(paths), len(set(paths)), "the dialog was given a duplicated row")

    # Generating with a list that is not on disk is reported, not raised: the
    # editor shows that state as "(new)", so it is reachable by just clicking.
    document.config.inputs.model_files = [directory / "does_not_exist.xml"]
    result = api.generate({})
    check(not result["success"], "generating from a missing list reported success")
    check(bool(result.get("message")), "the failure came back with nothing to read")


def test_a_type_belongs_to_its_list(work: Path) -> None:
    """A structure type is its own list's: no other list sees, uses or reuses it.

    It used to be offered in every list, and using it from another list copied
    it in - so one name ended up in two lists' files, and the first of them in
    the build then reshaped the other's structures.  Now it is not offered, a
    second list cannot take its name, and one name in two lists on disk is an
    error naming both, even when both say the same thing.
    """
    document, api, _config = open_copy(work)
    first, other = document.config.inputs.model_files[:2]
    fields = [{"name": "Fix", "valueType": "uint8_t", "arraySize": 1}]
    document.load(other)
    check(api.new_type({"name": "sNavShape", "fields": fields})["ok"],
          "the type was not declared")
    document.save()

    document.load(first)
    names = [item["name"] for item in api.state({})["structTypes"]]
    check("sNavShape" not in names, f"another list's type is not offered here: {names}")
    check(not api.add_structure({"name": "Nav", "type": "sNavShape"})["ok"],
          "a structure here cannot be of another list's type")
    answer = api.new_type({"name": "sNavShape", "fields": fields})
    check(not answer["ok"] and other.stem in answer.get("message", ""),
          f"its name is taken here, and the refusal names the list: {answer}")
    check(not api.delete_type({"name": "sNavShape"})["ok"],
          "nor can it be deleted from here")

    # one name in two lists' files - a hand edit, or a list brought in from
    # somewhere - is an error naming both, although the two are identical
    shutil.copy2(types_file_for(other), types_file_for(first))
    document.load(first)
    clash = [item for item in api.state({})["diagnostics"] if item["code"] == "TYP016"]
    check(len(clash) == 1 and clash[0]["severity"] == "error",
          f"one name in two lists is one error: {clash}")
    check(first.name in clash[0]["message"] and other.name in clash[0]["message"],
          f"naming both lists: {clash[0]['message']}")
    check(not document.generate()["success"], "and nothing is generated until one is renamed")


def _parameter_names(path: Path) -> List[str]:
    """The values one parameter list contributes, in order."""
    from pl_codegen.errors import DiagnosticCollector
    from pl_codegen.xml_model.xml_reader import read_xml

    return [leaf.name for leaf in read_xml(path, DiagnosticCollector()).flatten()]


def test_layout_warning(work: Path) -> None:
    """Generating must say when it moved a value a board may already store.

    The offset of a reset-proof value is positional, so inserting, disabling,
    moving or widening a parameter shifts everything after it - and none of that
    shows up in the generated code.  This is the check that it never happens
    quietly.

    The case builds its own parameters rather than using whatever the project
    holds today.  Every step here has to *generate*, and a project someone is
    halfway through editing may legitimately not - a duplicate name while two
    lists are being merged, say.  Depending on that would turn "your draft has
    an error" into "the memory layout warning is broken", which is a different
    and much more alarming thing to read.
    """
    document, api, _config = open_copy(work, empty=True)

    for name in ("Alpha", "Beta", "Gamma"):
        path = document.add_parameter("", "primitive")
        document.update(path, {"name": name, "gs_name": name})
    document.save()

    # the copy carries the project's last build; drop it so the first generate
    # here really is a first build
    previous = document.config.output.xml_file
    if previous.is_file():
        previous.unlink()

    first = api.generate({})
    check(first["success"], f"the first build failed: {first.get('message')}")
    check(first["drift"]["firstRun"], "the very first build has nothing to compare with")

    # generating again without touching anything must be silent
    again = api.generate({})
    check(not again["drift"]["breaksStoredData"], "an unchanged model reported a move")
    equal(again["drift"]["moved"], [], "an unchanged model moved something")

    # ... and moving a parameter to the front must not be
    names = [node.name for node in document.model.parameters]
    check(len(names) >= 2, "the project needs two parameters for this case")
    document.move(names[-1], -(len(names) - 1))
    moved = api.generate({})
    check(moved["success"], "generating after the move failed")
    drift = moved["drift"]
    check(drift["breaksStoredData"],
          "moving a parameter to the front did not warn about the memory layout")
    check(bool(drift["moved"]), "the warning named no parameter")
    check("MOVED" in drift["summary"], f"the summary is not loud enough: {drift['summary']}")
    for entry in drift["moved"]:
        check(entry["old"] != entry["new"],
              f"'{entry['parameter']}' is listed as moved but did not move")

    # Appending to the END of the LAST list in the build changes nothing that
    # already exists - and that is the whole point of the advice the warning
    # gives, so it has to actually hold.
    api.open_file({"path": str(document.config.inputs.model_files[-1])})
    document.add_parameter("", "primitive")
    document.update("NewParameter", {"name": "AppendedAtTheEnd"})
    appended = api.generate({})
    check(appended["success"], "generating after the append failed")
    equal(appended["drift"]["moved"], [],
          "appending at the end of the last list moved something that existed")
    check("AppendedAtTheEnd" in appended["drift"]["added"],
          "the appended parameter was not reported as added")


def test_no_external_dependency(_project: Path) -> None:
    """The tool must run on a machine that has never seen the internet.

    The company machines are offline, so `pip install` is not a step anybody can
    take: an import that is not in the Python standard library does not fail at
    the point where it was added, it fails on somebody else's desk, on the day
    they first open the editor.

    This is checked by reading the imports rather than by trying them, so it
    fails on the machine that ADDED the dependency - which is the only machine
    where fixing it is cheap.
    """
    standard = set(sys.stdlib_module_names)
    ours = {"pl_codegen", "pl_gui", "tests", "setup_environment"}

    offenders = []
    for path in sorted(APP_DIR.rglob("*.py")):
        # docs/ is the manual build. It runs on a developer's machine once a
        # release, not on the offline machines the tool has to work on, so it
        # is allowed the browser driver and the PDF reader it needs.
        if "__pycache__" in path.parts or "docs" in path.parts:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as error:
            raise Failure(f"{path.relative_to(APP_DIR)} does not parse: {error}")

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                root = name.split(".")[0]
                if root not in standard and root not in ours:
                    offenders.append(f"{path.relative_to(APP_DIR)}: {name}")

    equal(sorted(set(offenders)), [], "imports that are not in the standard library")


def test_every_pane_redraws(_project: Path) -> None:
    """A mutation must never redraw only half the screen.

    The editor keeps no state of its own: the model is the truth and every pane
    is drawn from it.  ``refresh(true)`` is the one exception - it leaves the
    form on the right alone so that typing is not interrupted mid-word - and it
    is safe ONLY where the action cannot have changed the selected node.

    Ticking Enabled in the tree broke exactly that rule once: the model and the
    tree moved, the form did not, and the two halves of the screen then
    disagreed about the same parameter with nothing to say which was right.

    So: any method that calls ``api.update`` - the one action that changes a
    node's fields - must redraw the form as well.  A DOM test could catch this
    too, but it would need a browser; this reads the source and needs nothing.
    """
    # the real source, not the temporary fixture copy: this reads the code the
    # project ships, and the fixture has no web/ folder
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")

    # Comments are stripped first, or the rule catches the comment that explains
    # the rule - "NOT refresh(true), because ..." reads as a call to it.
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)

    # split into methods: "  name(args) {" or "  async name(args) {" at one indent
    methods = re.split(r"\n  (?=(?:async )?[A-Za-z_]\w*\s*\()", code)
    offenders = []
    for body in methods:
        name = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if not name:
            continue
        if "api.update(" not in body:
            continue
        if re.search(r"refresh\(\s*true\s*\)", body):
            offenders.append(name.group(1))

    equal(offenders, [],
          "methods that change a node but keep the stale form (use refresh(), "
          "not refresh(true))")

    # and the checkbox in the tree has to go through that same update action,
    # rather than poking the model or the DOM behind its back
    bodies = {}
    for body in methods:
        found = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if found:
            bodies.setdefault(found.group(1), body)

    check("setEnabled" in bodies, "app.js still has a setEnabled method")
    check("api.update(" in bodies["setEnabled"],
          "the tree's Enabled tick goes through the normal update action")

    # The form is allowed to skip its own redraw while somebody is typing in it
    # - it already shows what they typed - but ONLY for a change the form
    # itself made.  The caret can be parked in a box while the reader ticks
    # something in the tree, and that change has to reach the form like any
    # other; getting this wrong is how the two halves of the screen last
    # disagreed.  So exactly one method may raise the flag.
    raisers = sorted(name for name, body in bodies.items()
                     if "editorView.ownEdit = true" in body)
    equal(raisers, ["applyChanges"],
          "methods that let the editor skip its redraw (only the form's own "
          "edits may)")

    editor_js = (APP_DIR / "src" / "pl_gui" / "web" / "editor.js").read_text(encoding="utf-8")
    check("this.ownEdit && this.isBeingTypedIn()" in editor_js,
          "editor.js must gate the skip on BOTH the flag and the caret")

    # and the flag has to be put down again, or the form stops redrawing for
    # good after the first edit
    check("finally" in bodies["applyChanges"]
          and "editorView.ownEdit = false" in bodies["applyChanges"],
          "applyChanges must clear ownEdit in a finally block")


def test_one_name_for_one_thing(_project: Path) -> None:
    """A concept must be called the same thing everywhere.

    Renaming something across a project is the change most likely to be left
    half done: the compiler catches the identifiers, the tests catch the keys,
    and nothing at all catches a heading in a generated comment, a label in a
    dialog, or a sentence in a docstring.  Every one of those was missed once.

    So the banned words are listed here.  If a rename is ever reversed, or a new
    name is chosen, this list is the one place that decides it - and the suite
    says exactly which files still disagree.
    """
    # word that must not appear -> what it is called now, and why
    BANNED = {
        "eParameterListDescriptorGroup": "eParameterType",
        "sParameterListDescriptorTag": "sParameterTag",
        "ePARAMETER_GROUP_": "ePARAMETER_TYPE_",
        "DEFAULT_GROUPS": "DEFAULT_PARAMETER_TYPES",
        "GroupRule": "ParameterTypeRule",
        "COLUMN_GROUPS": "COLUMN_TYPES",
        "data_type_name": "value_type_name",
        "PARAMETER_LIST_OFFSET_": "PARAMETER_LIST_TAG_<TAG>_<NAME>_OFFSET",
        "PARAMETER_LIST_SIZE_": "PARAMETER_LIST_TAG_<TAG>_SIZE",
        "TagLogId": "LogId (it is not a tag)",
        "fParameterList_GetLogIdSize": "removed with the LogId offset area",
        "ArraySize;": "removed: one descriptor is one value",
        "DataTypeRule": "ValueTypeRule",
        # the heading of the generated overview table
        '"DataType"': '"ValueType"',
    }
    # the old smart-data macro spelling, before the file_Function_ convention
    for old in ("fSmartDataRead_", "fSmartDataWrite_", "fSmartDataSetMinimum_",
                "fSmartDataGetMaximum_", "fSmartDataUserRead_"):
        BANNED[old] = old.replace("fSmartData", "fSmartData_")

    # The documentation is searched too.  It is the place a stale name survives
    # longest, because nothing compiles it and nobody greps it - and a manual
    # that calls a button by a name it no longer has is worse than no manual.
    searched = []
    for pattern in ("*.py", "*.js", "*.c", "*.h", "*.json", "*.html"):
        searched += [p for p in ROOT_DIR.rglob(pattern)
                     if "__pycache__" not in p.parts and ".dist" not in p.parts]

    offences = []
    for path in searched:
        # this file names the banned words on purpose
        if path.name == "run_editor_test.py":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        # A manual that explains a rename has to name the old thing; those
        # sections are marked, and only those are exempt.
        text = re.sub(r"<!-- HISTORY-BLOCK.*?/HISTORY-BLOCK -->", "", text, flags=re.S)
        for banned, instead in BANNED.items():
            if banned in text:
                offences.append(f"{path.relative_to(ROOT_DIR)}: '{banned}' "
                                f"(now: {instead})")

    equal(sorted(offences), [], "old names still in the source")

    # The manuals name the controls of the editor.  A label that was renamed in
    # index.html and not in the manual sends the reader looking for something
    # that is not on screen, so the two are checked against each other.
    labels = (APP_DIR / "src" / "pl_gui" / "web" / "index.html").read_text(encoding="utf-8")
    grid = (APP_DIR / "src" / "pl_gui" / "web" / "grid.js").read_text(encoding="utf-8")
    for shown, gone in (("Value type", "Data type"),
                        ("Tag ParamMode", "ParamMode column"),
                        ("Structure types…", "Save as a type"),
                        ("Structure type", "the mixed Data type list")):
        if shown in labels or shown in grid:
            continue
        raise Failure(f"the editor no longer shows '{shown}'; the manuals still "
                      f"describe it, so update them and this list together "
                      f"(it replaced '{gone}')")


def test_changing_the_value_type(work: Path) -> None:
    """Changing the type must leave nothing the new type cannot hold.

    The minimum, the maximum, the resolution and the default value only mean
    anything in terms of the value type, so a type change has to bring them
    along.  Left behind they are not merely untidy - turning a float32_t into a
    bool_t used to keep its 0..120 range, and the boolean form has no minimum
    or maximum box, so the warning that followed could be read and could not be
    acted on from the editor at all.

    Every pair of types is walked here, in both directions, and the model has
    to come out clean each time.
    """
    from pl_codegen.model.types import VALUE_TYPES

    document, api, _config = open_copy(work, empty=True)
    document.add_parameter("", "primitive")
    document.update("NewParameter", {
        "name": "Probe", "param_type": "MONITORING",
        "tags": {"SystemName": "SYS_NAV", "ParamMode": "PARAM_MODE_USER",
                 "ResetProof": False, "Loggable": False, "LogEncryption": False}})

    names = list(VALUE_TYPES)
    for start in names:
        for target in names:
            # a plausible starting point for the first type
            document.update("Probe", {"value_type_name": start})
            if start == "bool_t":
                document.update("Probe", {"default_value": True})
            elif start.startswith("float"):
                # FRACTIONS on purpose: an integer type can hold none of these,
                # and a value merely inside the new type's range is not yet a
                # value it can carry - C would quietly make 10.5 into 10.
                document.update("Probe", {"minimum": -10.5, "maximum": 10.5,
                                          "default_value": 7.25, "resolution": 0.25})
            else:
                document.update("Probe", {"minimum": 0, "maximum": 100,
                                          "default_value": 7, "resolution": 1})

            document.update("Probe", {"value_type_name": target})

            # only what this test is about: an empty description or gs name is
            # a house-style notice and has nothing to do with the type change
            complaints = [item for item in api.state({})["diagnostics"]
                          if str(item.get("location", {}).get("parameter", "")) == "Probe"
                          and item["code"][:3] in ("RNG", "TYP", "VAL")]
            equal([f"{c['code']}: {c['message']}" for c in complaints], [],
                  f"{start} -> {target} left the parameter in a state the editor "
                  f"cannot repair")

            node = document.find("Probe")
            value_type = node.value_type
            if value_type is not None and not value_type.is_float and not value_type.is_bool:
                for field in ("minimum", "maximum", "default_value", "resolution"):
                    value = getattr(node, field)
                    if value is None or isinstance(value, bool):
                        continue
                    check(float(value).is_integer(),
                          f"{start} -> {target} left {field}={value} on an integer type")
            if target == "bool_t":
                equal(isinstance(node.default_value, bool), True,
                      f"{start} -> bool_t left a non-boolean default")
            else:
                check(not isinstance(node.default_value, bool),
                      f"{start} -> {target} left a boolean default on a number")


def test_a_boolean_keeps_its_shape(work: Path) -> None:
    """A boolean must hold 0 / 1 / 1 and a real boolean default, always.

    Its form shows no minimum, maximum or resolution box, so a number written
    into one of those could never be seen and never be corrected.  The values
    were normalised when the TYPE changed, which left two ways in that skipped
    it: an update already in flight when the type became bool_t, and a
    structure converted straight to bool_t.
    """
    document, api, _config = open_copy(work, empty=True)
    document.add_parameter("", "primitive")
    document.update("NewParameter", {
        "name": "Flag", "param_type": "MONITORING",
        "tags": {"SystemName": "SYS_NAV", "ParamMode": "PARAM_MODE_USER",
                 "ResetProof": False, "Loggable": False, "LogEncryption": False}})

    def shape():
        node = document.find("Flag")
        return (node.minimum, node.maximum, node.resolution,
                isinstance(node.default_value, bool))

    document.update("Flag", {"value_type_name": "bool_t"})
    equal(shape(), (0, 1, 1, True), "a fresh boolean")

    # numbers written straight at it, as a stale page would
    document.update("Flag", {"minimum": 100, "maximum": -128,
                             "default_value": -1, "resolution": 0.5})
    equal(shape(), (0, 1, 1, True), "a boolean after nonsense was written at it")

    # A STRUCTURE cannot be turned into a boolean at all now: a structure is
    # of a structure type and holds fields, and the two are kept apart rather
    # than one silently becoming the other.
    document.add_parameter("", "struct")
    document.update("NewStruct", {"name": "Shape"})
    refused = api.update({"path": "Shape", "changes": {"value_type_name": "bool_t"}})
    equal(refused["ok"], False, "a structure was allowed to become a boolean")
    check("structure type" in refused["message"],
          f"the refusal should say what a structure needs: {refused['message']}")
    equal(document.find("Shape").kind.value, "struct", "and it is still a structure")
    check(document.delete("Shape"), "the structure could not be deleted")

    # Errors and warnings only: an info is the tool telling you what it did,
    # not something wrong with the model.
    complaints = [item["code"] for item in api.state({})["diagnostics"]
                  if item["code"][:3] in ("RNG", "TYP", "VAL")
                  and item["severity"] != "info"]
    equal(complaints, [], "a normalised boolean should report nothing")



def test_every_drive_can_be_reached(work: Path) -> None:
    """A project on another drive can be browsed to, opened and created.  (Reported.)

    Walking up from a folder ends at the root of ITS drive - the parent of
    ``C:\\`` is ``C:\\`` - so the dialogs could only ever reach the drive they
    started on.  Somebody whose work is on E: could not open a project and, with
    no box to type a folder into, could not create one either.
    """
    _document, api, config = open_copy(work)

    # -- the backend offers the roots, and both dialogs get them -----------
    roots = machine_roots()
    check(bool(roots), "the machine has at least one root to start from")
    for root in roots:
        check(Path(root).is_dir(), f"'{root}' is offered and is really there")
    if os.name == "nt":
        check(all(len(root) == 3 and root[1:] == ":\\" for root in roots),
              f"on Windows they are drive roots: {roots}")

    projects = api.browse_projects({"directory": str(config.parent)})
    check(projects["ok"], f"browsing was refused: {projects.get('message')}")
    equal(projects["drives"], roots, "the project dialog is told where it may start")

    lists = api.browse({"directory": str(config.parent)})
    check(lists["ok"], f"browsing was refused: {lists.get('message')}")
    equal(lists["drives"], roots, "and so is the parameter-list dialog")

    # -- the walk really does stop at a root, which is why they are needed -
    root = Path(str(config)).anchor
    at_root = api.browse_projects({"directory": root})
    check(at_root["ok"], f"a drive root cannot be listed: {at_root.get('message')}")
    equal(at_root["parent"], "", "there is nothing above a drive root to walk to")

    # -- and a project can be made in a folder that is only typed, not walked
    somewhere = work / "typed" / "not" / "walked" / "to"
    made = api.new_project({"folder": str(somewhere), "name": "Elsewhere",
                            "format": "smart_data"})
    check(made["ok"], f"a typed folder was refused: {made.get('message')}")
    check(Path(made["path"]).is_file(), "and the project file is really there")


def test_only_a_project_file_opens(work: Path) -> None:
    """A JSON file that is not a project must not open as one.

    Nothing in a project file is mandatory, so an empty object used to load as
    "a project with all the defaults" - and any JSON file on the machine with
    it.  Opening one made ITS folder the project root, so the next Generate
    would have written the parameter list into somebody's home directory, and
    the only clue was a screenful of "unknown configuration section".
    """
    from pl_codegen.config import Config
    from pl_codegen.errors import CodeGeneratorError

    stranger = work / "not_a_project.json"
    stranger.write_text('{"editor": {"theme": "dark"}, "recent": []}',
                        encoding="utf-8")
    try:
        Config.load(stranger)
    except CodeGeneratorError as error:
        message = str(error)
        assert "not a project file" in message, message
        assert "editor" in message, f"it says what the file does have: {message}"
    else:
        raise AssertionError("a settings file opened as a project")

    # ...and one section is enough to be a project, because a real project file
    # may leave every other section out and take the defaults.
    thin = work / "thin.json"
    thin.write_text('{"project": {"name": "Thin"}}', encoding="utf-8")
    config = Config.load(thin)
    assert config.project.name == "Thin", config.project.name



def test_no_list_no_parameter(work: Path) -> None:
    """A new project has no parameter list, so it has nowhere to keep a parameter.

    Adding one used to work - into memory only.  Save then said "No file name
    given.", and Generate wrote every output file from a parameter that existed
    nowhere on disk, while the command line, reading the same project,
    generated nothing.  In both formats.
    """
    from pl_gui.workspace import Workspace

    for fmt in ("smart_data", "param_table"):
        workspace = Workspace(work / f"settings_{fmt}.json")
        project = workspace.create(work / fmt, "Empty", output_format=fmt)
        workspace.open(project)
        api = Api(workspace)
        document = workspace.document

        check(not document.has_list, f"{fmt}: a new project has a list open")
        equal(api.state({})["file"], "", f"{fmt}: the editor is told there is no list")

        answer = api.add({"parent": "", "kind": "primitive"})
        check(not answer["ok"], f"{fmt}: a parameter was added with no list")
        check("no parameter list" in (answer.get("message") or ""),
              f"{fmt}: the refusal says why: {answer}")
        equal(document.model.parameters, [], f"{fmt}: nothing was kept in memory")

        saved = api.save({})
        check(not saved["ok"] and "no parameter list" in saved["message"],
              f"{fmt}: save says there is no list: {saved}")

        made = api.new_type({"name": "sThing"})
        check(not made["ok"], f"{fmt}: a structure type was declared with no list")

        result = document.generate()
        check(not result["success"], f"{fmt}: a project with no list generated code")
        codes = [item["code"] for item in result["diagnostics"]]
        check("VAL002" in codes and "VAL001" not in codes,
              f"{fmt}: the build says there is no LIST, not an empty one: {codes}")
        check(not (work / fmt / "cg_parameter_list").exists(),
              f"{fmt}: and not one output file was written")


def test_opening_a_list_already_in_the_build(work: Path) -> None:
    """'Open a parameter list' opens one that is already in the build.  (Reported.)

    It was refused as "already part of the build" - after the dialog's own
    check had thrown "Cannot read properties of undefined (reading 'length')"
    for every real parameter list, because the page read a name, 'templates',
    that the check no longer sends.
    """
    document, api, _config = open_copy(work)
    build = list(document.config.inputs.model_files)
    power = next(path for path in build if path.name == "power.xml")
    folder_before = sorted(item.name for item in power.parent.iterdir())

    verdict = api.inspect_list({"path": str(power)})
    check(verdict["ok"], f"a list of the build is a parameter list: {verdict}")
    check(verdict.get("inBuild") is True, "and the check says it is in the build already")
    for key in ("values", "parameters", "structures", "types", "notes"):
        check(key in verdict, f"the check sends '{key}', which the dialog reads")

    answer = api.add_existing_list({"path": str(power)})
    check(answer["ok"], f"OK on a list already in the build opens it: {answer}")
    check(answer.get("alreadyInBuild") is True, "and says that it only opened it")
    equal(Path(answer["path"]), power, "the list itself, not a copy")
    equal(list(document.config.inputs.model_files), build, "the build is unchanged")
    equal(sorted(item.name for item in power.parent.iterdir()), folder_before,
          "and nothing was copied")


def test_the_merged_view_names_every_rows_list(work: Path) -> None:
    """Every row of the merged view says which list it came from.  (Reported.)

    The List column was blank: the grid gave a top-level row its PARENT's list,
    which a top-level row does not have.  The backend matched rows to lists by
    NAME as well, so the fixture's Airspeed - which is in all three lists -
    named main.xml three times.
    """
    document, api, _config = open_copy(work)
    equal([path.name for path in document.config.inputs.model_files],
          ["main.xml", "navigation.xml", "power.xml"], "the fixture's build")
    check(document.path is not None and document.path.name == "main.xml",
          f"main.xml is the open list: {document.path}")

    api.add({"parent": "", "kind": "primitive"})     # new and unsaved, in main.xml
    tree = api.state({"allLists": True})["tree"]
    equal([(node["path"], node["ownerList"]) for node in tree],
          [("Airspeed", "main.xml"), ("NewParameter", "main.xml"),
           ("Airspeed", "navigation.xml"), ("Airspeed", "power.xml")],
          "every top-level row names its own list - a name in three lists included")


def test_one_file_shape_for_both_formats(work: Path) -> None:
    """A smart-data list is saved with its Address, its gsName and its size.

    One list has the same fields whatever project generates from it: the
    address a parameter table uses is in the file (0), the name the ground
    station shows is written gsName, and the array size is written size.  A
    file carrying the older spellings - userName, arraySize - reads exactly the
    same and is written the new way on its next save.
    """
    document, api, _config = open_copy(work)
    node = next(item for item in api.state({})["tree"] if item["path"] == "Airspeed")
    equal(node["gsName"], "Airspeed", "the list's gs name comes back")
    equal(node["address"], 0, "and an address of 0")

    document.save()
    text = document.path.read_text(encoding="utf-8")
    check('address="0"' in text, f"the address is in a smart-data project's file too: {text[:700]}")
    check('gsName="Airspeed"' in text, "the gs name is written gsName")
    check("userName" not in text, "and never userName")
    check('size="1"' in text and "arraySize" not in text,
          f"the array size is written size: {text[:700]}")

    # A file written while those two had their older names opens unchanged.
    legacy = document.path.with_name("older_names.xml")
    legacy.write_text(_FIXTURE_LIST.replace('gsName="Airspeed"', 'userName="Airspeed"'),
                      encoding="utf-8")
    document.load(legacy)
    older = next(item for item in api.state({})["tree"] if item["path"] == "Airspeed")
    equal((older["gsName"], older["arraySize"]), ("Airspeed", 1),
          "userName and arraySize still read")


def test_the_output_names_lists_from_the_project_root(work: Path) -> None:
    """Generated files name their lists from the project's folder.  (Reported.)

    The banner of every generated file listed its input files with the full
    path of the machine that built them - C:\\Users\\... - so the same build
    made on two machines differed in every file, and a project kept in git
    changed each time somebody else generated it.  From the folder of
    pl_project.json a list is 'parameter_lists/main.xml' wherever the project is:
    in the banners, and in the full parameter list, both in <SourceFiles> and
    in every parameter's <Source>.  A list kept outside the folder is reached
    with '..'.
    """
    document, api, config_path = open_copy(work, empty=True)
    path = document.add_parameter("", "primitive")
    document.update(path, {"name": "Alpha", "gs_name": "Alpha"})
    document.save()

    outside = work / "shared" / "outside.xml"
    outside.parent.mkdir(parents=True)
    outside.write_text("<?xml version='1.0' encoding='utf-8'?>\n"
                       '<ParameterListModel schemaVersion="1.0">\n'
                       "  <SourceFiles />\n  <Parameters />\n"
                       "</ParameterListModel>\n", encoding="utf-8")
    answer = api.select_lists({"paths": [str(item) for item in
                                         document.config.inputs.model_files]
                                        + [str(outside)]})
    check(answer["ok"], f"the list outside the project was not added: {answer}")

    result = api.generate({})
    check(result["success"], f"the build failed: {result.get('message')}")
    check(bool(result["files"]), "the build wrote no file")
    lists = ["parameter_lists/main.xml", "parameter_lists/navigation.xml",
             "parameter_lists/power.xml", "../shared/outside.xml"]
    machine = {str(config_path.parent), str(document.config.path.parent),
               document.config.path.parent.as_posix()}
    for item in result["files"]:
        text = Path(item).read_text(encoding="utf-8")
        banner = [line.strip(" *") for line in text.splitlines()[:40]]
        first = next((index for index, line in enumerate(banner)
                      if line.startswith("Input file(s)")), None)
        check(first is not None, f"{Path(item).name} has no 'Input file(s)' line")
        named = ([banner[first].split(":", 1)[1].strip()]
                 + banner[first + 1:first + len(lists)])
        equal(named, lists, f"the lists {Path(item).name} names")
        check(not any(folder in text for folder in machine),
              f"{Path(item).name} names this machine's folders")

    full_list = document.config.output.xml_file.read_text(encoding="utf-8")
    for name in lists:
        check(f'<SourceFile path="{name}" />' in full_list,
              f"the full parameter list names '{name}' from the project's folder")
    check('<Source file="parameter_lists/main.xml" />' in full_list,
          "and so does every parameter's <Source>")
    check(not any(folder in full_list for folder in machine),
          f"the full parameter list names this machine's folders: {full_list[:600]}")


def _as_the_form_sends(node: dict) -> dict:
    """Everything editor.js ``collect()`` sends when a box is left untouched.

    As the browser encodes it: a number goes through JavaScript and JSON, which
    write a whole one without its '.0' - so a limit read from the file as 0.0
    comes back as the int 0 - and a tag comes back as the text in its box.
    """
    def number(value):
        return int(value) if isinstance(value, float) and value.is_integer() else value

    tags = {key: value if value is None or isinstance(value, bool) else str(value)
            for key, value in node["tags"].items()}
    return {
        "name": node["name"], "gs_name": node["gsName"],
        "param_type": node["paramType"], "value_type_name": node["valueType"],
        "array_size": node["arraySize"], "unit": node["unit"], "enable": node["enable"],
        "default_value": number(node["defaultValue"]), "minimum": number(node["minimum"]),
        "maximum": number(node["maximum"]), "resolution": number(node["resolution"]),
        "log_id": node["logId"], "description": node["description"], "tags": tags,
    }


def test_the_unsaved_mark_means_different_from_the_file(work: Path) -> None:
    """The '*' is on exactly while the list differs from its file.  (Asked for.)

    Every edit used to mark a list modified - the one the form sends when a box
    is only left as well - and Undo back to what is on disk kept the mark, so a
    '*' would have called lists unsaved that nobody had changed.  The mark now
    compares the list with its file.
    """
    document, api, _config = open_copy(work)
    state = api.state({})
    equal((state["dirty"], state["fileShown"]), (False, "parameter_lists/main.xml"),
          "a list just opened is clean, and named from the project's folder")

    node = next(item for item in state["tree"] if item["path"] == "Airspeed")
    answer = api.update({"path": "Airspeed", "changes": _as_the_form_sends(node)})
    check(answer["ok"], f"the untouched form was refused: {answer.get('message')}")
    equal((document.dirty, document.can_undo), (False, False),
          "leaving a box untouched is no edit: no '*', nothing to undo")

    api.update({"path": "Airspeed", "changes": {"unit": "km/h"}})
    equal(api.state({})["dirty"], True, "a real edit marks the list")
    api.undo({})
    equal(document.dirty, False, "Undo back to what is on disk takes the mark away")
    api.redo({})
    equal(document.dirty, True, "and Redo puts it back")

    document.save()
    equal(document.dirty, False, "saving takes it away")
    api.undo({})
    equal(document.dirty, True, "Undo after a save is a change against the new file")
    api.redo({})
    equal(document.dirty, False, "and Redo is the file again")

    made = api.new_type({"name": "sMark", "fields": [{"name": "A", "valueType": "uint8_t"}]})
    check(made["ok"], f"the structure type was not declared: {made.get('message')}")
    equal(document.dirty, True, "a new structure type marks the list - its file changes")
    document.save()

    refused = api.update({"path": "Airspeed", "changes": {"value_type_name": "sMark"}})
    equal(refused["ok"], False, "a parameter cannot take a structure type")
    equal(document.dirty, False, "and a refused edit leaves the list as it was saved")

    document.model.defines = copy.deepcopy(document.model.defines)
    document.model.defines.values.setdefault("SYSTEM NAMES", []).append("SYS_MARK_TEST")
    equal(document.dirty, False,
          "the drop-down lists are the machine's, not part of the list's file")


def test_a_value_has_a_description_of_its_own(work: Path) -> None:
    """Each element of an array may say what IT means, and only that.  (Asked for.)

    Every element is the same kind of thing, ``[0]`` included.  The text they
    all fall back to is the DECLARATION's, edited on the row without brackets -
    and editing it there must not overwrite an element somebody has already
    written something for.  (The first version made ``[0]`` be the
    declaration's, which is what the report asked to change.)

    Everything else on the form belongs to the whole array - changing a unit on
    the eighth element changes all of them - and the log id keeps the one rule
    it has always had: the ids of one parameter run one after another.  Typing
    one on an element therefore MOVES the block, so that element gets the
    number typed.
    """
    document, api, _config = open_copy(work)
    api.update({"path": "Airspeed", "changes": {"array_size": 10, "log_id": 45}})
    declaration = document.find("Airspeed")

    # -- the description of one element ------------------------------------
    answer = api.update({"path": "Airspeed[3]",
                         "changes": {"description": "Only the fourth one."}})
    check(answer["ok"], f"the element was refused: {answer.get('message')}")
    equal(answer.get("selected"), "Airspeed[3]",
          "the editor goes on pointing at the element it was on")
    equal(declaration.element_descriptions, {"3": "Only the fourth one."},
          "one override, on the element that was edited")
    said = {leaf.name: leaf.description for leaf in document.model.flatten()}
    equal(said["Airspeed[3]"], "Only the fourth one.", "the fourth value says so")
    equal(said["Airspeed[4]"], "How fast the air is going past.",
          "and the fifth still reads the parameter's")

    # -- [0] is an element like any other ----------------------------------
    api.update({"path": "Airspeed[0]", "changes": {"description": "The first one."}})
    equal(declaration.description, "How fast the air is going past.",
          "editing [0] does NOT write the parameter's description")
    equal(sorted(declaration.element_descriptions), ["0", "3"],
          "it is an override like any other")
    said = {leaf.name: leaf.description for leaf in document.model.flatten()}
    equal(said["Airspeed[1]"], "How fast the air is going past.",
          "so the second value is untouched")

    # -- the parameter's own row is where they all change ------------------
    api.update({"path": "Airspeed", "changes": {"description": "Air speed, per wheel."}})
    said = {leaf.name: leaf.description for leaf in document.model.flatten()}
    equal(said["Airspeed[9]"], "Air speed, per wheel.",
          "editing the declaration reaches every element with nothing of its own")
    equal((said["Airspeed[0]"], said["Airspeed[3]"]),
          ("The first one.", "Only the fourth one."),
          "and leaves the two that were written by hand exactly as they were")

    # -- and saying the same thing hands it back ---------------------------
    api.update({"path": "Airspeed[3]", "changes": {"description": "Air speed, per wheel."}})
    api.update({"path": "Airspeed[0]", "changes": {"description": ""}})
    equal(declaration.element_descriptions, {},
          "a description equal to the parameter's, or an empty one, is no override")

    # -- every other field reaches the whole array -------------------------
    api.update({"path": "Airspeed[7]", "changes": {"unit": "km/h"}})
    equal(declaration.unit, "km/h", "a unit typed on one element is the array's")
    equal({leaf.unit for leaf in document.model.flatten()}, {"km/h"},
          "so all ten values carry it")

    # -- the log id moves the block ----------------------------------------
    answer = api.update({"path": "Airspeed[7]", "changes": {"log_id": 57}})
    check(answer["ok"], f"the log id was refused: {answer.get('message')}")
    equal(declaration.log_id, 50, "57 on the eighth value starts the block at 50")
    ids = [leaf.log_id for leaf in document.model.flatten()]
    equal(ids, list(range(50, 60)), "and the ids of the parameter are consecutive")

    refused = api.update({"path": "Airspeed[7]", "changes": {"log_id": 3}})
    equal(refused["ok"], False, "a block that would start below zero is refused")
    check("7" in (refused.get("message") or ""),
          f"and the message says what the value needs: {refused.get('message')!r}")
    equal(declaration.log_id, 50, "a refused edit changes nothing")


def test_a_field_of_a_struct_array_too(work: Path) -> None:
    """Wheels[0].Speed and Wheels[1].Speed may read differently.  (Decided.)

    The same rule one step in: the description belongs to the VALUE, and every
    other box on the form belongs to the field, which belongs to the structure
    type and therefore to every element of the array.
    """
    document, api, _config = open_copy(work, empty=True)
    added = api.add_structure({"name": "Wheels", "type": "sWheel",
                               "fields": [{"name": "Speed", "valueType": "float32_t"}]})
    check(added["ok"], f"the structure was not added: {added.get('message')}")
    path = added["selected"]
    api.update({"path": path, "changes": {"array_size": 2,
                                          "description": "One wheel."}})
    api.update({"path": f"{path}.Speed", "changes": {"description": "How fast it turns."}})

    api.update({"path": f"{path}[1].Speed", "changes": {"description": "The rear one."}})
    said = {leaf.name: leaf.description for leaf in document.model.flatten()}
    equal(said[f"{path}[1].Speed"], "The rear one.", "the rear wheel says its own thing")
    equal(said[f"{path}[0].Speed"], "How fast it turns.",
          "and the front one still reads the field's")

    api.update({"path": f"{path}[1].Speed", "changes": {"unit": "rpm"}})
    equal({leaf.unit for leaf in document.model.flatten()}, {"rpm"},
          "while a unit typed there belongs to the field, so both wheels take it")

    # The field's own declaration has NO row in the grid - the table draws
    # Wheels[0].Speed and Wheels[1].Speed and nothing in between - so the form
    # carries the way to it, and the text they share is written there.
    answer = api.update({"path": f"{path}.Speed",
                         "changes": {"description": "Turning speed of a wheel."}})
    check(answer["ok"], f"the field's declaration was refused: {answer.get('message')}")
    said = {leaf.name: leaf.description for leaf in document.model.flatten()}
    equal(said[f"{path}[0].Speed"], "Turning speed of a wheel.",
          "the wheel with nothing of its own follows the field")
    equal(said[f"{path}[1].Speed"], "The rear one.",
          "and the one written by hand is left exactly as it was")


def test_the_grid_selects_one_value(_project: Path) -> None:
    """A row that IS a value selects the value; the form knows which one.

    Read out of the sources, because the click that proves it lives in the
    browser.  Three halves have to agree: the row says what it selects, the
    application resolves a value path to the declaration behind it, and the
    form is told which value it is showing.
    """
    web = APP_DIR / "src" / "pl_gui" / "web"
    grid_js = (web / "grid.js").read_text(encoding="utf-8")
    app_js = (web / "app.js").read_text(encoding="utf-8")
    editor_js = (web / "editor.js").read_text(encoding="utf-8")

    check("select: shape.leaf ? path : node.path" in grid_js,
          "a leaf row selects its own value path, a structure the declaration")
    check("this.onSelect(row.dataset.select)" in grid_js,
          "and clicking it sends that, not the declaration")
    check('data-select="${escapeHtml(row.select)}"' in grid_js,
          "the row carries it, so reveal() and the highlight can read it")
    check('element.dataset.select === path' in grid_js,
          "reveal() finds an element's own row")
    check("mine[0].description" in grid_js,
          "and the Description cell shows what THAT value means")

    check("declarationPath" in app_js and "selectedNode(state)" in app_js,
          "the application resolves a value path to its declaration")
    check("editorView.show(node, state, this.selected)" in app_js,
          "and tells the form which value is selected")
    check("btn-duplicate" in app_js and "const element = !!node" in app_js,
          "Duplicate, Delete and Move are switched off on an element")

    check("valueShown(node, selected)" in editor_js,
          "the form works out which value it is showing")
    check("this.value ? this.value.description : node.description" in editor_js,
          "the Description box holds that value's text")
    check("this.value.logId" in editor_js,
          "and the log id box the id that value really got")
    # Reported: the paragraph that used to sit above the form said in five
    # lines what the form already shows, on every single element.
    check("elementNote" not in editor_js and "element-note" not in editor_js,
          "and no banner is pasted above the form")
    # A field of a struct array has no declaration row to click, so the form is
    # the only way to the text its elements share.
    check("btn-describe-all" in editor_js
          and "app.select(declarationPath(this.value.path))" in editor_js,
          "one button leads from an element to the declaration behind it")


def test_the_dialogs_offer_the_drives(_project: Path) -> None:
    """All three folder dialogs show the drives, and New takes a typed folder."""
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")

    check("function driveRow(" in app_js, "one helper draws the row of drives")
    for dialog in ("open-project-drives", "new-project-drives", "open-list-drives"):
        check(dialog in app_js, f"the dialog using '{dialog}' shows them")
        check(f"#{dialog} [data-drive]" in app_js, f"and '{dialog}' is clickable")

    check('id="new-project-where"' in app_js,
          "New project has a box for a folder that was never walked to")
    check('document.getElementById("new-project-where").value.trim()' in app_js
          and "folderFor(where, name)" in app_js,
          "and what is typed there is where the project is made")
    check("C:\\\\work\\\\my_project" not in app_js,
          "no placeholder implies the work must be on C:")


def test_a_row_put_somewhere_new_is_brought_into_sight(_project: Path) -> None:
    """An action that moves the selection scrolls its row into sight.  (Reported.)

    The grid puts its scroll back after every redraw, which is right for an
    edit and was wrong for '+ Add': a new parameter goes to the end of the
    list, so in a long list it was selected below the visible rows, with the
    form beside it describing a row nobody could see.  Adding, adding a
    structure, duplicating and moving all put the selection somewhere new, so
    each one has to reveal it.  Read from the source, like the redraw rule.
    """
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)
    methods = re.split(r"\n  (?=(?:async )?[A-Za-z_]\w*\s*\()", code)

    movers = ("api.add(", "api.addStructure(", "api.duplicate(", "api.move(")
    blind = []
    for body in methods:
        name = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if name and any(call in body for call in movers) \
                and "gridView.reveal(" not in body:
            blind.append(name.group(1))
    equal(blind, [], "methods that put the selection somewhere new and leave it out of sight")

    grid_js = (APP_DIR / "src" / "pl_gui" / "web" / "grid.js").read_text(encoding="utf-8")
    check(re.search(r"\n  reveal\(path\) \{", grid_js) is not None,
          "grid.js has the reveal(path) those methods call")


def test_the_shortcuts_are_bound_to_the_key(_project: Path) -> None:
    """A shortcut is the KEY, not the letter it types.  (Reported.)

    Every shortcut was read off ``event.key``, which is the letter: on a
    Persian layout the S key reports 'س', so Ctrl+S and every other one
    silently did nothing until the layout was switched back.  ``event.code``
    is the key itself and says the same thing on every layout.  Read from the
    source, the way the redraw rule above is.
    """
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")
    check("event.key.toLowerCase()" not in app_js,
          "a shortcut is still bound to the letter a key types")

    table = re.search(r"SHORTCUTS: \{(.*?)\}", app_js, re.S)
    check(table is not None, "app.js has one table of shortcuts")
    for code in ("KeyS", "KeyG", "KeyN", "KeyD", "KeyZ", "KeyY"):
        check(code in table.group(1), f"{code} is in that table")

    handler = app_js.split("bindShortcuts()", 1)[1].split("async runShortcut", 1)[0]
    check("this.SHORTCUTS[event.code]" in handler, "the handler reads event.code")
    check('classList.contains("hidden")' in handler,
          "a dialog in front of the page takes the keyboard")
    check('typing && (command === "undo"' in handler,
          "undo and redo are left to the box being typed in")
    check("await this.pendingEdit" in app_js,
          "Ctrl+S waits for the box it just left to be sent")
    check("editorView.commit()" in app_js,
          "and asks the form for what it holds, rather than trusting the blur")


def test_the_address_column_comes_before_the_description(_project: Path) -> None:
    """The Address column sits after the tags, and a hidden column stays hidden.

    Both reported together: Address had been dropped in the middle of the tag
    columns, and the Description heading had another one drawn on top of it.
    The second was a 0px column - List outside the merged view, Address outside
    a parameter table - whose HEADING was not clipped, so it spilled over the
    next one and made the whole header look reordered.
    """
    grid_js = (APP_DIR / "src" / "pl_gui" / "web" / "grid.js").read_text(encoding="utf-8")
    block = grid_js.split("columns: [", 1)[1].split("  ],", 1)[0]
    keys = re.findall(r'\{ key: "(\w+)"', block)
    check("address" in keys and "desc" in keys, f"the columns are readable: {keys}")
    equal(keys[keys.index("address") + 1], "desc",
          f"Address is the column before Description: {keys}")
    equal([key for key in keys if key.startswith(("system", "mode", "reset", "log", "crypt"))
           and keys.index(key) > keys.index("address")], [],
          "and every tag column is before it, not around it")

    style = (APP_DIR / "src" / "pl_gui" / "web" / "style.css").read_text(encoding="utf-8")
    heading = style.split(".grid-head {", 1)[1].split("}", 1)[0]
    check("overflow: hidden" in heading,
          "a 0px column's heading is clipped, or it paints over the next column")
    check('column.width !== "0px"' in grid_js,
          "and a 0px column is left out of the table, padding and all")
    check("kind" not in keys,
          f"what a variable holds is ONE column, not Kind plus Value type: {keys}")


def test_a_project_file_with_the_old_name_still_opens(work: Path) -> None:
    """A project written before the rename opens exactly as it did.  (Asked for.)

    The project file is called ``pl_project.json`` now: inside a firmware tree
    full of other people's files, ``project.json`` said nothing about whose
    project it was.  Everything that turns a FOLDER into a project file takes
    either name, so a project nobody has renamed still opens - from the editor
    and from the command line - and a folder holding both takes the new one.
    """
    config_path = _a_project(work / "old")
    _build_from_the_list_folder(config_path)
    legacy = config_path.with_name(LEGACY_PROJECT_FILE_NAME)
    config_path.rename(legacy)

    found = project_file_in(legacy.parent)
    equal(found.name, LEGACY_PROJECT_FILE_NAME, "the folder's old project file is found")
    document = Document(Config.load(found))
    document.load()
    _empty_the_other_lists(document)
    check(document.generate()["success"], "and the project still generates")
    equal(resolve_config_path(legacy.parent).name, LEGACY_PROJECT_FILE_NAME,
          "the command line finds it too")

    # A folder holding both is a project that has been renamed and still has
    # its old file: the new name is the one that counts.
    legacy.with_name(PROJECT_FILE_NAME).write_text(legacy.read_text(encoding="utf-8"),
                                                   encoding="utf-8")
    equal(project_file_in(legacy.parent).name, PROJECT_FILE_NAME,
          "with both there, the new name wins")
    equal(resolve_config_path(legacy.parent).name, PROJECT_FILE_NAME,
          "for the command line as well")


def test_nothing_replaces_the_open_list_in_silence(_project: Path) -> None:
    """Opening something else asks first, while the list has unsaved changes.

    Switching to another list, opening another project, reloading, making a
    list, adding an existing one: each replaces what is open, and each of them
    threw unsaved work away without a word.  They ask through one helper now.
    Read from the source, like the other rules here.

    'removeList' is the exception, on purpose: what it reopens something after
    is the list that has just been deleted, so there is nothing left to save.
    """
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)
    methods = re.split(r"\n  (?=(?:async )?[A-Za-z_]\w*\s*\()", code)

    opens = ("api.open(", "api.openProject(", "api.closeProject(", "api.newList(")
    silent = []
    for body in methods:
        name = re.match(r"(?:async )?([A-Za-z_]\w*)\s*\(", body)
        if not name or name.group(1) == "removeList":
            continue
        if any(call in body for call in opens) and "mayLeaveTheList(" not in body:
            silent.append(name.group(1))
    equal(silent, [],
          "methods that replace the open list without asking about unsaved work")
    check("confirm(" in app_js.split("mayLeaveTheList(question)", 1)[1][:400],
          "and that one helper is the thing that asks")


def test_a_problem_in_another_list_can_be_reached(_project: Path) -> None:
    """A problem row opens the list it belongs to.  (Reported.)

    The check runs over every list of the build at once, so the panel shows
    what is wrong in lists that are not open - and clicking one of those did
    nothing at all, because the parameter it names is not in the list on
    screen.  Each row now carries the file it came from, and the click opens
    that list (asking first, like everything else that replaces what is open)
    and selects the row there.
    """
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")
    check("data-file=" in app_js, "a problem row says which file it is in")
    check("async goToProblem(" in app_js, "and there is something to take you there")

    handler = app_js.split("async goToProblem(", 1)[1].split("\n  },", 1)[0]
    for wanted in ("api.open(", "mayLeaveTheList(", "gridView.reveal("):
        check(wanted in handler, f"opening the other list goes through {wanted}")
    check("samePath(" in handler,
          "and two spellings of one path count as the same file")


def test_the_messages_name_this_machines_launcher(work: Path) -> None:
    """Whatever tells somebody how to start the tool names the launcher they have.

    run.bat on Windows, ./run.sh everywhere else.  The environment check told a
    Linux user to double-click run.bat and to type 'python run.py' - which only
    works from inside bin/, and on most Linux machines not at all: they have
    python3.  Both systems are tried here, whichever one this is.
    """
    import contextlib
    import io
    import subprocess

    import pl_codegen.app_home as app_home
    import setup_environment

    for launcher, other in (("run.bat", "./run.sh"), ("./run.sh", "run.bat")):
        shipped, app_home.LAUNCHER = app_home.LAUNCHER, launcher
        try:
            said = io.StringIO()
            with contextlib.redirect_stdout(said):
                setup_environment._print_footer()
        finally:
            app_home.LAUNCHER = shipped
        text = said.getvalue()
        check(f"{launcher} editor" in text, f"the check names {launcher}:\n{text}")
        check(other not in text and "python run.py" not in text,
              f"and nothing a {launcher} machine cannot run:\n{text}")

    # the launcher this machine is told about is one the app ships ...
    check((APP_DIR / Path(app_home.LAUNCHER).name).is_file(),
          f"{app_home.LAUNCHER} is in the app folder")
    # ... the menu's own --help says it ...
    shown = subprocess.run([sys.executable, str(APP_DIR / "bin" / "run.py"), "--help"],
                           capture_output=True, text=True).stdout
    check(f"{app_home.LAUNCHER} generate --check" in shown
          and "python run.py" not in shown, f"run.py --help names the launcher:\n{shown}")
    # ... and the editor's page is told it rather than naming one itself
    _document, api, _config = open_copy(work)
    equal(api.state({})["tool"]["launcher"], app_home.LAUNCHER,
          "the launcher the page is told")
    app_js = (APP_DIR / "src" / "pl_gui" / "web" / "app.js").read_text(encoding="utf-8")
    code = re.sub(r"/\*.*?\*/", "", app_js, flags=re.S)
    check("run.bat" not in code and "run.sh" not in code,
          "app.js names no launcher of its own; it shows state.tool.launcher")


def test_every_browser_path_can_exist(_project: Path) -> None:
    """Every place the editor looks for a browser is a place a browser can be.

    The three macOS paths once read "Google Chrome.pl_app/...": renaming the
    tool's own "app" folder to "pl_app" swept through them too, so a Mac never
    found a browser and the editor always opened as a plain tab.  A macOS
    program is a bundle whose name ends in ".app", and no browser's path has
    anything to do with this tool's folders.
    """
    from pl_gui.browser import BROWSER_PATHS

    wrong = [path for path in BROWSER_PATHS["darwin"]
             if not re.fullmatch(r"/Applications/[^/]+\.app/Contents/MacOS/[^/]+", path)]
    wrong += [path for paths in BROWSER_PATHS.values() for path in paths
              if "pl_app" in path]
    equal(wrong, [], "browser paths that no machine has")


def test_the_browser_can_always_write_its_errors(work: Path) -> None:
    """A browser that writes a lot of errors never hangs the editor's window.

    Its error output went to a pipe that nothing read once the window was up.
    A pipe holds 64 KB on Linux, and Chrome on Linux writes to stderr freely:
    past that, its next write blocked, and the window with it.  A stand-in
    browser here writes 300 KB of errors, then leaves a mark - it has to get
    that far, on either system.
    """
    import time

    import pl_gui.server as server

    mark = work / "wrote-everything"
    stand_in = ("import pathlib, sys, time\n"
                "time.sleep(2.5)\n"
                "sys.stderr.write('x' * 300 * 1024)\n"
                "sys.stderr.flush()\n"
                f"pathlib.Path({str(mark)!r}).write_text('done')\n"
                "time.sleep(1)\n")
    kept = server.find_browser, server.app_window_command
    server.find_browser = lambda: sys.executable
    server.app_window_command = lambda browser, url, profile: [browser, "-c", stand_in]
    try:
        gui = server.GuiServer(None, port=8765)
        check(gui._open_app_window(str(work)), "a browser still running counts as opened")
        give_up = time.time() + 20
        while not mark.exists() and time.time() < give_up:
            time.sleep(0.2)
    finally:
        server.find_browser, server.app_window_command = kept
    check(mark.exists(), "a browser writing 300 KB of errors was blocked")


def test_no_browser_says_so(work: Path) -> None:
    """With no browser to start, the editor says so and names the address.

    It said "opened in the default browser" whatever had happened, so on a
    machine with no browser at all (no desktop, WSL) the console claimed
    success while nothing appeared, and never said where the editor was.
    """
    import logging

    import pl_gui.server as server
    from pl_codegen.logging_utils import get_logger

    said: List[logging.LogRecord] = []
    catcher = logging.Handler()
    catcher.emit = said.append                     # type: ignore[assignment]
    logger = get_logger()
    level = logger.level
    kept = server.find_browser, server.webbrowser.open
    server.find_browser = lambda: None
    server.webbrowser.open = lambda url, *args, **kwargs: False
    logger.addHandler(catcher)
    logger.setLevel(logging.INFO)
    try:
        gui = server.GuiServer(None, port=8765)
        gui._open(True, str(work))
    finally:
        server.find_browser, server.webbrowser.open = kept
        logger.removeHandler(catcher)
        logger.setLevel(level)

    lines = [record.getMessage() for record in said]
    check(not any("opened in the default browser" in line for line in lines),
          f"it does not claim a browser it never started: {lines}")
    check(any(gui.url in record.getMessage() and record.levelno >= logging.WARNING
              for record in said),
          f"it names the address to open by hand: {lines}")


def test_a_workspace_keeps_to_its_own_settings_file(work: Path) -> None:
    """A workspace given a settings file of its own writes that one and no other.

    It took the file and used the app's anyway, so every test that opened a
    project wrote a temp folder into the user's pl_app/var/settings.json - and
    emptied their recent list whenever a project on it was not on disk.
    """
    import json

    from pl_codegen.app_home import SETTINGS_FILE

    before = SETTINGS_FILE.read_bytes() if SETTINGS_FILE.is_file() else None
    own = work / "own_settings.json"
    workspace = Workspace(own)
    project = workspace.create(work / "p", "P")
    workspace.open(project)
    workspace.recent()
    workspace.close()
    after = SETTINGS_FILE.read_bytes() if SETTINGS_FILE.is_file() else None
    recorded = json.loads(own.read_text(encoding="utf-8")).get("recent") if own.is_file() else []
    check(str(project.resolve()) in (recorded or []),
          f"the workspace's own file records the project: {recorded}")
    check(after == before, "and the app's settings file was not touched")


def test_the_project_file_is_plain_json(work: Path) -> None:
    """A project file the app writes opens in any JSON editor without an error.

    It used to be JSONC - a page of // comments and trailing commas, every one
    of them an error to a JSON editor - and the editor's own rewrite of the list
    array left a trailing comma behind even in a file with no comments at all.
    """
    import json

    def plain(path: Path) -> dict:
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except ValueError as error:
            raise Failure(f"{path.name} is not plain JSON: {error}")

    plain(PROJECT_TEMPLATE)
    workspace = Workspace(work / "settings.json")
    project = workspace.create(work / "p", "Plain")
    equal(plain(project)["project"]["name"], "Plain", "a new project is plain JSON")

    workspace.open(project)
    api = Api(workspace)
    for name in ("first", "second"):
        check(api.new_list({"name": name})["ok"], f"list {name} was not made")
    equal(plain(project)["inputs"]["model_files"], ["first.xml", "second.xml"],
          "and stays plain JSON when the editor writes the lists into it")

    table = workspace.create(work / "t", "Table", "param_table")
    equal(plain(table)["output"]["format"], "param_table",
          "a parameter-table project too, with its format set")


def test_a_free_tag_takes_a_number(work: Path) -> None:
    """A number typed into Tag1..Tag4 is a number, as it is read from the file.  (Asked for.)

    The box is text, so '7' arrived as the text '7', and the free-tag rule - a
    number or a C identifier - reported it as neither.  Only in the editor: the
    build read the saved file, got the number 7 and passed.
    """
    document, api, _config = open_copy(work)
    free = [spec.tag_id for spec in TAG_REGISTRY if spec.kind is TagKind.FREE]
    wanted = {tag_id: number for number, tag_id in enumerate(free, start=7)}

    def send(tag_id: str, text: str) -> None:
        node = next(item for item in api.state({})["tree"] if item["name"] == "Airspeed")
        changes = _as_the_form_sends(node)
        changes["tags"][tag_id] = text
        check(api.update({"path": "Airspeed", "changes": changes})["ok"],
              f"{tag_id} = {text!r} was refused")

    for tag_id, number in wanted.items():
        send(tag_id, str(number))
    problems = [item["message"] for item in api.state({})["diagnostics"]
                if item["code"] == "TAG005"]
    check(not problems, f"a number in a free tag is no problem: {problems}")
    equal({tag_id: document.find("Airspeed").tags[tag_id] for tag_id in free}, wanted,
          "the free tags hold numbers")

    api.save({})
    check(not api.state({})["dirty"], "saved, the list is not marked modified")
    read_back = read_xml(document.path, DiagnosticCollector()).parameters[0].tags
    equal({tag_id: read_back[tag_id] for tag_id in free}, wanted,
          "and the file gives the same numbers back")

    send("Tag1", "not one")
    check(any(item["code"] == "TAG005" for item in api.state({})["diagnostics"]),
          "text that is neither a number nor an identifier is still reported")


CASES: List[Tuple[str, Callable[[Path], None]]] = [
    ("structure types (the template library)", test_structure_types),
    ("arrays of structures", test_structure_arrays),
    ("the parameter lists of the project", test_parameter_lists),
    ("odd list selections", test_list_selection_edge_cases),
    ("a type belongs to its own list", test_a_type_belongs_to_its_list),
    ("the memory layout warning", test_layout_warning),
    ("no external dependency", test_no_external_dependency),
    ("every pane redraws after a change", test_every_pane_redraws),
    ("one name for one thing", test_one_name_for_one_thing),
    ("changing the value type", test_changing_the_value_type),
    ("a boolean keeps its shape", test_a_boolean_keeps_its_shape),
    ("only a project file opens", test_only_a_project_file_opens),
    ("no list, no parameter", test_no_list_no_parameter),
    ("opening a list already in the build", test_opening_a_list_already_in_the_build),
    ("the merged view names every row's list", test_the_merged_view_names_every_rows_list),
    ("one file shape for both formats", test_one_file_shape_for_both_formats),
    ("the output names lists from the project root",
     test_the_output_names_lists_from_the_project_root),
    ("the unsaved mark means different from the file",
     test_the_unsaved_mark_means_different_from_the_file),
    ("a row put somewhere new is brought into sight",
     test_a_row_put_somewhere_new_is_brought_into_sight),
    ("the shortcuts are bound to the key, not the letter",
     test_the_shortcuts_are_bound_to_the_key),
    ("the Address column comes before the description",
     test_the_address_column_comes_before_the_description),
    ("a project file with the old name still opens",
     test_a_project_file_with_the_old_name_still_opens),
    ("nothing replaces the open list in silence",
     test_nothing_replaces_the_open_list_in_silence),
    ("a problem in another list can be reached",
     test_a_problem_in_another_list_can_be_reached),
    ("a value has a description of its own",
     test_a_value_has_a_description_of_its_own),
    ("a field of a struct array too", test_a_field_of_a_struct_array_too),
    ("the grid selects one value", test_the_grid_selects_one_value),
    ("the messages name this machine's launcher",
     test_the_messages_name_this_machines_launcher),
    ("every browser path can exist", test_every_browser_path_can_exist),
    ("the browser can always write its errors",
     test_the_browser_can_always_write_its_errors),
    ("no browser says so", test_no_browser_says_so),
    ("a workspace keeps to its own settings file",
     test_a_workspace_keeps_to_its_own_settings_file),
    ("the project file is plain JSON", test_the_project_file_is_plain_json),
    ("a free tag takes a number", test_a_free_tag_takes_a_number),
    ("every drive can be reached", test_every_drive_can_be_reached),
    ("the dialogs offer the drives", test_the_dialogs_offer_the_drives),
]


def main() -> int:
    failures = 0
    width = max(len(name) for name, _case in CASES)
    for name, case in CASES:
        with tempfile.TemporaryDirectory(prefix="pl_editor_test_") as raw:
            try:
                case(Path(raw))
            except Failure as error:
                print(f"  [{paint('FAIL', BOLD + BRIGHT_RED)}] "
                      f"{name.ljust(width)}  {paint(str(error), BRIGHT_RED)}")
                failures += 1
                continue
            except Exception as error:               # noqa: BLE001 - report and go on
                print(f"  [ERROR] {name.ljust(width)}  {type(error).__name__}: {error}")
                failures += 1
                continue
        print(f"  [{paint('PASS', GREEN)}] {name}")

    print()
    if failures:
        print(paint(f"{failures} of {len(CASES)} editor case(s) FAILED.",
                    BOLD + BRIGHT_RED))
        return 1
    print(paint(f"All {len(CASES)} editor cases passed.", GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Builds ``cg_parameter_list_defines.h``.

Read ``generate()`` from top to bottom: it is the generated file, in order.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from ...model.defines import GENERATED_ENUMS
from ...model.tags import TAG_REGISTRY
from .file_builder import FileBuilder

BRIEF = "Quantities, parameter indices, tag offsets and generated enumerations."


class ParameterListDefinesHeader(FileBuilder):
    """``PARAMETER_LIST_QTY``, the indices, the tag offsets and the enums."""

    @property
    def file_name(self) -> str:
        return self.defines_header

    def generate(self) -> str:
        text = ""

        # ---- banner and guards -----------------------------------------
        text += self.banner.generate(self.file_name, BRIEF, self.generation_notes())
        text += "\n"
        text += self.guard.generate_open(self.guard_name)
        text += "\n"
        text += self.cpp.generate_open()
        text += "\n"

        # ---- includes ---------------------------------------------------
        text += self.marker.generate("Includes")
        text += self.include.generate("stdint.h", standard=True)
        text += "\n"

        # ---- exported defines -------------------------------------------
        text += self.marker.generate("Exported defines")

        text += self.comment.generate_line("Number of parameters in the parameter list")
        text += self.define.generate(self.quantity, f"({len(self.parameters)}U)",
                                     "Number of enabled parameters")
        text += "\n"

        text += self.comment.generate_line("Index of every parameter inside the parameter list")
        text += self.define.generate_aligned_block(self._index_entries())
        text += "\n"

        array_entries = self._array_size_entries()
        if array_entries:
            text += self.comment.generate_line("Array size of every array parameter")
            text += self.define.generate_aligned_block(array_entries)
            text += "\n"

        text += self.comment.generate_line("Total size used by every tag")
        text += self.define.generate_aligned_block(self._tag_total_entries())
        text += "\n"

        text += self.comment.generate_line("MemoryOffset of every parameter, per tag")
        text += self.define.generate_aligned_block(self._tag_offset_entries())
        text += "\n"

        # ---- exported macros / types ------------------------------------
        text += self.marker.generate("Exported macros")
        text += self.marker.generate("Exported types")
        text += self._generate_enums()

        # ---- the remaining empty sections -------------------------------
        text += self.marker.generate("Exported functions")
        text += self.marker.generate("Exported variables")
        text += "\n"

        # ---- closing guards and footer ----------------------------------
        text += self.cpp.generate_close()
        text += "\n"
        text += self.guard.generate_close(self.guard_name)
        text += "\n"
        text += self.footer.generate()
        return text

    # -- the four define blocks ------------------------------------------
    def _index_entries(self) -> List[Tuple[str, str, Optional[str]]]:
        entries: List[Tuple[str, str, Optional[str]]] = []
        for index, parameter in enumerate(self.parameters):
            comment = parameter.value_type_name or ""
            # Each element is its own index now, so the comment says which
            # element of which declaration it is rather than a count.
            if parameter.declared_array_size > 1:
                comment += f" (element {parameter.element_index}"                            f" of {parameter.declared_array_size})"
            unit = self.unit_of(parameter)
            if unit:
                comment += f" [{unit}]"
            entries.append((self.index_of(parameter), f"({index}U)", comment.strip() or None))
        return entries

    def _array_size_entries(self) -> List[Tuple[str, str, Optional[str]]]:
        # One macro per array DECLARATION: a top level parameter's own array, or
        # an array field of a structure TYPE - which every parameter of that type
        # shares, so 'Stest.alive' is declared once however many parameters use
        # 'Stest'.
        return [(self.array_size_of_name(declaration), f"({size}U)",
                 f"Number of elements of '{declaration}'")
                for declaration, size, _node in self.model.array_declarations()]

    def _tag_total_entries(self) -> List[Tuple[str, str, Optional[str]]]:
        entries: List[Tuple[str, str, Optional[str]]] = []
        for spec in TAG_REGISTRY:
            area = self.offsets.area(spec.tag_id)
            if area is None or not area.entries:
                continue
            entries.append((self.offset_total_of(spec.tag_id), f"({area.total}U)",
                            f"Bytes used by tag '{spec.tag_id}' "
                            f"({len(area.entries)} parameter(s))"))
        return entries

    def _tag_offset_entries(self) -> List[Tuple[str, str, Optional[str]]]:
        entries: List[Tuple[str, str, Optional[str]]] = []
        for spec in TAG_REGISTRY:
            area = self.offsets.area(spec.tag_id)
            if area is None:
                continue
            for entry in area.entries:
                entries.append((self.offset_of(spec.tag_id, entry.parameter),
                                f"({entry.offset}U)", f"{entry.size} byte(s)"))
        return entries

    # -- the generated enumerations ---------------------------------------
    def _generate_enums(self) -> str:
        text = ""
        for column, type_name in GENERATED_ENUMS.items():
            values = self.model.defines.get(column)
            if not values:
                continue
            text += self.comment.generate_doc(
                f"Values of the '{column}' list of the parameter list.")
            members = [(value, index) for index, value in enumerate(values)]
            text += self.enum.generate(type_name, members)
            text += "\n"
        return text

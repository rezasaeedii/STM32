"""The drop-down lists - the company's own vocabulary.

``SYSTEM NAMES``, ``PARAM MODES``, ``TYPE`` and ``VALUE TYPES`` are the four
lists the editor offers.  They belong to **the company**, not to any one
project: ``SYS_AC_POWER`` means the same thing in every project on the machine,
and a project that carried its own copy would drift from the others the first
time somebody added a sub-system to one of them.

So they live with the app, in ``pl_app/var/choices.json``, and every project on
the machine reads the same file.  The defaults ship in
``pl_app/templates/choices.json`` and are copied out on first use, which is what
makes "restore the company defaults" a real button rather than a promise.

A parameter list written before this still has its own ``<Defines>`` section;
it is read, and used to seed the app's file the first time, so nothing is lost
on the way over.  Nothing writes ``<Defines>`` back out any more.
"""

from __future__ import annotations

import json
from typing import Dict, List, Optional

from .app_home import TEMPLATES_DIR, VAR_DIR
from .model.defines import (COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES, COLUMN_TYPES,
                            COLUMN_VALUE_TYPES, Defines)
from .model.types import VALUE_TYPES

#: Where the machine's lists live once somebody has edited them.
CHOICES_FILE = VAR_DIR / "choices.json"

#: What ships with the app, and what "restore the defaults" goes back to.
CHOICES_TEMPLATE = TEMPLATES_DIR / "choices.json"

#: The four lists, and the key each has in the JSON file.
COLUMNS = {
    "paramTypes": COLUMN_TYPES,
    "systemNames": COLUMN_SYSTEM_NAMES,
    "paramModes": COLUMN_PARAM_MODES,
    "valueTypes": COLUMN_VALUE_TYPES,
}

#: The company's own, as a last resort: a machine whose template file has been
#: deleted still has to be able to open a project.
FALLBACK: Dict[str, List[str]] = {
    "paramTypes": ["MONITORING", "SETTING", "COMMAND"],
    "systemNames": ["SYS_UNKNOWN"],
    "paramModes": ["PARAM_MODE_USER"],
    "valueTypes": list(VALUE_TYPES),
}


def default_choices() -> Dict[str, List[str]]:
    """What the app ships with - the "restore the defaults" answer."""
    data = _read(CHOICES_TEMPLATE)
    return {key: list(data.get(key) or FALLBACK[key]) for key in COLUMNS}


def load_choices() -> Defines:
    """The machine's lists, as the model wants them.

    The user's file wins; the shipped template fills anything it does not
    mention, so a list added to the app later shows up without anybody having
    to re-save.
    """
    shipped = default_choices()
    mine = _read(CHOICES_FILE)

    defines = Defines()
    for key, column in COLUMNS.items():
        values = mine.get(key)
        if not isinstance(values, list) or not values:
            values = shipped[key]
        defines.values[column] = [str(item).strip() for item in values if str(item).strip()]
    return defines


def save_choices(defines: Defines) -> None:
    """Write the machine's lists back."""
    data = {key: list(defines.get(column)) for key, column in COLUMNS.items()}
    try:
        CHOICES_FILE.parent.mkdir(parents=True, exist_ok=True)
        CHOICES_FILE.write_text(json.dumps(data, indent=2) + "\n",
                                encoding="utf-8", newline="\n")
    except OSError:
        # A read-only app folder is somebody's deliberate choice.  It costs the
        # change, and the caller has already been told it was saved - so this
        # is the one place that has to stay quiet rather than crash the editor.
        pass


def seed_from(defines: Optional[Defines]) -> None:
    """Take a file's own ``<Defines>`` as the machine's, if it has none yet.

    The one-time hand-over: the first project opened on a machine that has
    never had a choices file gives it its lists, so nothing anybody had typed
    into a parameter list is lost when the lists moved to the app.
    """
    if CHOICES_FILE.is_file() or defines is None:
        return
    if not any(defines.get(column) for column in COLUMNS.values()):
        return

    shipped = default_choices()
    merged = Defines()
    for key, column in COLUMNS.items():
        merged.values[column] = list(defines.get(column)) or shipped[key]
    save_choices(merged)


def _read(path) -> Dict[str, object]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}

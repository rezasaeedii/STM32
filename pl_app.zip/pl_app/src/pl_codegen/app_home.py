"""Where the app is installed, and what ships with it.

The tool now has two halves that live in different places:

  * **the app** - this folder.  The editor, the generator, the tests, the
    manuals and the templates.  Installed once on a machine, shared by every
    project, and never written to while a project is being edited.
  * **a project** - a folder somewhere else entirely, holding one project file
    (``pl_project.json``), the parameter lists and the generated output.

Anything that belongs to the *app* is found from here, so a project never has
to know where the app was unpacked.  That is what lets a project folder be
moved, copied to another machine or e-mailed to somebody: nothing inside it
points outwards.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

#: The ``pl_app`` folder.  This module is ``pl_app/src/pl_codegen/app_home.py``, so
#: the app is three levels up.
APP_DIR = Path(__file__).resolve().parent.parent.parent

#: The code itself.  The entry points in ``bin/`` put this on the import path.
SRC_DIR = APP_DIR / "src"

#: The entry points - one small file per action, all behind the launcher.
BIN_DIR = APP_DIR / "bin"

#: What a person starts the tool with on THIS machine: ``run.bat`` on Windows,
#: its twin ``run.sh`` everywhere else.  A message that tells somebody how to
#: run something names this, never one of the two by hand - a Linux user told
#: to double-click run.bat has been told the one thing that cannot work there.
LAUNCHER = "run.bat" if os.name == "nt" else "./run.sh"

#: State the app writes: which projects were open recently.  Not shipped, and
#: safe to delete.
VAR_DIR = APP_DIR / "var"

#: The manuals and their sources.
DOCS_DIR = APP_DIR / "docs"

#: Files the app ships for projects to start from.
TEMPLATES_DIR = APP_DIR / "templates"

#: The C library a project is given a copy of: ``smart_data`` and
#: ``parameter_descriptor``.  It is the firmware's, not the tool's - the
#: generated code plugs into it - so every project owns its own copy and can
#: version it with the rest of its firmware.
LIB_TEMPLATE_DIR = TEMPLATES_DIR / "lib"

#: What that copy is called inside a project.
LIB_DIR_NAME = "lib"

#: The company's C file template (a VS Code snippet file).  Every project on a
#: machine uses the same one unless it names its own.
SNIPPET_FILE = TEMPLATES_DIR / "c.json"

#: The project file a new project is copied from.
PROJECT_TEMPLATE = TEMPLATES_DIR / "pl_project.json"

#: Name of the project file inside a project folder.  It carries the tool's
#: initials on purpose: a project folder is usually one corner of a much bigger
#: project, where a file called "project.json" says nothing about whose project
#: it is - and collides with the first thing anybody else puts there.
PROJECT_FILE_NAME = "pl_project.json"

#: What that file was called before.  A project written then opens exactly as
#: it did: renaming it is the owner's to do, not the tool's.
LEGACY_PROJECT_FILE_NAME = "project.json"

#: Both names, for "is this file a project file?".
PROJECT_FILES = (PROJECT_FILE_NAME, LEGACY_PROJECT_FILE_NAME)


def project_file_in(folder: Path) -> Path:
    """The project file of *folder*: the new name, or the old one if that is there.

    Everything that turns a FOLDER into a project file goes through here, so
    "the folder I dragged in" means the same thing to the editor, to the
    command line and to the Open dialog.  With neither file there the new name
    comes back, so the message that follows names the file a project needs.
    """
    folder = Path(folder)
    current = folder / PROJECT_FILE_NAME
    legacy = folder / LEGACY_PROJECT_FILE_NAME
    return legacy if not current.is_file() and legacy.is_file() else current


def default_snippet_file() -> Optional[Path]:
    """The app's C template, or ``None`` when it is not there.

    ``None`` rather than an error: the snippet file only decides the *layout*
    of the generated files, so a missing one is worth working without.  A
    project that names a snippet file of its own still gets an error when that
    one is missing, because there somebody asked for a specific file.
    """
    return SNIPPET_FILE if SNIPPET_FILE.is_file() else None


#: The editor's own state: which project is open, and which were open before.
#: It belongs to the app rather than to any project, and it is safe to delete -
#: the next start simply has an empty recent list.
SETTINGS_FILE = VAR_DIR / "settings.json"


def read_settings(path: Optional[Path] = None) -> Dict[str, Any]:
    """The app settings, or an empty dict for anything wrong with them.

    A convenience file must never stop the tool from starting, so a missing,
    unreadable or corrupted one costs the recent list and nothing else.
    *path* is for a caller with a settings file of its own - a test; the app
    always uses :data:`SETTINGS_FILE`.
    """
    try:
        data = json.loads(Path(path or SETTINGS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def write_settings(data: Dict[str, Any], path: Optional[Path] = None) -> None:
    """Write the app settings, shrugging off a read-only app folder."""
    target = Path(path or SETTINGS_FILE)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(data, indent=2) + "\n",
                          encoding="utf-8", newline="\n")
    except OSError:
        pass


def last_project() -> Optional[Path]:
    """The most recent project that is still on disk.

    This is what the generator falls back to when nobody says which project to
    build: somebody who has just been editing a project and asks for code
    means *that* project.
    """
    for item in read_settings().get("recent") or []:
        if not isinstance(item, str):
            continue
        path = Path(item)
        if path.is_file():
            return path
    return None


def project_name(project_file: Path) -> str:
    """The name inside a project file, or the folder's name when it has none.

    Reading it needs the JSONC loader, so it lives here rather than being done
    twice - once by the editor's recent list and once by the menu.
    """
    from .config import load_jsonc          # local: config imports this module

    try:
        data = load_jsonc(Path(project_file))
        name = (data.get("project") or {}).get("name")
        if name:
            return str(name)
    except Exception:      # noqa: BLE001 - a listing must never fail on one bad row
        pass
    return Path(project_file).parent.name


"""Where the app is installed, and what ships with it.

The tool now has two halves that live in different places:

  * **the app** - this folder.  The editor, the generator, the tests, the
    manuals and the templates.  Installed once on a machine, shared by every
    project, and never written to while a project is being edited.
  * **a project** - a folder somewhere else entirely, holding one project file
    (``project.json``), the parameter lists and the generated output.

Anything that belongs to the *app* is found from here, so a project never has
to know where the app was unpacked.  That is what lets a project folder be
moved, copied to another machine or e-mailed to somebody: nothing inside it
points outwards.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

#: The ``app`` folder.  This module is ``app/src/pl_codegen/app_home.py``, so
#: the app is three levels up.
APP_DIR = Path(__file__).resolve().parent.parent.parent

#: The code itself.  The entry points in ``bin/`` put this on the import path.
SRC_DIR = APP_DIR / "src"

#: The entry points - one small file per action, all behind ``run.bat``.
BIN_DIR = APP_DIR / "bin"

#: State the app writes: which projects were open recently.  Not shipped, and
#: safe to delete.
VAR_DIR = APP_DIR / "var"

#: The manuals and their sources.
DOCS_DIR = APP_DIR / "docs"

#: Files the app ships for projects to start from.
TEMPLATES_DIR = APP_DIR / "templates"

#: The C library a project is given a copy of: ``smart_data`` and
#: ``parameter_descriptor``.  It is the firmware's, not the tool's - the
#: generated code plugs into it - so every project owns its own copy and can
#: version it with the rest of its firmware.
LIB_TEMPLATE_DIR = TEMPLATES_DIR / "lib"

#: What that copy is called inside a project.
LIB_DIR_NAME = "lib"

#: The company's C file template (a VS Code snippet file).  Every project on a
#: machine uses the same one unless it names its own.
SNIPPET_FILE = TEMPLATES_DIR / "c.json"

#: The project file a new project is copied from.
PROJECT_TEMPLATE = TEMPLATES_DIR / "project.json"

#: Name of the project file inside a project folder.  A project may be called
#: anything, but this is what "New project" writes and what the Open dialog
#: looks for first.
PROJECT_FILE_NAME = "project.json"


def default_snippet_file() -> Optional[Path]:
    """The app's C template, or ``None`` when it is not there.

    ``None`` rather than an error: the snippet file only decides the *layout*
    of the generated files, so a missing one is worth working without.  A
    project that names a snippet file of its own still gets an error when that
    one is missing, because there somebody asked for a specific file.
    """
    return SNIPPET_FILE if SNIPPET_FILE.is_file() else None


#: The editor's own state: which project is open, and which were open before.
#: It belongs to the app rather than to any project, and it is safe to delete -
#: the next start simply has an empty recent list.
SETTINGS_FILE = VAR_DIR / "settings.json"


def read_settings() -> Dict[str, Any]:
    """The app settings, or an empty dict for anything wrong with them.

    A convenience file must never stop the tool from starting, so a missing,
    unreadable or corrupted one costs the recent list and nothing else.
    """
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def write_settings(data: Dict[str, Any]) -> None:
    """Write the app settings, shrugging off a read-only app folder."""
    try:
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_FILE.write_text(json.dumps(data, indent=2) + "\n",
                                 encoding="utf-8", newline="\n")
    except OSError:
        pass


def last_project() -> Optional[Path]:
    """The most recent project that is still on disk.

    This is what the generator falls back to when nobody says which project to
    build: somebody who has just been editing a project and asks for code
    means *that* project.
    """
    for item in read_settings().get("recent") or []:
        if not isinstance(item, str):
            continue
        path = Path(item)
        if path.is_file():
            return path
    return None


def project_name(project_file: Path) -> str:
    """The name inside a project file, or the folder's name when it has none.

    Reading it needs the JSONC loader, so it lives here rather than being done
    twice - once by the editor's recent list and once by the menu.
    """
    from .config import load_jsonc          # local: config imports this module

    try:
        data = load_jsonc(Path(project_file))
        name = (data.get("project") or {}).get("name")
        if name:
            return str(name)
    except Exception:      # noqa: BLE001 - a listing must never fail on one bad row
        pass
    return Path(project_file).parent.name


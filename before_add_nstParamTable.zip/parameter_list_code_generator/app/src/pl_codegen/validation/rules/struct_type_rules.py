"""Rules about structure types - the ``struct`` declarations of the list.

A structure parameter names a type, the way a C++ variable names one.  These
rules check that the name means something, that it means a *structure*, and
that the declarations themselves make sense.

The two rules people meet most are the pair that keep the two worlds apart: a
parameter holds a value and may not name a structure type, and a structure
holds fields and may not name ``float32_t``.  Both used to be possible, and
both produced a parameter list that looked right and generated nonsense.
"""

from __future__ import annotations

from typing import Dict, List, Set

from ...errors import DiagnosticCollector, SourceLocation
from ...model.parameter import Parameter
from ...model.parameter_list import ParameterList
from ...model.struct_type import StructType
from ...model.types import resolve_value_type, supported_type_names
from ...naming import is_valid_c_identifier
from .rule_base import ValidationRule, enabled_nodes


class StructTypeRule(ValidationRule):
    """Every structure names a structure type, and every type exists."""

    rule_id = "STRUCT_TYPE"
    description = "A structure must name a structure type that exists."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        for parameter in enabled_nodes(model):
            name = (parameter.value_type_name or "").strip()

            if parameter.is_struct:
                if not name:
                    diagnostics.error(
                        "TYP002",
                        f"Structure '{parameter.name}' has no structure type.",
                        parameter.source,
                        hint="Pick one in the 'Data type' list, or make one with "
                             "'Structure types…' in the settings menu.")
                    continue
                if resolve_value_type(name) is not None:
                    diagnostics.error(
                        "TYP005",
                        f"Structure '{parameter.name}' is of type '{name}', which is "
                        f"a data type and not a structure.",
                        parameter.source,
                        hint=f"A structure holds fields, not a value. Give '{name}' "
                             f"to a field instead, or make this parameter a plain "
                             f"parameter.")
                    continue
                if library.get(name) is None:
                    known = ", ".join(library.names()) or "none yet"
                    diagnostics.error(
                        "TYP003",
                        f"Structure '{parameter.name}' is of type '{name}', which "
                        f"this project does not have.",
                        parameter.source,
                        hint=f"Known structure types: {known}. The structures of a "
                             f"list live in the '_structures.xml' file beside it; "
                             f"check that file came along with the list.")
            elif name and library.get(name) is not None:
                diagnostics.error(
                    "TYP004",
                    f"'{parameter.name}' is a parameter but its data type "
                    f"'{name}' is a structure type.",
                    parameter.source,
                    hint=f"A parameter holds one value. Pick one of "
                         f"{supported_type_names()}, or add it as a structure "
                         f"instead.")


class StructTypeDeclarationRule(ValidationRule):
    """The declarations themselves: names, fields, and what the fields hold."""

    rule_id = "STRUCT_TYPE_DECL"
    description = "Structure type declarations must be usable as C typedefs."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        for struct_type in library.all():
            where = SourceLocation(parameter=struct_type.name)

            if not is_valid_c_identifier(struct_type.name):
                diagnostics.error(
                    "TYP006",
                    f"Structure type '{struct_type.name}' is not a valid C identifier.",
                    where,
                    hint="It becomes a typedef, so use letters, digits and '_', and "
                         "do not start with a digit.")

            if not struct_type.fields:
                diagnostics.error(
                    "TYP007",
                    f"Structure type '{struct_type.name}' has no fields.",
                    where,
                    hint="An empty struct generates a typedef nothing can be built "
                         "from. Add a field, or delete the type.")

            seen: Set[str] = set()
            for member in struct_type.fields:
                if member.name in seen:
                    diagnostics.error(
                        "TYP008",
                        f"Structure type '{struct_type.name}' has two fields called "
                        f"'{member.name}'.", where,
                        hint="Two members of one struct cannot share a name.")
                seen.add(member.name)

                if not member.value_type_name:
                    diagnostics.error(
                        "TYP009",
                        f"Field '{struct_type.name}.{member.name}' has no data type.",
                        where,
                        hint=f"Pick one of {supported_type_names()}, or another "
                             f"structure type.")
                elif (resolve_value_type(member.value_type_name) is None
                      and library.get(member.value_type_name) is None):
                    diagnostics.error(
                        "TYP013",
                        f"Field '{struct_type.name}.{member.name}' is of type "
                        f"'{member.value_type_name}', which is neither a data type "
                        f"nor a structure type.",
                        where,
                        hint=f"Known data types: {supported_type_names()}. Known "
                             f"structure types: {', '.join(library.names()) or 'none'}.")

                if member.array_size < 1:
                    diagnostics.error(
                        "TYP014",
                        f"Field '{struct_type.name}.{member.name}' has array size "
                        f"{member.array_size}; it must be 1 or more.", where,
                        hint="Leave the cell empty for a single value.")


class StructTypeCycleRule(ValidationRule):
    """A structure type may not contain itself, however far around."""

    rule_id = "STRUCT_TYPE_CYCLE"
    description = "Structure types must not contain themselves."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        for struct_type in library.all():
            path = _cycle_from(struct_type, library)
            if path:
                diagnostics.error(
                    "TYP015",
                    f"Structure type '{struct_type.name}' contains itself: "
                    f"{' -> '.join(path)}.",
                    SourceLocation(parameter=struct_type.name),
                    hint="A struct cannot hold a copy of itself - it would have no "
                         "size. Break the loop by removing one of those fields.")


class StructTypeClashRule(ValidationRule):
    """One name, two different structures, once the lists are merged."""

    rule_id = "STRUCT_TYPE_CLASH"
    description = "A structure type name must mean the same thing in every list."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for name in model.type_clashes:
            diagnostics.error(
                "TYP016",
                f"Two parameter lists of this project both declare a structure type "
                f"called '{name}', and the two are not the same structure.",
                SourceLocation(parameter=name),
                hint="Rename one of them. Two lists CAN share a type - that is how "
                     "a shared list brings its structures with it - but only while "
                     "they say the same thing.")


def _cycle_from(struct_type: StructType, library) -> List[str]:
    """The chain of type names that leads back to *struct_type*, if any."""
    target = struct_type.name

    def walk(current: StructType, chain: List[str], seen: Set[str]) -> List[str]:
        for member in current.fields:
            nested = library.get(member.value_type_name)
            if nested is None:
                continue
            if nested.name == target:
                return chain + [nested.name]
            if nested.name in seen:
                continue
            found = walk(nested, chain + [nested.name], seen | {nested.name})
            if found:
                return found
        return []

    return walk(struct_type, [target], {target})

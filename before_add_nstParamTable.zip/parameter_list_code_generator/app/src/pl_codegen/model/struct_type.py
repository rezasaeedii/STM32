"""Structure types - the ``struct`` declarations of the parameter list.

A structure type is exactly what it is in C++::

    struct Position {
        float64_t Lat;
        float64_t Lon;
        int16_t   Samples[8];
    };

It says **what fields there are, what they are called and what they hold**, and
nothing else.  Deliberately *not* part of a type:

  * minimum, maximum, default value, resolution - these are the range one
    particular value may take, and two parameters of the same type routinely
    want different ones.  A C++ struct declaration carries none of them either;
  * tags, the parameter type, the log id, the GS name - all of these describe a
    parameter, and a type is not a parameter.

That split is the whole point.  Before this, a "type" was a copy: pressing it
duplicated a structure's fields into a parameter and the two then had nothing
to do with each other, so adding a field to the type left every parameter
already built from it behind.  Now a parameter *names* its type, and changing
the type changes every parameter that names it.

Where they live
---------------
Next to every parameter list ``foo.xml`` is ``foo_structures.xml``, holding the
types that list uses.  That is what makes a list portable: hand the two files
to another project and the structures come with them.  The project keeps an
index of every type it knows next to the model its last build was made from.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Dict, List, Optional


@dataclass
class StructField:
    """One member of a structure type.

    ``value_type_name`` is a primitive (``float32_t``) or the name of another
    structure type - C++ allows both, and a list that already nests structures
    needs both.
    """

    name: str
    value_type_name: str = ""
    array_size: int = 1
    unit: Optional[str] = None
    description: Optional[str] = None

    def copy(self) -> "StructField":
        return replace(self)


@dataclass
class StructType:
    """A ``struct`` declaration: a name and the fields inside it."""

    name: str
    description: str = ""
    fields: List[StructField] = field(default_factory=list)

    def copy(self) -> "StructType":
        return StructType(name=self.name, description=self.description,
                          fields=[member.copy() for member in self.fields])

    def field_named(self, name: str) -> Optional[StructField]:
        return next((member for member in self.fields if member.name == name), None)

    @property
    def shape(self) -> tuple:
        """What this type *is*, for comparing two declarations of one name.

        Two lists may both carry a type called ``Position`` - that is normal,
        it is how a shared list brings its structures with it.  They are the
        same type as long as they say the same thing, and this is what "the
        same thing" means.  The description is left out: prose differing is not
        a different struct.
        """
        return tuple((member.name, member.value_type_name, member.array_size)
                     for member in self.fields)

    def __str__(self) -> str:      # pragma: no cover - debugging helper
        return f"StructType({self.name}, {len(self.fields)} field(s))"


class StructTypeLibrary:
    """The structure types one model knows, by name.

    A name identifies a type, so this is a mapping and not a list: defining
    ``Position`` twice is not two types, it is one type declared twice, and the
    second declaration either agrees with the first or is a mistake somebody
    has to be told about.
    """

    def __init__(self, types: Optional[List[StructType]] = None) -> None:
        self._types: Dict[str, StructType] = {}
        for struct_type in types or []:
            self._types[struct_type.name] = struct_type

    # -- reading -----------------------------------------------------------
    def __len__(self) -> int:
        return len(self._types)

    def __iter__(self):
        return iter(self.all())

    def __contains__(self, name: object) -> bool:
        return str(name) in self._types

    def all(self) -> List[StructType]:
        """Every type, in the order a person would look for one: by name."""
        return [self._types[name] for name in sorted(self._types)]

    def names(self) -> List[str]:
        return sorted(self._types)

    def get(self, name: Optional[str]) -> Optional[StructType]:
        return self._types.get(str(name)) if name else None

    # -- writing -----------------------------------------------------------
    def put(self, struct_type: StructType) -> None:
        """Add or replace one type."""
        self._types[struct_type.name] = struct_type

    def remove(self, name: str) -> bool:
        return self._types.pop(name, None) is not None

    def rename(self, old: str, new: str) -> bool:
        """Rename a type, keeping its place in the library."""
        struct_type = self._types.pop(old, None)
        if struct_type is None:
            return False
        struct_type.name = new
        self._types[new] = struct_type
        return True

    def copy(self) -> "StructTypeLibrary":
        return StructTypeLibrary([item.copy() for item in self.all()])

    # -- merging -----------------------------------------------------------
    def merge(self, other: "StructTypeLibrary") -> List[str]:
        """Take in *other*'s types; return the names that disagree.

        Two lists carrying a type of the same name is the ordinary case - a
        shared parameter list brings its structures with it, so both files hold
        ``Position``.  They are one type while they say the same thing.  A name
        that means two different structures is the real problem, and it is
        returned rather than resolved: only a person can say which one was
        meant.
        """
        clashes: List[str] = []
        for struct_type in other.all():
            mine = self._types.get(struct_type.name)
            if mine is None:
                self._types[struct_type.name] = struct_type.copy()
            elif mine.shape != struct_type.shape:
                clashes.append(struct_type.name)
        return clashes

    def uses_of(self, name: str) -> List[str]:
        """Which types have a field of type *name* - what a rename must follow."""
        return [item.name for item in self.all()
                if any(member.value_type_name == name for member in item.fields)]

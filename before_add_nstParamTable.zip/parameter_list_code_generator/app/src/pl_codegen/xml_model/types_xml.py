"""Reading and writing the structure types that sit next to a parameter list.

Every parameter list ``foo.xml`` has a ``foo_structures.xml`` beside it holding the
structure types that list uses.  The two travel together: hand both to another
project and its parameters keep their shape, which is the whole reason the
types are not buried inside the list file.

The project keeps an index of every type it knows next to the model its last
build was made from, written on every save.  That index is *derived* - the truth
is always the file next to the list - so deleting it costs nothing but the next
save rebuilds it.

The format is deliberately small::

    <ParameterListTypes schemaVersion="1.0" ...>
      <StructType name="Position" description="A place on the earth.">
        <Field name="Lat" valueType="float64_t" arraySize="1" unit="deg" />
        <Field name="Lon" valueType="float64_t" arraySize="1" unit="deg" />
      </StructType>
    </ParameterListTypes>

There is nothing here about limits, tags or log ids, because a type has none of
those - see :mod:`pl_codegen.model.struct_type`.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from .. import __tool_name__, __version__
from ..errors import CodeGeneratorError, DiagnosticCollector, SourceLocation
from ..model.struct_type import StructField, StructType, StructTypeLibrary
from . import schema as sch

#: ``power.xml`` -> ``power_structures.xml``.  Next to the list and named after
#: it, so the two sort together in a folder listing and neither can be mistaken
#: for the other.  One word, no dot: ``power.types.xml`` looked like a parameter
#: list called "power" with an odd extension, and every tool that sorts on the
#: extension put it somewhere surprising.
TYPES_SUFFIX = "_structures.xml"


def is_types_file(path: Path) -> bool:
    """Whether *path* is a structures file and not a parameter list.

    The two live in the same folder and share an extension, so everything that
    offers "the .xml files here" has to ask.  Without this the Open dialog
    listed ``navigation.types`` as a parameter list, and opening it failed with
    a message about a root element - which is true, and no help at all.
    """
    return str(path).lower().endswith(TYPES_SUFFIX)


def types_file_for(list_file: Path) -> Path:
    """The structures file that belongs beside *list_file*."""
    list_file = Path(list_file)
    return list_file.with_name(list_file.stem + TYPES_SUFFIX)


def read_types(path: Path, diagnostics: Optional[DiagnosticCollector] = None
               ) -> StructTypeLibrary:
    """Read one types file.  A file that is not there is an empty library.

    Missing is not an error: a list written before structure types existed
    simply has none, and a list with no structures in it never grows one.
    """
    path = Path(path)
    if not path.is_file():
        return StructTypeLibrary()

    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise CodeGeneratorError(f"'{path}' is not a valid XML file: {exc}") from exc

    if root.tag != sch.TYPES_ROOT:
        raise CodeGeneratorError(
            f"'{path}' is not a structure-type file (root element is '{root.tag}', "
            f"expected '{sch.TYPES_ROOT}').")

    library = StructTypeLibrary()
    for element in root.findall(sch.STRUCT_TYPE):
        name = (element.get(sch.ATTR_NAME) or "").strip()
        if not name:
            if diagnostics is not None:
                diagnostics.error(
                    "TYP010", "A <StructType> element has no 'name' attribute.",
                    SourceLocation(file=str(path)),
                    hint="A structure type is identified by its name; it becomes "
                         "the C typedef.")
            continue

        struct_type = StructType(name=name,
                                 description=element.get(sch.ATTR_DESCRIPTION) or "")
        for member_element in element.findall(sch.STRUCT_FIELD):
            member_name = (member_element.get(sch.ATTR_NAME) or "").strip()
            if not member_name:
                if diagnostics is not None:
                    diagnostics.error(
                        "TYP011", f"A field of '{name}' has no 'name' attribute.",
                        SourceLocation(file=str(path), parameter=name),
                        hint="Every field needs a name; it becomes a C member.")
                continue
            struct_type.fields.append(StructField(
                name=member_name,
                value_type_name=(member_element.get(sch.ATTR_DATA_TYPE) or "").strip(),
                array_size=_to_int(member_element.get(sch.ATTR_ARRAY_SIZE), 1),
                unit=member_element.get(sch.ATTR_UNIT) or None,
                description=member_element.get(sch.ATTR_DESCRIPTION) or None))

        if struct_type.name in library:
            if diagnostics is not None:
                diagnostics.error(
                    "TYP012",
                    f"'{struct_type.name}' is declared twice in this file.",
                    SourceLocation(file=str(path), parameter=struct_type.name),
                    hint="A name identifies one structure type. Rename one of them, "
                         "or delete the copy.")
            continue
        library.put(struct_type)
    return library


def write_types(library: StructTypeLibrary, path: Path, *,
                emit_timestamp: bool = True) -> Optional[Path]:
    """Write *library* to *path*.

    An empty library removes the file rather than leaving an empty one behind:
    a list with no structures should look like a list with no structures, and a
    stale file full of types nobody uses is exactly the thing that later gets
    copied somewhere and causes a name clash.
    """
    path = Path(path)
    if not len(library):
        if path.is_file():
            path.unlink()
        return None

    root = ET.Element(sch.TYPES_ROOT)
    root.set(sch.ATTR_SCHEMA_VERSION, sch.SCHEMA_VERSION)
    root.set(sch.ATTR_GENERATOR, __tool_name__)
    root.set(sch.ATTR_GENERATOR_VERSION, __version__)

    for struct_type in library.all():
        element = ET.SubElement(root, sch.STRUCT_TYPE, {sch.ATTR_NAME: struct_type.name})
        if struct_type.description:
            element.set(sch.ATTR_DESCRIPTION, struct_type.description)
        for member in struct_type.fields:
            attributes = {sch.ATTR_NAME: member.name,
                          sch.ATTR_DATA_TYPE: member.value_type_name or ""}
            if member.array_size and member.array_size != 1:
                attributes[sch.ATTR_ARRAY_SIZE] = str(member.array_size)
            if member.unit:
                attributes[sch.ATTR_UNIT] = member.unit
            if member.description:
                attributes[sch.ATTR_DESCRIPTION] = member.description
            ET.SubElement(element, sch.STRUCT_FIELD, attributes)

    _indent(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
    return path


def _to_int(raw: Optional[str], default: int) -> int:
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return default


def _indent(element: ET.Element, level: int = 0, indent: str = "  ") -> None:
    padding = "\n" + level * indent
    if len(element):
        if not (element.text or "").strip():
            element.text = padding + indent
        for child in element:
            _indent(child, level + 1, indent)
        if not (element.tail or "").strip():
            element.tail = padding
        if not (element[-1].tail or "").strip():
            element[-1].tail = padding
    elif level and not (element.tail or "").strip():
        element.tail = padding

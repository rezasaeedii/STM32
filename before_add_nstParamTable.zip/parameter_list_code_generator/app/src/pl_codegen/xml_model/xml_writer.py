"""Model -> XML.

The XML file is the stable intermediate representation: the code generator only
ever reads *this*, and never whatever wrote it.
Producing a file in this format is therefore the whole contract a front end has
to meet.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .. import __tool_name__, __version__
from ..model.parameter import Parameter, ParameterKind
from ..model.parameter_list import ParameterList
from ..model.tags import TAG_REGISTRY
from . import schema as sch
from .types_xml import types_file_for, write_types


def _text(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return repr(value)
    return str(value)


def _set(element: ET.Element, name: str, value: object) -> None:
    """Set an attribute unless the value is ``None``."""
    if value is not None:
        element.set(name, _text(value))


def model_to_element(model: ParameterList, *, emit_timestamp: bool = True,
                     home: Optional[Path] = None) -> ET.Element:
    """Build the XML tree of *model*.

    *home* is the file the tree is about to be written to, and it is what
    makes a parameter list **portable**.  Without it every parameter carried
    the absolute path of the machine it was last saved on; move the project
    folder - which is the whole point of a project being a folder - and every
    diagnostic then named a file that was no longer there.
    """
    root = ET.Element(sch.ROOT)
    root.set(sch.ATTR_SCHEMA_VERSION, sch.SCHEMA_VERSION)
    root.set(sch.ATTR_GENERATOR, __tool_name__)
    root.set(sch.ATTR_GENERATOR_VERSION, __version__)
    if emit_timestamp:
        stamp = model.generated_at or datetime.now(timezone.utc).astimezone().isoformat(
            timespec="seconds")
        root.set(sch.ATTR_GENERATED_AT, stamp)

    files_element = ET.SubElement(root, sch.SOURCE_FILES)
    for path in model.source_files:
        ET.SubElement(files_element, sch.SOURCE_FILE, {sch.ATTR_PATH: path})

    # <Defines> is deliberately not written any more.  The drop-down lists are
    # the machine's (app/var/choices.json), so a copy in every parameter list
    # would be four copies of one thing, drifting apart the first time somebody
    # added a sub-system to one project.  Old files keep theirs until saved.

    parameters_element = ET.SubElement(root, sch.PARAMETERS)
    for parameter in model.parameters:
        parameters_element.append(_parameter_to_element(parameter, home))

    return root


def _parameter_to_element(parameter: Parameter,
                          home: Optional[Path] = None) -> ET.Element:
    element = ET.Element(sch.PARAMETER)
    _set(element, sch.ATTR_NAME, parameter.name)
    _set(element, sch.ATTR_KIND, parameter.kind.value)
    _set(element, sch.ATTR_ENABLE, parameter.enable)
    _set(element, sch.ATTR_GS_NAME, parameter.gs_name)
    _set(element, sch.ATTR_TYPE, parameter.param_type)
    _set(element, sch.ATTR_DATA_TYPE, parameter.value_type_name)
    _set(element, sch.ATTR_ARRAY_SIZE, parameter.array_size)
    _set(element, sch.ATTR_UNIT, parameter.unit)
    # Not inside <Tags>: the log id is not a tag.
    _set(element, sch.ATTR_LOG_ID, parameter.log_id)

    source = ET.SubElement(element, sch.SOURCE)
    _set(source, sch.ATTR_FILE, _source_file(parameter.source.file, home))
    _set(source, sch.ATTR_SHEET, parameter.source.sheet)
    _set(source, sch.ATTR_ROW, parameter.source.row)

    limits = ET.SubElement(element, sch.LIMITS)
    _set(limits, sch.ATTR_DEFAULT, parameter.default_value)
    _set(limits, sch.ATTR_MINIMUM, parameter.minimum)
    _set(limits, sch.ATTR_MAXIMUM, parameter.maximum)
    _set(limits, sch.ATTR_RESOLUTION, parameter.resolution)

    tags = ET.SubElement(element, sch.TAGS)
    for spec in TAG_REGISTRY:
        value = parameter.tags.get(spec.tag_id)
        if value is None:
            continue
        tag_element = ET.SubElement(tags, sch.TAG)
        tag_element.set(sch.ATTR_ID, spec.tag_id)
        tag_element.set(sch.ATTR_KIND, spec.kind.value)
        tag_element.set(sch.ATTR_VALUE, _text(value))

    if parameter.description:
        ET.SubElement(element, sch.DESCRIPTION).text = parameter.description

    if parameter.kind is ParameterKind.STRUCT:
        fields = ET.SubElement(element, sch.FIELDS)
        for child in parameter.children:
            fields.append(_parameter_to_element(child, home))

    return element


def _source_file(file: Optional[str], home: Optional[Path]) -> Optional[str]:
    """What to write in ``<Source file="...">``, if anything.

    Nothing at all when the parameter comes from the very file being written,
    which is the ordinary case: the reader already falls back to the file it
    is reading, so the attribute would only repeat it - in absolute form, and
    wrongly as soon as the folder moved.

    A parameter that really did come from somewhere else keeps its origin, as
    a path relative to the file being written when that is possible.  A list
    on another drive keeps its absolute path, because there is no relative
    path to write.
    """
    if not file or home is None:
        return file

    try:
        source = Path(file).expanduser()
        if not source.is_absolute():
            source = (home.parent / source)
        source = source.resolve()
        if source == home.resolve():
            return None
        return str(source.relative_to(home.resolve().parent))
    except (OSError, ValueError):
        # ValueError: not under the same folder - keep what we were given.
        return file


def write_xml(model: ParameterList, path: Path, *, emit_timestamp: bool = True) -> Path:
    """Write *model* to *path*, and its structure types beside it.

    The two are written together on purpose.  A list whose types file was left
    behind is a list whose parameters have no shape, so there is no moment at
    which only one of them is on disk.
    """
    path = Path(path)
    root = model_to_element(model, emit_timestamp=emit_timestamp, home=path)
    _indent(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)

    # Every type of THIS list - the ones its parameters use and the ones
    # declared while it was open.  Writing only the used ones threw away a type
    # somebody had just declared and had not placed yet, which is the shortest
    # possible route from "I made a struct" to "where did it go?".
    write_types(model.struct_types, types_file_for(path), emit_timestamp=emit_timestamp)
    return path


def _indent(element: ET.Element, level: int = 0, indent: str = "  ") -> None:
    """``ET.indent`` replacement that also works on Python 3.8."""
    padding = "\n" + level * indent
    if len(element):
        if not (element.text or "").strip():
            element.text = padding + indent
        for child in element:
            _indent(child, level + 1, indent)
        last: Optional[ET.Element] = element[-1]
        if last is not None and not (last.tail or "").strip():
            last.tail = padding
    if level and not (element.tail or "").strip():
        element.tail = padding

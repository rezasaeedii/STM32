# -*- coding: utf-8 -*-
"""Rebuild the parts of the appendix that must never disagree with the code.

Five tables in the appendix are pure facts about the tool: the validation
rules, the diagnostic codes, the data types, the tags and the configuration
keys.  They used to be written by hand, and every one of them was wrong within
a month - a rule renamed here, a code added there, and the manual quietly
started lying.

So they are generated instead, from the very registries the tool itself uses:

  * the rules from ``ALL_RULES``;
  * the diagnostic codes by reading every ``diagnostics.xxx("CODE", ...)`` call
    in the source, which is the only place a code can come from;
  * the data types from ``VALUE_TYPES``;
  * the tags from ``TAG_REGISTRY`` - which is also what keeps the "LogID is not
    a tag" line true: it is not in that registry, so it cannot appear in the
    table by accident;
  * the configuration keys from the ``Config`` dataclasses, so a setting the tool
    does not have can never be documented as if it did.

Each generated table sits between a pair of markers in the HTML, so the prose
around them stays hand-written:

    <!-- GEN:rules -->  ...generated...  <!-- /GEN:rules -->

    cd docs/manual_source
    python build_appendix.py
"""

from __future__ import annotations

import dataclasses
import html
import re
import sys
from pathlib import Path
from typing import Dict, List

HERE = Path(__file__).resolve().parent
APP = HERE.parent.parent          # docs/ lives inside app/
TOOLS = APP / 'src'
APPENDIX = HERE / "parts" / "p08_appendix.html"

sys.path.insert(0, str(TOOLS))

from pl_codegen.config import (CodegenConfig, InputConfig,          # noqa: E402
                                      OutputConfig, ProjectConfig, StyleConfig,
                                      ValidationConfig)
from pl_codegen.model.tags import (LOG_ID_FIELD, LOG_ID_LABEL,     # noqa: E402
                                          TAG_REGISTRY)
from pl_codegen.model.types import VALUE_TYPES          # noqa: E402
from pl_codegen.validation.rules import ALL_RULES      # noqa: E402

#: 'diagnostics.error("NAME001", ...)' and the info/warning spellings of it
CODE_CALL = re.compile(r'\.(?:error|warning|info)\(\s*"([A-Z]{3,8}\d{3})"')

#: what each code prefix is about, for the second table
FAMILIES = {
    "ARR": "آرایه",
    "DEF": "لیست‌های کشویی",
    "GRP": "گروه",
    "META": "توضیحات و واحد",
    "NAME": "نام‌ها",
    "RNG": "مقادیر و بازه",
    "STR": "استراکچر",
    "TAG": "تگ‌ها",
    "TYP": "تایپ‌های استراکچری",
    "TYPE": "تایپ داده",
    "VAL": "کلی",
    "XML": "مدل XML",
}


def esc(text: object) -> str:
    return html.escape(str(text), quote=False)


def ltr(text: object) -> str:
    """English text inside a right-to-left page needs its own direction."""
    return f'<span class="ltr">{esc(text)}</span>'


def rules_table() -> str:
    rows = ['<table><tr><th class="c" style="width:7%">#</th>'
            '<th style="width:26%">کلاس</th><th style="width:20%">rule_id</th>'
            '<th>کار</th></tr>']
    for number, rule in enumerate(ALL_RULES, start=1):
        rows.append(f'<tr><td class="c">{number}</td>'
                    f'<td class="mono">{esc(type(rule).__name__)}</td>'
                    f'<td class="mono">{esc(rule.rule_id)}</td>'
                    f'<td>{ltr(rule.description)}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def codes_by_family() -> Dict[str, List[str]]:
    found: Dict[str, set] = {}
    for path in sorted(TOOLS.rglob("*.py")):
        if "__pycache__" in path.parts or path.parts[-2:-1] == ("tests",):
            continue
        for code in CODE_CALL.findall(path.read_text(encoding="utf-8", errors="ignore")):
            prefix = re.match(r"[A-Z]+", code).group(0)
            found.setdefault(prefix, set()).add(code)
    return {prefix: sorted(codes) for prefix, codes in sorted(found.items())}


def codes_table() -> str:
    families = codes_by_family()
    total = sum(len(codes) for codes in families.values())
    rows = [f'<p>در مجموع <b>{total}</b> کد، مستقیم از سورس بیرون کشیده شده. '
            f'اگر کد تازه‌ای اضافه کردید کافی است <code>python build_appendix.py</code> '
            f'را دوباره اجرا کنید.</p>',
            '<table><tr><th style="width:16%">پیشوند</th>'
            '<th style="width:26%">دسته</th><th>کدها</th></tr>']
    for prefix, codes in families.items():
        rows.append(f'<tr><td class="mono">{esc(prefix)}</td>'
                    f'<td>{esc(FAMILIES.get(prefix, "—"))}</td>'
                    f'<td class="mono">{esc(", ".join(codes))}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def types_table() -> str:
    rows = ['<table><tr><th>نام C</th><th>پسوند</th><th class="c">بایت</th>'
            '<th>ساختار</th><th>سازنده</th><th class="c">بازه</th>'
            '<th>پسوند لیترال</th><th>Resolution پیش‌فرض</th></tr>']
    for name, value_type in VALUE_TYPES.items():
        has_range = "—" if value_type.is_bool else "دارد"
        rows.append(f'<tr><td class="mono">{esc(name)}</td>'
                    f'<td class="mono">{esc(value_type.suffix)}</td>'
                    f'<td class="c">{value_type.value_size}</td>'
                    f'<td class="mono">{esc(value_type.smart_data_struct)}</td>'
                    f'<td class="mono">{esc(value_type.constructor)}</td>'
                    f'<td class="c">{has_range}</td>'
                    f'<td class="mono">{esc(value_type.literal_suffix or "—")}</td>'
                    f'<td class="mono">{esc(value_type.default_resolution)}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def tags_table() -> str:
    """The tags, plus the one field that deliberately is not one.

    The log id is listed underneath rather than left out: a reader who does not
    find it here concludes the manual forgot it, so the table says instead that
    it is not a tag and why.
    """
    rows = ['<table><tr><th>tag_id</th><th>برچسب در ویرایشگر</th>'
            '<th>فیلد descriptor</th><th class="c">نوع</th>'
            '<th class="c">اجباری</th><th>لیست کشویی</th></tr>']
    for spec in TAG_REGISTRY:
        rows.append(f'<tr><td class="mono">{esc(spec.tag_id)}</td>'
                    f'<td class="mono">{esc(spec.label)}</td>'
                    f'<td class="mono">{esc(spec.descriptor_field)}</td>'
                    f'<td class="c mono">{esc(spec.kind.value)}</td>'
                    f'<td class="c">{"بله" if spec.mandatory else "—"}</td>'
                    f'<td class="mono">{esc(spec.defines_column or "—")}</td></tr>')
    rows.append('<tr class="notatag"><td class="mono">—</td>'
                f'<td class="mono">{esc(LOG_ID_LABEL)}</td>'
                f'<td class="mono">{esc(LOG_ID_FIELD)}</td>'
                '<td class="c mono">uint16_t</td><td class="c">—</td>'
                '<td class="mono">—</td></tr>')
    rows.append("</table>")
    rows.append('<p class="small"><b>سطر آخر تگ نیست.</b> شناسه‌ی لاگ نه ناحیه‌ی '
                'آفست دارد و نه جفت <code>{Value, MemoryOffset}</code>؛ یک '
                '<code>uint16_t</code> ساده در شناسنامه است و فقط تا وقتی معنا '
                'دارد که <code>Tag Loggable</code> برابر <code>TRUE</code> باشد. '
                'به همین دلیل تنها فیلدی است که پیشوند <code>Tag</code> نمی‌گیرد.</p>')
    return "\n".join(rows)


#: The sections of a project file, in the order they appear in it.
CONFIG_SECTIONS = (
    ("project", ProjectConfig),
    ("inputs", InputConfig),
    ("output", OutputConfig),
    ("style", StyleConfig),
    ("codegen", CodegenConfig),
    ("validation", ValidationConfig),
)


def config_table() -> str:
    """Every configuration key, read off the dataclasses that accept them."""
    rows = ['<table><tr><th style="width:16%">بخش</th><th style="width:30%">کلید</th>'
            '<th style="width:22%">نوع</th><th>پیش‌فرض</th></tr>']
    for section, cls in CONFIG_SECTIONS:
        for name, spec in cls.__dataclass_fields__.items():
            default = spec.default
            if default is dataclasses.MISSING:
                factory = spec.default_factory
                default = factory() if factory is not dataclasses.MISSING else None
            rows.append(f'<tr><td class="mono">{esc(section)}</td>'
                        f'<td class="mono">{esc(name)}</td>'
                        f'<td class="mono">{esc(_type_name(spec.type))}</td>'
                        f'<td class="mono">{esc(_default_text(default))}</td></tr>')
    rows.append("</table>")
    return "\n".join(rows)


def _default_text(value: object) -> str:
    """A default as the reader would type it into project.json.

    Paths are printed with forward slashes and lists without their Python
    repr: the manual is read on the machine the tool runs on, and
    ``[WindowsPath('../parameter_list.xml')]`` tells nobody what to write.
    """
    if value is None or value == "" or value == []:
        return "—"
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, (list, tuple)):
        return ", ".join(_default_text(item) for item in value)
    return str(value)


def _type_name(annotation: object) -> str:
    """The annotation as it is written in the source, without the module path."""
    text = annotation if isinstance(annotation, str) else getattr(
        annotation, "__name__", str(annotation))
    return text.replace("typing.", "").replace("pathlib.", "")


def splice(text: str, name: str, body: str) -> str:
    """Replace what is between ``<!-- GEN:name -->`` and its closing marker."""
    pattern = re.compile(rf"(<!-- GEN:{name} -->).*?(<!-- /GEN:{name} -->)", re.S)
    if not pattern.search(text):
        raise SystemExit(f"the '{name}' markers are missing from {APPENDIX.name}")
    return pattern.sub(lambda m: f"{m.group(1)}\n{body}\n{m.group(2)}", text)


def main() -> int:
    text = APPENDIX.read_text(encoding="utf-8")
    text = splice(text, "rules", rules_table())
    text = splice(text, "codes", codes_table())
    text = splice(text, "types", types_table())
    text = splice(text, "tags", tags_table())
    text = splice(text, "configkeys", config_table())
    APPENDIX.write_text(text, encoding="utf-8")

    keys = sum(len(cls.__dataclass_fields__) for _section, cls in CONFIG_SECTIONS)
    families = codes_by_family()
    print(f"appendix rebuilt: {len(ALL_RULES)} rules, "
          f"{sum(len(c) for c in families.values())} diagnostic codes, "
          f"{len(VALUE_TYPES)} data types, {len(TAG_REGISTRY)} tags, "
          f"{keys} configuration keys")
    unknown = [p for p in families if p not in FAMILIES]
    if unknown:
        print("  note: no Persian name for the code prefix(es):", ", ".join(unknown))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Extract a complete, accurate API inventory of every Python file of the app.

The developer manual documents every class, function and constant the tool has,
and this is where that list comes from: the code itself, read with ``ast``.  A
manual written by hand goes stale the first time somebody renames a method; this
one cannot, because it is rebuilt from the source every time.

    cd docs/manual_source
    python inventory.py        # -> api.json
"""
import ast, json, sys
from pathlib import Path

#: this file is 'docs/manual_source/inventory.py', so the project is two up
HERE = Path(__file__).resolve().parent
APP = HERE.parent.parent          # docs/ lives inside app/
ROOT = APP                        # bin/, src/ and tests/ are all documented

def sig(node):
    a = node.args
    parts = []
    pos = a.posonlyargs + a.args
    defaults = [None] * (len(pos) - len(a.defaults)) + list(a.defaults)
    for arg, d in zip(pos, defaults):
        s = arg.arg
        if arg.annotation is not None:
            s += ": " + ast.unparse(arg.annotation)
        if d is not None:
            s += " = " + ast.unparse(d)
        parts.append(s)
    if a.vararg: parts.append("*" + a.vararg.arg)
    if a.kwonlyargs:
        if not a.vararg: parts.append("*")
        for arg, d in zip(a.kwonlyargs, a.kw_defaults):
            s = arg.arg
            if arg.annotation is not None: s += ": " + ast.unparse(arg.annotation)
            if d is not None: s += " = " + ast.unparse(d)
            parts.append(s)
    if a.kwarg: parts.append("**" + a.kwarg.arg)
    out = f"{node.name}({', '.join(parts)})"
    if node.returns is not None:
        out += " -> " + ast.unparse(node.returns)
    return out

def summary(node):
    d = ast.get_docstring(node)
    if not d: return ""
    return " ".join(d.split("\n\n")[0].split())

def decorators(node):
    return [ast.unparse(d) for d in node.decorator_list]

def walk(path):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    # as_posix(), not str(): on Windows str() gives backslashes, and every
    # lookup elsewhere - render.py, and the keys of every notes_*.py - is
    # written with forward slashes.  Building the manual on Windows died with
    # a KeyError on the first file until this was made platform independent.
    info = {"path": path.relative_to(ROOT).as_posix(),
            "lines": len(path.read_text(encoding='utf-8').splitlines()),
            "doc": summary(tree), "classes": [], "functions": [], "constants": []}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            cls = {"name": node.name, "doc": summary(node),
                   "bases": [ast.unparse(b) for b in node.bases],
                   "decorators": decorators(node), "members": [], "fields": []}
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    cls["members"].append({"sig": sig(sub), "doc": summary(sub),
                                           "decorators": decorators(sub),
                                           "private": sub.name.startswith("_") and
                                                      not sub.name.startswith("__")})
                elif isinstance(sub, ast.AnnAssign) and isinstance(sub.target, ast.Name):
                    cls["fields"].append({
                        "name": sub.target.id,
                        "type": ast.unparse(sub.annotation),
                        "default": ast.unparse(sub.value) if sub.value is not None else None})
                elif isinstance(sub, ast.Assign):
                    for t in sub.targets:
                        if isinstance(t, ast.Name):
                            cls["fields"].append({"name": t.id, "type": "",
                                                  "default": ast.unparse(sub.value)})
            info["classes"].append(cls)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            info["functions"].append({"sig": sig(node), "doc": summary(node),
                                      "decorators": decorators(node),
                                      "private": node.name.startswith("_")})
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                if isinstance(t, ast.Name) and (t.id.isupper() or t.id.startswith("__")):
                    val = ast.unparse(node.value) if node.value is not None else ""
                    info["constants"].append({"name": t.id,
                                              "value": val if len(val) < 160 else val[:157] + "..."})
    return info

# docs/ is the manual's own build, which lives inside the app folder now.
# It is not part of the tool and the manual does not document it, so it is
# left out of the inventory rather than sitting unused in api.json.
# docs/ is the manual's own build, which lives inside the app folder. It is
# not part of the tool and the manual does not document it, so it is left out
# rather than sitting unused in api.json.  Paths are kept relative to app/ -
# "src/pl_codegen/cli.py" says where the file really is.
files = sorted(p for p in ROOT.rglob("*.py")
               if "__pycache__" not in p.parts and "docs" not in p.parts)
data = [walk(p) for p in files]
(HERE / 'api.json').write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
print(f"{len(data)} python files")
print("classes:", sum(len(d['classes']) for d in data),
      "| module functions:", sum(len(d['functions']) for d in data),
      "| methods:", sum(len(c['members']) for d in data for c in d['classes']))

# Parameter list code generator — the app

Edit a project's parameter lists in a browser, generate its `.c` / `.h` files.
Nothing is installed: the Python standard library only, because the machines
this runs on are offline.

This folder is the **app**. It is copied once onto a machine and never changes
while you work. The lists, the C library and the generated code belong to a
**project**, which is a folder somewhere else with a `project.json` in it.

**Start here:** double-click **`run.bat`** — the only thing in this folder you
ever run. It asks what you want:

| | |
|---|---|
| `1` | **Editor** — open a project and edit its parameter lists |
| `2` | **Generate code** — write the C files of the project opened last |
| `3` | **Tests** — run every self test of the tool |
| `4` | **Check this PC** — is the Python here complete enough? (run once) |

Or say it up front, from `run.bat` or a terminal:

```
run.bat tests
run.bat editor ..\projects\demo
run.bat generate -c ..\projects\demo --check
```

Anything after the action is passed on to it; each one also has its own
`--help`.

In the editor: `Ctrl+S` saves, `Ctrl+G` generates. **Project ▾** in the top bar
opens, creates and closes projects; **Structure types…** declares the `struct`
types the parameters are built from.

A **project** is a folder with a `project.json` in it — the lists it builds, in
what order, where its C goes, and its own copy of the C library. Every path in
it is relative to the file itself, so the folder can be moved or handed on. Each
parameter list `foo.xml` carries its structure types beside it in
`foo_structures.xml`, so a list can be taken into another project intact.

| folder | what is in it |
|---|---|
| `bin/` | the entry points — one small file per action |
| `src/` | the code: `pl_codegen/` (the generator) and `pl_gui/` (the editor) |
| `tests/` | the tool's own tests |
| `templates/` | what a new project is made of: `project.json`, `c.json`, `lib/`, and the company `choices.json` |
| `docs/` | the two Persian manuals, their sources, and the C usage example |
| `var/` | what the app writes: recent projects, and this machine's drop-down lists |

`templates/lib/` is the reference copy of the C library the generated code
plugs into. Every project gets its own copy of it, so a project versions the
library with the rest of its firmware.

The four drop-down lists (system names, parameter modes, types, data types) are
the **company's**, not a project's: they live in `var/choices.json` and every
project on this machine reads the same one.

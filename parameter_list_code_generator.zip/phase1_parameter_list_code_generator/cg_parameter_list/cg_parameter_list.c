/**
  ******************************************************************************
  * @file    cg_parameter_list.c
  * @brief   Generated parameter list and its access functions.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v1.0.0
  * Generated at   : 2026-08-31 00:18:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase1_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 5 enabled, 2 disabled
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_parameter_list.h"

#include <stddef.h>
#include <string.h>

#include "smart_data.h"
#include "cg_smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
/**
 * @brief Descriptor of every parameter of the merged parameter list. The order of the entries matches the index macros of 'cg_parameter_list_defines.h'.
 *
 */
const sParameterDescriptor ParameterList[PARAMETER_LIST_QTY] = {
    /* [0] POS_DRONE */
    {
        .pName = "PosDrone",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_PosDrone,
        .ArraySize = 1U,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_GS_COMPUTER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POS_DRONE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POS_DRONE },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POS_DRONE },
        .TagLogId = { .Value = 100U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POS_DRONE },
        .TagLogEncryption = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ENCRYPTION_POS_DRONE },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POS_DRONE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "A boolean: no minimum, maximum or resolution."
    },

    /* [1] VEL_DRONE */
    {
        .pName = "VelDrone",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_VelDrone[0],
        .ArraySize = VEL_DRONE_ARRAY_SIZE,
        .pUnit = "m/s",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_VEL_DRONE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_VEL_DRONE },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_VEL_DRONE },
        .TagLogId = { .Value = 104U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_VEL_DRONE },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_VEL_DRONE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "An array of 6 values; it reserves 6 x 8 = 48 log ids (104 .. 151)."
    },

    /* [2] ALTITUDE */
    {
        .pName = "Altitude",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Altitude,
        .ArraySize = 1U,
        .pUnit = "m",
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_ALTITUDE },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_ALTITUDE },
        .TagLogId = { .Value = 152U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_ALTITUDE },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_ALTITUDE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "The first free log id after VelDrone is 152."
    },

    /* [3] FULL_RANGE */
    {
        .pName = "FullRange",
        .Group = ePARAMETER_GROUP_SETTING,
        .pSmartData = (void *)&Cg_SmartData_FullRange,
        .ArraySize = 1U,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_NAV, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_FULL_RANGE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_FULL_RANGE },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_FULL_RANGE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "Minimum and Maximum both 0: the whole range of int32_t is allowed, so the default 500 is fine."
    },

    /* [4] SAMPLES */
    {
        .pName = "Samples",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_Samples[0],
        .ArraySize = SAMPLES_ARRAY_SIZE,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_AND, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_SAMPLES },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_READ_ONLY, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_SAMPLES },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "A large array, not logged."
    }
};

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Initialises the parameter list and every smart-data object.
 *
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
uint8_t fParameterList_Init(void) {

    uint8_t result = 0U;

    result = fCgSmartData_Init();
    if (result != 0U) {
        return result;
    }

    result = fParameterList_InitCompletedCallback();
    if (result != 0U) {
        return result;
    }

    return result;

}

/**
 * @brief Called once the parameter list has been initialised.
 *
 * @note  Implement this function in the application layer without the weak specifier to hook into the initialisation.
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
PARAMETER_LIST_WEAK uint8_t fParameterList_InitCompletedCallback(void) {

    return 0U;

}

/**
 * @brief Returns the number of parameters in the list.
 *
 * @return uint16_t Always PARAMETER_LIST_QTY.
 */
uint16_t fParameterList_GetQuantity(void) {

    return (uint16_t)PARAMETER_LIST_QTY;

}

/**
 * @brief Returns the descriptor of the parameter at *index*.
 *
 * @param index Index of the parameter, see 'cg_parameter_list_defines.h'.
 * @return const sParameterDescriptor* NULL when the index is out of range.
 */
const sParameterDescriptor * fParameterList_GetByIndex(uint16_t index) {

    if (index >= (uint16_t)PARAMETER_LIST_QTY) {
        return NULL;
    }

    return &ParameterList[index];

}

/**
 * @brief Returns the descriptor of the parameter called *pName*.
 *
 * @param pName Name of the parameter as written in the Excel sheet.
 * @return const sParameterDescriptor* NULL when no such parameter exists.
 */
const sParameterDescriptor * fParameterList_GetByName(const char *pName) {

    uint16_t index = 0U;

    if (pName == NULL) {
        return NULL;
    }

    for (index = 0U; index < (uint16_t)PARAMETER_LIST_QTY; index++) {
        if (strcmp(ParameterList[index].pName, pName) == 0) {
            return &ParameterList[index];
        }
    }

    return NULL;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

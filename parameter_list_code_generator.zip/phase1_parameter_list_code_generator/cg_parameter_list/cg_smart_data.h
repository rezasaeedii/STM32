/**
  ******************************************************************************
  * @file    cg_smart_data.h
  * @brief   Smart-data objects that hold the value of every parameter.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v1.0.0
  * Generated at   : 2026-08-31 00:18:04 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase1_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 5 enabled, 2 disabled
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_SMART_DATA_H
#define CG_SMART_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
uint8_t fCgSmartData_Init(void);

/* Exported variables ------------------------------------------------------- */
extern sSmartDataB8 Cg_SmartData_PosDrone;  /*!< A boolean: no minimum, maximum or resolution. */
extern sSmartDataF64 Cg_SmartData_VelDrone[VEL_DRONE_ARRAY_SIZE];  /*!< [m/s] An array of 6 values; it reserves 6 x 8 = 48 log ids (104 .. 151). */
extern sSmartDataF32 Cg_SmartData_Altitude;  /*!< [m] The first free log id after VelDrone is 152. */
extern sSmartDataI32 Cg_SmartData_FullRange;  /*!< Minimum and Maximum both 0: the whole range of int32_t is allowed, so the default 500 is fine. */
extern sSmartDataI16 Cg_SmartData_Samples[SAMPLES_ARRAY_SIZE];  /*!< A large array, not logged. */

#ifdef __cplusplus
}
#endif

#endif /* CG_SMART_DATA_H */

/* === Copyright (c) 2026 FAS === EOF === */

"""Checks that a faulty Excel file is rejected with the right diagnostics.

The test builds small workbooks in a temporary folder, runs the pipeline on
them and asserts which diagnostic codes are reported.  It needs no compiler.

Run it with::

    python tests/run_validation_test.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from openpyxl import Workbook  # noqa: E402

from pl_codegen.config import Config  # noqa: E402
from pl_codegen.errors import DiagnosticCollector, Severity  # noqa: E402
from pl_codegen.excel.excel_to_model import build_model  # noqa: E402
from pl_codegen.logging_utils import setup_logging  # noqa: E402
from pl_codegen.validation.validator import Validator  # noqa: E402

PARAMETER_HEADERS = [
    "Enable", "Name", "GS Name", "Group", "DataType", "Array Size", "DefaultValue",
    "Minimum", "Maximum", "Resolution", "Unit", "Tag System Name", "Tag Reset Proof",
    "Tag Loggable", "LogID", "Encrypt", "ParamMode", "Tag1", "Tag2", "Tag3", "Tag4",
    "Description",
]

DEFINES = {
    "BOOLEANS": [True, False],
    "GROUP": ["MONITORING", "COMMAND", "SETTING"],
    "TYPES": ["bool_t", "uint8_t", "int8_t", "uint16_t", "int16_t", "uint32_t", "int32_t",
              "uint64_t", "int64_t", "float32_t", "float64_t"],
    "SYSTEM NAMES": ["SYS_UNKNOWN", "SYS_GS_COMPUTER", "SYS_NAV"],
    "PARAM MODES": ["PARAM_MODE_USER", "PARAM_MODE_READ_ONLY"],
}


def valid_row(**overrides: Any) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "Enable": True, "Name": "GoodParam", "GS Name": "GoodParam", "Group": "MONITORING",
        "DataType": "uint8_t", "Array Size": 1, "DefaultValue": 5, "Minimum": 0,
        "Maximum": 10, "Resolution": 1, "Unit": "mm", "Tag System Name": "SYS_NAV",
        "Tag Reset Proof": True, "Tag Loggable": True, "LogID": 1000, "Encrypt": False,
        "ParamMode": "PARAM_MODE_USER", "Tag1": None, "Tag2": None, "Tag3": None,
        "Tag4": None, "Description": "A valid parameter.",
    }
    row.update(overrides)
    return row


def write_workbook(path: Path, rows: Sequence[Dict[str, Any]]) -> Path:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "ParameterList"
    sheet.append(PARAMETER_HEADERS)
    for row in rows:
        sheet.append([row.get(header) for header in PARAMETER_HEADERS])

    defines = workbook.create_sheet("Defines")
    columns = list(DEFINES)
    defines.append(columns)
    for index in range(max(len(values) for values in DEFINES.values())):
        defines.append([DEFINES[column][index] if index < len(DEFINES[column]) else None
                        for column in columns])

    workbook.save(path)
    return path


def run_case(work_dir: Path, name: str,
             rows: Sequence[Dict[str, Any]]) -> Dict[str, Set[str]]:
    """Validate a workbook and return the reported codes, by severity."""
    case_dir = work_dir / name
    case_dir.mkdir(parents=True, exist_ok=True)
    workbook = write_workbook(case_dir / f"{name}.xlsx", rows)

    config_data: Dict[str, Any] = {
        "inputs": {"excel_files": [str(workbook)]},
        "output": {"code_directory": str(case_dir / "gen"),
                   "xml_file": str(case_dir / "model.xml"),
                   "base_name": "parameter_list"},
        "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
    }
    config_path = case_dir / "config.json"
    config_path.write_text(json.dumps(config_data), encoding="utf-8")

    config = Config.load(config_path)
    diagnostics = DiagnosticCollector()
    model = build_model(config, diagnostics)
    Validator(config).validate(model, diagnostics)
    return {
        "error": {i.code for i in diagnostics.items if i.severity is Severity.ERROR},
        "warning": {i.code for i in diagnostics.items if i.severity is Severity.WARNING},
        "all": [i.code for i in diagnostics.items],
    }


CASES: List[Dict[str, Any]] = [
    {"name": "invalid_name", "expect": "NAME001",
     "rows": [valid_row(Name="2Bad Name")]},
    {"name": "reserved_name", "expect": "NAME002",
     "rows": [valid_row(Name="struct")]},
    {"name": "duplicate_name", "expect": "NAME003",
     "rows": [valid_row(), valid_row(LogID=1001)]},
    {"name": "macro_collision", "expect": "NAME004",
     "rows": [valid_row(Name="TestVar"), valid_row(Name="Test_Var", LogID=1001)]},
    {"name": "unsupported_type", "expect": "TYPE002",
     "rows": [valid_row(DataType="sMyStruct")]},
    {"name": "unknown_group", "expect": "GRP002",
     "rows": [valid_row(Group="TELEMETRY")]},
    {"name": "bad_array_size", "expect": "ARR001",
     "rows": [valid_row(**{"Array Size": 0})]},
    {"name": "value_out_of_c_type", "expect": "RNG001",
     "rows": [valid_row(Maximum=5000)]},
    {"name": "min_greater_than_max", "expect": "RNG002",
     "rows": [valid_row(Minimum=10, Maximum=1, DefaultValue=5)]},
    {"name": "default_out_of_range", "expect": "RNG003",
     "rows": [valid_row(DefaultValue=99)]},
    {"name": "missing_mandatory_tag", "expect": "TAG001",
     "rows": [valid_row(**{"Tag System Name": None})]},
    {"name": "unknown_system_name", "expect": "TAG003",
     "rows": [valid_row(**{"Tag System Name": "SYS_DOES_NOT_EXIST"})]},
    {"name": "loggable_without_log_id", "expect": "TAG010",
     "rows": [valid_row(LogID=None)]},
    {"name": "duplicate_log_id", "expect": "TAG012",
     "rows": [valid_row(Name="First"), valid_row(Name="Second")]},
    # float64_t x2 -> 16 ids, so 400 reserves 400..415 and 410 must be refused
    {"name": "log_id_range_overlap", "expect": "TAG013",
     "rows": [valid_row(Name="Wide", DataType="float64_t", **{"Array Size": 2},
                        Minimum=0, Maximum=0, DefaultValue=0, Resolution=1, LogID=400),
              valid_row(Name="Next", LogID=410)]},
    # the first free id after the wide parameter is 416 -> no error
    {"name": "log_id_range_ok", "expect": None,
     "rows": [valid_row(Name="Wide", DataType="float64_t", **{"Array Size": 2},
                        Minimum=0, Maximum=0, DefaultValue=0, Resolution=1, LogID=400),
              valid_row(Name="Next", LogID=416)]},
    {"name": "all_rows_disabled", "expect": "VAL001",
     "rows": [valid_row(Enable=False)]},
    {"name": "good", "expect": None,
     "rows": [valid_row(Name="First"), valid_row(Name="Second", LogID=1001)]},

    # ---- Minimum and Maximum both 0 (or both empty) = the whole range ------
    # The generated constructor gets the native range of the type, so a default
    # far outside [0, 0] is perfectly valid.
    {"name": "full_range_zero", "expect": None,
     "rows": [valid_row(Minimum=0, Maximum=0, DefaultValue=200)]},
    {"name": "full_range_empty", "expect": None,
     "rows": [valid_row(Minimum=None, Maximum=None, DefaultValue=200)]},
    # ... but one limit filled in and the other empty is a real range, and the
    # empty cell counts as 0 - so this default really is out of range
    {"name": "half_range_default_outside", "expect": "RNG003",
     "expect_warning": "RNG012",
     "rows": [valid_row(Minimum=None, Maximum=10, DefaultValue=200)]},

    # ---- LogID means nothing while the row is not logged -------------------
    {"name": "log_id_of_unlogged_row_is_free", "expect": None,
     "rows": [valid_row(Name="NotLogged", **{"Tag Loggable": False}, LogID=413),
              valid_row(Name="Logged", **{"Tag Loggable": True}, LogID=413)]},

    # ---- bool_t rows -------------------------------------------------------
    # 0 / 1 / 1 only restate what a boolean is: accepted in silence
    {"name": "boolean_natural_values", "expect": None, "forbid_warning": "RNG010",
     "rows": [valid_row(DataType="bool_t", DefaultValue=True,
                        Minimum=0, Maximum=1, Resolution=1)]},
    # anything else is reported ONCE, however many cells are odd
    {"name": "boolean_odd_values", "expect": None, "expect_warning": "RNG010",
     "warning_count": {"RNG010": 1},
     "rows": [valid_row(DataType="bool_t", DefaultValue=True,
                        Minimum=3, Maximum=9, Resolution=5)]},

    # ---- an integer row may not hold a fractional number -------------------
    # int() truncates, so 0.5 would silently become a resolution of 0; the
    # reader refuses the cell instead of quietly changing the number
    {"name": "fractional_resolution_on_integer", "expect": "EXL033",
     "rows": [valid_row(Resolution=0.5)]},
    {"name": "fractional_maximum_on_integer", "expect": "EXL033",
     "rows": [valid_row(Maximum=99.9)]},
    # the same numbers on a float type are perfectly fine
    {"name": "fractional_values_on_float", "expect": None,
     "rows": [valid_row(DataType="float32_t", DefaultValue=2.5,
                        Minimum=0, Maximum=99.9, Resolution=0.5)]},

    # ---- a resolution wider than the range ---------------------------------
    {"name": "resolution_wider_than_range", "expect": None,
     "expect_warning": "RNG016",
     "rows": [valid_row(Minimum=0, Maximum=10, Resolution=50)]},

    # ---- the GS name does not depend on logging ----------------------------
    {"name": "gs_name_missing_when_not_logged", "expect": None,
     "expect_warning": "TAG011",
     "rows": [valid_row(**{"GS Name": None, "Tag Loggable": False}, LogID=None)]},
]


def check_no_duplicate_diagnostics(work_dir: Path) -> int:
    """A full run must report each problem once, not once per stage.

    The pipeline reads the workbook, writes the XML model and reads it back.
    Validating in both stages would report every single diagnostic twice, which
    is exactly the kind of noise that makes a report useless.
    """
    from pl_codegen.pipeline import Pipeline

    case_dir = work_dir / "duplicates"
    case_dir.mkdir(parents=True, exist_ok=True)
    workbook = write_workbook(case_dir / "duplicates.xlsx", [
        valid_row(Name="One", **{"GS Name": None}),
        valid_row(Name="Two", **{"GS Name": None}, LogID=1001),
    ])
    config_path = case_dir / "config.json"
    config_path.write_text(json.dumps({
        "inputs": {"excel_files": [str(workbook)]},
        "output": {"code_directory": str(case_dir / "gen"),
                   "xml_file": str(case_dir / "model.xml"),
                   "base_name": "parameter_list"},
        "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
    }), encoding="utf-8")

    result = Pipeline(Config.load(config_path)).run()
    seen = [(item.code, str(item.location)) for item in result.diagnostics.items]
    duplicates = {entry for entry in seen if seen.count(entry) > 1}

    if duplicates:
        print(f"  [FAIL] {'no_duplicate_diagnostics':<32} reported twice: "
              f"{', '.join(sorted(code for code, _ in duplicates))}")
        return 1
    print(f"  [PASS] {'no_duplicate_diagnostics':<32} every problem reported once "
          f"({len(seen)} diagnostic(s))")
    return 0


def check_uncached_formula(work_dir: Path) -> int:
    """A formula whose result the workbook does not store must be reported.

    ``data_only=True`` gives back the *result* Excel last computed, and a file
    written by a script holds no results at all.  Such a cell reads as empty,
    and an empty Minimum/Maximum is not an error - it means "the whole range".
    So without this check the tool would silently generate the wrong limits.
    """
    case_dir = work_dir / "uncached_formula"
    case_dir.mkdir(parents=True, exist_ok=True)
    workbook = write_workbook(case_dir / "uncached_formula.xlsx",
                              [valid_row(Name="WithFormula")])

    # openpyxl never stores a computed value, so writing a formula through it
    # reproduces exactly the situation this check is about
    from openpyxl import load_workbook
    book = load_workbook(workbook)
    sheet = book["ParameterList"]
    sheet.cell(row=2, column=PARAMETER_HEADERS.index("Maximum") + 1).value = "=100*2"
    book.save(workbook)
    book.close()

    config_path = case_dir / "config.json"
    config_path.write_text(json.dumps({
        "inputs": {"excel_files": [str(workbook)]},
        "output": {"code_directory": str(case_dir / "gen"),
                   "xml_file": str(case_dir / "model.xml"),
                   "base_name": "parameter_list"},
        "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
    }), encoding="utf-8")

    diagnostics = DiagnosticCollector()
    build_model(Config.load(config_path), diagnostics)
    codes = {item.code for item in diagnostics.items if item.severity is Severity.ERROR}

    name = "uncached_formula"
    if "EXL004" in codes:
        print(f"  [PASS] {name:<32} expect EXL004; reported: EXL004")
        return 0
    print(f"  [FAIL] {name:<32} expect EXL004; reported: {', '.join(sorted(codes)) or '-'}")
    return 1


def check_unknown_config_key(work_dir: Path) -> int:
    """A misspelled configuration key must be reported, not ignored in silence."""
    import logging

    case_dir = work_dir / "unknown_config_key"
    case_dir.mkdir(parents=True, exist_ok=True)
    workbook = write_workbook(case_dir / "unknown_config_key.xlsx", [valid_row()])
    config_path = case_dir / "config.json"
    config_path.write_text(json.dumps({
        "inputs": {"excel_files": [str(workbook)]},
        "output": {"code_directory": str(case_dir / "gen"),
                   "xml_file": str(case_dir / "model.xml"),
                   "base_name": "parameter_list"},
        "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
        "codegen": {"emit_timestemp": False},        # deliberate typo
        "validatoin": {},                            # deliberate typo
    }), encoding="utf-8")

    records: List[str] = []

    class _Capture(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            records.append(record.getMessage())

    logger = logging.getLogger("pl_codegen")
    handler = _Capture()
    logger.addHandler(handler)
    try:
        Config.load(config_path)
    finally:
        logger.removeHandler(handler)

    name = "unknown_config_key"
    got_key = any("emit_timestemp" in text for text in records)
    got_section = any("validatoin" in text for text in records)
    if got_key and got_section:
        print(f"  [PASS] {name:<32} expect a warning for the typo'd key and section")
        return 0
    print(f"  [FAIL] {name:<32} key warned: {got_key}, section warned: {got_section}")
    return 1


def main() -> int:
    setup_logging(quiet=True)
    failures = 0

    with tempfile.TemporaryDirectory(prefix="pl_codegen_validation_") as raw_dir:
        work_dir = Path(raw_dir)
        for case in CASES:
            result = run_case(work_dir, case["name"], case["rows"])
            codes = result["error"]
            expected: Optional[str] = case["expect"]
            notes: List[str] = []

            if expected is None:
                ok = not codes
                notes.append("no error")
            else:
                ok = expected in codes
                notes.append(expected)

            wanted_warning = case.get("expect_warning")
            if wanted_warning:
                ok = ok and wanted_warning in result["warning"]
                notes.append(f"warning {wanted_warning}")

            forbidden = case.get("forbid_warning")
            if forbidden:
                ok = ok and forbidden not in result["warning"]
                notes.append(f"no {forbidden}")

            for code, times in (case.get("warning_count") or {}).items():
                actual = result["all"].count(code)
                ok = ok and actual == times
                notes.append(f"{code} x{times}" + ("" if actual == times else f" (got {actual})"))

            status = "PASS" if ok else "FAIL"
            print(f"  [{status}] {case['name']:<32} expect {', '.join(notes)}; "
                  f"reported: {', '.join(sorted(codes | result['warning'])) or '-'}")
            if not ok:
                failures += 1

        failures += check_no_duplicate_diagnostics(work_dir)
        failures += check_uncached_formula(work_dir)
        failures += check_unknown_config_key(work_dir)

    total = len(CASES) + 3
    print()
    if failures:
        print(f"{failures} of {total} validation case(s) FAILED.")
        return 1
    print(f"All {total} validation cases passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# parameter list code generator

Generates the parameter-list C code from `parameter_list_template.xlsx`.

```
python setup_environment.py    # once: installs openpyxl
python generate.py             # every time: Excel -> XML -> C files
```

The C files land in `cg_parameter_list/`, the XML model in `cg_output/`.
Everything is configured in `codegen_config.json`.

Useful switches: `--check` (validate only, writes nothing), `-v` (verbose),
`-W` (warnings are errors), `--list-rules`, `--help`.

Full documentation, in Persian, in the project folder:

* `parameter_list_user_manual_fa.pdf` — using the tool
* `parameter_list_developer_manual_fa.pdf` — changing the tool

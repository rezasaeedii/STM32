"""``MemoryOffset`` of every parameter, per tag.

Every tag owns an independent counter.  The rule is the same for all tags:

    the counter starts at 0 and, for every parameter that carries the tag,
    advances by  ``sizeof(value) * array size``

A parameter that does not carry the tag gets offset 0 and consumes nothing.

Example for the *Loggable* tag::

    P1  uint16_t          loggable       -> offset 0    (uses 2 bytes)
    P2  uint8_t           not loggable   -> no offset, uses nothing
    P3  uint64_t          loggable       -> offset 2    (uses 8 bytes)
    P4  uint32_t          loggable       -> offset 10   (uses 4 bytes)
    P5  uint16_t[4]       loggable       -> offset 14   (uses 8 bytes)
                                            total: 22 bytes

The sizes come from the C standard (``uint16_t`` is 2 bytes everywhere), so the
generated offsets are identical on every compiler.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from ..model.parameter import Parameter
from ..model.parameter_list import ParameterList
from ..model.tags import TAG_REGISTRY, TagSpec


def reserved_size(parameter: Parameter) -> int:
    """Bytes one parameter occupies inside the area of a tag it carries."""
    data_type = parameter.data_type
    if data_type is None:
        return 0
    return data_type.value_size * max(1, parameter.array_size)


@dataclass
class OffsetEntry:
    """The offset one parameter got inside the area of one tag."""

    tag_id: str
    parameter: Parameter
    offset: int
    size: int


@dataclass
class OffsetArea:
    """Everything allocated for a single tag."""

    tag: TagSpec
    entries: List[OffsetEntry] = field(default_factory=list)
    total: int = 0     #: total number of bytes used by this tag


class OffsetMap:
    """Lookup of ``(tag, parameter) -> offset``."""

    def __init__(self, areas: Dict[str, OffsetArea]) -> None:
        self._areas = areas
        self._lookup: Dict[Tuple[str, str], OffsetEntry] = {
            (entry.tag_id, entry.parameter.name): entry
            for area in areas.values() for entry in area.entries
        }

    @property
    def areas(self) -> Dict[str, OffsetArea]:
        return self._areas

    def area(self, tag_id: str) -> Optional[OffsetArea]:
        return self._areas.get(tag_id)

    def has_entry(self, tag_id: str, parameter_name: str) -> bool:
        return (tag_id, parameter_name) in self._lookup

    def offset(self, tag_id: str, parameter_name: str) -> int:
        entry = self._lookup.get((tag_id, parameter_name))
        return entry.offset if entry is not None else 0

    def size(self, tag_id: str, parameter_name: str) -> int:
        entry = self._lookup.get((tag_id, parameter_name))
        return entry.size if entry is not None else 0

    def total(self, tag_id: str) -> int:
        area = self._areas.get(tag_id)
        return area.total if area is not None else 0


def build_offset_map(model: ParameterList) -> OffsetMap:
    """Allocate an offset for every (parameter, tag) pair that carries the tag."""
    areas: Dict[str, OffsetArea] = {}

    for spec in TAG_REGISTRY:
        area = OffsetArea(tag=spec)
        cursor = 0

        for parameter in model.enabled:
            if not parameter.has_active_tag(spec.tag_id):
                continue
            step = reserved_size(parameter)
            area.entries.append(OffsetEntry(spec.tag_id, parameter, cursor, step))
            cursor += step

        area.total = cursor
        areas[spec.tag_id] = area

    return OffsetMap(areas)

"""Layout layer: the MemoryOffset of every parameter, per tag."""

from .tag_offset import OffsetArea, OffsetEntry, OffsetMap, build_offset_map, reserved_size

__all__ = ["OffsetArea", "OffsetEntry", "OffsetMap", "build_offset_map", "reserved_size"]

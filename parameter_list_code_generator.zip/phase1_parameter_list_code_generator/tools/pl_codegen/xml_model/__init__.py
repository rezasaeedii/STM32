"""The intermediate XML format that decouples the front-end from the generator.

Stage 1  : Excel (or, later, a GUI)  ->  XML
Stage 2  : XML                       ->  C source/header files

Only :mod:`schema` has to be shared with a future GUI implementation.
"""

from . import schema
from .xml_reader import read_xml
from .xml_writer import model_to_element, write_xml

__all__ = ["schema", "read_xml", "write_xml", "model_to_element"]

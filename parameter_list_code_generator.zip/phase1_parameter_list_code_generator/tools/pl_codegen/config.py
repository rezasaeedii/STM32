"""Loading and validating ``codegen_config.json``.

The configuration file is the only place where the user lists the Excel files of
the different sub-modules of the project.  All paths inside it are resolved
relative to the configuration file itself, so the tool can be run from anywhere.
"""

from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .errors import CodeGeneratorError
from .logging_utils import get_logger

#: What a generated file name / include guard may be made of.
_NAME_SAFE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

_TRAILING_COMMA = re.compile(r",(\s*[}\]])")
_LINE_COMMENT = re.compile(r"^\s*//.*$", re.MULTILINE)


def load_jsonc(path: Path) -> Dict[str, Any]:
    """Load a JSON file that may contain ``//`` comments and trailing commas.

    The company's ``c.json`` snippet file uses the VS Code JSON-with-comments
    dialect, and it is convenient to allow the same in our own config file.
    """
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        raise CodeGeneratorError(f"Cannot read '{path}': {exc}") from exc

    text = _LINE_COMMENT.sub("", text)
    text = _TRAILING_COMMA.sub(r"\1", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise CodeGeneratorError(f"'{path}' is not valid JSON: {exc}") from exc


@dataclass
class InputConfig:
    excel_files: List[Path] = field(default_factory=list)
    parameter_sheet: str = "ParameterList"
    defines_sheet: str = "Defines"


@dataclass
class OutputConfig:
    code_directory: Path = Path("../cg_parameter_list")
    xml_file: Path = Path("../cg_output/parameter_list.xml")
    file_prefix: str = "cg_"
    base_name: str = "parameter_list"


@dataclass
class StyleConfig:
    snippet_file: Optional[Path] = None
    company: str = "FAS"
    indent: str = "    "


@dataclass
class CodegenConfig:
    emit_description: bool = True
    emit_unit: bool = True
    emit_generation_info: bool = True
    emit_timestamp: bool = True
    index_define_prefix: str = ""
    offset_define_prefix: str = "PARAMETER_LIST_"
    smart_data_prefix: str = "Cg_SmartData_"
    descriptor_symbol: str = "ParameterList"
    quantity_define: str = "PARAMETER_LIST_QTY"
    #: extra ``#include`` lines for the generated .c file.  A free tag
    #: (Tag1..Tag4) may hold an application constant such as ``APP_FLAG_X``;
    #: without the header that declares it the generated file will not compile.
    extra_includes: List[str] = field(default_factory=list)


@dataclass
class ValidationConfig:
    treat_warnings_as_errors: bool = False
    require_description: bool = False
    require_unit: bool = False


@dataclass
class Config:
    """Fully resolved configuration."""

    path: Path
    inputs: InputConfig = field(default_factory=InputConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    style: StyleConfig = field(default_factory=StyleConfig)
    codegen: CodegenConfig = field(default_factory=CodegenConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)

    # -- loading ---------------------------------------------------------
    @classmethod
    def load(cls, config_path: Path) -> "Config":
        config_path = config_path.expanduser().resolve()
        if not config_path.is_file():
            raise CodeGeneratorError(f"Configuration file '{config_path}' does not exist.")

        data = load_jsonc(config_path)
        _warn_unknown_sections(data)
        root = config_path.parent

        def resolve(value: str) -> Path:
            candidate = Path(str(value)).expanduser()
            return candidate if candidate.is_absolute() else (root / candidate).resolve()

        raw_inputs = data.get("inputs") or {}
        _warn_unknown_keys("inputs", raw_inputs,
                           {"excel_files", "parameter_sheet", "defines_sheet"})
        excel_entries = raw_inputs.get("excel_files", [])
        if not isinstance(excel_entries, list) or not excel_entries:
            raise CodeGeneratorError(
                "Configuration error: 'inputs.excel_files' must be a non-empty list of paths.")

        inputs = InputConfig(
            excel_files=[resolve(entry) for entry in excel_entries],
            parameter_sheet=str(raw_inputs.get("parameter_sheet", "ParameterList")),
            defines_sheet=str(raw_inputs.get("defines_sheet", "Defines")),
        )

        raw_output = data.get("output") or {}
        _warn_unknown_keys("output", raw_output,
                           {"code_directory", "xml_file", "file_prefix", "base_name"})
        output = OutputConfig(
            code_directory=resolve(raw_output.get("code_directory", "../cg_parameter_list")),
            xml_file=resolve(raw_output.get("xml_file", "../cg_output/parameter_list.xml")),
            file_prefix=str(raw_output.get("file_prefix", "cg_")),
            base_name=str(raw_output.get("base_name", "") or inputs.excel_files[0].stem),
        )

        raw_style = data.get("style") or {}
        _warn_unknown_keys("style", raw_style, {"snippet_file", "company", "indent"})
        snippet = raw_style.get("snippet_file")
        style = StyleConfig(
            snippet_file=resolve(snippet) if snippet else None,
            company=str(raw_style.get("company", "FAS")),
            indent=str(raw_style.get("indent", "    ")),
        )

        codegen = _dataclass_from_dict(CodegenConfig, data.get("codegen") or {}, "codegen")
        validation = _dataclass_from_dict(ValidationConfig, data.get("validation") or {},
                                          "validation")
        codegen.extra_includes = [str(entry) for entry in (codegen.extra_includes or [])]

        config = cls(path=config_path, inputs=inputs, output=output, style=style,
                     codegen=codegen, validation=validation)
        config.validate()
        return config

    # -- checks ----------------------------------------------------------
    def validate(self) -> None:
        missing = [str(path) for path in self.inputs.excel_files if not path.is_file()]
        if missing:
            raise CodeGeneratorError(
                "The following Excel files listed in the configuration do not exist:\n  - "
                + "\n  - ".join(missing))
        if self.style.snippet_file is not None and not self.style.snippet_file.is_file():
            raise CodeGeneratorError(
                f"Style snippet file '{self.style.snippet_file}' does not exist.")

        # The file names become C include guards and #include lines, so they
        # have to survive being turned into identifiers.  'base_name' defaults
        # to the workbook's file name, and a workbook is very often called
        # something like "Parameter List (v2).xlsx".
        for key, value in (("output.base_name", self.output.base_name),
                           ("output.file_prefix", self.output.file_prefix)):
            if value and not _NAME_SAFE.fullmatch(value):
                raise CodeGeneratorError(
                    f"{key} is '{value}'. It becomes part of a file name and of a C "
                    f"include guard, so it may hold only letters, digits and '_'.\n"
                    f"Set '{key.split('.')[1]}' in the 'output' section of "
                    f"{self.path.name} to a plain name.")

    # -- helpers ---------------------------------------------------------
    def generated_file_name(self, suffix: str, extension: str) -> str:
        """``suffix='defines', extension='h'`` -> ``cg_parameter_list_defines.h``."""
        stem = f"{self.output.file_prefix}{self.output.base_name}"
        if suffix:
            stem = f"{stem}_{suffix}"
        return f"{stem}.{extension}"

    def smart_data_file_name(self, extension: str) -> str:
        return f"{self.output.file_prefix}smart_data.{extension}"


def _dataclass_from_dict(cls: type, data: Dict[str, Any], section: str = "") -> Any:
    """Build a dataclass from a dict, warning about keys it does not know.

    An unknown key is nearly always a typo - ``emit_timestemp`` instead of
    ``emit_timestamp``.  Silently dropping it means the user changes the setting,
    sees no effect, and has no way of finding out why, so it is reported.
    """
    known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    unknown = sorted(key for key in data if key not in known)
    if unknown:
        logger = get_logger()
        for key in unknown:
            suggestion = _closest(key, known)
            hint = f" Did you mean '{suggestion}'?" if suggestion else ""
            logger.warning("Unknown configuration key '%s%s' - it is ignored.%s",
                           f"{section}." if section else "", key, hint)
    return cls(**{key: value for key, value in data.items() if key in known})


def _closest(key: str, candidates: Any) -> Optional[str]:
    """The known key closest to *key*, or ``None`` when nothing is close."""
    matches = difflib.get_close_matches(key, sorted(candidates), n=1, cutoff=0.7)
    return matches[0] if matches else None


def _warn_unknown_sections(data: Dict[str, Any]) -> None:
    """Same idea, one level up: a whole section spelled wrongly does nothing."""
    known = {"inputs", "output", "style", "codegen", "validation"}
    logger = get_logger()
    for key in sorted(key for key in data if key not in known):
        suggestion = _closest(key, known)
        hint = f" Did you mean '{suggestion}'?" if suggestion else ""
        logger.warning("Unknown configuration section '%s' - it is ignored.%s", key, hint)


def _warn_unknown_keys(section: str, data: Dict[str, Any], known: Any) -> None:
    """The same check for the sections that are not built from a dataclass."""
    logger = get_logger()
    for key in sorted(key for key in data if key not in known):
        suggestion = _closest(key, known)
        hint = f" Did you mean '{suggestion}'?" if suggestion else ""
        logger.warning("Unknown configuration key '%s.%s' - it is ignored.%s",
                       section, key, hint)

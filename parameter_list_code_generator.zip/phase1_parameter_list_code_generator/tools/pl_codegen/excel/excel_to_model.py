"""Excel -> :class:`ParameterList`.

Several workbooks (one per project sub-module) are read and merged into a single
parameter list, exactly as if they had all been written in one sheet.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence

from ..config import Config
from ..errors import DiagnosticCollector, SourceLocation
from ..model.defines import Defines
from ..model.parameter import Parameter
from ..model.parameter_list import ParameterList
from ..model.tags import TAG_REGISTRY, TagKind
from ..model.types import resolve_data_type
from . import value_parsing as vp
from .column_schema import (COL_ARRAY_SIZE, COL_DATA_TYPE, COL_DEFAULT_VALUE, COL_DESCRIPTION,
                            COL_ENABLE, COL_GROUP, COL_GS_NAME, COL_MAXIMUM, COL_MINIMUM,
                            COL_NAME, COL_RESOLUTION, COL_UNIT, REQUIRED_COLUMNS)
from .workbook_reader import SheetData, WorkbookReader


class ExcelModelBuilder:
    """Builds a :class:`ParameterList` from the configured workbooks."""

    def __init__(self, config: Config, diagnostics: DiagnosticCollector) -> None:
        self._config = config
        self._diagnostics = diagnostics

    def build(self) -> ParameterList:
        model = ParameterList()
        model.source_files = [str(path) for path in self._config.inputs.excel_files]

        for excel_file in self._config.inputs.excel_files:
            self._read_workbook(excel_file, model)

        return model

    # -- one workbook ----------------------------------------------------
    def _read_workbook(self, path: Path, model: ParameterList) -> None:
        reader = WorkbookReader(path, self._diagnostics)
        try:
            parameter_sheet = reader.read_sheet(self._config.inputs.parameter_sheet, required=True)
            if parameter_sheet is None:
                return
            self._check_required_columns(parameter_sheet)
            for row in parameter_sheet.rows:
                parameter = self._read_parameter(parameter_sheet, row)
                if parameter is not None:
                    model.add(parameter)
        finally:
            reader.close()

    def _check_required_columns(self, sheet: SheetData) -> None:
        for column in REQUIRED_COLUMNS:
            if not sheet.has_column(column):
                self._diagnostics.error(
                    "EXL020", f"Required column '{column}' is missing from the sheet.",
                    sheet.location(row=1),
                    hint="Compare the sheet with 'parameter_list_template.xlsx'.")
        for spec in TAG_REGISTRY:
            if spec.mandatory and not sheet.has_column(spec.excel_column):
                self._diagnostics.error(
                    "EXL021",
                    f"Column '{spec.excel_column}' of mandatory tag '{spec.tag_id}' is missing.",
                    sheet.location(row=1))

    # -- one parameter ---------------------------------------------------
    def _read_parameter(self, sheet: SheetData, row) -> Optional[Parameter]:
        location = sheet.location(row=row.row_number)

        name = vp.parse_text(row.get(COL_NAME))
        if not name:
            self._diagnostics.error("EXL030", "Row has no parameter name and is skipped.",
                                    sheet.location(row=row.row_number, column=COL_NAME))
            return None

        enable, error = vp.parse_bool(row.get(COL_ENABLE), default=True)
        if error:
            self._diagnostics.error("EXL031", f"Column '{COL_ENABLE}': {error}",
                                    sheet.location(row=row.row_number, column=COL_ENABLE))
            enable = True

        parameter = Parameter(name=name, enable=bool(enable), source=location)
        parameter.gs_name = vp.parse_text(row.get(COL_GS_NAME))
        parameter.group = vp.parse_identifier(row.get(COL_GROUP))
        parameter.data_type_name = vp.parse_text(row.get(COL_DATA_TYPE))
        parameter.unit = vp.parse_text(row.get(COL_UNIT))
        parameter.description = vp.parse_text(row.get(COL_DESCRIPTION))

        array_size, error = vp.parse_int(row.get(COL_ARRAY_SIZE), default=1)
        if error:
            self._diagnostics.error("EXL032", f"Column '{COL_ARRAY_SIZE}': {error}",
                                    sheet.location(row=row.row_number, column=COL_ARRAY_SIZE))
            array_size = 1
        parameter.array_size = int(array_size if array_size is not None else 1)

        data_type = resolve_data_type(parameter.data_type_name)
        is_float = bool(data_type and data_type.is_float)
        is_bool = bool(data_type and data_type.is_bool)

        for column, attribute in ((COL_DEFAULT_VALUE, "default_value"),
                                  (COL_MINIMUM, "minimum"),
                                  (COL_MAXIMUM, "maximum"),
                                  (COL_RESOLUTION, "resolution")):
            # Only the default value of a bool_t row is a boolean.  Its
            # minimum, maximum and resolution are meaningless for that type,
            # so they are read as plain numbers: whatever is in them, the
            # reader should be able to say so plainly instead of failing to
            # turn "5" into TRUE.
            as_bool = is_bool and attribute == "default_value"
            value, error = vp.parse_numeric_for_type(row.get(column), is_float, as_bool)
            if error:
                self._diagnostics.error("EXL033", f"Column '{column}': {error}",
                                        sheet.location(row=row.row_number, column=column))
            setattr(parameter, attribute, value)

        self._read_tags(sheet, row, parameter)
        return parameter

    def _read_tags(self, sheet: SheetData, row, parameter: Parameter) -> None:
        for spec in TAG_REGISTRY:
            raw = row.get(spec.excel_column)
            location = sheet.location(row=row.row_number, column=spec.excel_column)

            if spec.kind is TagKind.BOOLEAN:
                value, error = vp.parse_bool(raw)
                if error:
                    self._diagnostics.error("EXL040", f"Tag '{spec.tag_id}': {error}", location)
                parameter.tags[spec.tag_id] = value
            elif spec.kind is TagKind.UNSIGNED:
                value, error = vp.parse_int(raw)
                if error:
                    self._diagnostics.error("EXL041", f"Tag '{spec.tag_id}': {error}", location)
                parameter.tags[spec.tag_id] = value
            elif spec.kind is TagKind.ENUM:
                parameter.tags[spec.tag_id] = vp.parse_identifier(raw)
            else:  # TagKind.FREE
                number, error = vp.parse_int(raw)
                parameter.tags[spec.tag_id] = number if not error else vp.parse_text(raw)


def read_defines_sheet(path: Path, sheet_name: str, diagnostics: DiagnosticCollector) -> Defines:
    """Read the *Defines* sheet in raw form (column header -> list of values)."""
    defines = Defines()
    reader = WorkbookReader(path, diagnostics)
    try:
        if sheet_name not in reader.sheet_names:
            diagnostics.warning(
                "EXL050", f"Worksheet '{sheet_name}' was not found; "
                          "the allowed values of this workbook cannot be checked.",
                SourceLocation(file=str(path)))
            return defines
        for column, values in reader.read_column_lists(sheet_name).items():
            for value in values:
                defines.add(column, value)
    finally:
        reader.close()
    return defines


def build_model(config: Config, diagnostics: DiagnosticCollector) -> ParameterList:
    """Read every configured workbook and return the merged model."""
    builder = ExcelModelBuilder(config, diagnostics)
    model = builder.build()

    # The generic sheet reader only keeps *known* columns, and the Defines sheet
    # uses its own headers, so it is read separately in raw form.
    merged = Defines()
    for path in config.inputs.excel_files:
        merged.merge(read_defines_sheet(path, config.inputs.defines_sheet, diagnostics))
    model.defines = merged
    return model


def excel_files_summary(files: Sequence[Path]) -> List[str]:
    return [str(path) for path in files]

"""Column names of the *ParameterList* sheet.

Everything the reader knows about the Excel layout lives here, so that adding or
renaming a column is a one-file change.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from ..model.tags import TAG_REGISTRY

COL_ENABLE = "Enable"
COL_NAME = "Name"
COL_GS_NAME = "GS Name"
COL_GROUP = "Group"
COL_DATA_TYPE = "DataType"
COL_ARRAY_SIZE = "Array Size"
COL_DEFAULT_VALUE = "DefaultValue"
COL_MINIMUM = "Minimum"
COL_MAXIMUM = "Maximum"
COL_RESOLUTION = "Resolution"
COL_UNIT = "Unit"
COL_DESCRIPTION = "Description"

#: Non-tag columns that must exist in the sheet.
REQUIRED_COLUMNS: List[str] = [COL_ENABLE, COL_NAME, COL_GROUP, COL_DATA_TYPE]

#: Non-tag columns the reader understands.
BASE_COLUMNS: List[str] = [
    COL_ENABLE, COL_NAME, COL_GS_NAME, COL_GROUP, COL_DATA_TYPE, COL_ARRAY_SIZE,
    COL_DEFAULT_VALUE, COL_MINIMUM, COL_MAXIMUM, COL_RESOLUTION, COL_UNIT, COL_DESCRIPTION,
]

#: Columns that exist in some sheets but are deliberately not used by the tool.
IGNORED_COLUMNS: List[str] = ["Depth", "Deep", "عمق"]

#: Alternative spellings accepted for a canonical column name.
COLUMN_ALIASES: Dict[str, str] = {
    "enabled": COL_ENABLE,
    "parameter name": COL_NAME,
    "param name": COL_NAME,
    "gsname": COL_GS_NAME,
    "gs_name": COL_GS_NAME,
    "data type": COL_DATA_TYPE,
    "datatype": COL_DATA_TYPE,
    "type": COL_DATA_TYPE,
    "arraysize": COL_ARRAY_SIZE,
    "array_size": COL_ARRAY_SIZE,
    "size": COL_ARRAY_SIZE,
    "default value": COL_DEFAULT_VALUE,
    "default": COL_DEFAULT_VALUE,
    "min": COL_MINIMUM,
    "max": COL_MAXIMUM,
    "res": COL_RESOLUTION,
    "desc": COL_DESCRIPTION,
    "comment": COL_DESCRIPTION,
    "log id": "LogID",
    "logid": "LogID",
    "encryption": "Encrypt",
    "param mode": "ParamMode",
    "parammode": "ParamMode",
}


def _normalise(header: str) -> str:
    return " ".join(str(header).strip().split()).lower()


def canonical_column(header: Optional[str]) -> Optional[str]:
    """Map a raw header cell onto a canonical column name (or ``None``)."""
    if header is None:
        return None
    key = _normalise(header)
    if not key:
        return None

    for column in BASE_COLUMNS:
        if _normalise(column) == key:
            return column
    for spec in TAG_REGISTRY:
        if _normalise(spec.excel_column) == key:
            return spec.excel_column
    for column in IGNORED_COLUMNS:
        if _normalise(column) == key:
            return column

    alias = COLUMN_ALIASES.get(key)
    return alias if alias else None


def all_known_columns() -> List[str]:
    return BASE_COLUMNS + [spec.excel_column for spec in TAG_REGISTRY]

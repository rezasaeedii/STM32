"""Parameter-list code generator package.

The package is intentionally split into small, single-responsibility modules so
that a normal user of the tool can find and edit exactly one file when a single
aspect of the generated code has to change:

    config.py          -> how the tool is configured
    errors.py          -> how problems are reported
    naming.py          -> how C identifiers are derived from Excel names
    model/             -> the in-memory description of a parameter list
    excel/             -> Excel  -> model
    xml_model/         -> model  <-> XML (the stable intermediate format)
    validation/        -> model  -> diagnostics
    layout/            -> model  -> the MemoryOffset of every tag
    codegen/           -> model  -> C source/header files
"""

__version__ = "1.0.0"
__tool_name__ = "parameter_list_code_generator"

__all__ = ["__version__", "__tool_name__"]

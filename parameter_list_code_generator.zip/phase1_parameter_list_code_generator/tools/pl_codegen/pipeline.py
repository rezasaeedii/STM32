"""The two-stage pipeline.

    Stage 1   Excel workbooks  ->  XML model file
    Stage 2   XML model file   ->  C source/header files

The stages are deliberately independent: a future GUI only has to produce a
valid XML file, and the code generator stays untouched.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from .codegen.c_style import CStyle
from .codegen.files import FILE_BUILDERS
from .config import Config
from .errors import DiagnosticCollector, Severity, SourceLocation
from .excel.excel_to_model import build_model
from .layout.tag_offset import build_offset_map
from .logging_utils import banner, get_logger
from .model.parameter_list import ParameterList
from .validation.validator import Validator
from .xml_model.xml_reader import read_xml
from .xml_model.xml_writer import write_xml


@dataclass
class PipelineResult:
    """Everything a caller needs to report the outcome of a run."""

    success: bool
    diagnostics: DiagnosticCollector
    xml_file: Optional[Path] = None
    generated_files: List[Path] = field(default_factory=list)
    parameter_count: int = 0


class Pipeline:
    """Runs the requested stages of the code generator."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._logger = get_logger()
        #: how many enabled parameters stage 1 wrote, so stage 2 can confirm
        #: the XML round trip did not lose any
        self._enabled_before_write: Optional[int] = None

    # -- stage 1 ---------------------------------------------------------
    def excel_to_xml(self, diagnostics: DiagnosticCollector) -> Optional[Path]:
        """Read every configured workbook, validate it and write the XML model."""
        self._logger.info(banner("Stage 1/2 - reading the Excel input"))
        for path in self._config.inputs.excel_files:
            self._logger.info("  reading %s", path)

        model = build_model(self._config, diagnostics)
        self._logger.info("  %d parameter row(s) found (%d enabled)",
                          len(model), len(model.enabled))

        if not Validator(self._config).validate(model, diagnostics):
            return None

        self._enabled_before_write = len(model.enabled)
        xml_path = write_xml(model, self._config.output.xml_file,
                             emit_timestamp=self._config.codegen.emit_timestamp)
        self._logger.info("  XML model written to %s", xml_path)
        return xml_path

    # -- stage 2 ---------------------------------------------------------
    def xml_to_code(self, xml_path: Path, diagnostics: DiagnosticCollector,
                    validate: bool = True) -> PipelineResult:
        """Generate the C files from an XML model file.

        *validate* is False during a full run, because stage 1 has already
        checked the very same parameters - running the rules again would report
        every problem twice.  The round trip is still checked, just cheaply:
        the XML must give back the same number of enabled parameters it was
        written from.
        """
        self._logger.info(banner("Stage 2/2 - generating the C code"))
        model = read_xml(xml_path, diagnostics)

        if validate:
            if not Validator(self._config).validate(model, diagnostics):
                return PipelineResult(False, diagnostics, xml_path)
        elif self._enabled_before_write is not None \
                and len(model.enabled) != self._enabled_before_write:
            diagnostics.error(
                "XML020",
                f"The XML model holds {len(model.enabled)} enabled parameter(s) but "
                f"{self._enabled_before_write} were written into it.",
                SourceLocation(file=str(xml_path)),
                hint="This is a bug in the tool, not in your Excel file.")
            return PipelineResult(False, diagnostics, xml_path)

        offsets = build_offset_map(model)
        style = CStyle.load(self._config.style.snippet_file,
                            company=self._config.style.company,
                            indent=self._config.style.indent)

        generated: List[Path] = []
        directory = self._config.output.code_directory

        for builder_class in FILE_BUILDERS:
            builder = builder_class(model, self._config, offsets, style)
            path = builder.save(directory)
            generated.append(path)
            self._logger.info("  generated %s (%d lines)", path.name,
                              path.read_text(encoding="utf-8").count("\n"))

        return PipelineResult(True, diagnostics, xml_path, generated,
                              parameter_count=len(model.enabled))

    # -- validate only ----------------------------------------------------
    def check(self) -> PipelineResult:
        """Validate the Excel input and write nothing at all.

        Nothing is written - not even a temporary copy of the XML model.  The
        earlier version of this ran the normal first stage and deleted the file
        afterwards, which quietly destroyed a model the user was keeping.
        """
        diagnostics = DiagnosticCollector()
        self._logger.info(banner("Checking the Excel input"))
        for path in self._config.inputs.excel_files:
            self._logger.info("  reading %s", path)

        model = build_model(self._config, diagnostics)
        self._logger.info("  %d parameter row(s) found (%d enabled)",
                          len(model), len(model.enabled))
        ok = Validator(self._config).validate(model, diagnostics)
        return PipelineResult(ok, diagnostics, parameter_count=len(model.enabled))

    # -- full run --------------------------------------------------------
    def run(self, *, only_xml: bool = False,
            from_xml: Optional[Path] = None) -> PipelineResult:
        diagnostics = DiagnosticCollector()

        if from_xml is not None:
            return self.xml_to_code(from_xml, diagnostics)

        xml_path = self.excel_to_xml(diagnostics)
        if xml_path is None:
            return PipelineResult(False, diagnostics)
        if only_xml:
            return PipelineResult(True, diagnostics, xml_path)
        # stage 1 validated this very model already
        return self.xml_to_code(xml_path, diagnostics, validate=False)


def render_diagnostics(diagnostics: DiagnosticCollector, verbose: bool) -> str:
    """Format the diagnostics for the console."""
    minimum = Severity.INFO if verbose else Severity.WARNING
    return diagnostics.render(minimum)

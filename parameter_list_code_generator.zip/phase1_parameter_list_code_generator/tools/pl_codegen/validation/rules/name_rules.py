"""Rules about parameter names and derived C identifiers."""

from __future__ import annotations

from typing import Dict, List

from ...errors import DiagnosticCollector
from ...model.parameter_list import ParameterList
from ...model.tags import TAG_REGISTRY
from ...naming import (array_size_macro, index_macro, is_reserved_keyword,
                       is_valid_c_identifier, offset_macro, offset_total_macro,
                       smart_data_symbol)
from .rule_base import ValidationRule

#: Names the generated headers already use, or that come from smart_data.h.
#: A parameter whose macros land on one of these silently redefines it.
RESERVED_MACROS = {"TRUE", "FALSE", "NULL"}


class NameSyntaxRule(ValidationRule):
    """The parameter name must be usable as a C identifier."""

    rule_id = "NAME"
    description = "Parameter names must be valid, non-reserved C identifiers."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in model.parameters:
            if not is_valid_c_identifier(parameter.name):
                diagnostics.error(
                    "NAME001",
                    f"Parameter name '{parameter.name}' is not a valid C identifier.",
                    parameter.source,
                    hint="Use letters, digits and '_' only, and do not start with a digit.")
            elif is_reserved_keyword(parameter.name):
                diagnostics.error(
                    "NAME002",
                    f"Parameter name '{parameter.name}' is a reserved C/C++ keyword.",
                    parameter.source)


class NameUniquenessRule(ValidationRule):
    """Names must be unique across *all* merged workbooks."""

    rule_id = "NAME_UNIQUE"
    description = "Parameter names must be unique across every input workbook."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        seen: Dict[str, List] = {}
        for parameter in model.parameters:
            seen.setdefault(parameter.name, []).append(parameter)

        for name, duplicates in seen.items():
            if len(duplicates) < 2:
                continue
            origins = "; ".join(str(item.source) for item in duplicates)
            for parameter in duplicates:
                diagnostics.error(
                    "NAME003",
                    f"Parameter name '{name}' is defined {len(duplicates)} times.",
                    parameter.source,
                    hint=f"All definitions: {origins}")


class IndexMacroCollisionRule(ValidationRule):
    """Every identifier the generator invents must be unique and legal.

    Two different problems live here, and both produce code that *compiles*:

    * Two parameters can map onto the same macro.  ``TestVar`` and
      ``Test_Var`` both become ``TEST_VAR``, and the second ``#define`` silently
      wins.
    * A parameter can collide with a macro the generator makes for another
      reason - the array size of a different parameter, a tag offset, the
      quantity define - or with ``TRUE`` / ``FALSE`` / ``NULL`` from
      ``smart_data.h``.  A row named ``ParameterListQty`` redefines
      ``PARAMETER_LIST_QTY``, and the descriptor table is then declared with the
      wrong length.

    So every generated name is collected into one table with the reason it
    exists, and any name claimed twice is an error.
    """

    rule_id = "NAME_MACRO"
    description = "Generated macros and symbols must be unique and valid C identifiers."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        index_prefix = self.config.codegen.index_define_prefix
        offset_prefix = self.config.codegen.offset_define_prefix
        smart_prefix = self.config.codegen.smart_data_prefix

        #: name -> list of (what it is, the parameter it belongs to or None)
        claimed: Dict[str, List] = {}

        def claim(name: str, reason: str, parameter=None) -> None:
            claimed.setdefault(name, []).append((reason, parameter))

        # ---- what the generator makes regardless of the parameters --------
        claim(self.config.codegen.quantity_define, "the number of parameters")
        for macro in RESERVED_MACROS:
            claim(macro, "defined by smart_data.h")
        for spec in TAG_REGISTRY:
            claim(offset_total_macro(spec.tag_id, offset_prefix),
                  f"the size of the '{spec.tag_id}' tag area")

        # ---- and what it makes for each parameter --------------------------
        for parameter in model.enabled:
            claim(index_macro(parameter.name, index_prefix), "an index macro", parameter)
            claim(smart_data_symbol(parameter.name, smart_prefix),
                  "a smart-data object", parameter)
            if parameter.is_array:
                claim(array_size_macro(parameter.name, index_prefix),
                      "an array size macro", parameter)
            for spec in TAG_REGISTRY:
                if parameter.has_active_tag(spec.tag_id):
                    claim(offset_macro(spec.tag_id, parameter.name, offset_prefix),
                          f"the '{spec.tag_id}' offset macro", parameter)

        # ---- report -------------------------------------------------------
        for name, owners in claimed.items():
            reported = [item for item in owners if item[1] is not None]
            if len(owners) < 2 or not reported:
                continue
            described = "; ".join(
                f"{reason}" + (f" of '{item.name}'" if item is not None else "")
                for reason, item in owners)
            for _reason, parameter in reported:
                diagnostics.error(
                    "NAME004",
                    f"'{name}' is used for more than one thing: {described}.",
                    parameter.source,
                    hint="Rename the parameter, or change 'codegen.index_define_prefix' "
                         "or 'codegen.offset_define_prefix' in the configuration.")


class GeneratedIdentifierRule(ValidationRule):
    """A name that is a legal C identifier can still make an illegal macro.

    ``to_macro_case`` strips the underscores at the ends, so a parameter called
    ``_1`` - perfectly legal in C - becomes the macro ``1``, and the generated
    header does not compile.  The names the generator derives are therefore
    checked as well, not only the name the user wrote.
    """

    rule_id = "NAME_DERIVED"
    description = "Macros and symbols derived from a name must be valid C identifiers."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        index_prefix = self.config.codegen.index_define_prefix
        offset_prefix = self.config.codegen.offset_define_prefix
        smart_prefix = self.config.codegen.smart_data_prefix

        for parameter in model.enabled:
            derived = [
                ("index macro", index_macro(parameter.name, index_prefix)),
                ("smart-data object", smart_data_symbol(parameter.name, smart_prefix)),
            ]
            if parameter.is_array:
                derived.append(("array size macro",
                                array_size_macro(parameter.name, index_prefix)))
            for spec in TAG_REGISTRY:
                if parameter.has_active_tag(spec.tag_id):
                    derived.append((f"'{spec.tag_id}' offset macro",
                                    offset_macro(spec.tag_id, parameter.name,
                                                 offset_prefix)))

            for what, name in derived:
                if is_valid_c_identifier(name) and not is_reserved_keyword(name):
                    continue
                diagnostics.error(
                    "NAME005",
                    f"The {what} derived from '{parameter.name}' is '{name}', "
                    f"which is not a usable C identifier.",
                    parameter.source,
                    hint="Give the parameter a name that starts with a letter and "
                         "holds letters, digits and inner underscores.")

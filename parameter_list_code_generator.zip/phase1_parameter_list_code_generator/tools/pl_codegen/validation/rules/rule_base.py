"""Base class shared by every validation rule.

A rule is a small, self-contained class with one job.  Adding a new check means
adding one file in this folder and listing the class in ``rules/__init__.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from ...config import Config
from ...errors import DiagnosticCollector
from ...model.parameter_list import ParameterList


class ValidationRule(ABC):
    """One check performed on the whole parameter list."""

    #: short, stable identifier used as a diagnostic code prefix
    rule_id: str = "RULE"
    #: one-line description shown by ``generate.py --list-rules``
    description: str = ""

    def __init__(self, config: Config) -> None:
        self.config = config

    @abstractmethod
    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        """Inspect *model* and append findings to *diagnostics*."""

    def __str__(self) -> str:  # pragma: no cover - debugging helper
        return f"{self.rule_id}: {self.description}"

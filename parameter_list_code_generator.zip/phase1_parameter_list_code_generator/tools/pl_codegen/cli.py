"""Command line interface of the parameter-list code generator."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional, Sequence

from . import __tool_name__, __version__
from .config import Config
from .errors import CodeGeneratorError, Severity
from .logging_utils import banner, setup_logging
from .pipeline import Pipeline, render_diagnostics
from .validation.rules import ALL_RULES

DEFAULT_CONFIG = "codegen_config.json"

#: The 'tools' folder, where the configuration file lives next to generate.py.
TOOLS_DIR = Path(__file__).resolve().parent.parent

EXIT_OK = 0
EXIT_VALIDATION_FAILED = 1
EXIT_TOOL_ERROR = 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="generate.py",
        description="Generates the parameter-list C code from one or more Excel workbooks.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python generate.py                       # full run with the default config\n"
            "  python generate.py --only-xml            # only refresh the XML model\n"
            "  python generate.py --from-xml model.xml  # generate code from an existing XML\n"
            "  python generate.py --check               # validate the Excel files only\n"))

    parser.add_argument("-c", "--config", type=Path, default=None,
                        help=f"configuration file (default: the {DEFAULT_CONFIG} of the "
                             f"current folder, otherwise the one next to generate.py)")
    parser.add_argument("--only-xml", action="store_true",
                        help="stop after writing the intermediate XML model")
    parser.add_argument("--from-xml", type=Path, metavar="FILE",
                        help="skip the Excel stage and generate code from FILE")
    parser.add_argument("--check", action="store_true",
                        help="validate the input only; write no file at all")
    parser.add_argument("--list-rules", action="store_true",
                        help="print every validation rule and exit")
    parser.add_argument("-W", "--warnings-as-errors", action="store_true",
                        help="treat warnings as errors")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="also show informational diagnostics")
    parser.add_argument("-q", "--quiet", action="store_true", help="only show problems")
    parser.add_argument("--version", action="version",
                        version=f"{__tool_name__} {__version__}")
    return parser


def resolve_config_path(given: Optional[Path]) -> Path:
    """Where to read the configuration from.

    ``generate.py`` is meant to work from any working directory, so the default
    cannot simply be a relative name: running it as
    ``python tools/generate.py`` from the project folder would look for the
    configuration in the project folder and fail.  A file in the current folder
    still wins, which is what someone experimenting with a second configuration
    expects.
    """
    if given is not None:
        return given
    local = Path(DEFAULT_CONFIG)
    if local.is_file():
        return local
    return TOOLS_DIR / DEFAULT_CONFIG


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_parser().parse_args(argv)
    logger = setup_logging(verbose=arguments.verbose, quiet=arguments.quiet)

    if arguments.list_rules:
        _print_rules()
        return EXIT_OK

    try:
        config = Config.load(resolve_config_path(arguments.config))
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if arguments.warnings_as_errors:
        config.validation.treat_warnings_as_errors = True

    logger.info("%s v%s", __tool_name__, __version__)
    logger.info("configuration: %s", config.path)

    try:
        pipeline = Pipeline(config)
        if arguments.check:
            result = pipeline.check()
        else:
            result = pipeline.run(only_xml=arguments.only_xml, from_xml=arguments.from_xml)
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if not arguments.quiet or not result.success:
        _print_summary(result, arguments.verbose)
    return EXIT_OK if result.success else EXIT_VALIDATION_FAILED


def _print_rules() -> None:
    print("Validation rules:")
    for rule_class in ALL_RULES:
        print(f"  {rule_class.rule_id:<16} {rule_class.description}")


def _print_summary(result, verbose: bool) -> None:
    diagnostics = result.diagnostics
    text = render_diagnostics(diagnostics, verbose)
    print(banner("Diagnostics"))
    print(text)
    print()
    print(diagnostics.summary())

    if result.success:
        if result.generated_files:
            print(f"\nGenerated {len(result.generated_files)} file(s) for "
                  f"{result.parameter_count} parameter(s):")
            for path in result.generated_files:
                print(f"  {path}")
        elif result.xml_file is not None:
            print(f"\nXML model: {result.xml_file}")
        if result.generated_files and result.xml_file is not None:
            print(f"  {result.xml_file}")
        print("\nDone.")
    else:
        print("\nCode generation was aborted because the input contains errors.")
        if diagnostics.count(Severity.ERROR) == 0:
            print("(warnings are treated as errors)")


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

"""The aggregated parameter list: several workbooks merged into one model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional

from .defines import Defines
from .parameter import Parameter


@dataclass
class ParameterList:
    """All parameters of all input workbooks, treated as a single list."""

    parameters: List[Parameter] = field(default_factory=list)
    defines: Defines = field(default_factory=Defines)
    source_files: List[str] = field(default_factory=list)
    generator_version: str = ""
    generated_at: str = ""

    # -- collection behaviour -------------------------------------------
    def __iter__(self) -> Iterator[Parameter]:
        return iter(self.parameters)

    def __len__(self) -> int:
        return len(self.parameters)

    def add(self, parameter: Parameter) -> None:
        self.parameters.append(parameter)

    # -- views -----------------------------------------------------------
    @property
    def enabled(self) -> List[Parameter]:
        """Parameters that take part in code generation, in Excel order."""
        return [parameter for parameter in self.parameters if parameter.enable]

    @property
    def disabled(self) -> List[Parameter]:
        return [parameter for parameter in self.parameters if not parameter.enable]

    def index_of(self, name: str) -> Optional[int]:
        for index, parameter in enumerate(self.enabled):
            if parameter.name == name:
                return index
        return None

    def by_name(self) -> Dict[str, Parameter]:
        return {parameter.name: parameter for parameter in self.parameters}

    def used_data_type_suffixes(self) -> List[str]:
        """Smart-data suffixes actually used by the enabled parameters."""
        suffixes: List[str] = []
        for parameter in self.enabled:
            data_type = parameter.data_type
            if data_type is not None and data_type.suffix not in suffixes:
                suffixes.append(data_type.suffix)
        return suffixes

    def has_array_parameters(self) -> bool:
        return any(parameter.is_array for parameter in self.enabled)

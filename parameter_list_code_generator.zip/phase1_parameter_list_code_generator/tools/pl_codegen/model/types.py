"""Registry of the C data types supported by the parameter list.

Adding a new supported data type is a one-entry change in :data:`DATA_TYPES`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass(frozen=True)
class CDataType:
    """Everything the generator needs to know about one supported C type."""

    c_name: str            #: name used in the Excel sheet, e.g. ``uint8_t``
    suffix: str            #: smart-data suffix, e.g. ``U8``
    kind: str              #: ``"bool"`` | ``"int"`` | ``"float"``
    signed: bool
    bits: int
    literal_suffix: str    #: appended to numeric literals in generated C code
    native_min: Optional[float]
    native_max: Optional[float]

    @property
    def smart_data_struct(self) -> str:
        return f"sSmartData{self.suffix}"

    @property
    def constructor(self) -> str:
        return f"fSmartData_{self.suffix}_Ctor"

    @property
    def enum_name(self) -> str:
        return f"eSMART_DATA_TYPE_{self.suffix}"

    @property
    def value_size(self) -> int:
        """Size in bytes of the *value* of this type.

        This is what the tag offsets advance by: a ``uint16_t``
        parameter occupies 2 bytes, a ``uint64_t`` one occupies 8.  The sizes
        are fixed by the C standard, so the generated offsets are the same on
        every compiler.
        """
        return 1 if self.kind == "bool" else self.bits // 8

    @property
    def has_range(self) -> bool:
        """``bool_t`` smart data has no min/max/resolution."""
        return self.kind != "bool"

    @property
    def is_float(self) -> bool:
        return self.kind == "float"

    @property
    def is_bool(self) -> bool:
        return self.kind == "bool"


def _int(c_name: str, suffix: str, bits: int, signed: bool, literal_suffix: str) -> CDataType:
    if signed:
        native_min, native_max = -(2 ** (bits - 1)), 2 ** (bits - 1) - 1
    else:
        native_min, native_max = 0, 2 ** bits - 1
    return CDataType(c_name, suffix, "int", signed, bits, literal_suffix, native_min, native_max)


#: Every data type the generator can emit.  Structs and enums are intentionally
#: **not** supported in this phase and are rejected by the validator.
DATA_TYPES: Dict[str, CDataType] = {
    "bool_t": CDataType("bool_t", "B8", "bool", False, 8, "", None, None),
    "uint8_t": _int("uint8_t", "U8", 8, False, "U"),
    "int8_t": _int("int8_t", "I8", 8, True, ""),
    "uint16_t": _int("uint16_t", "U16", 16, False, "U"),
    "int16_t": _int("int16_t", "I16", 16, True, ""),
    "uint32_t": _int("uint32_t", "U32", 32, False, "UL"),
    "int32_t": _int("int32_t", "I32", 32, True, "L"),
    "uint64_t": _int("uint64_t", "U64", 64, False, "ULL"),
    "int64_t": _int("int64_t", "I64", 64, True, "LL"),
    "float32_t": CDataType("float32_t", "F32", "float", True, 32, "f", -3.4028235e38, 3.4028235e38),
    "float64_t": CDataType("float64_t", "F64", "float", True, 64, "", -1.7976931348623157e308,
                           1.7976931348623157e308),
}

#: Spellings accepted in the Excel sheet that map onto a canonical type.
TYPE_ALIASES: Dict[str, str] = {
    "bool": "bool_t",
    "boolean": "bool_t",
    "b8": "bool_t",
    "float": "float32_t",
    "double": "float64_t",
    "float_t": "float32_t",
    "u8": "uint8_t", "i8": "int8_t", "s8": "int8_t",
    "u16": "uint16_t", "i16": "int16_t", "s16": "int16_t",
    "u32": "uint32_t", "i32": "int32_t", "s32": "int32_t",
    "u64": "uint64_t", "i64": "int64_t", "s64": "int64_t",
    "f32": "float32_t", "f64": "float64_t",
}


def resolve_data_type(name: Optional[str]) -> Optional[CDataType]:
    """Return the :class:`CDataType` for *name*, or ``None`` when unsupported."""
    if not name:
        return None
    key = str(name).strip()
    if key in DATA_TYPES:
        return DATA_TYPES[key]
    return DATA_TYPES.get(TYPE_ALIASES.get(key.lower(), ""), None)


def supported_type_names() -> str:
    """Comma separated list of supported type names (used in error messages)."""
    return ", ".join(sorted(DATA_TYPES))

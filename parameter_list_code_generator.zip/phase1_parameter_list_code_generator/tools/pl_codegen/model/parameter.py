"""In-memory description of a single parameter."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Union

from ..errors import SourceLocation
from .types import CDataType, resolve_data_type

#: Value a tag can hold once it has been read from Excel / XML.
TagValue = Union[bool, int, str, None]

#: Numeric value of a parameter (default / min / max / resolution).
NumericValue = Union[int, float, bool, None]


@dataclass
class Parameter:
    """One row of the *ParameterList* sheet."""

    name: str
    enable: bool = True
    gs_name: Optional[str] = None
    group: Optional[str] = None
    data_type_name: Optional[str] = None
    array_size: int = 1
    default_value: NumericValue = None
    minimum: NumericValue = None
    maximum: NumericValue = None
    resolution: NumericValue = None
    unit: Optional[str] = None
    tags: Dict[str, TagValue] = field(default_factory=dict)
    description: Optional[str] = None
    source: SourceLocation = field(default_factory=SourceLocation)

    # -- derived ---------------------------------------------------------
    @property
    def data_type(self) -> Optional[CDataType]:
        """Resolved data type, or ``None`` when the type is unknown/unsupported."""
        return resolve_data_type(self.data_type_name)

    @property
    def is_array(self) -> bool:
        return self.array_size > 1

    @property
    def range_disabled(self) -> bool:
        """True when this parameter is not meant to have an allowed range.

        Writing a zero minimum **and** a zero maximum means "the whole range of
        the type", as the module specification requires.  Leaving both cells
        empty means the same thing - the user simply did not ask for a range.

        What that turns into in the generated code is the *native* range of the
        C type, never ``0, 0``: the smart-data constructor refuses a default
        value outside ``[min, max]``, so ``0, 0`` would make every parameter
        with a non-zero default fail at run time.
        """
        return _is_zero_or_empty(self.minimum) and _is_zero_or_empty(self.maximum)

    @property
    def effective_minimum(self) -> NumericValue:
        """The minimum the generated constructor will actually be given."""
        return self._effective_limit(self.minimum, native=True, low=True)

    @property
    def effective_maximum(self) -> NumericValue:
        """The maximum the generated constructor will actually be given."""
        return self._effective_limit(self.maximum, native=True, low=False)

    def _effective_limit(self, value: NumericValue, native: bool, low: bool) -> NumericValue:
        data_type = self.data_type
        if data_type is None or not data_type.has_range:
            return None
        if self.range_disabled and native:
            return data_type.native_min if low else data_type.native_max
        # only one of the two cells was filled in: the empty one counts as zero
        return 0 if value is None else value

    def tag(self, tag_id: str) -> TagValue:
        return self.tags.get(tag_id)

    def effective_tag(self, tag_id: str) -> TagValue:
        """The value of a tag as the generated code will see it.

        Only one tag is not simply what the cell says: ``LogID`` belongs to
        logging, so it exists only while ``Tag Loggable`` is TRUE.  A number
        left behind in the LogID cell of a row that is not logged means
        nothing - it must not reserve an id, must not clash with anything, and
        must not appear in the generated table.
        """
        from .tags import LOG_ID_TAG, LOGGABLE_TAG

        if tag_id == LOG_ID_TAG and not self.has_active_tag(LOGGABLE_TAG):
            return None
        return self.tags.get(tag_id)

    def has_active_tag(self, tag_id: str) -> bool:
        """Whether this parameter *carries* the tag.

        This is what decides whether the parameter takes up room in that tag's
        offset area, so it goes through :meth:`effective_tag` - a log id on a
        non-loggable parameter reserves nothing.

        A boolean tag is carried when it is TRUE.  Any other tag is carried
        whenever a value is written, **including zero**: 0 is a perfectly good
        log id, and treating it as "no tag" would leave that parameter out of
        the offset area while the log-id rule still reserved ids for it - the
        two would then disagree about the memory map.
        """
        value = self.effective_tag(tag_id)
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            return True
        return str(value).strip() != ""

    def __str__(self) -> str:  # pragma: no cover - debugging helper
        return f"Parameter({self.name}, {self.data_type_name}, x{self.array_size})"


def _is_zero_or_empty(value: NumericValue) -> bool:
    """An empty cell and a zero mean the same thing for a limit."""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return float(value) == 0.0

"""Entry point of the parameter-list code generator.

Usage (from the ``tools`` folder)::

    python setup_environment.py     # once, installs the required packages
    python generate.py              # generates the C files

Everything else is configured in ``codegen_config.json``.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running the script directly from any working directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from pl_codegen.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())

/**
  ******************************************************************************
  * @file    cg_parameter_list_defines.h
  * @brief   Quantities, parameter indices, tag offsets and generated enumerations.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-08-29 14:25:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 6 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_DEFINES_H
#define CG_PARAMETER_LIST_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include <stdint.h>

/* Exported defines --------------------------------------------------------- */
/* Number of parameters in the parameter list */
#define PARAMETER_LIST_QTY  (6U)  /*!< Number of enabled parameters */

/* Index of every parameter inside the parameter list */
#define POS_DRONE   (0U)  /*!< uint8_t [mm] */
#define VEL_DRONE   (1U)  /*!< float64_t [m/s] */
#define TEST_ARRAY  (2U)  /*!< int8_t[100] */
#define TEST_VAR    (3U)  /*!< int32_t */
#define TEST_VAR2   (4U)  /*!< int32_t */
#define REZASAEEDI  (5U)  /*!< int64_t */

/* Array size of every array parameter */
#define TEST_ARRAY_ARRAY_SIZE  (100U)  /*!< Number of elements of 'TestArray' */

/* Total size used by every tag */
#define PARAMETER_LIST_SIZE_SYSTEM_NAME     (125U)  /*!< Bytes used by tag 'SystemName' (6 parameter(s)) */
#define PARAMETER_LIST_SIZE_RESET_PROOF     (9U)    /*!< Bytes used by tag 'ResetProof' (2 parameter(s)) */
#define PARAMETER_LIST_SIZE_LOGGABLE        (9U)    /*!< Bytes used by tag 'Loggable' (2 parameter(s)) */
#define PARAMETER_LIST_SIZE_LOG_ID          (109U)  /*!< Bytes used by tag 'LogId' (3 parameter(s)) */
#define PARAMETER_LIST_SIZE_LOG_ENCRYPTION  (9U)    /*!< Bytes used by tag 'LogEncryption' (2 parameter(s)) */
#define PARAMETER_LIST_SIZE_PARAM_MODE      (125U)  /*!< Bytes used by tag 'ParamMode' (6 parameter(s)) */

/* MemoryOffset of every parameter, per tag */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_POS_DRONE     (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_VEL_DRONE     (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_ARRAY    (9U)    /*!< 100 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_VAR      (109U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_VAR2     (113U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_SYSTEM_NAME_REZASAEEDI    (117U)  /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_POS_DRONE     (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_RESET_PROOF_VEL_DRONE     (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_POS_DRONE        (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOGGABLE_VEL_DRONE        (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_POS_DRONE          (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_VEL_DRONE          (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ID_TEST_ARRAY         (9U)    /*!< 100 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ENCRYPTION_POS_DRONE  (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_LOG_ENCRYPTION_VEL_DRONE  (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_POS_DRONE      (0U)    /*!< 1 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_VEL_DRONE      (1U)    /*!< 8 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_ARRAY     (9U)    /*!< 100 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_VAR       (109U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_VAR2      (113U)  /*!< 4 byte(s) */
#define PARAMETER_LIST_OFFSET_PARAM_MODE_REZASAEEDI     (117U)  /*!< 8 byte(s) */

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/**
 * @brief Values of the 'SYSTEM NAMES' column of the Excel 'Defines' sheet.
 *
 */
typedef enum {

    SYS_UNKNOWN         = 0,
    SYS_GS_COMPUTER     = 1,
    SYS_GS_MANAGER      = 2,
    SYS_GS_POWER        = 3,
    SYS_ANTENNA_TRACKER = 4,
    SYS_AC_MANAGER      = 5,
    SYS_AC_POWER        = 6,
    SYS_AC_AUTOPILOT    = 7,
    SYS_GIMBAL          = 8,
    SYS_LOCK_TRACK      = 9,
    SYS_LINK_GS         = 10,
    SYS_GS_USB2CAN      = 11,
    SYS_LINK_AIR        = 12,
    SYS_BOOTLOADER      = 13,
    SYS_LINK_BOX        = 14,
    SYS_GOVERNOR        = 15,
    SYS_NAV             = 16,
    SYS_AND             = 17,
    SYS_VNS             = 18,
    SYS_RHS             = 19,
    SYS_AUP             = 20

} eParameterListSystemName;

/**
 * @brief Values of the 'PARAM MODES' column of the Excel 'Defines' sheet.
 *
 */
typedef enum {

    PARAM_MODE_USER         = 0,
    PARAM_MODE_READ_ONLY    = 1,
    PARAM_MODE_PRODUCT_TYPE = 2,
    PARAM_MODE_FACTORY      = 3,
    PARAM_MODE_CALIB        = 4,
    PARAM_MODE_TEMPORARY    = 5

} eParameterListParamMode;

/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_DEFINES_H */

/* === Copyright (c) 2026 FAS === EOF === */

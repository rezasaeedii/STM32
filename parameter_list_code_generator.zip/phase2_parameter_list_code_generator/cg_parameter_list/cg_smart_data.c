/**
  ******************************************************************************
  * @file    cg_smart_data.c
  * @brief   Definition and construction of the generated smart-data objects.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-08-29 14:25:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 6 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_smart_data.h"
#include "smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
sSmartDataU8 Cg_SmartData_PosDrone;
sSmartDataF64 Cg_SmartData_VelDrone;
sSmartDataI8 Cg_SmartData_TestArray[TEST_ARRAY_ARRAY_SIZE];
sSmartDataI32 Cg_SmartData_TestVar;
sSmartDataI32 Cg_SmartData_TestVar2;
sSmartDataI64 Cg_SmartData_Rezasaeedi;

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Constructs every generated smart-data object.
 *
 * @return uint8_t 0 on success, otherwise the failing eSmartDataStatus value.
 */
uint8_t fCgSmartData_Init(void) {

    eSmartDataStatus status = eSMART_DATA_OK;
    uint16_t index = 0U;

    status = fSmartData_U8_Ctor(&Cg_SmartData_PosDrone, 0U, 10U, 1U, 1U);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_F64_Ctor(&Cg_SmartData_VelDrone, -10.0, 10.0, 2.0, 0.01);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    for (index = 0U; index < TEST_ARRAY_ARRAY_SIZE; index++) {
        status = fSmartData_I8_Ctor(&Cg_SmartData_TestArray[index], (-1), 1, 1, 1);
        if (status != eSMART_DATA_OK) {
            return (uint8_t)status;
        }
    }

    status = fSmartData_I32_Ctor(&Cg_SmartData_TestVar, 0L, 100L, 1L, 1L);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_I32_Ctor(&Cg_SmartData_TestVar2, 0L, 100L, 1L, 1L);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    status = fSmartData_I64_Ctor(&Cg_SmartData_Rezasaeedi, 0LL, 100LL, 1LL, 1LL);
    if (status != eSMART_DATA_OK) {
        return (uint8_t)status;
    }

    return (uint8_t)status;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

/**
  ******************************************************************************
  * @file    cg_smart_data.h
  * @brief   Smart-data objects that hold the value of every parameter.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-08-29 14:25:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 6 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_SMART_DATA_H
#define CG_SMART_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "smart_data.h"
#include "cg_parameter_list_defines.h"
#include "cg_parameter_list_types.h"

/* Exported defines --------------------------------------------------------- */
/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
uint8_t fCgSmartData_Init(void);

/* Exported variables ------------------------------------------------------- */
extern sSmartDataU8 Cg_SmartData_PosDrone;  /*!< [mm] This is a test description */
extern sSmartDataF64 Cg_SmartData_VelDrone;  /*!< [m/s] This is a test description */
extern sSmartDataI8 Cg_SmartData_TestArray[TEST_ARRAY_ARRAY_SIZE];  /*!< This is a test description */
extern sSmartDataI32 Cg_SmartData_TestVar;  /*!< This is a test description */
extern sSmartDataI32 Cg_SmartData_TestVar2;  /*!< This is a test description */
extern sSmartDataI64 Cg_SmartData_Rezasaeedi;  /*!< This is a test description */

#ifdef __cplusplus
}
#endif

#endif /* CG_SMART_DATA_H */

/* === Copyright (c) 2026 FAS === EOF === */

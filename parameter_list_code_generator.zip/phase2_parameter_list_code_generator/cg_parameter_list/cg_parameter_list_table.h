/**
  ******************************************************************************
  * @file    cg_parameter_list_table.h
  * @brief   The Excel parameter list, drawn as a table. Documentation only - no code.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-08-29 14:25:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 6 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CG_PARAMETER_LIST_TABLE_H
#define CG_PARAMETER_LIST_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
/* Exported defines --------------------------------------------------------- */
/*
  Parameter list - values

  +---+----+---------------+-----------+------------+-------------+-----+---------+-----+-----+------+------+
  | # | En | Name          | GS Name   | Group      | DataType    | Arr | Default | Min | Max | Res  | Unit |
  +---+----+---------------+-----------+------------+-------------+-----+---------+-----+-----+------+------+
  | 0 | x  | PosDrone      | PosDrone  | MONITORING | uint8_t     | 1   | 1       | 0   | 10  | 1    | mm   |
  | 1 | x  | VelDrone      | VelDrone  | MONITORING | float64_t   | 1   | 2       | -10 | 10  | 0.01 | m/s  |
  | 2 | x  | TestArray     | TestArray | MONITORING | int8_t      | 100 | 1       | -1  | 1   | 1    | -    |
  | 3 | x  | TestVar       | -         | SETTING    | int32_t     | 1   | 1       | 0   | 100 | 1    | -    |
  | - |    | TestVarStruct | -         | MONITORING | sTestStruct | 1   | -       | -   | -   | -    | -    |
  | 4 | x  | TestVar2      | -         | SETTING    | int32_t     | 1   | 1       | 0   | 100 | 1    | -    |
  | 5 | x  | Rezasaeedi    | rezasname | SETTING    | int64_t     | 1   | 1       | 0   | 100 | 1    | -    |
  +---+----+---------------+-----------+------------+-------------+-----+---------+-----+-----+------+------+
*/

/*
  Parameter list - tags

  +---+---------------+---------------------+------------+----------+-------+---------------+-------------------------+------+------+------+------+-------------+
  | # | Name          | SystemName          | ResetProof | Loggable | LogId | LogEncryption | ParamMode               | Tag1 | Tag2 | Tag3 | Tag4 | LogID range |
  +---+---------------+---------------------+------------+----------+-------+---------------+-------------------------+------+------+------+------+-------------+
  | 0 | PosDrone      | SYS_GS_COMPUTER     | x          | x        | 1001  | x             | PARAM_MODE_USER         | -    | -    | -    | -    | 1001        |
  | 1 | VelDrone      | SYS_ANTENNA_TRACKER | x          | x        | 1044  | x             | PARAM_MODE_READ_ONLY    | -    | -    | -    | -    | 1044..1051  |
  | 2 | TestArray     | SYS_LOCK_TRACK      |            |          | 1052  |               | PARAM_MODE_PRODUCT_TYPE | -    | -    | -    | -    | 1052..1151  |
  | 3 | TestVar       | SYS_GS_POWER        |            |          | -     |               | PARAM_MODE_CALIB        | -    | -    | -    | -    | -           |
  | - | TestVarStruct | SYS_LINK_GS         | x          |          | -     |               | PARAM_MODE_TEMPORARY    | -    | -    | -    | -    | -           |
  | 4 | TestVar2      | SYS_GS_POWER        |            |          | -     |               | PARAM_MODE_CALIB        | -    | -    | -    | -    | -           |
  | 5 | Rezasaeedi    | SYS_GS_POWER        |            |          | -     |               | PARAM_MODE_CALIB        | -    | -    | -    | -    | -           |
  +---+---------------+---------------------+------------+----------+-------+---------------+-------------------------+------+------+------+------+-------------+
*/

/*
  MemoryOffset of every parameter, per tag

  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+
  | # | Name          | Bytes | SystemName | ResetProof | Loggable | LogId | LogEncryption | ParamMode |
  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+
  | 0 | PosDrone      | 1     | 0          | 0          | 0        | 0     | 0             | 0         |
  | 1 | VelDrone      | 8     | 1          | 1          | 1        | 1     | 1             | 1         |
  | 2 | TestArray     | 100   | 9          | -          | -        | 9     | -             | 9         |
  | 3 | TestVar       | 4     | 109        | -          | -        | -     | -             | 109       |
  | 4 | TestVar2      | 4     | 113        | -          | -        | -     | -             | 113       |
  | 5 | Rezasaeedi    | 8     | 117        | -          | -        | -     | -             | 117       |
  |   | TOTAL (bytes) |       | 125        | 9          | 9        | 109   | 9             | 125       |
  +---+---------------+-------+------------+------------+----------+-------+---------------+-----------+

  Every tag owns an independent counter that starts at 0 and advances by
  sizeof(value) * ArraySize for every parameter that carries the tag.
  '-' means the tag is not active for that parameter, so its offset is 0.
*/

/* Exported macros ---------------------------------------------------------- */
/* Exported types ----------------------------------------------------------- */
/* Exported functions ------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* CG_PARAMETER_LIST_TABLE_H */

/* === Copyright (c) 2026 FAS === EOF === */

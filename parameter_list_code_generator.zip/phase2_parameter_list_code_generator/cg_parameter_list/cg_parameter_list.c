/**
  ******************************************************************************
  * @file    cg_parameter_list.c
  * @brief   Generated parameter list and its access functions.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v2.0.0
  * Generated at   : 2026-08-29 14:25:05 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\phase2_parameter_list_code_generator\parameter_list_template.xlsx
  * Parameters     : 6 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "cg_parameter_list.h"

#include <stddef.h>
#include <string.h>

#include "smart_data.h"
#include "cg_smart_data.h"

/* Private defines ---------------------------------------------------------- */
/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/* Exported variables ------------------------------------------------------- */
/**
 * @brief Descriptor of every parameter of the merged parameter list.
 *        The order of the entries matches the index macros of 'cg_parameter_list_defines.h'.
 *
 */
const sParameterDescriptor ParameterList[PARAMETER_LIST_QTY] = {
    /* [0] POS_DRONE */
    {
        .pName = "PosDrone",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_PosDrone,
        .ArraySize = 1U,
        .pUnit = "mm",
        .TagSystemName = { .Value = (uint32_t)SYS_GS_COMPUTER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_POS_DRONE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_POS_DRONE },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_POS_DRONE },
        .TagLogId = { .Value = 1001U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_POS_DRONE },
        .TagLogEncryption = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ENCRYPTION_POS_DRONE },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_USER, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_POS_DRONE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    },

    /* [1] VEL_DRONE */
    {
        .pName = "VelDrone",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_VelDrone,
        .ArraySize = 1U,
        .pUnit = "m/s",
        .TagSystemName = { .Value = (uint32_t)SYS_ANTENNA_TRACKER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_VEL_DRONE },
        .TagResetProof = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_RESET_PROOF_VEL_DRONE },
        .TagLoggable = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOGGABLE_VEL_DRONE },
        .TagLogId = { .Value = 1044U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_VEL_DRONE },
        .TagLogEncryption = { .Value = (uint32_t)TRUE, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ENCRYPTION_VEL_DRONE },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_READ_ONLY, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_VEL_DRONE },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    },

    /* [2] TEST_ARRAY */
    {
        .pName = "TestArray",
        .Group = ePARAMETER_GROUP_MONITORING,
        .pSmartData = (void *)&Cg_SmartData_TestArray[0],
        .ArraySize = TEST_ARRAY_ARRAY_SIZE,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_LOCK_TRACK, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_ARRAY },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 1052U, .MemoryOffset = PARAMETER_LIST_OFFSET_LOG_ID_TEST_ARRAY },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_PRODUCT_TYPE, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_ARRAY },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    },

    /* [3] TEST_VAR */
    {
        .pName = "TestVar",
        .Group = ePARAMETER_GROUP_SETTING,
        .pSmartData = (void *)&Cg_SmartData_TestVar,
        .ArraySize = 1U,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_GS_POWER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_VAR },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_CALIB, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_VAR },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    },

    /* [4] TEST_VAR2 */
    {
        .pName = "TestVar2",
        .Group = ePARAMETER_GROUP_SETTING,
        .pSmartData = (void *)&Cg_SmartData_TestVar2,
        .ArraySize = 1U,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_GS_POWER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_TEST_VAR2 },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_CALIB, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_TEST_VAR2 },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    },

    /* [5] REZASAEEDI */
    {
        .pName = "Rezasaeedi",
        .Group = ePARAMETER_GROUP_SETTING,
        .pSmartData = (void *)&Cg_SmartData_Rezasaeedi,
        .ArraySize = 1U,
        .pUnit = NULL,
        .TagSystemName = { .Value = (uint32_t)SYS_GS_POWER, .MemoryOffset = PARAMETER_LIST_OFFSET_SYSTEM_NAME_REZASAEEDI },
        .TagResetProof = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLoggable = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagLogId = { .Value = 0U, .MemoryOffset = 0U },
        .TagLogEncryption = { .Value = (uint32_t)FALSE, .MemoryOffset = 0U },
        .TagParamMode = { .Value = (uint32_t)PARAM_MODE_CALIB, .MemoryOffset = PARAMETER_LIST_OFFSET_PARAM_MODE_REZASAEEDI },
        .Tag1 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag2 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag3 = { .Value = 0U, .MemoryOffset = 0U },
        .Tag4 = { .Value = 0U, .MemoryOffset = 0U },
        .pDescription = "This is a test description"
    }
};

/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/

/**
 * @brief Initialises the parameter list and every smart-data object.
 *
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
uint8_t fParameterList_Init(void) {

    uint8_t result = 0U;

    result = fCgSmartData_Init();
    if (result != 0U) {
        return result;
    }

    result = fParameterList_InitCompletedCallback();
    if (result != 0U) {
        return result;
    }

    return result;

}

/**
 * @brief Called once the parameter list has been initialised.
 *
 * @note  Implement this function in the application layer without the weak
 *        specifier to hook into the initialisation.
 * @return uint8_t 0 on success, otherwise a non-zero error code.
 */
PARAMETER_LIST_WEAK uint8_t fParameterList_InitCompletedCallback(void) {

    return 0U;

}

/**
 * @brief Returns the number of parameters in the list.
 *
 * @return uint16_t Always PARAMETER_LIST_QTY.
 */
uint16_t fParameterList_GetQuantity(void) {

    return (uint16_t)PARAMETER_LIST_QTY;

}

/**
 * @brief Returns the descriptor of the parameter at *index*.
 *
 * @param index Index of the parameter, see 'cg_parameter_list_defines.h'.
 * @return const sParameterDescriptor* NULL when the index is out of range.
 */
const sParameterDescriptor * fParameterList_GetByIndex(uint16_t index) {

    if (index >= (uint16_t)PARAMETER_LIST_QTY) {
        return NULL;
    }

    return &ParameterList[index];

}

/**
 * @brief Returns the descriptor of the parameter called *pName*.
 *
 * @param pName Name of the parameter; a field of a structure is
 *              listed under its dotted name, e.g. "Position.Home.Lat".
 * @return const sParameterDescriptor* NULL when no such parameter exists.
 */
const sParameterDescriptor * fParameterList_GetByName(const char *pName) {

    uint16_t index = 0U;

    if (pName == NULL) {
        return NULL;
    }

    for (index = 0U; index < (uint16_t)PARAMETER_LIST_QTY; index++) {
        if (strcmp(ParameterList[index].pName, pName) == 0) {
            return &ParameterList[index];
        }
    }

    return NULL;

}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */

"""Proves that this tool never needs the internet.

The company machines are offline, so this script exists to make that checkable
instead of merely claimed.  Run it any time - it needs nothing installed:

    cd tools
    python check_offline.py

It walks every file the tool ships and fails if it finds:

  * a URL pointing anywhere other than this machine;
  * an HTML page loading a script, stylesheet, font or image from outside;
  * a CSS ``@import`` or ``url()`` reaching outside;
  * a ``fetch`` / ``XMLHttpRequest`` / ``import`` to a remote address;
  * Python code that opens a network connection (``socket``, ``urllib``,
    ``requests``, ``http.client``) outside the two places that are allowed to:
    the loopback web server of the editor, and the optional package install in
    ``setup_environment.py``.

Exit code 0 means: this folder can be copied onto an air-gapped machine and
everything except "install openpyxl" will work.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import List, NamedTuple

TOOLS_DIR = Path(__file__).resolve().parent
PROJECT_DIR = TOOLS_DIR.parent

#: Directories that are never scanned.
SKIP_DIRECTORIES = {"__pycache__", ".git", ".vscode", ".dist", "cg_output"}

#: Extensions that are scanned as text.
TEXT_SUFFIXES = {".py", ".js", ".css", ".html", ".htm", ".json", ".md", ".xml", ".txt"}

#: Hosts that mean "this machine".
LOCAL_HOSTS = ("127.0.0.1", "localhost", "[::1]", "0.0.0.0")

#: Files allowed to mention the network, and why.
ALLOWED = {
    "tools/setup_environment.py":
        "runs 'pip install openpyxl' - the one optional, one-time online step",
    "tools/check_offline.py":
        "this checker; the patterns it searches for are written down in it",
    "tools/pl_gui/server.py":
        "the loopback web server of the editor",
    "tools/pl_gui/browser.py":
        "starts the local browser with its background networking switched off",
    "tools/README.md":
        "documentation",
}

#: An absolute URL, or a protocol relative one.  The second form insists on a
#: dot and a closing slash so that a '//' comment in a regex is not mistaken
#: for an address.
URL_PATTERN = re.compile(
    r"""https?://([A-Za-z0-9._~:\[\]-]+)"""
    r"""|(?<![\w:.])//([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+)/""")
NETWORK_IMPORT_PATTERN = re.compile(
    r"^\s*(?:import|from)\s+(socket|urllib|requests|http\.client|httpx|aiohttp|ftplib|"
    r"telnetlib|smtplib|xmlrpc)\b", re.MULTILINE)
REMOTE_TAG_PATTERN = re.compile(
    r"""<(?:script|link|img|iframe|source|audio|video)[^>]*?"""
    r"""(?:src|href)\s*=\s*["'](?!data:|#|/|\.|[A-Za-z0-9_-]+\.)([^"']+)""",
    re.IGNORECASE)
CSS_REMOTE_PATTERN = re.compile(
    r"""@import\s+(?:url\()?["']?(?!data:)(https?:|//)""", re.IGNORECASE)

#: Text a browser shows but never fetches: a quoted sample in the manual.
CODE_BLOCK_PATTERN = re.compile(r"<(pre|code)\b[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL)


def blank_out(pattern: re.Pattern, text: str) -> str:
    """Replace every match with spaces, keeping the newlines so line numbers hold."""
    return pattern.sub(lambda m: re.sub(r"[^\n]", " ", m.group(0)), text)


class Finding(NamedTuple):
    path: str
    line: int
    detail: str


def relative(path: Path) -> str:
    return path.relative_to(PROJECT_DIR).as_posix()


def files_to_scan() -> List[Path]:
    result = []
    for path in sorted(PROJECT_DIR.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        if any(part in SKIP_DIRECTORIES for part in path.parts):
            continue
        # the manual embeds its font and screenshots as base64; scanning the
        # whole data URI is pointless, the URL check below still covers it
        result.append(path)
    return result


def line_of(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def _scan_text(suffix: str, text: str) -> List[Finding]:
    """The whole check, on one piece of text.  ``Finding.path`` is left empty."""
    suffix = suffix.lower()
    findings: List[Finding] = []

    # data: URIs are local by definition and would otherwise flood the output
    stripped = re.sub(r"data:[^\"')\s]+", "data:<embedded>", text)

    # An address printed inside <pre> or <code> is a quoted example - the manual
    # shows what a bad reference looks like.  The browser never fetches it, so
    # only the text outside those blocks is scanned for addresses.  A real
    # <link>/<script>/<img> is still caught: the tag check below sees the whole
    # file, and inside a code block the tag is written as &lt;link&gt; anyway.
    addressable = blank_out(CODE_BLOCK_PATTERN, stripped) \
        if suffix in {".html", ".htm"} else stripped

    for match in URL_PATTERN.finditer(addressable):
        host = match.group(1) or match.group(2)
        if host.startswith(LOCAL_HOSTS):
            continue
        findings.append(Finding("", line_of(addressable, match.start()),
                                f"external address '//{host}'"))

    if suffix in {".html", ".htm"}:
        for match in REMOTE_TAG_PATTERN.finditer(stripped):
            findings.append(Finding("", line_of(stripped, match.start()),
                                    f"tag loads '{match.group(1)}' from outside"))

    if suffix == ".css":
        for match in CSS_REMOTE_PATTERN.finditer(stripped):
            findings.append(Finding("", line_of(stripped, match.start()),
                                    "CSS @import from outside"))

    if suffix == ".py":
        for match in NETWORK_IMPORT_PATTERN.finditer(text):
            findings.append(Finding("", line_of(text, match.start()),
                                    f"imports the network module '{match.group(1)}'"))

    return findings


def scan(path: Path) -> List[Finding]:
    name = relative(path)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as error:
        return [Finding(name, 0, f"could not be read: {error}")]

    return [finding._replace(path=name) for finding in _scan_text(path.suffix, text)]


#: Snippets the checker must catch, so that "no problems found" means something.
SELF_TEST = [
    ("page.html", '<script src="https://cdn.example.com/x.js"></script>'),
    ("page.html", '<link rel="stylesheet" href="//fonts.example.com/f.css">'),
    ("page.html", '<img src="http://example.com/logo.png">'),
    ("sheet.css", '@import url("https://fonts.example.com/f.css");'),
    ("code.js", 'fetch("https://api.example.com/v1")'),
    ("code.py", "import requests"),
    ("code.py", "from urllib import request"),
    # a real reference next to a quoted one must still be caught
    ("page.html", '<pre>https://a.example.com</pre>'
                  '<link href="https://real.example.com/f.css">'),
]

#: Snippets the checker must NOT flag.
SELF_TEST_CLEAN = [
    ("code.py", '_LINE_COMMENT = re.compile(r"^\\s*//.*$")'),
    ("code.py", 'url = f"http://127.0.0.1:{port}/"'),
    ("page.html", '<script src="app.js"></script>'),
    ("page.html", '<img src="data:image/png;base64,iVBORw0">'),
    ("sheet.css", "src:url(data:font/woff2;base64,d09GMg)"),
    # the manual quotes bad examples; a browser never fetches them
    ("page.html", '<pre>&lt;link href="https://fonts.example.com/f.css"&gt;</pre>'),
    ("page.html", '<code>https://cdn.example.com/x.js</code>'),
]


def self_test() -> bool:
    """Check the checker: it must catch the bad samples and pass the good ones."""
    ok = True
    for label, samples, must_find in (("must be caught", SELF_TEST, True),
                                      ("must be accepted", SELF_TEST_CLEAN, False)):
        print(f"  {label}:")
        for name, snippet in samples:
            suffix = Path(name).suffix
            found = bool(_scan_text(suffix, snippet))
            good = found is must_find
            ok = ok and good
            print(f"    [{'ok' if good else 'FAIL'}] {snippet[:60]}")
    print()
    print("self-test passed." if ok else "SELF-TEST FAILED.")
    return ok


def main() -> int:
    if "--self-test" in sys.argv:
        print("Self-test of the offline checker:")
        return 0 if self_test() else 1

    print("=" * 78)
    print("Offline check - does anything here need the internet?")
    print("=" * 78)
    print(f"folder: {PROJECT_DIR}")
    print()

    problems: List[Finding] = []
    excused = 0
    scanned = 0

    for path in files_to_scan():
        scanned += 1
        for finding in scan(path):
            if finding.path in ALLOWED:
                excused += 1
                continue
            problems.append(finding)

    print(f"scanned {scanned} file(s).")
    if excused:
        print(f"\nAllowed on purpose ({excused} match(es)):")
        for name, reason in ALLOWED.items():
            if (PROJECT_DIR / name).is_file():
                print(f"  {name:<34} {reason}")

    print()
    if problems:
        print(f"FOUND {len(problems)} thing(s) that would need the internet:")
        for finding in problems:
            print(f"  {finding.path}:{finding.line}  {finding.detail}")
        print("\nFix them before copying this folder to an offline machine.")
        return 1

    print("OK - nothing here contacts anything outside this machine.")
    print()
    print("  * the editor's server binds to 127.0.0.1 only")
    print("  * its pages load no external script, stylesheet, font or image")
    print("  * the browser it starts has background networking switched off")
    print("  * the PDF manual embeds its font and screenshots inside the HTML")
    print("  * the only online step in the whole tool is the optional")
    print("    'pip install openpyxl' in setup_environment.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

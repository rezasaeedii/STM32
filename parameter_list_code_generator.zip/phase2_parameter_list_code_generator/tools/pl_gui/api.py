"""The JSON API the browser talks to.

One method per action, all of them tiny.  Adding a button to the GUI means
adding one method here and one ``fetch`` call in ``web/app.js``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List

from pl_codegen import __tool_name__, __version__
from pl_codegen.model.defines import (COLUMN_GROUPS, COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES,
                                      COLUMN_TYPES)
from pl_codegen.model.parameter import Parameter
from pl_codegen.model.parameter_list import PATH_SEPARATOR
from pl_codegen.model.tags import TAG_REGISTRY, TagKind
from pl_codegen.model.types import DATA_TYPES

from .document import Document


class Api:
    """Every endpoint the front end can call."""

    def __init__(self, document: Document) -> None:
        self.document = document

    # -- dispatch ----------------------------------------------------------
    def handlers(self) -> Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]]:
        return {
            "state": self.state,
            "open": self.open_file,
            "save": self.save,
            "add": self.add,
            "duplicate": self.duplicate,
            "delete": self.delete,
            "move": self.move,
            "update": self.update,
            "undo": self.undo,
            "redo": self.redo,
            "defines": self.set_defines,
            "default_defines": self.default_defines,
            "generate": self.generate,
            "import_excel": self.import_excel,
            "next_log_id": self.next_log_id,
        }

    # -- reading -------------------------------------------------------------
    def state(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        """Everything the front end needs to render one full screen."""
        document = self.document
        return {
            "tool": {"name": __tool_name__, "version": __version__},
            "file": str(document.path) if document.path else "",
            "dirty": document.dirty,
            "canUndo": document.can_undo,
            "canRedo": document.can_redo,
            "tree": [_node(child, child.name, {}, None)
                     for child in document.model.parameters],
            "diagnostics": document.validate(),
            "defines": {
                "groups": document.model.defines.get(COLUMN_GROUPS),
                "types": document.model.defines.get(COLUMN_TYPES) or list(DATA_TYPES),
                "systemNames": document.model.defines.get(COLUMN_SYSTEM_NAMES),
                "paramModes": document.model.defines.get(COLUMN_PARAM_MODES),
            },
            "tagSpecs": [
                {
                    "id": spec.tag_id,
                    "label": spec.excel_column,
                    "kind": spec.kind.value,
                    "mandatory": spec.mandatory,
                    "definesColumn": spec.defines_column,
                    "description": spec.description,
                }
                for spec in TAG_REGISTRY
            ],
            "outputDirectory": str(document.config.output.code_directory),
            # every sub-module of the project; the editor works on one at a time
            "modules": [{"path": str(path), "name": path.stem,
                         "current": document.path is not None and path == document.path,
                         "exists": path.is_file()}
                        for path in document.config.inputs.model_files],
        }

    # -- file ------------------------------------------------------------------
    def open_file(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = request.get("path") or None
        diagnostics = self.document.load(Path(path) if path else None)
        return {"ok": True, "diagnostics": diagnostics}

    def save(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = request.get("path") or None
        target = self.document.save(Path(path) if path else None)
        return {"ok": True, "path": str(target)}

    # -- tree editing ------------------------------------------------------------
    def add(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.add_parameter(str(request.get("parent") or ""),
                                           str(request.get("kind") or "primitive"))
        return {"ok": True, "selected": path}

    def duplicate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.duplicate(str(request.get("path") or ""))
        return {"ok": path is not None, "selected": path}

    def delete(self, request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.delete(str(request.get("path") or ""))}

    def move(self, request: Dict[str, Any]) -> Dict[str, Any]:
        path = self.document.move(str(request.get("path") or ""),
                                  int(request.get("offset") or 0))
        return {"ok": path is not None, "selected": path}

    def update(self, request: Dict[str, Any]) -> Dict[str, Any]:
        changes = dict(request.get("changes") or {})
        path = self.document.update(str(request.get("path") or ""), changes)
        return {"ok": path is not None, "selected": path}

    def undo(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.undo() is not None}

    def redo(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": self.document.redo() is not None}

    def set_defines(self, request: Dict[str, Any]) -> Dict[str, Any]:
        column = {"groups": COLUMN_GROUPS, "systemNames": COLUMN_SYSTEM_NAMES,
                  "paramModes": COLUMN_PARAM_MODES, "types": COLUMN_TYPES}
        key = str(request.get("list") or "")
        if key not in column:
            return {"ok": False, "message": f"Unknown list '{key}'."}
        self.document.set_defines(column[key], list(request.get("values") or []))
        return {"ok": True}

    def default_defines(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        """The company lists a new model starts with, for the 'restore' button."""
        from .document import DEFAULT_GROUPS, DEFAULT_PARAM_MODES, DEFAULT_SYSTEM_NAMES

        return {
            "ok": True,
            "groups": list(DEFAULT_GROUPS),
            "systemNames": list(DEFAULT_SYSTEM_NAMES),
            "paramModes": list(DEFAULT_PARAM_MODES),
            "types": list(DATA_TYPES),
        }

    # -- actions --------------------------------------------------------------
    def generate(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return self.document.generate()

    def import_excel(self, request: Dict[str, Any]) -> Dict[str, Any]:
        from pl_codegen.errors import CodeGeneratorError, DiagnosticCollector
        from pl_codegen.excel.excel_to_model import build_model

        path = request.get("path")
        config = self.document.config
        if path:
            config.inputs.excel_files = [Path(path)]
        if not config.inputs.excel_files:
            return {"ok": False, "message": "No Excel file was given."}

        try:
            diagnostics = DiagnosticCollector()
            model = build_model(config, diagnostics)
        except CodeGeneratorError as error:
            return {"ok": False, "message": str(error)}
        except ImportError:
            return {"ok": False,
                    "message": "The 'openpyxl' package is not installed. "
                               "Run 'python setup_environment.py' first."}

        self.document.snapshot("import")
        self.document.model = model
        self.document._ensure_defines()  # noqa: SLF001 - same package
        return {"ok": True, "diagnostics": diagnostics.to_list(),
                "count": len(model.flatten())}

    def next_log_id(self, _request: Dict[str, Any]) -> Dict[str, Any]:
        return {"ok": True, "value": self.document.next_free_log_id()}


def _node(parameter: Parameter, path: str,
          inherited: Dict[str, Any], inherited_group: Any,
          owner: str = "") -> Dict[str, Any]:
    """One node of the tree, as the front end wants it.

    Tags and the group belong to the top level entry.  For a field, ``owner`` is
    the name of that entry and ``effectiveTags`` / ``effectiveGroup`` are its
    values - the editor shows them read-only instead of an editable form.
    """
    is_field = bool(owner)
    effective = dict(inherited) if is_field else {
        key: value for key, value in parameter.tags.items() if value is not None}
    effective_group = inherited_group if is_field else parameter.group

    return {
        "path": path,
        "isField": is_field,
        "owner": owner,
        "name": parameter.name,
        "kind": parameter.kind.value,
        "enable": parameter.enable,
        "gsName": parameter.gs_name,
        "group": parameter.group,
        "dataType": parameter.data_type_name,
        "arraySize": parameter.array_size,
        "defaultValue": parameter.default_value,
        "minimum": parameter.minimum,
        "maximum": parameter.maximum,
        "resolution": parameter.resolution,
        "unit": parameter.unit,
        "description": parameter.description,
        "tags": {spec.tag_id: parameter.tags.get(spec.tag_id) for spec in TAG_REGISTRY},
        "effectiveTags": {spec.tag_id: effective.get(spec.tag_id) for spec in TAG_REGISTRY},
        "effectiveGroup": effective_group,
        "children": [_node(child, f"{path}{PATH_SEPARATOR}{child.name}",
                           effective, effective_group, owner or parameter.name)
                     for child in parameter.children],
    }

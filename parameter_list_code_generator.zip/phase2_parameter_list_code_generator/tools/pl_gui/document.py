"""The document the GUI edits: the parameter list plus its file and undo stack.

Everything the front end does goes through this class, so the rules about what
a valid edit is live in one place.
"""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from pl_codegen.config import Config
from pl_codegen.errors import DiagnosticCollector, Severity
from pl_codegen.model.defines import (COLUMN_GROUPS, COLUMN_PARAM_MODES, COLUMN_SYSTEM_NAMES,
                                      COLUMN_TYPES, Defines)
from pl_codegen.model.parameter import Parameter, ParameterKind
from pl_codegen.model.parameter_list import PATH_SEPARATOR, ParameterList
from pl_codegen.model.tags import TAG_REGISTRY
from pl_codegen.model.types import DATA_TYPES
from pl_codegen.pipeline import Pipeline
from pl_codegen.validation.validator import Validator
from pl_codegen.xml_model.xml_reader import read_xml
from pl_codegen.xml_model.xml_writer import write_xml

#: how many steps of undo the GUI keeps
UNDO_DEPTH = 60

# The drop-down lists a brand new model starts with.  They are the company
# lists, copied from the 'Defines' sheet of the phase 1 workbook, so a list
# created in the editor offers exactly the same choices the Excel file did.
# Edit them here (or per model, with the "Lists..." button in the editor).
DEFAULT_GROUPS = [
    "MONITORING",
    "COMMAND",
    "SETTING",
]

DEFAULT_SYSTEM_NAMES = [
    "SYS_UNKNOWN",
    "SYS_GS_COMPUTER",
    "SYS_GS_MANAGER",
    "SYS_GS_POWER",
    "SYS_ANTENNA_TRACKER",
    "SYS_AC_MANAGER",
    "SYS_AC_POWER",
    "SYS_AC_AUTOPILOT",
    "SYS_GIMBAL",
    "SYS_LOCK_TRACK",
    "SYS_LINK_GS",
    "SYS_GS_USB2CAN",
    "SYS_LINK_AIR",
    "SYS_BOOTLOADER",
    "SYS_LINK_BOX",
    "SYS_GOVERNOR",
    "SYS_NAV",
    "SYS_AND",
    "SYS_VNS",
    "SYS_RHS",
    "SYS_AUP",
]

DEFAULT_PARAM_MODES = [
    "PARAM_MODE_USER",
    "PARAM_MODE_READ_ONLY",
    "PARAM_MODE_PRODUCT_TYPE",
    "PARAM_MODE_FACTORY",
    "PARAM_MODE_CALIB",
    "PARAM_MODE_TEMPORARY",
]


class Document:
    """The in-memory parameter list plus everything the GUI needs around it."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.model = ParameterList()
        self.path: Optional[Path] = config.inputs.model_file
        self.dirty = False
        self._undo: List[Tuple[str, ParameterList]] = []
        self._redo: List[Tuple[str, ParameterList]] = []

    # -- loading and saving ------------------------------------------------
    def load(self, path: Optional[Path] = None) -> List[Dict[str, object]]:
        """Read the XML model.  Returns the diagnostics of the read."""
        target = Path(path) if path else self.path
        diagnostics = DiagnosticCollector()
        if target is not None and target.is_file():
            self.model = read_xml(target, diagnostics)
            self.path = target
        else:
            self.model = ParameterList()
            self.path = target
        self._ensure_defines()
        self.dirty = False
        self._undo.clear()
        self._redo.clear()
        return diagnostics.to_list()

    def save(self, path: Optional[Path] = None) -> Path:
        target = Path(path) if path else self.path
        if target is None:
            raise ValueError("No file name given.")
        write_xml(self.model, target,
                  emit_timestamp=self.config.codegen.emit_timestamp)
        self.path = target
        self.dirty = False
        return target

    def _ensure_defines(self) -> None:
        """Make sure the drop-down lists are never empty."""
        defines: Defines = self.model.defines
        if not defines.get(COLUMN_TYPES):
            for name in DATA_TYPES:
                defines.add(COLUMN_TYPES, name)
        for column, values in ((COLUMN_GROUPS, DEFAULT_GROUPS),
                               (COLUMN_SYSTEM_NAMES, DEFAULT_SYSTEM_NAMES),
                               (COLUMN_PARAM_MODES, DEFAULT_PARAM_MODES)):
            if not defines.get(column):
                for value in values:
                    defines.add(column, value)

    # -- undo / redo --------------------------------------------------------
    def snapshot(self, label: str) -> None:
        """Remember the current state before changing it."""
        self._undo.append((label, copy.deepcopy(self.model)))
        del self._undo[:-UNDO_DEPTH]
        self._redo.clear()
        self.dirty = True

    def undo(self) -> Optional[str]:
        if not self._undo:
            return None
        label, state = self._undo.pop()
        self._redo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    def redo(self) -> Optional[str]:
        if not self._redo:
            return None
        label, state = self._redo.pop()
        self._undo.append((label, copy.deepcopy(self.model)))
        self.model = state
        self.dirty = True
        return label

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    # -- finding nodes ------------------------------------------------------
    def find(self, path: str) -> Optional[Parameter]:
        return self.model.find(path) if path else None

    def parent_of(self, path: str) -> Tuple[Optional[Parameter], List[Parameter]]:
        """Return ``(parent node or None, the list the node lives in)``."""
        parts = path.split(PATH_SEPARATOR)
        if len(parts) == 1:
            return None, self.model.parameters
        parent = self.model.find(PATH_SEPARATOR.join(parts[:-1]))
        return parent, parent.children if parent else self.model.parameters

    # -- editing ------------------------------------------------------------
    def add_parameter(self, parent_path: str = "", kind: str = "primitive") -> str:
        """Add a parameter (or a struct) under *parent_path*; return its path."""
        self.snapshot("add")
        parent = self.find(parent_path) if parent_path else None
        siblings = parent.children if parent is not None and parent.is_struct \
            else self.model.parameters
        prefix = parent_path if (parent is not None and parent.is_struct) else ""

        node = Parameter(
            name=_unique_name("NewStruct" if kind == "struct" else "NewParameter", siblings),
            kind=ParameterKind.STRUCT if kind == "struct" else ParameterKind.PRIMITIVE)
        if node.is_primitive:
            node.data_type_name = "uint8_t"
            node.default_value = 0
            node.minimum = 0
            node.maximum = 0
            node.resolution = 1
        if prefix == "":
            node.group = self.model.defines.get(COLUMN_GROUPS)[0] \
                if self.model.defines.get(COLUMN_GROUPS) else "MONITORING"
            node.tags = {spec.tag_id: _default_tag(spec, self.model.defines)
                         for spec in TAG_REGISTRY}
        siblings.append(node)
        return f"{prefix}{PATH_SEPARATOR}{node.name}" if prefix else node.name

    def duplicate(self, path: str) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("duplicate")
        _parent, siblings = self.parent_of(path)
        clone = copy.deepcopy(node)
        clone.name = _unique_name(node.name, siblings)
        _clear_log_ids(clone)
        siblings.insert(siblings.index(node) + 1, clone)
        prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
        return f"{prefix}{PATH_SEPARATOR}{clone.name}" if prefix else clone.name

    def delete(self, path: str) -> bool:
        node = self.find(path)
        if node is None:
            return False
        self.snapshot("delete")
        _parent, siblings = self.parent_of(path)
        siblings.remove(node)
        return True

    def move(self, path: str, offset: int) -> Optional[str]:
        node = self.find(path)
        if node is None:
            return None
        _parent, siblings = self.parent_of(path)
        index = siblings.index(node)
        target = index + offset
        if not 0 <= target < len(siblings):
            return None
        self.snapshot("move")
        siblings.pop(index)
        siblings.insert(target, node)
        return path

    def update(self, path: str, changes: Dict[str, object]) -> Optional[str]:
        """Apply the values coming from the editor form.  Returns the new path."""
        node = self.find(path)
        if node is None:
            return None
        self.snapshot("edit")

        # Tags and the group belong to the top level entry.  A field inside a
        # structure cannot set them, so drop them here as well as in the form -
        # that way a stale page can never write them either.
        if PATH_SEPARATOR in path:
            changes.pop("tags", None)
            changes.pop("group", None)

        new_path = path
        if "name" in changes:
            name = str(changes.pop("name") or "").strip()
            if name and name != node.name:
                node.name = name
                prefix = path.rsplit(PATH_SEPARATOR, 1)[0] if PATH_SEPARATOR in path else ""
                new_path = f"{prefix}{PATH_SEPARATOR}{name}" if prefix else name

        tags = changes.pop("tags", None)
        if isinstance(tags, dict):
            node.tags = dict(tags)

        for key, value in changes.items():
            if hasattr(node, key):
                setattr(node, key, value)
        return new_path

    # -- defines -------------------------------------------------------------
    def set_defines(self, column: str, values: List[str]) -> None:
        self.snapshot("defines")
        self.model.defines.values[column.upper()] = [str(v).strip()
                                                     for v in values if str(v).strip()]

    # -- validation and generation -------------------------------------------
    def merged_model(self) -> ParameterList:
        """This module as it is being edited, plus the others as they are on disk.

        The project is one parameter list even when it is split over several
        files, so a name or a log id clashing with another sub-module has to
        show up while editing, not at the end.
        """
        others = [path for path in self.config.inputs.model_files
                  if self.path is None or path != self.path]
        if not others:
            return self.model

        merged = copy.deepcopy(self.model)
        quiet = DiagnosticCollector()
        for path in others:
            if path.is_file():
                merged.extend(read_xml(path, quiet))
        return merged

    def validate(self) -> List[Dict[str, object]]:
        diagnostics = DiagnosticCollector()
        Validator(self.config).validate(self.merged_model(), diagnostics)
        return diagnostics.to_list()

    def generate(self) -> Dict[str, object]:
        """Save the model, then generate the code from every configured module.

        Saving first is not a convenience - it is what keeps the editor and
        ``generate.py`` from ever disagreeing.  If the editor generated from the
        model in its memory while the file on disk still held the previous
        version, the next command line run would silently produce different
        code.  So the file is written first, and the generator then reads the
        same files the command line reads.
        """
        diagnostics = DiagnosticCollector()
        pipeline = Pipeline(self.config)

        saved = None
        if self.path is not None:
            saved = self.save()

        # Every other sub-module is read from disk and merged in, so the editor
        # generates exactly what "python generate.py" would.
        model = pipeline.load_model(diagnostics) if saved is not None else self.model

        result = pipeline.generate(model, diagnostics)
        return {
            "success": result.success,
            "files": [str(path) for path in result.generated_files],
            "count": result.parameter_count,
            "saved": str(saved) if saved else "",
            "modules": [str(path) for path in self.config.inputs.model_files],
            "diagnostics": diagnostics.to_list(),
        }

    def next_free_log_id(self) -> int:
        """The first log id no parameter has reserved yet.

        ``flatten()`` has already spread every structure's block over its
        leaves, so looking at the leaves covers structures too.
        """
        highest = 0
        for leaf in self.model.flatten():
            log_id = leaf.tags.get("LogId")
            if isinstance(log_id, int) and not isinstance(log_id, bool):
                highest = max(highest, log_id + max(1, leaf.reserved_size))
        return highest

    # -- what the front end renders -------------------------------------------
    def error_count(self) -> int:
        return sum(1 for item in self.validate()
                   if item["severity"] == Severity.ERROR.label)


def _default_tag(spec, defines: Defines):
    from pl_codegen.model.tags import TagKind
    if spec.kind is TagKind.BOOLEAN:
        return False
    if spec.kind is TagKind.ENUM and spec.defines_column:
        values = defines.get(spec.defines_column)
        return values[0] if values else None
    return None


def _unique_name(base: str, siblings: List[Parameter]) -> str:
    taken = {node.name for node in siblings}
    if base not in taken:
        return base
    index = 2
    while f"{base}{index}" in taken:
        index += 1
    return f"{base}{index}"


def _clear_log_ids(node: Parameter) -> None:
    """A copy must not reuse the log ids of the original."""
    if "LogId" in node.tags:
        node.tags["LogId"] = None
    for child in node.children:
        _clear_log_ids(child)

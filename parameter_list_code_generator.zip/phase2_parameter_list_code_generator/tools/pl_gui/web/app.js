/* ==========================================================================
   app.js - wires the toolbar, the tree, the editor and the problems panel
   together.  This is the only file that knows about all of them.
   ========================================================================== */

const app = {
  state: null,
  selected: "",

  async start() {
    treeView.init(document.getElementById("tree"), (path, keepEditor) => {
      this.selected = path;
      this.paint(keepEditor);
    });
    editorView.init(
      document.getElementById("editor"),
      document.getElementById("editor-title"),
      document.getElementById("editor-path"),
      (changes) => this.applyChanges(changes));

    this.bindToolbar();
    this.bindShortcuts();
    await this.refresh();
    setStatus("Ready");
  },

  /* ------------------------------------------------------------ loading */
  async refresh(keepEditor) {
    this.state = await api.state();
    this.paint(keepEditor);
  },

  paint(keepEditor) {
    const state = this.state;

    document.getElementById("file-name").textContent = state.file || "(no file)";
    document.getElementById("file-name").classList.toggle("dirty", state.dirty);
    this.paintModules(state);
    document.getElementById("btn-undo").disabled = !state.canUndo;
    document.getElementById("btn-redo").disabled = !state.canRedo;

    const problemPaths = new Set(
      state.diagnostics.filter((d) => d.severity === "error")
                       .map((d) => d.location.parameter).filter(Boolean));
    treeView.render(state.tree, this.selected, problemPaths);

    const node = findNode(state.tree, this.selected);
    if (!node) { this.selected = ""; editorView.clear(); }
    else if (!keepEditor) editorView.show(node, state);

    this.paintProblems(state.diagnostics);
    this.paintCounts(state);
    this.updateButtons(node);
  },

  /* The project can be split over several files, one per sub-module. The
     editor works on one of them; the others are still validated against, so a
     clash between two sub-modules shows up here and not at the end. */
  paintModules(state) {
    const picker = document.getElementById("module-picker");
    const modules = state.modules || [];
    picker.hidden = modules.length < 2;
    if (picker.hidden) return;

    picker.innerHTML = modules.map((module) => {
      const label = escapeHtml(module.name) + (module.exists ? "" : " (new)");
      return `<option value="${escapeHtml(module.path)}"` +
             `${module.current ? " selected" : ""}>${label}</option>`;
    }).join("");
  },

  paintCounts(state) {
    const leaves = countLeaves(state.tree);
    const structs = countStructs(state.tree);
    document.getElementById("tree-count").textContent =
      `${leaves} value(s)` + (structs ? ` in ${structs} structure(s)` : "");
    const errors = state.diagnostics.filter((d) => d.severity === "error").length;
    const warnings = state.diagnostics.filter((d) => d.severity === "warning").length;
    document.getElementById("status-counts").textContent =
      `${leaves} values · ${errors} errors · ${warnings} warnings`;
  },

  paintProblems(diagnostics) {
    const badge = document.getElementById("problem-badge");
    const errors = diagnostics.filter((d) => d.severity === "error").length;
    const warnings = diagnostics.filter((d) => d.severity === "warning").length;
    badge.textContent = errors || warnings || 0;
    badge.className = "badge " + (errors ? "bad" : warnings ? "warn" : "ok");

    const list = document.getElementById("problems");
    if (!diagnostics.length) {
      list.innerHTML = `<div class="problem-empty">No problems. The model is ready to generate.</div>`;
      return;
    }
    const order = { error: 0, warning: 1, info: 2 };
    const sorted = diagnostics.slice().sort((a, b) => order[a.severity] - order[b.severity]);

    list.innerHTML = sorted.map((item) => `
      <div class="problem ${item.severity}" data-path="${escapeHtml(item.location.parameter || "")}">
        <span class="sev">${item.severity}</span>
        <span class="code">${escapeHtml(item.code)}</span>
        <span class="msg">${escapeHtml(item.message)}
          ${item.location.parameter ? `<span class="where">→ ${escapeHtml(item.location.parameter)}</span>` : ""}
          ${item.hint ? `<span class="hint">${escapeHtml(item.hint)}</span>` : ""}
        </span>
      </div>`).join("");

    for (const row of list.querySelectorAll(".problem")) {
      row.addEventListener("click", () => this.select(row.dataset.path));
    }
  },

  updateButtons(node) {
    /* the two "into the selected structure" buttons only make sense on a structure */
    const intoStruct = !node || node.kind !== "struct";
    document.getElementById("btn-add-field").disabled = intoStruct;
    document.getElementById("btn-add-substruct").disabled = intoStruct;
    for (const id of ["btn-duplicate", "btn-delete", "btn-up", "btn-down"]) {
      document.getElementById(id).disabled = !node;
    }
  },

  /* Select a node by path and reveal it (used by the Problems panel and by
     the "edit them on <structure>" button of a field). */
  select(path) {
    if (!path) return;
    this.selected = path;
    expandTo(path);
    this.paint();
  },

  /* ------------------------------------------------------------ editing */
  async applyChanges(changes) {
    if (!this.selected) return;
    const answer = await api.update(this.selected, changes);
    if (answer.selected) this.selected = answer.selected;
    await this.refresh();
    setStatus("Edited");
  },

  async addNode(kind, intoStruct) {
    const parent = intoStruct ? this.selected : "";
    const answer = await api.add(parent, kind);
    this.selected = answer.selected;
    if (parent) treeView.collapsed.delete(parent);
    await this.refresh();
    setStatus(kind === "struct" ? "Structure added" : "Parameter added");
  },

  /* ------------------------------------------------------------ toolbar */
  bindToolbar() {
    const on = (id, handler) => document.getElementById(id).addEventListener("click", handler);

    on("btn-save", () => this.save());
    on("btn-reload", async () => {
      if (this.state.dirty && !confirm("Discard the unsaved changes and reload?")) return;
      await api.open(null); this.selected = ""; await this.refresh(); setStatus("Reloaded");
    });

    document.getElementById("module-picker").addEventListener("change", async (event) => {
      const path = event.target.value;
      if (this.state.dirty &&
          !confirm("This module has unsaved changes. Switch anyway and lose them?")) {
        this.paint(true);   // put the picker back on the current module
        return;
      }
      await api.open(path);
      this.selected = "";
      await this.refresh();
      setStatus("Switched module");
    });

    on("btn-add", () => this.addNode("primitive", false));
    on("btn-add-struct", () => this.addNode("struct", false));
    on("btn-add-field", () => this.addNode("primitive", true));
    on("btn-add-substruct", () => this.addNode("struct", true));

    on("btn-duplicate", async () => {
      const answer = await api.duplicate(this.selected);
      if (answer.selected) this.selected = answer.selected;
      await this.refresh(); setStatus("Duplicated");
    });
    on("btn-delete", () => this.remove());
    on("btn-up", () => this.moveNode(-1));
    on("btn-down", () => this.moveNode(1));

    on("btn-undo", async () => { await api.undo(); await this.refresh(); setStatus("Undo"); });
    on("btn-redo", async () => { await api.redo(); await this.refresh(); setStatus("Redo"); });

    on("btn-lists", () => this.editLists());
    on("btn-import", () => this.importExcel());
    on("btn-generate", () => this.generate());

    document.getElementById("filter").addEventListener("input", (event) => {
      treeView.filter = event.target.value.trim();
      this.paint(true);
    });

    document.getElementById("btn-toggle-problems").addEventListener("click", (event) => {
      event.stopPropagation();
      document.getElementById("problems-pane").classList.toggle("collapsed");
    });
  },

  bindShortcuts() {
    document.addEventListener("keydown", (event) => {
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
      if (event.ctrlKey && event.key.toLowerCase() === "s") { event.preventDefault(); this.save(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "g") { event.preventDefault(); this.generate(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "n") { event.preventDefault(); this.addNode("primitive", false); }
      else if (event.ctrlKey && event.key.toLowerCase() === "d") { event.preventDefault(); document.getElementById("btn-duplicate").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "z") { event.preventDefault(); document.getElementById("btn-undo").click(); }
      else if (event.ctrlKey && event.key.toLowerCase() === "y") { event.preventDefault(); document.getElementById("btn-redo").click(); }
      else if (event.key === "Delete" && !typing && this.selected) { this.remove(); }
    });
  },

  async remove() {
    if (!this.selected) return;
    if (!confirm(`Delete '${this.selected}'?`)) return;
    await api.remove(this.selected);
    this.selected = "";
    await this.refresh();
    setStatus("Deleted");
  },

  async moveNode(offset) {
    await api.move(this.selected, offset);
    await this.refresh();
  },

  async save() {
    const answer = await api.save(null);
    await this.refresh(true);
    toast(`Saved to ${answer.path}`, "good");
    setStatus("Saved");
  },

  /* ------------------------------------------------------------ actions */
  async generate() {
    setStatus("Generating…");
    const result = await api.generate();
    await this.refresh(true);
    if (!result.success) {
      toast("The model has errors - nothing was generated. See Problems.", "bad");
      document.getElementById("problems-pane").classList.remove("collapsed");
      setStatus("Generation aborted");
      return;
    }
    const files = result.files.map((f) => `<div>${escapeHtml(f)}</div>`).join("");
    const modules = (result.modules || []).length > 1
      ? `<p class="modal-note">Read from ${result.modules.length} sub-module(s):</p>
         <div class="file-list">${result.modules
           .map((m) => `<div>${escapeHtml(m)}</div>`).join("")}</div>` : "";
    const saved = result.saved
      ? `<p class="modal-note">The model was saved to
         <code>${escapeHtml(result.saved)}</code> first, so
         <code>python generate.py</code> now produces exactly the same code.</p>` : "";

    showModal("Code generated",
      `${saved}${modules}<p class="modal-note">${result.count} value(s) written into
       ${result.files.length} file(s):</p><div class="file-list">${files}</div>`,
      null);
    setStatus(`Generated ${result.files.length} files`);
  },

  async importExcel() {
    showModal("Import from Excel",
      `<p class="modal-note">This replaces the whole parameter list with the content of
       the Excel file. The current list stays in the undo history.</p>
       <label>Path of the .xlsx file</label>
       <input type="text" id="excel-path" placeholder="../parameter_list_template.xlsx">`,
      async () => {
        const path = document.getElementById("excel-path").value.trim();
        const answer = await api.importExcel(path || null);
        if (!answer.ok) { toast(answer.message || "Import failed.", "bad"); return; }
        this.selected = "";
        await this.refresh();
        toast(`Imported ${answer.count} value(s).`, "good");
      });
  },

  /* The four lists that used to be the 'Defines' sheet of the Excel file. */
  editLists() {
    const defines = this.state.defines;
    const keys = ["groups", "systemNames", "paramModes", "types"];
    const labels = {
      groups: "Groups", systemNames: "System names",
      paramModes: "Parameter modes", types: "Data types",
    };

    let body = `<p class="modal-note">One value per line, in the order they should get
       their enum value. These are the choices the editor offers and the enumerations
       the generator writes into <code>cg_parameter_list_defines.h</code>.</p>
       <button type="button" class="inline-btn" id="btn-restore-lists">
         Restore the company defaults</button>`;
    for (const key of keys) {
      body += `<label>${labels[key]} <span class="count" id="count-${key}"></span></label>
        <textarea id="list-${key}">${escapeHtml((defines[key] || []).join("\n"))}</textarea>`;
    }

    showModal("Drop-down lists", body, async () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").map((v) => v.trim()).filter(Boolean);
        await api.setDefines(key, values);
      }
      await this.refresh();
      toast("Lists updated.", "good");
    });

    /* live count under each box, so a truncated list is obvious */
    const recount = () => {
      for (const key of keys) {
        const values = document.getElementById(`list-${key}`).value
          .split("\n").filter((v) => v.trim());
        document.getElementById(`count-${key}`).textContent = `(${values.length})`;
      }
    };
    for (const key of keys) {
      document.getElementById(`list-${key}`).addEventListener("input", recount);
    }
    recount();

    document.getElementById("btn-restore-lists").addEventListener("click", async () => {
      const defaults = await api.defaultDefines();
      for (const key of keys) {
        document.getElementById(`list-${key}`).value = (defaults[key] || []).join("\n");
      }
      recount();
    });
  },
};

/* ---------------------------------------------------------------- helpers */
function findNode(nodes, path) {
  for (const node of nodes) {
    if (node.path === path) return node;
    const found = findNode(node.children || [], path);
    if (found) return found;
  }
  return null;
}

function countLeaves(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (!node.enable) continue;
    total += node.kind === "struct" ? countLeaves(node.children) : 1;
  }
  return total;
}

function countStructs(nodes) {
  let total = 0;
  for (const node of nodes) {
    if (node.kind === "struct") total += 1 + countStructs(node.children);
  }
  return total;
}

function expandTo(path) {
  const parts = path.split(".");
  for (let index = 1; index < parts.length; index++) {
    treeView.collapsed.delete(parts.slice(0, index).join("."));
  }
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

let toastTimer = null;
function toast(message, kind) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.className = "toast " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.add("hidden"), 4200);
}

function showModal(title, bodyHtml, onOk) {
  const modal = document.getElementById("modal");
  document.getElementById("modal-title").textContent = title;
  document.getElementById("modal-body").innerHTML = bodyHtml;
  const okButton = document.getElementById("modal-ok");
  const cancelButton = document.getElementById("modal-cancel");
  okButton.textContent = onOk ? "OK" : "Close";
  cancelButton.style.display = onOk ? "" : "none";

  const close = () => { modal.classList.add("hidden"); };
  okButton.onclick = async () => { if (onOk) await onOk(); close(); };
  cancelButton.onclick = close;
  modal.classList.remove("hidden");
}

window.addEventListener("DOMContentLoaded", () => app.start());

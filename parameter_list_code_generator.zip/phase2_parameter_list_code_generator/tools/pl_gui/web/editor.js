/* ==========================================================================
   editor.js - the form on the right.

   buildForm() writes the HTML of one parameter, top to bottom, and collect()
   reads it back.  Adding a field to the editor means adding one entry here.
   ========================================================================== */

const editorView = {
  element: null,
  titleElement: null,
  pathElement: null,
  node: null,
  state: null,
  onChange: () => {},

  init(element, titleElement, pathElement, onChange) {
    this.element = element;
    this.titleElement = titleElement;
    this.pathElement = pathElement;
    this.onChange = onChange;
  },

  clear() {
    this.node = null;
    this.titleElement.textContent = "Nothing selected";
    this.pathElement.textContent = "";
    this.element.innerHTML =
      `<p class="empty">Select a parameter on the left, or add one with
       <b>+ Parameter</b>.</p>`;
  },

  show(node, state) {
    this.node = node;
    this.state = state;
    this.titleElement.textContent = node.kind === "struct"
      ? `Structure — ${node.name}` : `Parameter — ${node.name}`;
    this.pathElement.textContent = node.path;
    this.element.innerHTML = node.kind === "struct"
      ? this.structForm(node, state) : this.primitiveForm(node, state);
    this.wire();
  },

  /* ---------------------------------------------------------- structure */
  structForm(node, state) {
    let html = "";
    html += `<div class="field-group"><h3>Identity</h3><div class="grid">`;
    html += this.text("name", "Name", node.name, true);
    html += this.text("gs_name", "GS name", node.gsName);
    if (!node.isField) {
      html += this.select("group", "Group", node.group, state.defines.groups, true);
    }
    html += this.check("enable", "Enabled (a disabled structure is skipped)", node.enable);
    html += `</div></div>`;

    html += `<div class="field-group"><h3>Description</h3><div class="grid wide">`;
    html += this.area("description", "Description", node.description);
    html += `</div></div>`;

    html += node.isField
      ? this.inheritedGroup(node, state)
      : this.tagsGroup(node, state,
          "A structure is classified as one thing: every field and sub-structure " +
          "inside it gets these tags and this group. LogID is the first id of the " +
          "block; the fields take consecutive ids out of it.");

    html += `<div class="field-group"><h3>Fields</h3>
      <p class="modal-note">${node.children.length} field(s).
      Use <b>+ Field</b> or <b>+ Sub-structure</b> in the toolbar to add one while
      this structure is selected.</p>
      </div>`;
    return html;
  },

  /* ---------------------------------------------------------- primitive */
  primitiveForm(node, state) {
    const isBool = (node.dataType || "").toLowerCase() === "bool_t";

    let html = "";
    html += `<div class="field-group"><h3>Identity</h3><div class="grid">`;
    html += this.text("name", "Name", node.name, true);
    html += this.text("gs_name", "GS name", node.gsName);
    if (!node.isField) {
      html += this.select("group", "Group", node.group, state.defines.groups, true);
    }
    html += this.select("data_type_name", "Data type", node.dataType, state.defines.types, true);
    html += this.number("array_size", "Array size", node.arraySize, 1);
    html += this.text("unit", "Unit", node.unit);
    html += this.check("enable", "Enabled (a disabled parameter is not generated)", node.enable);
    html += `</div></div>`;

    html += `<div class="field-group"><h3>Value</h3><div class="grid">`;
    if (isBool) {
      html += this.select("default_value", "Default value",
        node.defaultValue ? "true" : "false", ["false", "true"]);
      html += `<div class="field"><label>Range</label>
        <span class="hint">bool_t has no minimum, maximum or resolution.</span></div>`;
    } else {
      html += this.number("default_value", "Default value", node.defaultValue);
      html += this.number("minimum", "Minimum", node.minimum);
      html += this.number("maximum", "Maximum", node.maximum);
      html += this.number("resolution", "Resolution", node.resolution);
      html += `<div class="field"><label>&nbsp;</label>
        <span class="hint">Minimum and maximum both 0 disables the range check.</span></div>`;
    }
    html += `</div></div>`;

    html += node.isField ? this.inheritedGroup(node, state)
                         : this.tagsGroup(node, state, null);

    html += `<div class="field-group"><h3>Description</h3><div class="grid wide">`;
    html += this.area("description", "Description", node.description);
    html += `</div></div>`;
    return html;
  },

  /* ------------------------------------------- what a field inherits */
  /* A field has no tags and no group of its own: it is part of one structure,
     so it shares that structure's classification.  They are shown read-only
     here, with a button that jumps to the structure to change them. */
  inheritedGroup(node, state) {
    const owner = escapeHtml(node.owner || "");
    let rows = `<div class="inherited-row"><span class="k">Group</span>
      <span class="v">${escapeHtml(node.effectiveGroup || "—")}</span></div>`;

    for (const spec of state.tagSpecs) {
      const value = node.effectiveTags[spec.id];
      let shown = value === null || value === undefined ? "—"
                : typeof value === "boolean" ? (value ? "TRUE" : "FALSE") : String(value);
      let note = "";
      if (spec.id === "LogId" && shown !== "—") {
        shown = `${shown} + offset`;
        note = `<span class="note">the block starts here; this field's own id is
                computed from the fields before it</span>`;
      }
      rows += `<div class="inherited-row"><span class="k">${escapeHtml(spec.label)}</span>
        <span class="v">${escapeHtml(shown)}</span>${note}</div>`;
    }

    return `<div class="field-group"><h3>Classification &mdash; from ${owner}</h3>
      <p class="modal-note">Tags and the group belong to the structure, not to its
      fields: <b>${owner}</b> is one thing that belongs to one subsystem, is reset
      proof or is not, and is logged or is not. Everything inside it shares that.</p>
      <div class="inherited-table">${rows}</div>
      <button type="button" class="inline-btn" id="btn-goto-owner">
        Edit them on ${owner}</button>
      </div>`;
  },

  /* ---------------------------------------------------------- tags */
  tagsGroup(node, state, note) {
    let html = `<div class="field-group"><h3>Tags</h3>`;
    if (note) html += `<p class="modal-note">${note}</p>`;
    html += `<div class="grid">`;

    for (const spec of state.tagSpecs) {
      const value = node.tags[spec.id];
      const label = `${spec.label}${spec.mandatory ? ' <span class="req">*</span>' : ""}`;

      if (spec.kind === "boolean") {
        const current = value === null || value === undefined ? "" : (value ? "true" : "false");
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <select data-tag="${spec.id}" data-bool="1">
            <option value=""${current === "" ? " selected" : ""}>—</option>
            <option value="true"${current === "true" ? " selected" : ""}>TRUE</option>
            <option value="false"${current === "false" ? " selected" : ""}>FALSE</option>
          </select>
        </div>`;
      } else if (spec.kind === "enum") {
        const options = state.defines[
          spec.definesColumn === "SYSTEM NAMES" ? "systemNames" : "paramModes"] || [];
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <select data-tag="${spec.id}">${optionList(options, value, true)}</select>
        </div>`;
      } else if (spec.id === "LogId") {
        const note = node.kind === "struct"
          ? `<span class="hint">first id of the block; the fields take
             consecutive ids out of it</span>` : "";
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <input type="number" class="mono" data-tag="${spec.id}"
                 value="${value == null ? "" : value}" step="1" min="0">
          <button type="button" class="inline-btn" id="btn-next-log-id">Use next free id</button>
          ${note}
        </div>`;
      } else {
        html += `<div class="field">
          <label title="${escapeHtml(spec.description)}">${label}</label>
          <input type="text" class="mono" data-tag="${spec.id}"
                 value="${escapeHtml(value == null ? "" : value)}">
        </div>`;
      }
    }
    html += `</div></div>`;
    return html;
  },

  /* ---------------------------------------------------------- widgets */
  text(name, label, value, required) {
    return `<div class="field"><label>${label}${required ? ' <span class="req">*</span>' : ""}</label>
      <input type="text" class="mono" data-field="${name}" value="${escapeHtml(value ?? "")}"></div>`;
  },
  number(name, label, value, min) {
    const minimum = min === undefined ? "" : `min="${min}"`;
    return `<div class="field"><label>${label}</label>
      <input type="number" class="mono" data-field="${name}" step="any" ${minimum}
             value="${value == null ? "" : value}"></div>`;
  },
  select(name, label, value, options, required, extra) {
    return `<div class="field"><label>${label}${required ? ' <span class="req">*</span>' : ""}</label>
      <select data-field="${name}">${optionList(options || [], value, true)}</select>${extra || ""}</div>`;
  },
  check(name, label, value) {
    return `<div class="field check">
      <input type="checkbox" id="field-${name}" data-field="${name}" ${value ? "checked" : ""}>
      <label for="field-${name}">${label}</label></div>`;
  },
  area(name, label, value) {
    return `<div class="field"><label>${label}</label>
      <textarea data-field="${name}">${escapeHtml(value ?? "")}</textarea></div>`;
  },

  /* ---------------------------------------------------------- reading back */
  wire() {
    for (const input of this.element.querySelectorAll("[data-field],[data-tag]")) {
      const event = (input.tagName === "SELECT" || input.type === "checkbox")
        ? "change" : "blur";
      input.addEventListener(event, () => this.onChange(this.collect()));
      if (input.tagName !== "SELECT" && input.type !== "checkbox") {
        input.addEventListener("keydown", (keyEvent) => {
          if (keyEvent.key === "Enter" && input.tagName !== "TEXTAREA") input.blur();
        });
      }
    }
    const nextId = this.element.querySelector("#btn-next-log-id");
    if (nextId) {
      nextId.addEventListener("click", async () => {
        const answer = await api.nextLogId();
        const input = this.element.querySelector('[data-tag="LogId"]');
        input.value = answer.value;
        this.onChange(this.collect());
      });
    }

    const gotoOwner = this.element.querySelector("#btn-goto-owner");
    if (gotoOwner) {
      gotoOwner.addEventListener("click", () => app.select(this.node.owner));
    }
  },

  collect() {
    const changes = {};
    const tags = Object.assign({}, this.node.tags);
    const isBool = (this.node.dataType || "").toLowerCase() === "bool_t";

    for (const input of this.element.querySelectorAll("[data-field]")) {
      const name = input.dataset.field;
      if (input.type === "checkbox") { changes[name] = input.checked; continue; }
      const raw = input.value.trim();

      if (name === "default_value" && isBool) { changes[name] = raw === "true"; continue; }
      if (["array_size"].includes(name)) { changes[name] = raw === "" ? 1 : parseInt(raw, 10); continue; }
      if (["default_value", "minimum", "maximum", "resolution"].includes(name)) {
        changes[name] = raw === "" ? null : Number(raw);
        continue;
      }
      changes[name] = raw === "" ? null : raw;
    }

    for (const input of this.element.querySelectorAll("[data-tag]")) {
      const id = input.dataset.tag;
      const raw = input.value.trim();
      if (raw === "") { tags[id] = null; continue; }
      if (input.dataset.bool) { tags[id] = raw === "true"; continue; }
      tags[id] = input.type === "number" ? parseInt(raw, 10) : raw;
    }

    changes.tags = tags;
    return changes;
  },
};

function optionList(values, selected, allowEmpty) {
  let html = allowEmpty ? `<option value=""${selected == null ? " selected" : ""}>—</option>` : "";
  for (const value of values) {
    const isSelected = String(value) === String(selected) ? " selected" : "";
    html += `<option value="${escapeHtml(value)}"${isSelected}>${escapeHtml(value)}</option>`;
  }
  return html;
}

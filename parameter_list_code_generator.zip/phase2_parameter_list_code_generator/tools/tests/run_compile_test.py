"""End-to-end test: generate the code and compile it with a real C/C++ compiler.

The test
  1. runs the generator on ``parameter_list.xml`` into a temporary folder,
  2. compiles the generated files together with ``smart_data.c`` as **C99** and
     compiles the generated headers as **C++**,
  3. links and runs a small program that calls ``fParameterList_Init()``,
     walks the descriptor table and exercises the usage example.

Run it with::

    python tests/run_compile_test.py

It needs ``gcc`` and ``g++`` on the PATH; on Windows a MinGW or WSL toolchain
works.  The test never touches the files under ``cg_parameter_list`` of the
project: everything is generated into a temporary folder.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from pl_codegen.cli import main as generator_main  # noqa: E402

C_COMPILER = "gcc"
CXX_COMPILER = "g++"

def _run(command: List[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def have_compiler(name: str) -> bool:
    return shutil.which(name) is not None


def write_config(work_dir: Path, inputs: dict, name: str = "codegen_config.json") -> Path:
    """Write a configuration that generates into *work_dir*."""
    config = {
        "inputs": inputs,
        "output": {
            "code_directory": str(work_dir / "generated"),
            "xml_file": str(work_dir / "from_excel.xml"),
            "file_prefix": "cg_",
            "base_name": "parameter_list",
        },
        "style": {"snippet_file": str(PROJECT_DIR / "c.json"), "company": "FAS",
                  "indent": "    "},
        "codegen": {"emit_description": True, "emit_unit": True,
                    "emit_generation_info": True, "emit_timestamp": False},
        "validation": {"treat_warnings_as_errors": False},
    }
    path = work_dir / name
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return path


#: The three ways a project can feed the generator; all three must compile.
def input_variants() -> List[dict]:
    variants = [
        {"label": "one XML module (the editor)",
         "inputs": {"model_files": [str(PROJECT_DIR / "parameter_list.xml")]}},
    ]

    extra = PROJECT_DIR / "module_navigation" / "parameter_list_nav.xml"
    if extra.is_file():
        variants.append(
            {"label": "two XML modules, merged",
             "inputs": {"model_files": [str(PROJECT_DIR / "parameter_list.xml"),
                                        str(extra)]}})

    workbook = PROJECT_DIR / "parameter_list_template.xlsx"
    try:
        import openpyxl  # noqa: F401
        has_excel = workbook.is_file()
    except ImportError:
        has_excel = False
    if has_excel:
        variants.append(
            {"label": "Excel (phase 1 input)", "with_example": False,
             "inputs": {"source": "excel", "excel_files": [str(workbook)],
                        "model_files": [str(PROJECT_DIR / "parameter_list.xml")]}})
    return variants


# smart_data.c includes the project's chrono.h. When the firmware's real
# chrono module is not reachable from here, this stub stands in for it; the
# stub folder is searched LAST, so a real chrono.h always wins.
_CHRONO_STUB_H = """
#ifndef CHRONO_H
#define CHRONO_H
#include <stdint.h>
static uint64_t fChrono_GetContinuousTickUs(void) { return 0U; }
#endif
"""

_LOG_STUB_C = """
#include "parameter_list_usage_example.h"

void fExample_SendToLog(uint32_t logId, const void *pValue, uint32_t memoryOffset) {
    (void)logId; (void)pValue; (void)memoryOffset;
}

uint8_t fExample_UseHome(const sCgStruct_Position_Home *pHome) {
    return (pHome == NULL) ? 1U : 0U;
}
"""


def compile_c(work_dir: Path, includes: List[str], with_example: bool = True) -> bool:
    """The example uses the demo parameters, so it only fits the XML model."""
    (work_dir / "log_stub.c").write_text(_LOG_STUB_C, encoding="utf-8")
    sources = [
        PROJECT_DIR / "smart_data" / "smart_data.c",
        work_dir / "generated" / "cg_smart_data.c",
        work_dir / "generated" / "cg_parameter_list.c",
    ]
    if with_example:
        sources += [PROJECT_DIR / "example" / "parameter_list_usage_example.c",
                    work_dir / "log_stub.c"]
    sources.append(work_dir / "main.c")
    command = [C_COMPILER, "-std=c99", "-Wall", "-Wextra", "-Wpedantic",
               *includes, *[str(path) for path in sources],
               "-o", str(work_dir / "parameter_list_test")]
    result = _run(command)
    if result.returncode != 0:
        print("C compilation FAILED:\n" + result.stderr)
        return False
    if result.stderr.strip():
        print("C compiler warnings:\n" + result.stderr)
    return True


def compile_cxx(work_dir: Path, includes: List[str]) -> bool:
    """The generated headers must be usable from C++ as well."""
    source = work_dir / "cxx_include_test.cpp"
    source.write_text(
        '#include "cg_parameter_list.h"\n'
        '#include "cg_smart_data.h"\n'
        '#include "cg_parameter_list_defines.h"\n'
        '#include "cg_parameter_list_table.h"\n'
        '#include "cg_parameter_list_types.h"\n'
        "int main() { return (int)ParameterList[0].ArraySize - 1; }\n",
        encoding="utf-8")
    command = [CXX_COMPILER, "-std=c++11", "-Wall", "-Wextra", "-c",
               *includes, str(source), "-o", str(work_dir / "cxx_include_test.o")]
    result = _run(command)
    if result.returncode != 0:
        print("C++ compilation FAILED:\n" + result.stderr)
        return False
    return True


_MAIN_HEAD = """
#include <stdio.h>
#include <string.h>
#include "cg_parameter_list.h"
"""

_MAIN_HEAD_WITH_EXAMPLE = _MAIN_HEAD + '#include "parameter_list_usage_example.h"\n'

_MAIN_BODY = """
int main(void) {
    uint16_t index = 0U;
    uint8_t result = fParameterList_Init();
    if (result != 0U) {
        printf("fParameterList_Init failed with %u\\n", (unsigned)result);
        return 1;
    }
    if (fParameterList_GetQuantity() != PARAMETER_LIST_QTY) {
        printf("wrong quantity\\n");
        return 1;
    }
    for (index = 0U; index < PARAMETER_LIST_QTY; index++) {
        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL || pDescriptor->pName == NULL) {
            printf("descriptor %u is broken\\n", (unsigned)index);
            return 1;
        }
        if (fParameterList_GetByName(pDescriptor->pName) != pDescriptor) {
            printf("lookup by name failed for %s\\n", pDescriptor->pName);
            return 1;
        }
        if (pDescriptor->pSmartData == NULL) {
            printf("no smart data for %s\\n", pDescriptor->pName);
            return 1;
        }
    }
    if (fParameterList_GetByIndex(PARAMETER_LIST_QTY) != NULL) {
        printf("out of range index was accepted\\n");
        return 1;
    }
    EXAMPLE_CALLS
    printf("OK: %u parameters initialised and verified" EXAMPLE_NOTE "\\n",
           (unsigned)PARAMETER_LIST_QTY);
    return 0;
}
"""

_EXAMPLE_CALLS = """
    /* The usage example must work as well. */
    fExample_DirectAccess();
    if (fExample_CheckedAccess() != eSMART_DATA_OK) {
        printf("fExample_CheckedAccess failed\\n");
        return 1;
    }
    if (fExample_DescriptorAccess() != 0U) {
        printf("fExample_DescriptorAccess failed\\n");
        return 1;
    }
    if (fExample_StructAccess() != 0U) {
        printf("fExample_StructAccess failed\\n");
        return 1;
    }
    fExample_ArrayAccess();
    if (fExample_ReadIfNew() != TRUE || fExample_ReadIfNew() != FALSE) {
        printf("fExample_ReadIfNew failed\\n");
        return 1;
    }
"""


def main_source(with_example: bool) -> str:
    head = _MAIN_HEAD_WITH_EXAMPLE if with_example else _MAIN_HEAD
    calls = _EXAMPLE_CALLS if with_example else ""
    note = '", usage example runs"' if with_example else '""'
    return (head + f"#define EXAMPLE_NOTE {note}\n"
            + _MAIN_BODY.replace("    EXAMPLE_CALLS", calls))


def main() -> int:
    for compiler in (C_COMPILER, CXX_COMPILER):
        if not have_compiler(compiler):
            print(f"SKIPPED: '{compiler}' was not found on the PATH.")
            return 0

    variants = input_variants()
    print(f"Checking {len(variants)} input variant(s).\n")

    for number, variant in enumerate(variants, start=1):
        label = variant["label"]
        with_example = variant.get("with_example", True)
        print(f"=== {number}/{len(variants)}  {label} ===")
        if not check_one(variant["inputs"], with_example):
            return 1
        print()

    print("All checks passed.")
    return 0


def check_one(inputs: dict, with_example: bool) -> bool:
    """Generate from *inputs*, compile the result and run it."""
    with tempfile.TemporaryDirectory(prefix="pl_codegen_test_") as raw_dir:
        work_dir = Path(raw_dir)

        print("  1/4 generating the code ...")
        config_path = write_config(work_dir, inputs)
        exit_code = generator_main(["--config", str(config_path), "--quiet"])
        if exit_code != 0:
            print(f"  FAILED: the generator returned {exit_code}.")
            return False

        (work_dir / "main.c").write_text(main_source(with_example), encoding="utf-8")
        stub_dir = work_dir / "stubs"
        stub_dir.mkdir(exist_ok=True)
        (stub_dir / "chrono.h").write_text(_CHRONO_STUB_H, encoding="utf-8")
        includes = [f"-I{PROJECT_DIR}",
                    f"-I{PROJECT_DIR / 'example'}",
                    f"-I{PROJECT_DIR / 'smart_data'}",
                    f"-I{PROJECT_DIR / 'parameter_descriptor'}",
                    f"-I{work_dir / 'generated'}",
                    f"-I{stub_dir}"]

        print("  2/4 compiling as C99 ...")
        if not compile_c(work_dir, includes, with_example):
            return False

        print("  3/4 compiling the headers as C++ ...")
        if not compile_cxx(work_dir, includes):
            return False

        print("  4/4 running the generated parameter list ...")
        result = _run([str(work_dir / "parameter_list_test")])
        print("        " + result.stdout.strip())
        if result.returncode != 0:
            print("  FAILED: the test program returned a non-zero exit code.")
            return False
    return True


if __name__ == "__main__":
    raise SystemExit(main())

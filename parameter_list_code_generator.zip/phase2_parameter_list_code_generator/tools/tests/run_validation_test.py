"""Checks that a faulty parameter list is rejected with the right diagnostics.

Each case builds a small model in memory, runs the validator on it and asserts
which diagnostic code comes back.  No compiler and no Excel file needed.

Run it with::

    python tests/run_validation_test.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

TOOLS_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

from pl_codegen.config import Config  # noqa: E402
from pl_codegen.errors import DiagnosticCollector, Severity  # noqa: E402
from pl_codegen.logging_utils import setup_logging  # noqa: E402
from pl_codegen.model.defines import (COLUMN_GROUPS, COLUMN_PARAM_MODES,  # noqa: E402
                                      COLUMN_SYSTEM_NAMES, COLUMN_TYPES, Defines)
from pl_codegen.model.parameter import Parameter, ParameterKind  # noqa: E402
from pl_codegen.model.parameter_list import ParameterList  # noqa: E402
from pl_codegen.model.types import DATA_TYPES  # noqa: E402
from pl_codegen.validation.validator import Validator  # noqa: E402

SYSTEM_NAMES = ["SYS_UNKNOWN", "SYS_NAV"]
PARAM_MODES = ["PARAM_MODE_USER", "PARAM_MODE_READ_ONLY"]
GROUPS = ["MONITORING", "SETTING", "COMMAND"]


# ---------------------------------------------------------------- builders
def tags(**overrides: Any) -> Dict[str, Any]:
    base = {"SystemName": "SYS_NAV", "ResetProof": False, "Loggable": False,
            "LogId": None, "LogEncryption": False, "ParamMode": "PARAM_MODE_USER"}
    base.update(overrides)
    return base


def value(name: str = "GoodParam", **overrides: Any) -> Parameter:
    node = Parameter(name=name, group="MONITORING", data_type_name="uint8_t",
                     default_value=5, minimum=0, maximum=10, resolution=1,
                     unit="mm", gs_name=name, description="A valid parameter.")
    node.tags = tags()
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def struct(name: str, *children: Parameter, **overrides: Any) -> Parameter:
    node = Parameter(name=name, kind=ParameterKind.STRUCT, group="MONITORING",
                     description="A structure.")
    node.tags = tags()
    node.children = list(children)
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def field(name: str, **overrides: Any) -> Parameter:
    """A field of a structure: no tags and no group of its own."""
    node = Parameter(name=name, data_type_name="uint8_t", default_value=0,
                     minimum=0, maximum=10, resolution=1, gs_name=name,
                     description="A field.")
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def inner(name: str, *children: Parameter, **overrides: Any) -> Parameter:
    """A sub-structure: like a field, it carries no tags and no group."""
    node = Parameter(name=name, kind=ParameterKind.STRUCT, description="A structure.")
    node.children = list(children)
    for key, item in overrides.items():
        if key == "tags":
            node.tags.update(item)
        else:
            setattr(node, key, item)
    return node


def model(*parameters: Parameter) -> ParameterList:
    result = ParameterList(parameters=list(parameters))
    defines = Defines()
    for name in DATA_TYPES:
        defines.add(COLUMN_TYPES, name)
    for name in GROUPS:
        defines.add(COLUMN_GROUPS, name)
    for name in SYSTEM_NAMES:
        defines.add(COLUMN_SYSTEM_NAMES, name)
    for name in PARAM_MODES:
        defines.add(COLUMN_PARAM_MODES, name)
    result.defines = defines
    return result


# ---------------------------------------------------------------- the cases
CASES: List[Dict[str, Any]] = [
    # ---- names -----------------------------------------------------------
    {"name": "invalid_name", "expect": "NAME001",
     "model": lambda: model(value("2Bad Name"))},
    {"name": "reserved_name", "expect": "NAME002",
     "model": lambda: model(value("struct"))},
    {"name": "duplicate_top_level", "expect": "NAME003",
     "model": lambda: model(value("Same"), value("Same"))},
    {"name": "duplicate_field", "expect": "NAME003",
     "model": lambda: model(struct("S", field("A"), field("A")))},
    {"name": "macro_collision", "expect": "NAME004",
     "model": lambda: model(value("TestVar"), value("Test_Var"))},

    # ---- structures ------------------------------------------------------
    {"name": "empty_struct", "expect": "STR001",
     "model": lambda: model(struct("Empty"))},
    {"name": "array_of_struct", "expect": "STR002",
     "model": lambda: model(struct("S", field("A"), array_size=4))},

    # ---- types and ranges -------------------------------------------------
    {"name": "unsupported_type", "expect": "TYPE002",
     "model": lambda: model(value(data_type_name="sMyStruct"))},
    {"name": "unknown_group", "expect": "GRP002",
     "model": lambda: model(value(group="TELEMETRY"))},
    {"name": "struct_without_group", "expect": "GRP001",
     "model": lambda: model(struct("S", field("A"), group=None))},
    {"name": "field_with_own_tag", "expect": "STR004",
     "model": lambda: model(struct("S", field("A", tags={"Loggable": True})))},
    {"name": "field_with_own_group", "expect": "STR005",
     "model": lambda: model(struct("S", field("A", group="SETTING")))},
    {"name": "substruct_with_own_tag", "expect": "STR004",
     "model": lambda: model(struct("S", inner("Inner", field("A"),
                                              tags={"SystemName": "SYS_NAV"})))},
    {"name": "bad_array_size", "expect": "ARR001",
     "model": lambda: model(value(array_size=0))},
    {"name": "value_out_of_c_type", "expect": "RNG001",
     "model": lambda: model(value(maximum=5000))},
    {"name": "min_greater_than_max", "expect": "RNG002",
     "model": lambda: model(value(minimum=10, maximum=1, default_value=5))},
    {"name": "default_out_of_range", "expect": "RNG003",
     "model": lambda: model(value(default_value=99))},

    # ---- tags -------------------------------------------------------------
    {"name": "missing_mandatory_tag", "expect": "TAG001",
     "model": lambda: model(value(tags={"SystemName": None}))},
    {"name": "unknown_system_name", "expect": "TAG003",
     "model": lambda: model(value(tags={"SystemName": "SYS_NOPE"}))},
    {"name": "loggable_without_log_id", "expect": "TAG010",
     "model": lambda: model(value(tags={"Loggable": True}))},
    {"name": "duplicate_log_id", "expect": "TAG012",
     "model": lambda: model(value("A", tags={"Loggable": True, "LogId": 500}),
                            value("B", tags={"Loggable": True, "LogId": 500}))},
    # float64_t x2 reserves 16 ids: 400..415, so 410 must be refused
    {"name": "log_id_range_overlap", "expect": "TAG013",
     "model": lambda: model(
         value("Wide", data_type_name="float64_t", array_size=2, minimum=0, maximum=0,
               default_value=0, tags={"Loggable": True, "LogId": 400}),
         value("Next", tags={"Loggable": True, "LogId": 410}))},

    # ---- the good cases ---------------------------------------------------
    {"name": "log_id_range_ok", "expect": None,
     "model": lambda: model(
         value("Wide", data_type_name="float64_t", array_size=2, minimum=0, maximum=0,
               default_value=0, tags={"Loggable": True, "LogId": 400}),
         value("Next", tags={"Loggable": True, "LogId": 416}))},
    {"name": "empty_list", "expect": "VAL001", "model": lambda: model()},
    {"name": "all_disabled", "expect": "VAL001",
     "model": lambda: model(value(enable=False))},
    {"name": "flat_ok", "expect": None,
     "model": lambda: model(value("First"), value("Second"))},
    # every field takes the mandatory tags and the group of its structure
    {"name": "struct_inherits_ok", "expect": None,
     "model": lambda: model(struct("Position",
                                   inner("Home", field("Lat"), field("Lon")),
                                   field("Alt")))},
    # one log id on the structure covers all of its fields
    {"name": "struct_log_id_ok", "expect": None,
     "model": lambda: model(struct("S", field("A"), field("B"), field("C"),
                                   tags={"Loggable": True, "LogId": 700}))},
    # an exact clash with one of the fields is the clearer TAG012
    {"name": "struct_log_id_hits_field", "expect": "TAG012",
     "model": lambda: model(
         struct("S", field("A"), field("B"), field("C"),
                tags={"Loggable": True, "LogId": 700}),
         value("After", tags={"Loggable": True, "LogId": 702}))},
    # a float32 field reserves 4 ids, so 702 lands inside its range
    {"name": "struct_log_id_block_overlap", "expect": "TAG013",
     "model": lambda: model(
         struct("S", field("Wide", data_type_name="float32_t", minimum=0, maximum=0,
                           default_value=0),
                tags={"Loggable": True, "LogId": 700}),
         value("After", tags={"Loggable": True, "LogId": 702}))},
    # the block of S is 700..702, so 703 is the first free id
    {"name": "struct_log_id_block_ok", "expect": None,
     "model": lambda: model(
         struct("S", field("A"), field("B"), field("C"),
                tags={"Loggable": True, "LogId": 700}),
         value("After", tags={"Loggable": True, "LogId": 703}))},
]


def run_case(config: Config, build: Callable[[], ParameterList]) -> Set[str]:
    diagnostics = DiagnosticCollector()
    Validator(config).validate(build(), diagnostics)
    return {item.code for item in diagnostics.items if item.severity is Severity.ERROR}


def main() -> int:
    setup_logging(quiet=True)
    failures = 0

    with tempfile.TemporaryDirectory(prefix="pl_codegen_validation_") as raw_dir:
        work_dir = Path(raw_dir)
        config_path = work_dir / "config.json"
        config_path.write_text(json.dumps({
            "inputs": {"model_file": str(work_dir / "model.xml")},
            "output": {"code_directory": str(work_dir / "gen")},
            "style": {"snippet_file": str(PROJECT_DIR / "c.json")},
        }), encoding="utf-8")
        config = Config.load(config_path)

        for case in CASES:
            codes = run_case(config, case["model"])
            expected: Optional[str] = case["expect"]

            if expected is None:
                ok = not codes
                detail = "no error expected"
            else:
                ok = expected in codes
                detail = f"expected {expected}"

            print(f"  [{'PASS' if ok else 'FAIL'}] {case['name']:<24} {detail}; "
                  f"reported: {', '.join(sorted(codes)) or '-'}")
            if not ok:
                failures += 1

    print()
    if failures:
        print(f"{failures} of {len(CASES)} validation case(s) FAILED.")
        return 1
    print(f"All {len(CASES)} validation cases passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""One-click environment check / dependency installation.

Run this file once (double-click it on Windows, or ``python setup_environment.py``)
before using ``gui.py`` or ``generate.py``.

Since phase 2 the parameter list is edited in the graphical editor and stored in
``parameter_list.xml``, so **the editor and the code generator need nothing but
the Python standard library**.  The only optional package is ``openpyxl``, and it
is used exclusively by the "Import from Excel" button, which converts an old
phase-1 workbook into the XML model.

This script deliberately has **no** third-party dependency itself, so it always
runs, also on a machine with no internet connection.
"""

from __future__ import annotations

import argparse
import importlib
import platform
import subprocess
import sys
from pathlib import Path
from typing import List, NamedTuple

MINIMUM_PYTHON = (3, 8)
TOOLS_DIR = Path(__file__).resolve().parent
REQUIREMENTS_FILE = TOOLS_DIR / "requirements.txt"


class Requirement(NamedTuple):
    """A package the tool can use."""

    module: str          #: name used in ``import``
    distribution: str    #: name used by ``pip install``
    reason: str
    optional: bool       #: True when the tool still works without it


#: Everything the tool may want to import.  Add a line here and the checker,
#: the installer and ``requirements.txt`` all pick it up.
REQUIREMENTS: List[Requirement] = [
    Requirement("openpyxl", "openpyxl>=3.0",
                "only for 'Import from Excel' (reading old .xlsx parameter lists)",
                optional=True),
]

#: Standard library modules the editor and the generator rely on.  They ship
#: with Python; the check only exists to give a clear message on a stripped
#: down Python installation.
STANDARD_MODULES = [
    ("xml.etree.ElementTree", "reading and writing parameter_list.xml"),
    ("http.server", "the local web server behind the graphical editor"),
    ("json", "the configuration file and the editor API"),
    ("webbrowser", "opening the editor in the default browser"),
]


def _print_header() -> None:
    print("=" * 78)
    print("Parameter list code generator - environment setup")
    print("=" * 78)
    print(f"Python      : {platform.python_version()} ({sys.executable})")
    print(f"Platform    : {platform.system()} {platform.release()}")
    print(f"Tools folder: {TOOLS_DIR}")
    print()


def check_python_version() -> bool:
    if sys.version_info < MINIMUM_PYTHON:
        print(f"ERROR: Python {MINIMUM_PYTHON[0]}.{MINIMUM_PYTHON[1]} or newer is required, "
              f"but {platform.python_version()} is running.")
        return False
    return True


def check_standard_modules() -> bool:
    """The editor and the generator need these - and only these."""
    print("Checking the standard library modules the tool uses:")
    ok = True
    for name, reason in STANDARD_MODULES:
        try:
            importlib.import_module(name)
            print(f"  [ok]      {name:<24} - {reason}")
        except ImportError:
            print(f"  [MISSING] {name:<24} - {reason}")
            ok = False
    if not ok:
        print("\nERROR: this Python installation is incomplete. Install the official\n"
              "       Python distribution from python.org and run this script again.")
    return ok


def missing_requirements() -> List[Requirement]:
    print("\nChecking the optional packages:")
    missing: List[Requirement] = []
    for requirement in REQUIREMENTS:
        try:
            importlib.import_module(requirement.module)
            print(f"  [ok]      {requirement.module:<12} - {requirement.reason}")
        except ImportError:
            print(f"  [missing] {requirement.module:<12} - {requirement.reason}")
            missing.append(requirement)
    return missing


def install(requirements: List[Requirement], upgrade: bool = False) -> bool:
    command = [sys.executable, "-m", "pip", "install"]
    if upgrade:
        command.append("--upgrade")
    command.extend(requirement.distribution for requirement in requirements)

    print("\nRunning:", " ".join(command))
    try:
        subprocess.check_call(command)
    except FileNotFoundError:
        print("\nERROR: 'pip' was not found for this Python installation.")
        return False
    except subprocess.CalledProcessError as error:
        print(f"\nERROR: pip failed with exit code {error.returncode}.")
        print("If your machine is offline or behind a proxy, install from an internal mirror:")
        print(f"  {sys.executable} -m pip install --index-url <mirror> "
              f"{' '.join(r.distribution for r in requirements)}")
        return False
    return True


def verify(requirements: List[Requirement]) -> bool:
    print("\nVerifying the installation ...")
    ok = True
    for requirement in requirements:
        try:
            module = importlib.import_module(requirement.module)
            version = getattr(module, "__version__", "unknown")
            print(f"  [ok] {requirement.module} {version}")
        except ImportError:
            print(f"  [FAILED] {requirement.module} is still not importable.")
            ok = False
    return ok


def write_requirements_file() -> None:
    """Keep ``requirements.txt`` in sync with :data:`REQUIREMENTS`."""
    lines = ["# Generated by setup_environment.py - do not edit by hand.",
             "# The editor and the code generator need no package at all;",
             "# everything listed here is optional.", ""]
    lines.extend(f"{requirement.distribution}  # {requirement.reason}"
                 for requirement in REQUIREMENTS)
    REQUIREMENTS_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _print_footer(excel_available: bool) -> None:
    print()
    print("-" * 78)
    print("You can now run:")
    print("  python gui.py         - open the graphical parameter list editor")
    print("  python generate.py    - generate the C files from parameter_list.xml")
    print("  python generate.py --check   - only validate, write nothing")
    if not excel_available:
        print()
        print("'Import from Excel' stays disabled until 'openpyxl' is installed,")
        print("but nothing else is affected.")
    print("-" * 78)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Check the environment and install the optional packages.")
    parser.add_argument("--check-only", action="store_true",
                        help="only report what is missing, install nothing")
    parser.add_argument("--upgrade", action="store_true",
                        help="upgrade the packages even if they are already installed")
    arguments = parser.parse_args()

    _print_header()
    if not check_python_version():
        return 2
    if not check_standard_modules():
        return 2

    missing = missing_requirements()
    write_requirements_file()

    print("\nThe graphical editor and the code generator are ready to run - "
          "they need no extra package.")

    if arguments.upgrade:
        missing = list(REQUIREMENTS)
    if not missing:
        _print_footer(excel_available=True)
        return 0
    if arguments.check_only:
        print(f"\n{len(missing)} optional package(s) missing. "
              f"Re-run without --check-only to install them.")
        _print_footer(excel_available=False)
        return 0

    if not install(missing, upgrade=arguments.upgrade):
        # A failed optional install is not a failed setup.
        _print_footer(excel_available=False)
        return 0
    verify(missing)
    _print_footer(excel_available=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

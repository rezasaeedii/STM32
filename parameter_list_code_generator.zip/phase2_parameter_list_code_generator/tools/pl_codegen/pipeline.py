"""The pipeline.

There is exactly one code generator, and it only ever reads the XML model.
What changed in phase 2 is that the XML can now be produced two ways:

    editor  ->  XML  ─┐
                      ├─►  model  ->  validation  ->  tag offsets  ->  C files
    Excel   ->  XML  ─┘

* ``source = "xml"``   the editor owns the list (structures are possible)
* ``source = "excel"`` the workbooks own it (phase 1 behaviour, no structures)

Either way several files can be listed - one per sub-module of the project -
and they are merged into one list before anything else happens.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from .codegen.c_style import CStyle
from .codegen.files import FILE_BUILDERS
from .config import Config
from .errors import CodeGeneratorError, DiagnosticCollector, Severity
from .layout.tag_offset import build_offset_map
from .logging_utils import banner, get_logger
from .model.parameter_list import ParameterList
from .validation.validator import Validator
from .xml_model.xml_reader import read_xml
from .xml_model.xml_writer import write_xml


@dataclass
class PipelineResult:
    """Everything a caller needs to report the outcome of a run."""

    success: bool
    diagnostics: DiagnosticCollector
    model_file: Optional[Path] = None
    generated_files: List[Path] = field(default_factory=list)
    parameter_count: int = 0


class Pipeline:
    """Runs the code generator."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._logger = get_logger()

    # -- reading the model -----------------------------------------------
    def load_model(self, diagnostics: DiagnosticCollector,
                   model_file: Optional[Path] = None) -> ParameterList:
        """The merged parameter list of every configured sub-module."""
        paths = [model_file] if model_file else list(self._config.inputs.model_files)

        merged = ParameterList()
        for index, path in enumerate(paths):
            self._logger.info("  reading %s", path)
            if not path.is_file():
                raise CodeGeneratorError(
                    f"The model file '{path}' does not exist.\n"
                    f"Create it with the editor (python gui.py), import it from Excel "
                    f"(python generate.py --from-excel), or fix 'inputs.model_files' "
                    f"in {self._config.path.name}.")
            part = read_xml(path, diagnostics)
            if str(path) not in part.source_files:
                part.source_files.append(str(path))
            if index == 0:
                merged = part
            else:
                merged.extend(part)

        if len(paths) > 1:
            self._logger.info("  merged %d module(s) into one list", len(paths))
        return merged

    def load_from_excel(self, diagnostics: DiagnosticCollector,
                        write_to: Optional[Path] = None) -> ParameterList:
        """Read the workbooks and write the XML model they describe.

        By default the XML lands in ``output.xml_file`` - an intermediate file
        next to the generated code.  The model the editor owns is only ever
        written by an explicit ``--import-excel``.
        """
        from .excel.excel_to_model import build_model  # lazily: needs openpyxl

        if not self._config.inputs.excel_files:
            raise CodeGeneratorError(
                "No Excel file is listed in 'inputs.excel_files' of the configuration.")

        for path in self._config.inputs.excel_files:
            self._logger.info("  reading %s", path)
        model = build_model(self._config, diagnostics)

        target = write_to or self._config.output.xml_file
        target.parent.mkdir(parents=True, exist_ok=True)
        write_xml(model, target, emit_timestamp=self._config.codegen.emit_timestamp)
        self._logger.info("  XML model written to %s", target)
        return model

    # -- generating --------------------------------------------------------
    def generate(self, model: ParameterList,
                 diagnostics: DiagnosticCollector) -> PipelineResult:
        """Validate *model* and write the C files."""
        if not Validator(self._config).validate(model, diagnostics):
            return PipelineResult(False, diagnostics)

        offsets = build_offset_map(model)
        style = CStyle.load(self._config.style.snippet_file,
                            company=self._config.style.company,
                            indent=self._config.style.indent)

        generated: List[Path] = []
        directory = self._config.output.code_directory

        for builder_class in FILE_BUILDERS:
            builder = builder_class(model, self._config, offsets, style)
            path = builder.save(directory)
            generated.append(path)
            self._logger.info("  generated %s (%d lines)", path.name,
                              path.read_text(encoding="utf-8").count("\n"))

        return PipelineResult(True, diagnostics, self._config.inputs.model_file,
                              generated, len(model.flatten()))


    def run(self, model_file: Optional[Path] = None,
            from_excel: Optional[bool] = None) -> PipelineResult:
        """Produce the C files, from whichever input the configuration names."""
        diagnostics = DiagnosticCollector()
        use_excel = self._config.inputs.from_excel if from_excel is None else from_excel

        if use_excel:
            self._logger.info(banner("Reading the Excel parameter list"))
            model = self.load_from_excel(diagnostics)
        else:
            self._logger.info(banner("Reading the parameter list"))
            model = self.load_model(diagnostics, model_file)

        self._logger.info("  %d top level parameter(s), %d value(s) after flattening",
                          len(model), len(model.flatten()))

        self._logger.info(banner("Generating the C code"))
        return self.generate(model, diagnostics)

    def check(self, from_excel: Optional[bool] = None) -> PipelineResult:
        """Validate the input without writing any C file."""
        diagnostics = DiagnosticCollector()
        use_excel = self._config.inputs.from_excel if from_excel is None else from_excel

        self._logger.info(banner("Checking the parameter list"))
        if use_excel:
            from .excel.excel_to_model import build_model  # lazily: needs openpyxl
            for path in self._config.inputs.excel_files:
                self._logger.info("  reading %s", path)
            model = build_model(self._config, diagnostics)
            source: Optional[Path] = self._config.inputs.excel_files[0]
        else:
            model = self.load_model(diagnostics)
            source = self._config.inputs.model_file

        ok = Validator(self._config).validate(model, diagnostics)
        return PipelineResult(ok, diagnostics, source,
                              parameter_count=len(model.flatten()))

    # -- importing ----------------------------------------------------------
    def import_excel(self, destination: Optional[Path] = None,
                     force: bool = False) -> PipelineResult:
        """Move an Excel list into the editor's model file, and stop there.

        This is the migration command, so unlike a normal run it *does* write
        the file the editor owns - and refuses to do so silently if that file
        already holds a list.
        """
        diagnostics = DiagnosticCollector()
        self._logger.info(banner("Importing the Excel input"))

        target = destination or self._config.inputs.model_file
        if target.is_file() and not force:
            raise CodeGeneratorError(
                f"'{target}' already exists and would be replaced by the Excel list.\n"
                f"Everything in it - structures included - would be lost.\n"
                f"  * to replace it anyway:      python generate.py --import-excel --force\n"
                f"  * to import somewhere else:  python generate.py --import-excel "
                f"-m other.xml\n"
                f"  * to generate from Excel without touching it: "
                f"python generate.py --from-excel")

        model = self.load_from_excel(diagnostics, write_to=target)
        return PipelineResult(not diagnostics.has_errors, diagnostics, target,
                              parameter_count=len(model.flatten()))


def render_diagnostics(diagnostics: DiagnosticCollector, verbose: bool) -> str:
    """Format the diagnostics for the console."""
    minimum = Severity.INFO if verbose else Severity.WARNING
    return diagnostics.render(minimum)

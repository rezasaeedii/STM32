"""Parameter-list code generator package.

The package is intentionally split into small, single-responsibility modules so
that a normal user of the tool can find and edit exactly one file when a single
aspect of the generated code has to change:

    config.py          -> how the tool is configured
    errors.py          -> how problems are reported
    naming.py          -> how C identifiers are derived from parameter names
    model/             -> the in-memory description of a parameter list
    xml_model/         -> model  <-> XML (the source of truth on disk)
    excel/             -> Excel  -> model (only for importing an old workbook)
    validation/        -> model  -> diagnostics
    layout/            -> model  -> the MemoryOffset of every tag
    codegen/           -> model  -> C source/header files

The graphical editor lives next to this package, in ``pl_gui``; it edits the
same model and writes the same XML.
"""

__version__ = "2.0.0"
__tool_name__ = "parameter_list_code_generator"

__all__ = ["__version__", "__tool_name__"]

"""Model -> XML.

The XML file is the stable intermediate representation: the code generator only
ever reads *this*, never the Excel files directly.  A future GUI therefore only
has to produce a file in this format.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .. import __tool_name__, __version__
from ..model.parameter import Parameter, ParameterKind
from ..model.parameter_list import ParameterList
from ..model.tags import TAG_REGISTRY
from . import schema as sch


def _text(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return repr(value)
    return str(value)


def _set(element: ET.Element, name: str, value: object) -> None:
    """Set an attribute unless the value is ``None``."""
    if value is not None:
        element.set(name, _text(value))


def model_to_element(model: ParameterList, *, emit_timestamp: bool = True) -> ET.Element:
    """Build the XML tree of *model*."""
    root = ET.Element(sch.ROOT)
    root.set(sch.ATTR_SCHEMA_VERSION, sch.SCHEMA_VERSION)
    root.set(sch.ATTR_GENERATOR, __tool_name__)
    root.set(sch.ATTR_GENERATOR_VERSION, __version__)
    if emit_timestamp:
        stamp = model.generated_at or datetime.now(timezone.utc).astimezone().isoformat(
            timespec="seconds")
        root.set(sch.ATTR_GENERATED_AT, stamp)

    files_element = ET.SubElement(root, sch.SOURCE_FILES)
    for path in model.source_files:
        ET.SubElement(files_element, sch.SOURCE_FILE, {sch.ATTR_PATH: path})

    defines_element = ET.SubElement(root, sch.DEFINES)
    for column in sorted(model.defines.values):
        group_element = ET.SubElement(defines_element, sch.DEFINE_GROUP,
                                      {sch.ATTR_NAME: column})
        for value in model.defines.get(column):
            ET.SubElement(group_element, sch.DEFINE_VALUE, {sch.ATTR_VALUE: value})

    parameters_element = ET.SubElement(root, sch.PARAMETERS)
    for parameter in model.parameters:
        parameters_element.append(_parameter_to_element(parameter))

    return root


def _parameter_to_element(parameter: Parameter) -> ET.Element:
    element = ET.Element(sch.PARAMETER)
    _set(element, sch.ATTR_NAME, parameter.name)
    _set(element, sch.ATTR_KIND, parameter.kind.value)
    _set(element, sch.ATTR_ENABLE, parameter.enable)
    _set(element, sch.ATTR_GS_NAME, parameter.gs_name)
    _set(element, sch.ATTR_GROUP, parameter.group)
    _set(element, sch.ATTR_DATA_TYPE, parameter.data_type_name)
    _set(element, sch.ATTR_ARRAY_SIZE, parameter.array_size)
    _set(element, sch.ATTR_UNIT, parameter.unit)

    source = ET.SubElement(element, sch.SOURCE)
    _set(source, sch.ATTR_FILE, parameter.source.file)
    _set(source, sch.ATTR_SHEET, parameter.source.sheet)
    _set(source, sch.ATTR_ROW, parameter.source.row)

    limits = ET.SubElement(element, sch.LIMITS)
    _set(limits, sch.ATTR_DEFAULT, parameter.default_value)
    _set(limits, sch.ATTR_MINIMUM, parameter.minimum)
    _set(limits, sch.ATTR_MAXIMUM, parameter.maximum)
    _set(limits, sch.ATTR_RESOLUTION, parameter.resolution)

    tags = ET.SubElement(element, sch.TAGS)
    for spec in TAG_REGISTRY:
        value = parameter.tags.get(spec.tag_id)
        if value is None:
            continue
        tag_element = ET.SubElement(tags, sch.TAG)
        tag_element.set(sch.ATTR_ID, spec.tag_id)
        tag_element.set(sch.ATTR_KIND, spec.kind.value)
        tag_element.set(sch.ATTR_VALUE, _text(value))

    if parameter.description:
        ET.SubElement(element, sch.DESCRIPTION).text = parameter.description

    if parameter.kind is ParameterKind.STRUCT:
        fields = ET.SubElement(element, sch.FIELDS)
        for child in parameter.children:
            fields.append(_parameter_to_element(child))

    return element


def write_xml(model: ParameterList, path: Path, *, emit_timestamp: bool = True) -> Path:
    """Write *model* to *path* as a pretty printed XML file."""
    root = model_to_element(model, emit_timestamp=emit_timestamp)
    _indent(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
    return path


def _indent(element: ET.Element, level: int = 0, indent: str = "  ") -> None:
    """``ET.indent`` replacement that also works on Python 3.8."""
    padding = "\n" + level * indent
    if len(element):
        if not (element.text or "").strip():
            element.text = padding + indent
        for child in element:
            _indent(child, level + 1, indent)
        last: Optional[ET.Element] = element[-1]
        if last is not None and not (last.tail or "").strip():
            last.tail = padding
    if level and not (element.tail or "").strip():
        element.tail = padding

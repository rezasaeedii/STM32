"""In-memory description of a single parameter.

A parameter is either a **primitive** (it holds one value, possibly an array of
values) or a **struct** (it holds other parameters, which may themselves be
structs).  The tree can be nested as deeply as needed.

**Tags and the group belong to the top level entry**, never to a field inside a
structure.  A structure is one thing that belongs to one subsystem, is reset
proof or is not, and is logged or is not; its fields are the smart-data objects
that make it up, and they all share that classification.  So a field carries
only what is really its own: name, type, array size, unit, limits, description.


The code generator never walks the tree itself: it asks
:meth:`~pl_codegen.model.parameter_list.ParameterList.flatten` for the list of
*leaves*, where every leaf is a primitive with a dotted name such as
``Position.Home.Lat``.  That keeps the generated descriptor table exactly the
same shape it had before structs existed.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Dict, Iterator, List, Optional, Union

from ..errors import SourceLocation
from .types import CDataType, resolve_data_type

#: Value a tag can hold once it has been read from the GUI / XML.
TagValue = Union[bool, int, str, None]

#: Numeric value of a parameter (default / min / max / resolution).
NumericValue = Union[int, float, bool, None]


class ParameterKind(Enum):
    """What a parameter is."""

    PRIMITIVE = "primitive"   #: holds a value of a supported C type
    STRUCT = "struct"         #: holds other parameters


@dataclass
class Parameter:
    """One node of the parameter tree."""

    name: str
    kind: ParameterKind = ParameterKind.PRIMITIVE
    enable: bool = True
    gs_name: Optional[str] = None
    group: Optional[str] = None
    data_type_name: Optional[str] = None
    array_size: int = 1
    default_value: NumericValue = None
    minimum: NumericValue = None
    maximum: NumericValue = None
    resolution: NumericValue = None
    unit: Optional[str] = None
    tags: Dict[str, TagValue] = field(default_factory=dict)
    description: Optional[str] = None
    children: List["Parameter"] = field(default_factory=list)
    source: SourceLocation = field(default_factory=SourceLocation)

    #: filled in by :meth:`ParameterList.flatten` - the C expression that
    #: reaches this leaf, e.g. ``Cg_SmartData_Position.Home.Lat``
    c_object: Optional[str] = None

    # -- what kind of node is this ---------------------------------------
    @property
    def is_struct(self) -> bool:
        return self.kind is ParameterKind.STRUCT

    @property
    def is_primitive(self) -> bool:
        return self.kind is ParameterKind.PRIMITIVE

    @property
    def data_type(self) -> Optional[CDataType]:
        """Resolved data type, or ``None`` for a struct/unknown type."""
        return resolve_data_type(self.data_type_name) if self.is_primitive else None

    @property
    def is_array(self) -> bool:
        return self.array_size > 1

    @property
    def range_disabled(self) -> bool:
        """A zero minimum *and* a zero maximum disables the allowed range."""
        return _is_zero(self.minimum) and _is_zero(self.maximum)

    @property
    def reserved_size(self) -> int:
        """Bytes this value occupies: ``sizeof(value) * array size``.

        This one number drives both the ``MemoryOffset`` of every tag and the
        number of log ids a value reserves.
        """
        data_type = self.data_type
        if data_type is None:
            return 0
        return data_type.value_size * max(1, self.array_size)

    # -- tags -------------------------------------------------------------
    def tag(self, tag_id: str) -> TagValue:
        return self.tags.get(tag_id)

    def has_active_tag(self, tag_id: str) -> bool:
        """A tag is *active* when it holds a truthy, non-empty value."""
        value = self.tags.get(tag_id)
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, int):
            return value != 0
        return str(value).strip() != ""

    # -- tree helpers ------------------------------------------------------
    def walk(self) -> Iterator["Parameter"]:
        """Yield this node and every node below it."""
        yield self
        for child in self.children:
            yield from child.walk()

    def enabled_children(self) -> List["Parameter"]:
        return [child for child in self.children if child.enable]

    def copy_as_leaf(self, dotted_name: str, c_object: str,
                     tags: Dict[str, TagValue]) -> "Parameter":
        """A flat copy of this leaf, as the code generator wants to see it."""
        return replace(self, name=dotted_name, c_object=c_object, tags=dict(tags),
                       children=[])

    def __str__(self) -> str:  # pragma: no cover - debugging helper
        if self.is_struct:
            return f"Parameter({self.name}, struct, {len(self.children)} field(s))"
        return f"Parameter({self.name}, {self.data_type_name}, x{self.array_size})"


def _is_zero(value: NumericValue) -> bool:
    return value is not None and not isinstance(value, str) and float(value) == 0.0

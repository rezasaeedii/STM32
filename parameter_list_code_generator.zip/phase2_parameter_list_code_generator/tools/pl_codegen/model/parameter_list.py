"""The whole parameter list: a tree of parameters plus the allowed values."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Tuple

from dataclasses import replace

from ..errors import SourceLocation
from .defines import Defines
from .parameter import Parameter, ParameterKind, TagValue

#: separator between a struct and its field in a flattened name
PATH_SEPARATOR = "."

#: the one tag that is spread over the leaves instead of being copied to them
LOG_ID_TAG = "LogId"


@dataclass
class ParameterList:
    """All parameters of the project, as a tree."""

    parameters: List[Parameter] = field(default_factory=list)
    defines: Defines = field(default_factory=Defines)
    source_files: List[str] = field(default_factory=list)
    generator_version: str = ""
    generated_at: str = ""

    # -- collection behaviour -------------------------------------------
    def __iter__(self) -> Iterator[Parameter]:
        return iter(self.parameters)

    def __len__(self) -> int:
        return len(self.parameters)

    def add(self, parameter: Parameter) -> None:
        self.parameters.append(parameter)

    def extend(self, other: "ParameterList") -> None:
        """Append another sub-module's list to this one.

        The result is exactly what one big list would have been: the order of
        the modules decides the order of the indices, and the drop-down lists
        are merged.  Duplicate names or overlapping log ids across modules are
        found by the normal validation afterwards, which names the file each
        parameter came from.
        """
        self.parameters.extend(other.parameters)
        self.defines.merge(other.defines)
        for name in other.source_files:
            if name not in self.source_files:
                self.source_files.append(name)

    # -- the tree ---------------------------------------------------------
    def walk(self) -> Iterator[Parameter]:
        """Every node of the tree, parents before children."""
        for parameter in self.parameters:
            yield from parameter.walk()

    @property
    def enabled(self) -> List[Parameter]:
        """Top level parameters that take part in code generation."""
        return [parameter for parameter in self.parameters if parameter.enable]

    @property
    def disabled(self) -> List[Parameter]:
        return [parameter for parameter in self.parameters if not parameter.enable]

    def find(self, dotted_name: str) -> Optional[Parameter]:
        """Look a node up by its dotted path, e.g. ``Position.Home.Lat``."""
        nodes = self.parameters
        found: Optional[Parameter] = None
        for part in dotted_name.split(PATH_SEPARATOR):
            found = next((node for node in nodes if node.name == part), None)
            if found is None:
                return None
            nodes = found.children
        return found

    def assign_paths(self) -> None:
        """Write the dotted path of every node into its ``source.parameter``.

        Diagnostics then always tell the user *which* parameter they are about,
        and the GUI can jump straight to it.
        """
        for parameter in self.parameters:
            _stamp(parameter, [])

    # -- flattening --------------------------------------------------------
    def flatten(self) -> List[Parameter]:
        """Every enabled *leaf*, with a dotted name and a C access expression.

        A struct contributes no entry of its own; only its fields do.  Every
        leaf of a top level entry gets **that entry's** tags and group - a
        structure is classified as one thing, and its fields inherit the
        classification without being able to contradict it.

        The one tag that cannot simply be copied is ``LogId``, because a log id
        identifies a single value.  A structure's log id is therefore the
        *first* id of a block, and the leaves take consecutive ids out of it,
        each one reserving ``sizeof(value) * array size`` (see
        :func:`_distribute_log_ids`).
        """
        self.assign_paths()
        leaves: List[Parameter] = []
        for parameter in self.enabled:
            first = len(leaves)
            _collect(parameter, [], parameter.name, dict(parameter.tags),
                     parameter.group, leaves)
            _distribute_log_ids(leaves[first:], parameter)
        return leaves

    def struct_parameters(self) -> List[Tuple[str, Parameter]]:
        """Every enabled struct as ``(dotted path, node)``, deepest first.

        Deepest first is the order the C typedefs have to be emitted in: an
        inner structure must be declared before the structure that uses it.
        """
        found: List[Tuple[str, Parameter]] = []
        for parameter in self.enabled:
            _collect_structs(parameter, [], found)
        return found

    # -- views used by the code generator ---------------------------------
    def used_data_type_suffixes(self) -> List[str]:
        suffixes: List[str] = []
        for leaf in self.flatten():
            data_type = leaf.data_type
            if data_type is not None and data_type.suffix not in suffixes:
                suffixes.append(data_type.suffix)
        return suffixes

    def has_array_parameters(self) -> bool:
        return any(leaf.is_array for leaf in self.flatten())

    def by_name(self) -> Dict[str, Parameter]:
        return {parameter.name: parameter for parameter in self.parameters}


def _collect(node: Parameter, path: List[str], root_name: str,
             tags: Dict[str, TagValue], group: Optional[str],
             leaves: List[Parameter]) -> None:
    """Walk one node and append its leaves to *leaves*.

    *tags* and *group* come from the top level entry and are handed down
    unchanged - a field never overrides them.
    """
    if not node.enable:
        return

    path = path + [node.name]

    if node.kind is ParameterKind.STRUCT:
        for child in node.children:
            _collect(child, path, root_name, tags, group, leaves)
        return

    dotted = PATH_SEPARATOR.join(path)
    member = PATH_SEPARATOR.join(path[1:])
    c_object = root_name if not member else f"{root_name}.{member}"

    leaf = node.copy_as_leaf(dotted, c_object, tags)
    leaf.group = group
    leaves.append(leaf)


def _distribute_log_ids(block: List[Parameter], root: Parameter) -> None:
    """Give every leaf of one top level entry its own log id.

    The entry's ``LogId`` is the first id of the block; each leaf then takes as
    many consecutive ids as it has bytes, in tree order::

        Position          LogId = 400
          Home.Lat        float64_t     -> 400 .. 407
          Home.Lon        float64_t     -> 408 .. 415
          Alt             float32_t     -> 416 .. 419
          Samples         int16_t[8]    -> 420 .. 435

    For a plain value the block holds a single leaf, so it simply keeps the id
    that was entered - exactly as before structures existed.
    """
    first = root.tags.get(LOG_ID_TAG)
    if not isinstance(first, int) or isinstance(first, bool):
        return

    cursor = first
    for leaf in block:
        leaf.tags[LOG_ID_TAG] = cursor
        cursor += max(1, leaf.reserved_size)


def _stamp(node: Parameter, path: List[str]) -> None:
    path = path + [node.name]
    node.source = replace(node.source, parameter=PATH_SEPARATOR.join(path))
    for child in node.children:
        _stamp(child, path)


def _collect_structs(node: Parameter, path: List[str],
                     found: List[Tuple[str, Parameter]]) -> None:
    """Append struct nodes as ``(dotted path, node)``, children before parent."""
    if not node.enable or node.kind is not ParameterKind.STRUCT:
        return
    path = path + [node.name]
    for child in node.children:
        _collect_structs(child, path, found)
    found.append((PATH_SEPARATOR.join(path), node))

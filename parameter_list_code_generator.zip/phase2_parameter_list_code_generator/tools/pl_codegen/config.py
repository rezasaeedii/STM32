"""Loading and validating ``codegen_config.json``.

The configuration file is the only place where the user lists the Excel files of
the different sub-modules of the project.  All paths inside it are resolved
relative to the configuration file itself, so the tool can be run from anywhere.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .errors import CodeGeneratorError

_TRAILING_COMMA = re.compile(r",(\s*[}\]])")
_LINE_COMMENT = re.compile(r"^\s*//.*$", re.MULTILINE)


def load_jsonc(path: Path) -> Dict[str, Any]:
    """Load a JSON file that may contain ``//`` comments and trailing commas.

    The company's ``c.json`` snippet file uses the VS Code JSON-with-comments
    dialect, and it is convenient to allow the same in our own config file.
    """
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        raise CodeGeneratorError(f"Cannot read '{path}': {exc}") from exc

    text = _LINE_COMMENT.sub("", text)
    text = _TRAILING_COMMA.sub(r"\1", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise CodeGeneratorError(f"'{path}' is not valid JSON: {exc}") from exc


@dataclass
class InputConfig:
    """Where the parameter list comes from.

    A project is usually split over several sub-modules, each owned by a
    different team, and each keeping its own parameter list next to its own
    code.  Both input paths support that the same way: list the files here and
    the generator merges them into one list, exactly as if they were one file.
    """

    #: the XML models, in order.  The first one is the one the editor opens by
    #: default; every one of them is a sub-module of the project.
    model_files: List[Path] = field(default_factory=lambda: [Path("../parameter_list.xml")])
    #: the Excel workbooks, in order - the phase 1 input, still fully supported
    excel_files: List[Path] = field(default_factory=list)
    #: "xml" (the editor owns the list) or "excel" (the workbooks own it)
    source: str = "xml"
    parameter_sheet: str = "ParameterList"
    defines_sheet: str = "Defines"

    @property
    def model_file(self) -> Path:
        """The first model file - what a single-module project has."""
        return self.model_files[0]

    @property
    def from_excel(self) -> bool:
        return self.source == "excel"


@dataclass
class OutputConfig:
    code_directory: Path = Path("../cg_parameter_list")
    #: where the XML goes when the input is Excel.  It is an intermediate file
    #: there, so it is written next to the generated code and never over the
    #: model the editor owns.
    xml_file: Path = Path("../cg_output/parameter_list.xml")
    file_prefix: str = "cg_"
    base_name: str = "parameter_list"


@dataclass
class StyleConfig:
    snippet_file: Optional[Path] = None
    company: str = "FAS"
    indent: str = "    "


@dataclass
class CodegenConfig:
    emit_description: bool = True
    emit_unit: bool = True
    emit_generation_info: bool = True
    emit_timestamp: bool = True
    index_define_prefix: str = ""
    offset_define_prefix: str = "PARAMETER_LIST_"
    smart_data_prefix: str = "Cg_SmartData_"
    struct_type_prefix: str = "sCgStruct_"
    descriptor_symbol: str = "ParameterList"
    quantity_define: str = "PARAMETER_LIST_QTY"


@dataclass
class ValidationConfig:
    treat_warnings_as_errors: bool = False
    require_description: bool = False
    require_unit: bool = False


@dataclass
class Config:
    """Fully resolved configuration."""

    path: Path
    inputs: InputConfig = field(default_factory=InputConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    style: StyleConfig = field(default_factory=StyleConfig)
    codegen: CodegenConfig = field(default_factory=CodegenConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)

    # -- loading ---------------------------------------------------------
    @classmethod
    def load(cls, config_path: Path) -> "Config":
        config_path = config_path.expanduser().resolve()
        if not config_path.is_file():
            raise CodeGeneratorError(f"Configuration file '{config_path}' does not exist.")

        data = load_jsonc(config_path)
        root = config_path.parent

        def resolve(value: str) -> Path:
            candidate = Path(str(value)).expanduser()
            return candidate if candidate.is_absolute() else (root / candidate).resolve()

        raw_inputs = data.get("inputs", {})
        excel_entries = raw_inputs.get("excel_files", []) or []

        # 'model_files' is the list; 'model_file' is the one-file spelling of
        # the same thing, kept so a single-module config stays short.
        model_entries = raw_inputs.get("model_files") or []
        if not model_entries:
            model_entries = [raw_inputs.get("model_file", "../parameter_list.xml")]

        source = str(raw_inputs.get("source", "xml")).strip().lower()
        if source not in {"xml", "excel"}:
            raise CodeGeneratorError(
                f"inputs.source is '{source}'; it must be 'xml' or 'excel'.")

        inputs = InputConfig(
            model_files=[resolve(entry) for entry in model_entries],
            excel_files=[resolve(entry) for entry in excel_entries],
            source=source,
            parameter_sheet=str(raw_inputs.get("parameter_sheet", "ParameterList")),
            defines_sheet=str(raw_inputs.get("defines_sheet", "Defines")),
        )

        raw_output = data.get("output", {})
        output = OutputConfig(
            code_directory=resolve(raw_output.get("code_directory", "../cg_parameter_list")),
            xml_file=resolve(raw_output.get("xml_file", "../cg_output/parameter_list.xml")),
            file_prefix=str(raw_output.get("file_prefix", "cg_")),
            base_name=str(raw_output.get("base_name", "") or inputs.model_file.stem),
        )

        raw_style = data.get("style", {})
        snippet = raw_style.get("snippet_file")
        style = StyleConfig(
            snippet_file=resolve(snippet) if snippet else None,
            company=str(raw_style.get("company", "FAS")),
            indent=str(raw_style.get("indent", "    ")),
        )

        codegen = _dataclass_from_dict(CodegenConfig, data.get("codegen", {}))
        validation = _dataclass_from_dict(ValidationConfig, data.get("validation", {}))

        config = cls(path=config_path, inputs=inputs, output=output, style=style,
                     codegen=codegen, validation=validation)
        config.validate()
        return config

    # -- checks ----------------------------------------------------------
    def validate(self) -> None:
        missing = [str(path) for path in self.inputs.excel_files if not path.is_file()]
        if missing:
            raise CodeGeneratorError(
                "The following Excel files listed in the configuration do not exist:\n  - "
                + "\n  - ".join(missing))
        if self.inputs.from_excel and not self.inputs.excel_files:
            raise CodeGeneratorError(
                "inputs.source is 'excel' but 'inputs.excel_files' is empty.")
        if self.style.snippet_file is not None and not self.style.snippet_file.is_file():
            raise CodeGeneratorError(
                f"Style snippet file '{self.style.snippet_file}' does not exist.")

    # -- helpers ---------------------------------------------------------
    def generated_file_name(self, suffix: str, extension: str) -> str:
        """``suffix='defines', extension='h'`` -> ``cg_parameter_list_defines.h``."""
        stem = f"{self.output.file_prefix}{self.output.base_name}"
        if suffix:
            stem = f"{stem}_{suffix}"
        return f"{stem}.{extension}"

    def smart_data_file_name(self, extension: str) -> str:
        return f"{self.output.file_prefix}smart_data.{extension}"


def _dataclass_from_dict(cls: type, data: Dict[str, Any]) -> Any:
    """Build a dataclass from a dict, ignoring unknown keys."""
    known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
    return cls(**{key: value for key, value in data.items() if key in known})

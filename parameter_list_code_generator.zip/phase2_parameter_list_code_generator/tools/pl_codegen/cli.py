"""Command line interface of the parameter-list code generator.

The GUI (``python gui.py``) is the normal way to edit the parameter list; this
command line tool is what a build script or a CI job calls.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional, Sequence

import argparse

from . import __tool_name__, __version__
from .config import Config
from .errors import CodeGeneratorError, Severity
from .logging_utils import banner, setup_logging
from .pipeline import Pipeline, render_diagnostics
from .validation.rules import ALL_RULES

DEFAULT_CONFIG = "codegen_config.json"

EXIT_OK = 0
EXIT_VALIDATION_FAILED = 1
EXIT_TOOL_ERROR = 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="generate.py",
        description="Generates the parameter-list C code from the XML model.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python generate.py                     # generate from the configured input\n"
            "  python generate.py --from-excel        # Excel -> XML -> C, in one run\n"
            "  python generate.py --from-xml          # force the XML model as the input\n"
            "  python generate.py -m other.xml        # generate from another model file\n"
            "  python generate.py --check             # validate only, write nothing\n"
            "  python generate.py --import-excel      # Excel -> XML, and stop there\n"))

    parser.add_argument("-c", "--config", type=Path, default=Path(DEFAULT_CONFIG),
                        help=f"configuration file (default: {DEFAULT_CONFIG})")
    parser.add_argument("-m", "--model", type=Path, metavar="FILE",
                        help="XML model file to use instead of the configured one(s)")
    parser.add_argument("--from-excel", action="store_true",
                        help="read the Excel files, write the XML model, generate the code")
    parser.add_argument("--from-xml", action="store_true",
                        help="read the XML model even when the config says 'excel'")
    parser.add_argument("--check", action="store_true",
                        help="validate the input only; write no file at all")
    parser.add_argument("--import-excel", action="store_true",
                        help="build the XML model out of 'inputs.excel_files' and stop")
    parser.add_argument("--force", action="store_true",
                        help="let --import-excel replace an existing model file")
    parser.add_argument("--list-rules", action="store_true",
                        help="print every validation rule and exit")
    parser.add_argument("-W", "--warnings-as-errors", action="store_true",
                        help="treat warnings as errors")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="also show informational diagnostics")
    parser.add_argument("-q", "--quiet", action="store_true", help="only show problems")
    parser.add_argument("--version", action="version",
                        version=f"{__tool_name__} {__version__}")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    arguments = build_parser().parse_args(argv)
    logger = setup_logging(verbose=arguments.verbose, quiet=arguments.quiet)

    if arguments.list_rules:
        print("Validation rules:")
        for rule_class in ALL_RULES:
            print(f"  {rule_class.rule_id:<16} {rule_class.description}")
        return EXIT_OK

    try:
        config = Config.load(arguments.config)
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if arguments.warnings_as_errors:
        config.validation.treat_warnings_as_errors = True

    if arguments.from_excel and arguments.from_xml:
        logger.error("--from-excel and --from-xml cannot be used together.")
        return EXIT_TOOL_ERROR

    from_excel: Optional[bool] = None
    if arguments.from_excel:
        from_excel = True
    elif arguments.from_xml or arguments.model:
        from_excel = False

    logger.info("%s v%s", __tool_name__, __version__)
    logger.info("configuration: %s", config.path)
    logger.info("input: %s", _describe_input(config, from_excel))

    try:
        pipeline = Pipeline(config)
        if arguments.import_excel:
            result = pipeline.import_excel(arguments.model, arguments.force)
        elif arguments.check:
            result = pipeline.check(from_excel)
        else:
            result = pipeline.run(arguments.model, from_excel)
    except CodeGeneratorError as error:
        logger.error("%s", error)
        return EXIT_TOOL_ERROR

    if not arguments.quiet or not result.success:
        _print_summary(result, arguments.verbose)
    return EXIT_OK if result.success else EXIT_VALIDATION_FAILED


def _describe_input(config, from_excel: Optional[bool]) -> str:
    """One line saying exactly which files the run will read."""
    use_excel = config.inputs.from_excel if from_excel is None else from_excel
    files = config.inputs.excel_files if use_excel else config.inputs.model_files
    kind = "Excel" if use_excel else "XML model"
    if not files:
        return f"{kind} (no file configured)"
    if len(files) == 1:
        return f"{kind} {files[0]}"
    listing = "".join(f"\n         - {path}" for path in files)
    return f"{kind}, {len(files)} module(s) merged:{listing}"


def _print_summary(result, verbose: bool) -> None:
    diagnostics = result.diagnostics
    print(banner("Diagnostics"))
    print(render_diagnostics(diagnostics, verbose))
    print()
    print(diagnostics.summary())

    if result.success:
        if result.generated_files:
            print(f"\nGenerated {len(result.generated_files)} file(s) for "
                  f"{result.parameter_count} value(s):")
            for path in result.generated_files:
                print(f"  {path}")
        elif result.model_file is not None:
            print(f"\nModel: {result.model_file}  ({result.parameter_count} value(s))")
        print("\nDone.")
    else:
        print("\nCode generation was aborted because the model contains errors.")
        if diagnostics.count(Severity.ERROR) == 0:
            print("(warnings are treated as errors)")


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())

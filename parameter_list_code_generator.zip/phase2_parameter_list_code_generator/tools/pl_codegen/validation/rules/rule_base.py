"""Base class shared by every validation rule.

A rule is a small, self-contained class with one job.  Adding a new check means
adding one file in this folder and listing the class in ``rules/__init__.py``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from typing import List

from ...config import Config
from ...errors import DiagnosticCollector
from ...model.parameter import Parameter, ParameterKind
from ...model.parameter_list import PATH_SEPARATOR, ParameterList


class ValidationRule(ABC):
    """One check performed on the whole parameter list."""

    #: short, stable identifier used as a diagnostic code prefix
    rule_id: str = "RULE"
    #: one-line description shown by ``generate.py --list-rules``
    description: str = ""

    def __init__(self, config: Config) -> None:
        self.config = config

    @abstractmethod
    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        """Inspect *model* and append findings to *diagnostics*."""

    def __str__(self) -> str:  # pragma: no cover - debugging helper
        return f"{self.rule_id}: {self.description}"


def enabled_nodes(model: ParameterList) -> List[Parameter]:
    """Every enabled node of the tree, structs included."""
    found: List[Parameter] = []
    for parameter in model.parameters:
        _walk_enabled(parameter, found)
    return found


def enabled_leaves(model: ParameterList) -> List[Parameter]:
    """Every enabled primitive node (structs excluded)."""
    return [node for node in enabled_nodes(model) if node.is_primitive]


def enabled_structs(model: ParameterList) -> List[Parameter]:
    """Every enabled struct node."""
    return [node for node in enabled_nodes(model) if node.is_struct]


def dotted_names(model: ParameterList) -> List[str]:
    """The dotted path of every enabled node, in tree order."""
    found: List[str] = []
    for parameter in model.parameters:
        _walk_paths(parameter, [], found)
    return found


def _walk_enabled(node: Parameter, found: List[Parameter]) -> None:
    if not node.enable:
        return
    found.append(node)
    for child in node.children:
        _walk_enabled(child, found)


def _walk_paths(node: Parameter, path: List[str], found: List[str]) -> None:
    if not node.enable:
        return
    path = path + [node.name]
    found.append(PATH_SEPARATOR.join(path))
    for child in node.children:
        _walk_paths(child, path, found)

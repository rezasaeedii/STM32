"""Rules about default value, minimum, maximum and resolution."""

from __future__ import annotations

from ...errors import DiagnosticCollector
from ...model.parameter_list import ParameterList
from .rule_base import ValidationRule, enabled_leaves


class NativeRangeRule(ValidationRule):
    """Values must fit into the C type of the parameter."""

    rule_id = "RANGE_NATIVE"
    description = "Default/minimum/maximum must fit into the declared C type."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            data_type = parameter.data_type
            if data_type is None or data_type.is_bool:
                continue
            for label, value in (("DefaultValue", parameter.default_value),
                                 ("Minimum", parameter.minimum),
                                 ("Maximum", parameter.maximum),
                                 ("Resolution", parameter.resolution)):
                if value is None:
                    continue
                low, high = data_type.native_min, data_type.native_max
                if low is None or high is None:
                    continue
                if float(value) < float(low) or float(value) > float(high):
                    diagnostics.error(
                        "RNG001",
                        f"'{label}' = {value} does not fit into '{data_type.c_name}' "
                        f"(allowed: {low} .. {high}).", parameter.source)


class MinMaxOrderRule(ValidationRule):
    """The minimum must not be greater than the maximum."""

    rule_id = "RANGE_ORDER"
    description = "Minimum must be smaller than or equal to maximum."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            data_type = parameter.data_type
            if data_type is None or not data_type.has_range:
                continue
            if parameter.minimum is None or parameter.maximum is None:
                continue
            if float(parameter.minimum) > float(parameter.maximum):
                diagnostics.error(
                    "RNG002",
                    f"Minimum ({parameter.minimum}) is greater than maximum "
                    f"({parameter.maximum}).", parameter.source)


class DefaultInRangeRule(ValidationRule):
    """The default value must be inside the allowed range.

    A minimum *and* a maximum of zero disables the range check, as required by
    the module specification.
    """

    rule_id = "RANGE_DEFAULT"
    description = "The default value must lie inside [minimum, maximum]."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            data_type = parameter.data_type
            if data_type is None or not data_type.has_range:
                continue
            if parameter.default_value is None or parameter.range_disabled:
                continue
            if parameter.minimum is None or parameter.maximum is None:
                continue
            value = float(parameter.default_value)
            if value < float(parameter.minimum) or value > float(parameter.maximum):
                diagnostics.error(
                    "RNG003",
                    f"Default value {parameter.default_value} is outside the allowed range "
                    f"[{parameter.minimum}, {parameter.maximum}]. "
                    f"The smart-data constructor would fail at run time.",
                    parameter.source)


class RequiredValuesRule(ValidationRule):
    """Non-boolean parameters need a default value and a resolution."""

    rule_id = "RANGE_REQUIRED"
    description = "Default value and resolution must be present for non-boolean parameters."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_leaves(model):
            data_type = parameter.data_type
            if data_type is None:
                continue
            if data_type.is_bool:
                for label, value in (("Minimum", parameter.minimum),
                                     ("Maximum", parameter.maximum),
                                     ("Resolution", parameter.resolution)):
                    if value is not None:
                        diagnostics.warning(
                            "RNG010",
                            f"'{label}' is ignored for the boolean type '{data_type.c_name}'.",
                            parameter.source)
                continue

            if parameter.default_value is None:
                diagnostics.warning(
                    "RNG011", "No default value; 0 is used instead.", parameter.source)
            if parameter.minimum is None:
                diagnostics.warning(
                    "RNG012", "No minimum; 0 is used instead (range check disabled).",
                    parameter.source)
            if parameter.maximum is None:
                diagnostics.warning(
                    "RNG013", "No maximum; 0 is used instead (range check disabled).",
                    parameter.source)
            if parameter.resolution is None:
                diagnostics.warning(
                    "RNG014", "No resolution; 1 is used instead.", parameter.source)
            elif float(parameter.resolution) <= 0.0:
                diagnostics.warning(
                    "RNG015",
                    f"Resolution {parameter.resolution} is not positive.", parameter.source)


class MetadataRule(ValidationRule):
    """Optional documentation columns."""

    rule_id = "META"
    description = "Description and unit completeness (configurable)."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        require_description = self.config.validation.require_description
        require_unit = self.config.validation.require_unit
        for parameter in enabled_leaves(model):
            if not parameter.description:
                if require_description:
                    diagnostics.error("META001", "No description is set.",
                                      parameter.source)
                else:
                    diagnostics.info("META001", "No description is set.",
                                     parameter.source)
            if require_unit and not parameter.unit:
                data_type = parameter.data_type
                if data_type is not None and not data_type.is_bool:
                    diagnostics.error("META002", "No unit is set.", parameter.source)

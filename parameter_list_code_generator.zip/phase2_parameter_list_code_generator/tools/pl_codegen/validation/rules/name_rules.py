"""Rules about parameter names and the C identifiers derived from them."""

from __future__ import annotations

from typing import Dict, List

from ...errors import DiagnosticCollector
from ...model.parameter import Parameter
from ...model.parameter_list import ParameterList
from ...naming import index_macro, is_reserved_keyword, is_valid_c_identifier
from .rule_base import ValidationRule, enabled_nodes


class NameSyntaxRule(ValidationRule):
    """Every name must be usable as a C identifier."""

    rule_id = "NAME"
    description = "Parameter and field names must be valid, non-reserved C identifiers."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in _all_nodes(model):
            if not is_valid_c_identifier(parameter.name):
                diagnostics.error(
                    "NAME001",
                    f"Name '{parameter.name}' is not a valid C identifier.",
                    parameter.source,
                    hint="Use letters, digits and '_' only, and do not start with a digit.")
            elif is_reserved_keyword(parameter.name):
                diagnostics.error(
                    "NAME002",
                    f"Name '{parameter.name}' is a reserved C/C++ keyword.",
                    parameter.source)


class NameUniquenessRule(ValidationRule):
    """Names must be unique among the siblings that share a parent."""

    rule_id = "NAME_UNIQUE"
    description = "Names must be unique inside their parent (and at the top level)."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        self._check_level(model.parameters, "the parameter list", diagnostics)
        for parameter in _all_nodes(model):
            if parameter.is_struct:
                self._check_level(parameter.children, f"struct '{parameter.name}'",
                                  diagnostics)

    @staticmethod
    def _check_level(nodes: List[Parameter], where: str,
                     diagnostics: DiagnosticCollector) -> None:
        seen: Dict[str, List[Parameter]] = {}
        for node in nodes:
            seen.setdefault(node.name, []).append(node)
        for name, duplicates in seen.items():
            if len(duplicates) < 2:
                continue
            for node in duplicates:
                diagnostics.error(
                    "NAME003",
                    f"Name '{name}' is used {len(duplicates)} times in {where}.",
                    node.source)


class IndexMacroCollisionRule(ValidationRule):
    """The generated index macros must stay unique after case conversion."""

    rule_id = "NAME_MACRO"
    description = "Generated index macros (UPPER_SNAKE_CASE) must not collide."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        prefix = self.config.codegen.index_define_prefix
        macros: Dict[str, List[Parameter]] = {}
        for leaf in model.flatten():
            macros.setdefault(index_macro(leaf.name, prefix), []).append(leaf)

        for macro, owners in macros.items():
            if len(owners) < 2:
                continue
            names = ", ".join(item.name for item in owners)
            for leaf in owners:
                diagnostics.error(
                    "NAME004",
                    f"Parameters {names} all map onto the same index macro '{macro}'.",
                    leaf.source,
                    hint="Rename one of them, or set 'codegen.index_define_prefix' "
                         "in the configuration.")


class StructRule(ValidationRule):
    """Structures must have fields, and may not be arrays in this phase."""

    rule_id = "STRUCT"
    description = "Structures must contain at least one field and cannot be arrays."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in enabled_nodes(model):
            if not parameter.is_struct:
                continue

            if not parameter.enabled_children():
                diagnostics.error(
                    "STR001",
                    f"Structure '{parameter.name}' has no enabled field.",
                    parameter.source,
                    hint="Add a field, or disable the whole structure.")

            if parameter.array_size > 1:
                diagnostics.error(
                    "STR002",
                    f"Structure '{parameter.name}' has array size "
                    f"{parameter.array_size}; arrays of structures are not supported.",
                    parameter.source,
                    hint="Set the array size to 1. A field inside the structure may "
                         "still be an array.")

            if parameter.data_type_name:
                diagnostics.warning(
                    "STR003",
                    f"Structure '{parameter.name}' has a data type "
                    f"('{parameter.data_type_name}'); it is ignored.",
                    parameter.source)


class StructFieldRule(ValidationRule):
    """A field takes its tags and its group from the structure it lives in."""

    rule_id = "STRUCT_FIELD"
    description = "Fields of a structure must not carry tags or a group of their own."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for root in model.enabled:
            if not root.is_struct:
                continue
            for field in _fields_of(root):
                own_tags = sorted(key for key, value in field.tags.items()
                                  if value is not None)
                if own_tags:
                    diagnostics.error(
                        "STR004",
                        f"Field '{field.source.parameter or field.name}' sets the tag(s) "
                        f"{', '.join(own_tags)}; tags belong to the structure.",
                        field.source,
                        hint=f"Set them on '{root.name}' instead - every field of a "
                             f"structure shares its classification.")
                if field.group:
                    diagnostics.error(
                        "STR005",
                        f"Field '{field.source.parameter or field.name}' sets the group "
                        f"'{field.group}'; the group belongs to the structure.",
                        field.source,
                        hint=f"Set the group on '{root.name}' instead.")


def _fields_of(root: Parameter) -> List[Parameter]:
    """Every node below *root*, structures and values alike."""
    return [node for node in root.walk() if node is not root]


def _all_nodes(model: ParameterList) -> List[Parameter]:
    """Every node of the tree, disabled ones included (names still matter)."""
    return list(model.walk())

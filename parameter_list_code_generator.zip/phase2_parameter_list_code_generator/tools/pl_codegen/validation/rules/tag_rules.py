"""Rules about tags.

Tags themselves are interpreted by the application layer, not by the code
generator.  The generator only checks that the *values written in the Excel
sheet* are consistent, so that the generated C file always compiles.
"""

from __future__ import annotations

from typing import List, Tuple

from ...errors import DiagnosticCollector
from ...model.parameter_list import ParameterList
from ...model.tags import LOG_ID_TAG, LOGGABLE_TAG, TAG_REGISTRY, TAGS_BY_ID, TagKind
from ...layout.tag_offset import reserved_size
from ...naming import is_valid_c_identifier
from .rule_base import ValidationRule

#: Maximum value that fits into ``sParameterListDescriptorTag.Value`` (uint32_t).
TAG_VALUE_MAX = 0xFFFFFFFF


class MandatoryTagRule(ValidationRule):
    """Mandatory tags must carry a value for every enabled parameter."""

    rule_id = "TAG_MANDATORY"
    description = "Mandatory tags must be filled in for every enabled parameter."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in model.flatten():
            for spec in TAG_REGISTRY:
                if not spec.mandatory:
                    continue
                if parameter.tags.get(spec.tag_id) is None:
                    diagnostics.error(
                        "TAG001",
                        f"Mandatory tag '{spec.tag_id}' (column '{spec.excel_column}') is empty.",
                        parameter.source, hint=spec.description)


class TagEnumValueRule(ValidationRule):
    """Enum tags must use a value declared in the *Defines* sheet."""

    rule_id = "TAG_ENUM"
    description = "Enum tag values must be declared in the Defines sheet."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for spec in TAG_REGISTRY:
            if spec.kind is not TagKind.ENUM or not spec.defines_column:
                continue
            allowed = model.defines.get(spec.defines_column)
            for parameter in model.flatten():
                value = parameter.tags.get(spec.tag_id)
                if value is None:
                    continue
                text = str(value)
                if not is_valid_c_identifier(text):
                    diagnostics.error(
                        "TAG002",
                        f"Tag '{spec.tag_id}' value '{text}' is not a valid C identifier.",
                        parameter.source)
                elif allowed and text not in allowed:
                    diagnostics.error(
                        "TAG003",
                        f"Tag '{spec.tag_id}' value '{text}' is not listed in the "
                        f"'{spec.defines_column}' column of the Defines sheet.",
                        parameter.source,
                        hint=f"Allowed values: {', '.join(allowed)}.")


class TagValueRangeRule(ValidationRule):
    """Numeric tag values must fit into ``uint32_t``."""

    rule_id = "TAG_RANGE"
    description = "Numeric tag values must fit into the uint32_t descriptor field."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for parameter in model.flatten():
            for tag_id, value in parameter.tags.items():
                if not isinstance(value, int) or isinstance(value, bool):
                    continue
                if value < 0 or value > TAG_VALUE_MAX:
                    spec = TAGS_BY_ID.get(tag_id)
                    column = spec.excel_column if spec else tag_id
                    diagnostics.error(
                        "TAG004",
                        f"Tag '{tag_id}' (column '{column}') value {value} does not fit into "
                        f"uint32_t (0 .. {TAG_VALUE_MAX}).", parameter.source)


class FreeTagSyntaxRule(ValidationRule):
    """Free tags must be either a number or a C identifier."""

    rule_id = "TAG_FREE"
    description = "Free tags (Tag1..Tag4) must hold a number or a C identifier."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        for spec in TAG_REGISTRY:
            if spec.kind is not TagKind.FREE:
                continue
            for parameter in model.flatten():
                value = parameter.tags.get(spec.tag_id)
                if value is None or isinstance(value, (int, bool)):
                    continue
                if not is_valid_c_identifier(str(value)):
                    diagnostics.error(
                        "TAG005",
                        f"Tag '{spec.tag_id}' value '{value}' is neither a number nor a valid "
                        f"C identifier.", parameter.source)


class LogIdRule(ValidationRule):
    """Loggable parameters need a log id, and log id ranges must not overlap.

    A log id is not a single number: a parameter reserves as many consecutive
    ids as it occupies bytes, i.e. ``sizeof(value) * array size``.  A
    ``float64_t`` with array size 2 written as log id 400 therefore reserves
    400 .. 415, and the next parameter may not start before 416.
    """

    rule_id = "TAG_LOG_ID"
    description = "A loggable parameter needs a log id whose reserved range is free."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        claimed: List[Tuple[int, int, object]] = []   # (first, last, parameter)

        for parameter in model.flatten():
            loggable = parameter.has_active_tag(LOGGABLE_TAG)
            log_id = parameter.tags.get(LOG_ID_TAG)

            if loggable and log_id is None:
                diagnostics.error(
                    "TAG010", "The parameter is loggable but has no 'LogID'.",
                    parameter.source,
                    hint="A loggable parameter needs a log id so that the log file can be "
                         "decoded.")
            if loggable and not parameter.gs_name:
                diagnostics.warning(
                    "TAG011", "The parameter is loggable but has no 'GS Name'.",
                    parameter.source)

            if not isinstance(log_id, int) or isinstance(log_id, bool):
                continue

            span = reserved_size(parameter)
            if span <= 0:
                continue
            first, last = log_id, log_id + span - 1

            for other_first, other_last, other in claimed:
                if first > other_last or last < other_first:
                    continue
                if first == other_first and last == other_last:
                    diagnostics.error(
                        "TAG012",
                        f"Log id {log_id} is already used by '{other.name}'.",
                        parameter.source,
                        hint=f"'{other.name}' is defined at {other.source}.")
                else:
                    diagnostics.error(
                        "TAG013",
                        f"Log id range {first}..{last} of '{parameter.name}' overlaps the "
                        f"range {other_first}..{other_last} reserved by '{other.name}'.",
                        parameter.source,
                        hint=f"'{other.name}' ({other.data_type_name} x{other.array_size}) "
                             f"reserves {other_last - other_first + 1} id(s) starting at "
                             f"{other_first}; the first free id after it is {other_last + 1}.")
                break
            else:
                claimed.append((first, last, parameter))

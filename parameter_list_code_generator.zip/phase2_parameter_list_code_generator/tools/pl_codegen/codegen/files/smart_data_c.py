"""Builds ``cg_smart_data.c``.

Read ``generate()`` from top to bottom: it is the generated file, in order.
"""

from __future__ import annotations

from ..literals import constructor_arguments
from .file_builder import FileBuilder
from .smart_data_h import INIT_BRIEF, INIT_DOC_RETURN, INIT_FUNCTION, INIT_RETURN

BRIEF = "Definition and construction of the generated smart-data objects."

LOOP_INDEX = "index"
STATUS = "status"


class SmartDataSource(FileBuilder):
    """Defines every smart-data object and constructs it in ``fCgSmartData_Init``."""

    @property
    def file_name(self) -> str:
        return self.smart_data_source

    def generate(self) -> str:
        text = ""

        # ---- banner ------------------------------------------------------
        text += self.banner.generate(self.file_name, BRIEF, self.generation_notes())
        text += "\n"

        # ---- includes ----------------------------------------------------
        text += self.marker.generate("Includes")
        text += self.include.generate(self.smart_data_header)
        text += self.include.generate("smart_data.h")
        text += "\n"

        text += self.marker.generate("Private defines")
        text += self.marker.generate("Private macros")
        text += self.marker.generate("Private types")
        text += self.marker.generate("Private variables")
        text += self.marker.generate("Private functions")

        # ---- one object per top level parameter ---------------------------
        text += self.marker.generate("Exported variables")
        for c_type, name, array_size, _comment in self.top_level_objects():
            text += self.variable.generate_definition(
                c_type=c_type, name=name, array_size=array_size)
        text += "\n"

        # ---- the init function --------------------------------------------
        text += self.comment.generate_separator("Exported Functions")
        text += "\n"
        text += self.comment.generate_doc(INIT_BRIEF, returns=INIT_DOC_RETURN)
        text += self.function.generate_begin(INIT_RETURN, INIT_FUNCTION)
        text += self.function.generate_body(self._init_body())
        text += self.function.generate_end()
        text += "\n"

        text += self.comment.generate_separator("Private Functions")
        text += "\n"
        text += self.footer.generate()
        return text

    # -- the body of fCgSmartData_Init ------------------------------------
    def _init_body(self) -> str:
        tab = self.tab
        body = f"eSmartDataStatus {STATUS} = eSMART_DATA_OK;\n"
        if self.model.has_array_parameters():
            body += f"uint16_t {LOOP_INDEX} = 0U;\n"
        body += "\n"

        for parameter in self.parameters:
            data_type = parameter.data_type
            if data_type is None:
                continue

            symbol = self.smart_data_of(parameter)
            arguments = constructor_arguments(parameter, data_type)

            if parameter.is_array:
                size = self.array_size_of(parameter)
                body += f"for ({LOOP_INDEX} = 0U; {LOOP_INDEX} < {size}; {LOOP_INDEX}++) {{\n"
                body += f"{tab}{STATUS} = {data_type.constructor}"
                body += f"(&{symbol}[{LOOP_INDEX}], {arguments});\n"
                body += f"{tab}if ({STATUS} != eSMART_DATA_OK) {{\n"
                body += f"{tab}{tab}return ({INIT_RETURN}){STATUS};\n"
                body += f"{tab}}}\n"
                body += "}\n"
            else:
                body += f"{STATUS} = {data_type.constructor}(&{symbol}, {arguments});\n"
                body += f"if ({STATUS} != eSMART_DATA_OK) {{\n"
                body += f"{tab}return ({INIT_RETURN}){STATUS};\n"
                body += "}\n"
            body += "\n"

        body += f"return ({INIT_RETURN}){STATUS};"
        return body

"""Builds ``cg_parameter_list_table.h``.

This file contains no code at all: it draws the parameter list as ASCII tables
inside comment blocks, so a developer can see the whole parameter list next to
the generated code without opening Excel.  Disabled rows are shown too.

Read ``generate()`` from top to bottom: it is the generated file, in order.
"""

from __future__ import annotations

from typing import List, Optional

from ...layout.tag_offset import reserved_size
from ...model.parameter import Parameter
from ...model.tags import TAG_REGISTRY
from .file_builder import FileBuilder

BRIEF = "The Excel parameter list, drawn as a table. Documentation only - no code."


class ParameterListTableHeader(FileBuilder):
    """Draws the parameter sheet and the tag sheet as ASCII tables."""

    @property
    def file_name(self) -> str:
        return self.table_header

    def generate(self) -> str:
        text = ""

        # ---- banner and guards -----------------------------------------
        text += self.banner.generate(self.file_name, BRIEF, self.generation_notes())
        text += "\n"
        text += self.guard.generate_open(self.guard_name)
        text += "\n"
        text += self.cpp.generate_open()
        text += "\n"

        text += self.marker.generate("Includes")

        # ---- table 1: the value of every parameter -----------------------
        text += self.marker.generate("Exported defines")
        text += self.comment.generate_block(
            self.table.generate(self._value_rows()),
            title="Parameter list - values")
        text += "\n"

        # ---- table 2: the tag columns ------------------------------------
        text += self.comment.generate_block(
            self.table.generate(self._tag_rows()),
            title="Parameter list - tags")
        text += "\n"

        # ---- table 3: the MemoryOffset of every parameter, per tag --------
        text += self.comment.generate_block(
            self.table.generate(self._offset_rows()) + self._offset_note(),
            title="MemoryOffset of every parameter, per tag")
        text += "\n"

        text += self.marker.generate("Exported macros")
        text += self.marker.generate("Exported types")
        text += self.marker.generate("Exported functions")
        text += self.marker.generate("Exported variables")
        text += "\n"

        # ---- closing guards and footer ------------------------------------
        text += self.cpp.generate_close()
        text += "\n"
        text += self.guard.generate_close(self.guard_name)
        text += "\n"
        text += self.footer.generate()
        return text

    # -- table 1 : name, type, range ---------------------------------------
    def _value_rows(self) -> List[List[str]]:
        rows = [["#", "En", "Name", "GS Name", "Group", "DataType", "Arr",
                 "Default", "Min", "Max", "Res", "Unit"]]
        index = 0
        for parameter in self.model.parameters:
            if parameter.enable:
                number = str(index)
                index += 1
            else:
                number = "-"
            rows.append([
                number,
                "x" if parameter.enable else " ",
                parameter.name,
                parameter.gs_name or "-",
                (parameter.group or "-").upper(),
                parameter.data_type_name or "-",
                str(parameter.array_size),
                _number(parameter.default_value),
                _number(parameter.minimum),
                _number(parameter.maximum),
                _number(parameter.resolution),
                parameter.unit or "-",
            ])
        return rows

    # -- table 2 : the tags -------------------------------------------------
    def _tag_rows(self) -> List[List[str]]:
        rows = [["#", "Name"] + [spec.tag_id for spec in TAG_REGISTRY] + ["LogID range"]]
        index = 0
        for parameter in self.model.parameters:
            if parameter.enable:
                number = str(index)
                index += 1
            else:
                number = "-"
            row = [number, parameter.name]
            for spec in TAG_REGISTRY:
                row.append(_tag(parameter.tags.get(spec.tag_id)))
            row.append(self._log_id_range(parameter))
            rows.append(row)
        return rows

    def _log_id_range(self, parameter: Parameter) -> str:
        log_id = parameter.tags.get("LogId")
        if not isinstance(log_id, int) or isinstance(log_id, bool):
            return "-"
        span = reserved_size(parameter)
        if span <= 1:
            return str(log_id)
        return f"{log_id}..{log_id + span - 1}"

    # -- table 3 : the offsets ---------------------------------------------
    def _offset_rows(self) -> List[List[str]]:
        tags = [spec for spec in TAG_REGISTRY
                if self.offsets.area(spec.tag_id) and self.offsets.area(spec.tag_id).entries]
        rows = [["#", "Name", "Bytes"] + [spec.tag_id for spec in tags]]

        for index, parameter in enumerate(self.parameters):
            row = [str(index), parameter.name, str(reserved_size(parameter))]
            for spec in tags:
                if self.offsets.has_entry(spec.tag_id, parameter.name):
                    row.append(str(self.offsets.offset(spec.tag_id, parameter.name)))
                else:
                    row.append("-")
            rows.append(row)

        totals = ["", "TOTAL (bytes)", ""]
        totals.extend(str(self.offsets.total(spec.tag_id)) for spec in tags)
        rows.append(totals)
        return rows

    @staticmethod
    def _offset_note() -> List[str]:
        return [
            "",
            "Every tag owns an independent counter that starts at 0 and advances by",
            "sizeof(value) * ArraySize for every parameter that carries the tag.",
            "'-' means the tag is not active for that parameter, so its offset is 0.",
        ]


def _number(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _tag(value: object) -> str:
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "x" if value else " "
    return str(value)

"""Builds ``cg_parameter_list_types.h`` -- the generated structure types.

Every struct parameter becomes one C structure whose members are the smart-data
objects of its fields.  A nested struct becomes a member of its parent's type,
so the C code mirrors the tree the user built in the GUI::

    typedef struct {
        sSmartDataF64 Lat;
        sSmartDataF64 Lon;
    } sCgStruct_Position_Home;

    typedef struct {
        sCgStruct_Position_Home Home;
        sSmartDataF32           Alt;
    } sCgStruct_Position;

Read ``generate()`` from top to bottom: it is the generated file, in order.
"""

from __future__ import annotations

from typing import List, Tuple

from ...model.parameter import Parameter
from ...naming import array_size_macro
from .file_builder import FileBuilder

BRIEF = "Structure types generated from the structures of the parameter list."


class ParameterTypesHeader(FileBuilder):
    """One ``typedef struct`` per struct parameter, inner types first."""

    @property
    def file_name(self) -> str:
        return self.types_header

    def generate(self) -> str:
        text = ""

        # ---- banner and guards -----------------------------------------
        text += self.banner.generate(self.file_name, BRIEF, self.generation_notes())
        text += "\n"
        text += self.guard.generate_open(self.guard_name)
        text += "\n"
        text += self.cpp.generate_open()
        text += "\n"

        # ---- includes ---------------------------------------------------
        text += self.marker.generate("Includes")
        text += self.include.generate("smart_data.h")
        text += self.include.generate(self.defines_header)
        text += "\n"

        text += self.marker.generate("Exported defines")
        text += self.marker.generate("Exported macros")

        # ---- one typedef per structure, deepest first --------------------
        text += self.marker.generate("Exported types")
        structs = self.model.struct_parameters()
        if not structs:
            text += self.comment.generate_line(
                "The parameter list contains no structure.")
            text += "\n"
        else:
            for dotted_name, node in structs:
                text += self._generate_struct(dotted_name, node)
                text += "\n"

        text += self.marker.generate("Exported functions")
        text += self.marker.generate("Exported variables")
        text += "\n"

        # ---- closing guards and footer ------------------------------------
        text += self.cpp.generate_close()
        text += "\n"
        text += self.guard.generate_close(self.guard_name)
        text += "\n"
        text += self.footer.generate()
        return text

    # -- one structure ------------------------------------------------------
    def _generate_struct(self, dotted_name: str, node: Parameter) -> str:
        members = self._members(dotted_name, node)

        text = self.comment.generate_doc(
            f"Structure parameter '{dotted_name}'.",
            notes=[node.description] if node.description else ())
        text += "typedef struct {\n"
        text += "\n"

        type_width = max((len(member[0]) for member in members), default=0)
        for c_type, name, array_size, comment in members:
            line = f"{self.tab}{c_type.ljust(type_width)} {name}"
            if array_size:
                line += f"[{array_size}]"
            line += ";"
            if comment:
                line += f"  /*!< {comment} */"
            text += line + "\n"

        text += "\n"
        text += f"}} {self.struct_type_of(dotted_name)};\n"
        return text

    def _members(self, dotted_name: str, node: Parameter) -> List[Tuple]:
        """``(c type, field name, array size macro or None, comment)`` per field."""
        members: List[Tuple] = []
        for child in node.enabled_children():
            child_path = f"{dotted_name}.{child.name}"

            if child.is_struct:
                members.append((self.struct_type_of(child_path), child.name, None,
                                child.description or None))
                continue

            data_type = child.data_type
            if data_type is None:
                continue

            comment = child.description
            if child.unit and self.config.codegen.emit_unit:
                comment = f"[{child.unit}] {comment}" if comment else f"[{child.unit}]"

            members.append((
                data_type.smart_data_struct,
                child.name,
                self.array_size_of_name(child_path) if child.is_array else None,
                comment))
        return members

    def array_size_of_name(self, dotted_name: str) -> str:
        """Array-size macro of a field, addressed by its dotted path."""
        return array_size_macro(dotted_name, self.config.codegen.index_define_prefix)

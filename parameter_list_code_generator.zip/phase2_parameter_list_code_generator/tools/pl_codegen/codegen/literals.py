"""Formatting of C literals.

Getting these right is what keeps the generated code warning-free, so all of it
lives in one place.
"""

from __future__ import annotations

import math
from typing import Optional

from ..model.parameter import NumericValue, Parameter
from ..model.types import CDataType

#: Maximum number of significant digits emitted for floating point values.
FLOAT32_DIGITS = 9
FLOAT64_DIGITS = 17


def escape_string(text: Optional[str]) -> str:
    """Return a C string literal for *text* (``NULL`` when it is empty)."""
    if text is None:
        return "NULL"
    escaped = (text.replace("\\", "\\\\")
                   .replace('"', '\\"')
                   .replace("\r", "\\r")
                   .replace("\n", "\\n")
                   .replace("\t", "\\t"))
    return f'"{escaped}"'


def bool_literal(value: object) -> str:
    return "TRUE" if bool(value) else "FALSE"


def unsigned_literal(value: int) -> str:
    return f"{int(value)}U"


def float_literal(value: float, data_type: CDataType) -> str:
    """Format a floating point literal for ``float32_t`` / ``float64_t``."""
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"'{value}' cannot be written as a C floating point literal.")
    digits = FLOAT32_DIGITS if data_type.suffix == "F32" else FLOAT64_DIGITS
    text = repr(round(float(value), digits))
    if "e" in text or "E" in text:
        mantissa, _, exponent = text.partition("e")
        if "." not in mantissa:
            mantissa += ".0"
        text = f"{mantissa}e{exponent}"
    elif "." not in text:
        text += ".0"
    return text + data_type.literal_suffix


def integer_literal(value: int, data_type: CDataType) -> str:
    """Format an integer literal, keeping the sign outside the suffix."""
    number = int(value)
    if number < 0:
        return f"({number}{data_type.literal_suffix})"
    return f"{number}{data_type.literal_suffix}"


def numeric_literal(value: NumericValue, data_type: CDataType,
                    fallback: NumericValue = 0) -> str:
    """Render *value* as a literal of *data_type*, using *fallback* when empty."""
    effective = fallback if value is None else value
    if data_type.is_bool:
        return bool_literal(effective)
    if data_type.is_float:
        return float_literal(float(effective), data_type)
    return integer_literal(int(effective), data_type)


def constructor_arguments(parameter: Parameter, data_type: CDataType) -> str:
    """Arguments of ``fSmartData_XX_Ctor`` for *parameter* (without ``me``)."""
    if data_type.is_bool:
        return numeric_literal(parameter.default_value, data_type, fallback=False)
    minimum = numeric_literal(parameter.minimum, data_type, fallback=0)
    maximum = numeric_literal(parameter.maximum, data_type, fallback=0)
    default = numeric_literal(parameter.default_value, data_type, fallback=0)
    resolution = numeric_literal(parameter.resolution, data_type, fallback=1)
    return f"{minimum}, {maximum}, {default}, {resolution}"


def tag_value_literal(value: object) -> str:
    """Render a tag value for the ``uint32_t Value`` field of the descriptor."""
    if value is None:
        return "0U"
    if isinstance(value, bool):
        return f"(uint32_t){bool_literal(value)}"
    if isinstance(value, int):
        return unsigned_literal(value)
    text = str(value).strip()
    if not text:
        return "0U"
    return f"(uint32_t){text}"

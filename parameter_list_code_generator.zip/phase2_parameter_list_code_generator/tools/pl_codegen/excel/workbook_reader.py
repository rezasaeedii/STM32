"""Low-level Excel access: turns a worksheet into header-keyed rows.

This module knows about *openpyxl*; nothing else in the tool does.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..errors import CodeGeneratorError, DiagnosticCollector, SourceLocation
from .column_schema import canonical_column

try:  # pragma: no cover - import guard
    from openpyxl import load_workbook
except ImportError as exc:  # pragma: no cover
    raise CodeGeneratorError(
        "The 'openpyxl' package is required.\n"
        "Run 'python setup_environment.py' in the tools folder to install the dependencies."
    ) from exc


@dataclass
class SheetRow:
    """One data row of a worksheet, keyed by canonical column name."""

    row_number: int
    values: Dict[str, Any] = field(default_factory=dict)

    def get(self, column: str) -> Any:
        return self.values.get(column)

    def is_empty(self) -> bool:
        return all(value is None or str(value).strip() == "" for value in self.values.values())


@dataclass
class SheetData:
    """A worksheet reduced to ``headers`` + ``rows``."""

    file: Path
    sheet_name: str
    headers: Dict[int, str] = field(default_factory=dict)   # column index -> canonical name
    raw_headers: Dict[int, str] = field(default_factory=dict)
    rows: List[SheetRow] = field(default_factory=list)

    def location(self, row: Optional[int] = None, column: Optional[str] = None) -> SourceLocation:
        return SourceLocation(file=str(self.file), sheet=self.sheet_name, row=row, column=column)

    def has_column(self, column: str) -> bool:
        return column in self.headers.values()


class WorkbookReader:
    """Reads the sheets of one workbook."""

    def __init__(self, path: Path, diagnostics: DiagnosticCollector) -> None:
        self._path = path
        self._diagnostics = diagnostics
        try:
            with warnings.catch_warnings():
                # openpyxl warns about Excel extensions it does not model
                # (conditional formatting, data validation); they do not affect
                # the values the code generator reads.
                warnings.simplefilter("ignore", UserWarning)
                self._workbook = load_workbook(path, data_only=True, read_only=True)
        except Exception as exc:  # noqa: BLE001 - openpyxl raises many types
            raise CodeGeneratorError(f"Cannot open workbook '{path}': {exc}") from exc

    @property
    def sheet_names(self) -> List[str]:
        return list(self._workbook.sheetnames)

    def close(self) -> None:
        try:
            self._workbook.close()
        except Exception:  # noqa: BLE001 - best effort
            pass

    def read_column_lists(self, sheet_name: str) -> Dict[str, List[str]]:
        """Read a sheet as ``{header: [values, ...]}``.

        Used for the *Defines* sheet, which is a plain list-per-column table
        with its own headers rather than the parameter column schema.
        """
        result: Dict[str, List[str]] = {}
        if sheet_name not in self._workbook.sheetnames:
            return result

        rows = self._workbook[sheet_name].iter_rows(values_only=True)
        header_row = next(rows, None)
        if header_row is None:
            return result

        headers = [str(header).strip() if header is not None else "" for header in header_row]
        for header in headers:
            if header:
                result.setdefault(header, [])

        for cells in rows:
            for index, cell in enumerate(cells):
                if index >= len(headers) or not headers[index] or cell is None:
                    continue
                text = str(cell).strip()
                if text and text not in result[headers[index]]:
                    result[headers[index]].append(text)
        return result

    def read_sheet(self, sheet_name: str, *, required: bool = True) -> Optional[SheetData]:
        """Read one worksheet into a :class:`SheetData`."""
        if sheet_name not in self._workbook.sheetnames:
            message = (f"Worksheet '{sheet_name}' was not found. "
                       f"Available sheets: {', '.join(self._workbook.sheetnames)}.")
            if required:
                self._diagnostics.error("EXL001", message, SourceLocation(file=str(self._path)))
            else:
                self._diagnostics.warning("EXL002", message, SourceLocation(file=str(self._path)))
            return None

        worksheet = self._workbook[sheet_name]
        data = SheetData(file=self._path, sheet_name=sheet_name)

        rows_iterator = worksheet.iter_rows(values_only=True)
        header_row = next(rows_iterator, None)
        if header_row is None:
            self._diagnostics.error("EXL003", f"Worksheet '{sheet_name}' is empty.",
                                    data.location())
            return data

        for position, cell_value in enumerate(header_row, start=1):
            if cell_value is None:
                continue
            raw = str(cell_value).strip()
            if not raw:
                continue
            data.raw_headers[position] = raw
            canonical = canonical_column(raw)
            if canonical is None:
                self._diagnostics.info(
                    "EXL010", f"Column '{raw}' is not known to the code generator and is ignored.",
                    data.location(row=1, column=raw))
                continue
            if canonical in data.headers.values():
                self._diagnostics.error(
                    "EXL011", f"Column '{canonical}' appears more than once.",
                    data.location(row=1, column=raw))
                continue
            data.headers[position] = canonical

        # Row 1 holds the headers, therefore the data starts at row 2.
        for offset, cell_values in enumerate(rows_iterator, start=2):
            values: Dict[str, Any] = {}
            for position, cell_value in enumerate(cell_values, start=1):
                column = data.headers.get(position)
                if column is None:
                    continue
                values[column] = _clean(cell_value)
            row = SheetRow(row_number=offset, values=values)
            if not row.is_empty():
                data.rows.append(row)

        return data


def _clean(value: Any) -> Any:
    """Normalise a raw cell value (trim strings, drop empty strings)."""
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        return text if text else None
    return value

"""Rules that turn Excel names into C identifiers.

Keeping every naming decision in one module means that a change of naming
convention is a one-file change.
"""

from __future__ import annotations

import re

# ``TestVarU16`` -> ``TEST_VAR_U16``  /  ``PosDrone`` -> ``POS_DRONE``
_BOUNDARY_LOWER_UPPER = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
_BOUNDARY_ACRONYM = re.compile(r"(?<=[A-Z])(?=[A-Z][a-z])")

_C_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

#: Keywords that must never be used as a parameter name (C99 + C++ subset that
#: matters for the generated headers).
C_RESERVED_KEYWORDS = frozenset({
    "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else",
    "enum", "extern", "float", "for", "goto", "if", "inline", "int", "long", "register",
    "restrict", "return", "short", "signed", "sizeof", "static", "struct", "switch", "typedef",
    "union", "unsigned", "void", "volatile", "while", "_Bool", "_Complex", "_Imaginary",
    "_Alignas", "_Alignof", "_Atomic", "_Generic", "_Noreturn", "_Static_assert", "_Thread_local",
    # C++ keywords -- the generated headers must be includable from C++
    "asm", "bool", "catch", "class", "const_cast", "delete", "dynamic_cast", "explicit",
    "export", "false", "friend", "mutable", "namespace", "new", "operator", "private",
    "protected", "public", "reinterpret_cast", "static_cast", "template", "this", "throw",
    "true", "try", "typeid", "typename", "using", "virtual", "wchar_t", "nullptr",
    "constexpr", "decltype", "noexcept", "alignas", "alignof", "char16_t", "char32_t",
    "static_assert", "thread_local",
})


def is_valid_c_identifier(name: str) -> bool:
    """Return ``True`` when *name* can be used as a C identifier."""
    return bool(name) and _C_IDENTIFIER.match(name) is not None


def is_reserved_keyword(name: str) -> bool:
    """Return ``True`` when *name* collides with a C/C++ keyword."""
    return name in C_RESERVED_KEYWORDS


def to_macro_case(name: str) -> str:
    """Convert a CamelCase / dotted name into ``UPPER_SNAKE_CASE``.

    ``TestVarU16`` -> ``TEST_VAR_U16``, ``PosDrone`` -> ``POS_DRONE``,
    ``Position.Home.Lat`` -> ``POSITION_HOME_LAT``.
    """
    text = name.strip().replace("-", "_").replace(" ", "_").replace(".", "_")
    text = _BOUNDARY_ACRONYM.sub("_", text)
    text = _BOUNDARY_LOWER_UPPER.sub("_", text)
    text = re.sub(r"_+", "_", text)
    return text.upper().strip("_")


def index_macro(name: str, prefix: str = "") -> str:
    """Name of the ``#define`` that holds the index of a parameter."""
    return f"{prefix}{to_macro_case(name)}"


def array_size_macro(name: str, prefix: str = "") -> str:
    """Name of the ``#define`` that holds the array size of a parameter."""
    return f"{prefix}{to_macro_case(name)}_ARRAY_SIZE"


def smart_data_symbol(name: str, prefix: str = "Cg_SmartData_") -> str:
    """Name of the generated smart-data object of a top level parameter."""
    return f"{prefix}{name}"


def struct_type_name(dotted_name: str, prefix: str = "sCgStruct_") -> str:
    """C type name of a generated structure, e.g. ``sCgStruct_Position_Home``."""
    return prefix + dotted_name.replace(".", "_")


def offset_macro(tag_id: str, name: str, prefix: str = "") -> str:
    """Name of the ``#define`` holding the MemoryOffset of a parameter/tag pair."""
    return f"{prefix}OFFSET_{to_macro_case(tag_id)}_{to_macro_case(name)}"


def offset_total_macro(tag_id: str, prefix: str = "") -> str:
    """Name of the ``#define`` holding the total bytes used by a tag."""
    return f"{prefix}SIZE_{to_macro_case(tag_id)}"


def include_guard(file_name: str) -> str:
    """Include guard derived from a file name, matching the company snippet."""
    stem = file_name.rsplit(".", 1)[0]
    return f"{stem.upper()}_H"

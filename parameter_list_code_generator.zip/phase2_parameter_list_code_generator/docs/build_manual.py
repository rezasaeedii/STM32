"""Rebuilds the Persian PDF manual from ``manual_fa.html``.

Usage::

    cd docs
    python build_manual.py

**Nothing has to be installed and nothing has to be online.**  The script prints
``manual_fa.html`` with a Chromium based browser that is already on the machine
(Microsoft Edge, Google Chrome, Chromium or Brave), started with every
background-networking switch turned off.  The Persian font and the screenshots
are embedded inside the HTML file itself, and the running footer with the page
numbers comes from CSS ``@page`` rules, so the result is the same on every
machine - including a machine with no internet connection at all.

If no browser is found, you can always produce the same PDF by hand:
open ``manual_fa.html`` in Edge/Chrome and press Ctrl+P -> "Save as PDF",
with "Margins: Default" and "Headers and footers" switched OFF.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import List, Optional

DOCS_DIR = Path(__file__).resolve().parent
PROJECT_DIR = DOCS_DIR.parent
SOURCE = DOCS_DIR / "manual_fa.html"
OUTPUT = PROJECT_DIR / "parameter_list_codegen_manual_fa.pdf"

# The switches that stop the browser from doing its own background networking.
# They live next to the editor, which needs exactly the same list; this script
# still works on its own if the tools folder is not there.
sys.path.insert(0, str(PROJECT_DIR / "tools"))
try:
    from pl_gui.browser import OFFLINE_FLAGS
except ImportError:  # pragma: no cover - only when docs/ is copied on its own
    OFFLINE_FLAGS = ["--disable-background-networking", "--disable-component-update",
                     "--disable-sync", "--disable-breakpad", "--no-first-run",
                     "--safebrowsing-disable-auto-update", "--metrics-recording-only"]

#: Names looked up on the PATH, on any operating system.
BROWSER_COMMANDS = [
    "msedge", "microsoft-edge", "microsoft-edge-stable",
    "chrome", "google-chrome", "google-chrome-stable",
    "chromium", "chromium-browser", "brave", "brave-browser",
]

#: Well known installation paths, checked when the PATH lookup fails.
BROWSER_PATHS = {
    "win32": [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
    ],
    "darwin": [
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
    ],
    "linux": [
        "/usr/bin/microsoft-edge", "/usr/bin/google-chrome", "/usr/bin/chromium",
        "/usr/bin/chromium-browser", "/snap/bin/chromium",
    ],
}


def find_browser() -> Optional[str]:
    """Return the path of a Chromium based browser, or ``None``."""
    override = os.environ.get("PL_CODEGEN_BROWSER")
    if override and Path(override).is_file():
        return override

    for command in BROWSER_COMMANDS:
        found = shutil.which(command)
        if found:
            return found

    platform = "win32" if sys.platform.startswith("win") else \
               "darwin" if sys.platform == "darwin" else "linux"
    for candidate in BROWSER_PATHS[platform]:
        if Path(candidate).is_file():
            return candidate

    # Playwright users already have a browser downloaded; reuse it.
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            path = playwright.chromium.executable_path
        if Path(path).is_file():
            return path
    except Exception:  # noqa: BLE001 - playwright is entirely optional
        pass
    return None


def render(browser: str) -> Path:
    """Print ``manual_fa.html`` to ``OUTPUT`` with *browser*."""
    if not SOURCE.is_file():
        raise SystemExit(f"'{SOURCE}' not found.")

    # A throw-away profile keeps the user's own browser session untouched.
    with tempfile.TemporaryDirectory(prefix="pl_manual_") as profile:
        command: List[str] = [
            browser,
            "--headless",
            "--disable-gpu",
            "--no-sandbox",
            "--no-pdf-header-footer",      # the footer comes from CSS @page
            "--run-all-compositor-stages-before-draw",
            "--virtual-time-budget=10000",
            *OFFLINE_FLAGS,               # never touch the network
            f"--user-data-dir={profile}",
            f"--print-to-pdf={OUTPUT}",
            SOURCE.as_uri(),
        ]
        result = subprocess.run(command, capture_output=True, text=True)

    if not OUTPUT.is_file() or OUTPUT.stat().st_size == 0:
        raise SystemExit("The browser did not produce a PDF.\n"
                         f"command: {' '.join(command)}\n{result.stderr}")
    return OUTPUT


def manual_instructions() -> str:
    return (
        "No Chromium based browser was found.\n"
        "\n"
        "Either:\n"
        "  * point the script at one:   set PL_CODEGEN_BROWSER=<path to msedge.exe>\n"
        "  * or build the PDF by hand:  open docs/manual_fa.html in Edge or Chrome,\n"
        "    press Ctrl+P, choose 'Save as PDF', set Margins to 'Default' and switch\n"
        "    'Headers and footers' OFF. The result is identical.\n"
    )


def main() -> int:
    browser = find_browser()
    if browser is None:
        print(manual_instructions())
        return 1

    print(f"browser: {browser}")
    output = render(browser)
    print(f"written: {output}  ({output.stat().st_size // 1024} KB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

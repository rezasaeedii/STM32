/**
  ******************************************************************************
  * @file    nsrParamTables.h
  * @brief   Parameter tables of every sub-system, as ADD_PARAM() lines.
  *
  * This file is generated automatically - DO NOT EDIT IT BY HAND.
  * Generator      : parameter_list_code_generator v1.0.0
  * Generated at   : 2026-09-12 00:44:18 +0330
  * Input file(s)  : C:\Users\Admin\Desktop\com\parameter_list_code_generator\projects\agreement\sys_gs_manager_paramTable.xml
  *                   C:\Users\Admin\Desktop\com\parameter_list_code_generator\projects\agreement\sys_rhs_paramTable.xml
  * Parameters     : 5 value(s)
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 Fds.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

//WARNING: Order of subsytems should comply SYS_GS_ enum (at least for last system)
//WARNING: DO NOT ADD NEW ITEMS BETWEEN OLD ITEM

//ADD_PARAM(data type, TYPE_ENUM, PR_NAME, "param name in gs", SYS_NAME, param index, default value, min, max, resolution, mode (0 is recommended), address (0 :: auto), "description")

#define PARAM_MODE_USER             (0)
#define PARAM_MODE_READ_ONLY        (1)
#define PARAM_MODE_PRODUCT_TYPE     (2)
#define PARAM_MODE_FACTORY          (3)
#define PARAM_MODE_CALIB            (4)
#define PARAM_MODE_TEMPORARY        (5)

#if DESIRED_SUB_SYSTEM == SYS_GS_MANAGER || DESIRED_SUB_SYSTEM == SYS_ALL
ADD_PARAM(uint8_t, TYPE_UINT8 , PR_GSM_TABLE_NUM        , "GSM_TABLE_NUM"    , SYS_GS_MANAGER, 0, 31  , 0   , 255 , 1    , PARAM_MODE_READ_ONLY, 400, "GSM_TABLE_NUM returns last parameter number")
ADD_PARAM(int8_t , TYPE_INT8  , PR_GSM_PINOUT_TYPE      , "GSM_PINOUT_TYPE"  , SYS_GS_MANAGER, 1, -1  , -1  , 100 , 1    , PARAM_MODE_READ_ONLY, 0  , "-1: Unknown,\n 2:GSV2,\n 3:GSV3R1")
ADD_PARAM(float  , TYPE_FLOAT , PR_GSM_INITIAL_LOCK_SIZE, "INITIAL_LOCK_SIZE", SYS_GS_MANAGER, 2, 0.04, 0.01, 0.3 , 0.01 , PARAM_MODE_USER     , 0  , "Lock Box Size Parameter")

#endif

#if DESIRED_SUB_SYSTEM == SYS_RHS || DESIRED_SUB_SYSTEM == SYS_ALL
ADD_PARAM(double , TYPE_DOUBLE, PR_RHS_GAIN             , "RHS_GAIN"         , SYS_RHS       , 0, 1.5 , 0.0 , 10.0, 0.001, PARAM_MODE_CALIB    , 900, "loop gain")
ADD_PARAM(uint8_t, TYPE_UINT8 , table                   , "table"            , SYS_RHS       , 1, 0   , 0   , 0   , 1    , PARAM_MODE_USER     , 0  , "")

#endif


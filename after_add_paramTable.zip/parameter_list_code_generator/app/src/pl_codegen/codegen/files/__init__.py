"""One class per generated file.

Each module here holds a ``FileBuilder`` whose ``generate()`` writes the whole
file from top to bottom with ``text += ...``.  Reading that one method tells you
exactly what the generated file will look like.

Adding a new output file: write a module here and list its class in
:data:`SMART_DATA_BUILDERS`.

There are two sets of them, because there are two output formats.  Which set a
run uses is the project's to say, and :func:`builders_for` is where that is
decided - once, from the configuration, rather than in every caller.
"""

from __future__ import annotations

from typing import List, Type

from ...config import Config, FORMAT_PARAM_TABLE
from .file_builder import FileBuilder
from .parameter_list_c import ParameterListSource
from .parameter_list_defines_h import ParameterListDefinesHeader
from .parameter_list_h import ParameterListHeader
from .parameter_list_table_h import ParameterListTableHeader
from .param_table_h import ParamTableHeader
from .parameter_types_h import ParameterTypesHeader
from .smart_data_c import SmartDataSource
from .smart_data_h import SmartDataHeader

#: The ``smart_data`` format, generated in this order.
SMART_DATA_BUILDERS: List[Type[FileBuilder]] = [
    ParameterListDefinesHeader,
    ParameterTypesHeader,
    SmartDataHeader,
    SmartDataSource,
    ParameterListHeader,
    ParameterListSource,
    ParameterListTableHeader,
]

#: The ``param_table`` format: one file, and that is the whole of it.
PARAM_TABLE_BUILDERS: List[Type[FileBuilder]] = [ParamTableHeader]


def builders_for(config: Config) -> List[Type[FileBuilder]]:
    """The files this project's format produces."""
    if config.output.format == FORMAT_PARAM_TABLE:
        return list(PARAM_TABLE_BUILDERS)
    return list(SMART_DATA_BUILDERS)


__all__ = [
    "builders_for", "SMART_DATA_BUILDERS", "PARAM_TABLE_BUILDERS", "FileBuilder",
    "ParameterListDefinesHeader", "ParameterListHeader", "ParameterListSource",
    "ParameterListTableHeader", "ParameterTypesHeader", "ParamTableHeader",
    "SmartDataHeader", "SmartDataSource",
]

# -*- coding: utf-8 -*-
"""Every claim the documentation makes that the code can check.

Run it with::

    python tests/run_docs_test.py

Two kinds of check:

  * a phrase that describes something that no longer exists - a button that was
    renamed, a folder that moved, a file whose name changed;
  * a name the docs quote that ought to exist in the source, and does not.

Docs that name a thing nobody can find are worse than no docs: the reader goes
looking, does not find it, and stops trusting the rest.
"""
import pathlib
import re
import sys

APP = pathlib.Path(__file__).resolve().parent.parent
ROOT = APP.parent
sys.path.insert(0, str(APP / "src"))

from pl_codegen.logging_utils import (BOLD, BRIGHT_RED, GREEN,  # noqa: E402
                                      colour_supported, paint)
import pl_codegen.logging_utils as _logging_utils               # noqa: E402

_logging_utils._colour_enabled = colour_supported()

#: text that must not appear anywhere any more -> what it is now
GONE = {
    "tools/": "app/",
    "tools\\\\": "app\\",
    "codegen_config.json": "project.json",
    "model_snapshot": "full_parameter_list",
    "last_build_file": "full_parameter_list_file",
    "last_build/": "full_parameter_list/",
    "snapshot_file": "full_parameter_list_file",
    ".types.xml": "_structures.xml",
    "StructTemplates": "the structures file beside the list",
    "Save as a type": "Structure types…",
    "Save '": "Structure types…",
    "save_template": "create_struct_type / update_struct_type",
    "apply_template": "use_struct_type",
    "delete_template": "delete_struct_type",
    "useTemplate": "useType",
    "editTemplates": "editTypes",
    "state.templates": "state.structTypes",
    "tree.js": "grid.js",
    "run_gui.bat": "run.bat",
    "run_tests.bat": "run.bat tests",
    "run_setup.bat": "run.bat setup",
    "run_generate.bat": "run.bat generate",
    "+ Sub-structure": "the field table of a structure type",
    "Lists ▾": "the ☰ button",
    "btn-view-tree": "there is one view now",
    "btn-save-template": "btn-edit-type",
    "phase2": "there is one phase",
    "فاز دو": "there is one phase",
    "GS Name": "User Name",
    "GS name": "User Name",
}

#: files the docs are allowed to name, checked against the tree
KNOWN_PATHS = re.compile(
    r"\b(?:app/)?(?:src/|bin/|tests/|docs/|templates/)?"
    r"(?:pl_codegen|pl_gui)?/?[\w/]+\.(?:py|js|css|html|json|c|h|xml|bat)\b")

WHERE = [
    APP / "README.md",
    APP / "src" / "pl_codegen" / "README.md",
    APP / "docs" / "user_manual_fa.html",
    APP / "templates" / "project.json",
    APP / "run.bat",
]
WHERE += sorted((APP / "docs" / "manual_source" / "parts").glob("*.html"))
WHERE += sorted((APP / "docs" / "manual_source").glob("notes_*.py"))
WHERE += sorted((APP / "docs" / "manual_source").glob("build_*.py"))

#: sections the manual marks as history: they name old things ON PURPOSE
HISTORY = re.compile(r"<!-- HISTORY-BLOCK.*?/HISTORY-BLOCK -->", re.S)


def main() -> int:
    problems = 0
    for path in WHERE:
        if not path.is_file():
            continue
        text = HISTORY.sub("", path.read_text(encoding="utf-8"))
        # Two files name old things legitimately: the pitfalls chapter is ABOUT
        # what changed, and the file-by-file reference is generated from the
        # code itself, so by construction it says what the code says.
        if path.name == "p05_reference.html":
            continue
        historical = path.name in ("p07_pitfalls.html",)
        for stale, instead in GONE.items():
            if stale in text:
                if historical and stale in ("Save as a type", "StructTemplates",
                                            "save_template", "apply_template",
                                            "codegen_config.json", "tools/"):
                    continue
                count = text.count(stale)
                print(f"  STALE  {path.relative_to(ROOT)}: {count} x {stale!r}"
                      f"  ->  {instead}")
                problems += count

    # ---- names the docs quote that must exist -------------------------
    print()
    tree = {p.relative_to(APP).as_posix() for p in APP.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts}
    quoted = set()
    for path in WHERE:
        if not path.is_file() or path.suffix not in (".html", ".md"):
            continue
        text = HISTORY.sub("", path.read_text(encoding="utf-8"))
        for match in KNOWN_PATHS.findall(text):
            name = match.lstrip("/")
            if name.startswith("app/"):
                name = name[4:]
            quoted.add(name)

    missing = []
    for name in sorted(quoted):
        if name in tree:
            continue
        # a bare file name is fine if something in the tree ends with it
        if any(item.endswith("/" + name) or item == name for item in tree):
            continue
        missing.append(name)

    interesting = [n for n in missing
                   if n.startswith(("src/", "bin/", "tests/", "docs/", "templates/",
                                    "pl_codegen/", "pl_gui/"))]
    for name in interesting:
        print(f"  NO SUCH FILE  {name}")
    problems += len(interesting)

    print()
    if problems:
        print(paint(f"{problems} stale reference(s) in the documentation.",
                    BOLD + BRIGHT_RED))
        return 1
    print(paint("The documentation names nothing that no longer exists.", GREEN))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

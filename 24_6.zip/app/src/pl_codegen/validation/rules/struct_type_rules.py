"""Rules about structure types - the ``struct`` declarations of the list.

A structure parameter names a type, the way a C++ variable names one.  These
rules check that the name means something, that it means a *structure*, and
that the declarations themselves make sense.

The two rules people meet most are the pair that keep the two worlds apart: a
parameter holds a value and may not name a structure type, and a structure
holds fields and may not name ``float32_t``.  Both used to be possible, and
both produced a parameter list that looked right and generated nonsense.

A problem in a declaration is an error only for a type the build really
generates; for a type nothing uses it is a warning (see :class:`_TypeProblems`).
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set

from ...errors import DiagnosticCollector, SourceLocation
from ...model.parameter import Parameter
from ...model.parameter_list import ParameterList
from ...model.struct_type import StructType, StructTypeLibrary
from ...model.types import resolve_value_type, supported_type_names
from ...naming import is_valid_c_identifier
from .rule_base import ValidationRule, enabled_nodes


class StructTypeRule(ValidationRule):
    """Every structure names a structure type, and every type exists."""

    rule_id = "STRUCT_TYPE"
    description = "A structure must name a structure type that exists."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        for parameter in enabled_nodes(model):
            name = (parameter.value_type_name or "").strip()

            if parameter.is_struct:
                if not name:
                    diagnostics.error(
                        "TYP002",
                        f"Structure '{parameter.name}' has no structure type.",
                        parameter.source,
                        hint="Pick one in the 'Data type' list, or make one with "
                             "'Structure types…' in the settings menu.")
                    continue
                if resolve_value_type(name) is not None:
                    diagnostics.error(
                        "TYP005",
                        f"Structure '{parameter.name}' is of type '{name}', which is "
                        f"a data type and not a structure.",
                        parameter.source,
                        hint=f"A structure holds fields, not a value. Give '{name}' "
                             f"to a field instead, or make this parameter a plain "
                             f"parameter.")
                    continue
                if library.get(name) is None:
                    known = ", ".join(library.names()) or "none yet"
                    diagnostics.error(
                        "TYP003",
                        f"Structure '{parameter.name}' is of type '{name}', which "
                        f"this project does not have.",
                        parameter.source,
                        hint=f"Known structure types: {known}. The structures of a "
                             f"list live in the '_structures.xml' file beside it; "
                             f"check that file came along with the list.")
            elif name and library.get(name) is not None:
                diagnostics.error(
                    "TYP004",
                    f"'{parameter.name}' is a parameter but its data type "
                    f"'{name}' is a structure type.",
                    parameter.source,
                    hint=f"A parameter holds one value. Pick one of "
                         f"{supported_type_names()}, or add it as a structure "
                         f"instead.")


class _TypeProblems:
    """Reports a problem of a structure TYPE at the severity it really has.

    A type the build generates a typedef for is an error: the generated code
    would be wrong.  A type nothing uses generates nothing, so the same finding
    is a warning.  It used to be an error either way - which blocked Generate
    over a type no structure had, and stayed in the Problems panel after the
    last structure of the type was deleted, looking like that structure's own
    error.  (Reported.)

    Either way the diagnostic names the type (``location.struct_type``), and the
    editor opens 'Structure types…' on it.  A type in use also names the first
    structure that holds it, so the row still jumps somewhere real.
    """

    def __init__(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        self.diagnostics = diagnostics
        self.library = model.struct_types
        self.in_use = {item.name for item in model.struct_types_in_use()}
        self.structures = model.struct_parameters()

    def report(self, name: str, code: str, message: str, hint: str) -> None:
        if name in self.in_use:
            where = SourceLocation(parameter=self._holder(name), struct_type=name)
            self.diagnostics.error(code, message, where, hint=hint)
            return
        self.diagnostics.warning(
            code, f"{message} No structure uses it, so nothing is generated from it.",
            SourceLocation(struct_type=name),
            hint=f"{hint} Or, since nothing uses it, delete it in 'Structure types…'.")

    def _holder(self, name: str) -> Optional[str]:
        """The first enabled structure that has *name* in it, however deep."""
        for path, node in self.structures:
            if name in _reachable(node.value_type_name, self.library):
                return path
        return None


class StructTypeDeclarationRule(ValidationRule):
    """The declarations themselves: names, fields, and what the fields hold."""

    rule_id = "STRUCT_TYPE_DECL"
    description = "Structure type declarations must be usable as C typedefs."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        problems = _TypeProblems(model, diagnostics)
        for struct_type in library.all():
            name = struct_type.name

            if not is_valid_c_identifier(name):
                problems.report(
                    name, "TYP006",
                    f"Structure type '{name}' is not a valid C identifier.",
                    hint="It becomes a typedef, so use letters, digits and '_', and "
                         "do not start with a digit.")

            if not struct_type.fields:
                problems.report(
                    name, "TYP007",
                    f"Structure type '{name}' has no fields.",
                    hint="An empty struct generates a typedef nothing can be built "
                         "from. Add a field, or delete the type.")

            seen: Set[str] = set()
            for member in struct_type.fields:
                if member.name in seen:
                    problems.report(
                        name, "TYP008",
                        f"Structure type '{name}' has two fields called "
                        f"'{member.name}'.",
                        hint="Two members of one struct cannot share a name.")
                seen.add(member.name)

                if not member.value_type_name:
                    problems.report(
                        name, "TYP009",
                        f"Field '{name}.{member.name}' has no data type.",
                        hint=f"Pick one of {supported_type_names()}, or another "
                             f"structure type.")
                elif (resolve_value_type(member.value_type_name) is None
                      and library.get(member.value_type_name) is None):
                    problems.report(
                        name, "TYP013",
                        f"Field '{name}.{member.name}' is of type "
                        f"'{member.value_type_name}', which is neither a data type "
                        f"nor a structure type.",
                        hint=f"Known data types: {supported_type_names()}. Known "
                             f"structure types: {', '.join(library.names()) or 'none'}.")

                if member.array_size < 1:
                    problems.report(
                        name, "TYP014",
                        f"Field '{name}.{member.name}' has array size "
                        f"{member.array_size}; it must be 1 or more.",
                        hint="Leave the cell empty for a single value.")


class StructTypeCycleRule(ValidationRule):
    """A structure type may not contain itself, however far around."""

    rule_id = "STRUCT_TYPE_CYCLE"
    description = "Structure types must not contain themselves."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        library = model.struct_types
        problems = _TypeProblems(model, diagnostics)
        for struct_type in library.all():
            path = _cycle_from(struct_type, library)
            if path:
                problems.report(
                    struct_type.name, "TYP015",
                    f"Structure type '{struct_type.name}' contains itself: "
                    f"{' -> '.join(path)}.",
                    hint="A struct cannot hold a copy of itself - it would have no "
                         "size. Break the loop by removing one of those fields.")


class StructTypeClashRule(ValidationRule):
    """One name, two different structures, once the lists are merged."""

    rule_id = "STRUCT_TYPE_CLASH"
    description = "A structure type name must mean the same thing in every list."

    def check(self, model: ParameterList, diagnostics: DiagnosticCollector) -> None:
        problems = _TypeProblems(model, diagnostics)
        for name in model.type_clashes:
            problems.report(
                name, "TYP016",
                f"Two parameter lists of this project both declare a structure type "
                f"called '{name}', and the two are not the same structure.",
                hint="Rename one of them. Two lists CAN share a type - that is how "
                     "a shared list brings its structures with it - but only while "
                     "they say the same thing.")


def _reachable(name: Optional[str], library: StructTypeLibrary) -> Set[str]:
    """*name* and every structure type it holds as a field, however deep."""
    found: Set[str] = set()
    queue = [name] if name else []
    while queue:
        current = library.get(queue.pop())
        if current is None or current.name in found:
            continue
        found.add(current.name)
        queue.extend(member.value_type_name for member in current.fields)
    return found


def _cycle_from(struct_type: StructType, library) -> List[str]:
    """The chain of type names that leads back to *struct_type*, if any."""
    target = struct_type.name

    def walk(current: StructType, chain: List[str], seen: Set[str]) -> List[str]:
        for member in current.fields:
            nested = library.get(member.value_type_name)
            if nested is None:
                continue
            if nested.name == target:
                return chain + [nested.name]
            if nested.name in seen:
                continue
            found = walk(nested, chain + [nested.name], seen | {nested.name})
            if found:
                return found
        return []

    return walk(struct_type, [target], {target})

# -*- coding: utf-8 -*-
NOTES = {}

NOTES["src/pl_codegen/validation/__init__.py"] = {"fa": "<p>چند <code>import</code> برای راحتی.</p>", "when": "به‌ندرت."}

NOTES["src/pl_codegen/validation/rules/rule_base.py"] = {
 "fa": """<p>کلاس پایه‌ی هر قانون. سه چیز از هر قانون خواسته می‌شود:
<code>rule_id</code>، <code>description</code> (که <code>--list-rules</code> چاپش
می‌کند) و متد <code>check()</code>. سازنده‌اش <code>config</code> را نگه می‌دارد تا
قوانین بتوانند به تنظیمات نگاه کنند.</p>""",
 "when": "تقریباً هیچ‌وقت؛ مگر بخواهید به همه‌ی قوانین امکان تازه‌ای بدهید.",
 "sym": {
  "ValidationRule": "کلاس پایه‌ی هر قانون اعتبارسنجی.",
  "ValidationRule.rule_id": "شناسه‌ی کوتاه قانون، در خروجی <code>--list-rules</code>.",
  "ValidationRule.description": "توضیح یک‌خطی قانون.",
  "ValidationRule.check": "قانون را روی مدل اجرا می‌کند و پیام‌ها را به <code>diagnostics</code> اضافه می‌کند. هیچ‌وقت استثنا نمی‌دهد.",
  "enabled_nodes": "همه‌ی گره‌های فعال درخت، استراکچرها هم.",
  "enabled_leaves": "همه‌ی گره‌های اولیه‌ی فعال (بدون استراکچرها).",
  "enabled_structs": "همه‌ی استراکچرهای فعال.",
  "dotted_names": "مسیر نقطه‌دار هر گره‌ی فعال.",
  "declared_values": "مثل <code>flatten()</code>، ولی یک ورودی به‌ازای هر <b>اعلان</b> نه هر مقدار.",
 },
 "after": """<div class="warn">
<b>یک پیام به‌ازای هر اعلان، نه هر مقدار</b>
<p>
<code>ParameterList.flatten()</code> نگاهِ کدساز است: یک ورودی برای هر <b>مقدار</b>، پس
<code>CellVoltage[6]</code> شش ورودی است. قانونی که خاصیتِ خودِ پارامتر را می‌سنجد — یک
تگِ خالی، یک تایپِ ناموجود — اگر روی آن قدم بزند همان یک اشتباه را شش بار گزارش می‌کند؛
با یک آرایه‌ی ۷۰۰۰۰تایی می‌شود ۳۵۰۰۰۰ پیام. <code>declared_values()</code> همان فهرست
است با حذفِ تکرارِ عنصرها (و تگ‌ها و تایپِ به‌ارث‌رسیده سرِ جایش می‌ماند).
</p>
<p>
<b>قاعده:</b> خاصیتِ <i>اعلان</i> (تگ، تایپ، نام) →
<code>declared_values()</code>؛ خاصیتِ <i>مقدار</i> (شناسه‌ی لاگ، آفست) →
<code>flatten()</code>.
</p>
</div>""",
}

NOTES["src/pl_codegen/validation/rules/__init__.py"] = {
 "fa": """<p>فهرست <code>ALL_RULES</code>: ترتیب اجرای قوانین. ترتیب فقط روی ترتیب <b>پیام‌ها</b>
اثر دارد، نه روی نتیجه.</p>
<div class="ok"><b>افزودن یک قانون = یک کلاس تازه + یک سطر در این لیست.</b></div>""",
 "when": "هر بار که قانون تازه‌ای می‌نویسید.",
 "sym": {"ALL_RULES": "همه‌ی کلاس‌های قانون، به ترتیب اجرا."},
}

NOTES["src/pl_codegen/validation/validator.py"] = {
 "fa": """<p>همه‌ی قوانین را می‌سازد، پشت سر هم اجرا می‌کند، و بعد <b>تصمیم می‌گیرد آیا تولید
کد ادامه پیدا کند</b>: با هر ارور نه، و با هر هشدار هم نه اگر
<code>treat_warnings_as_errors</code> روشن باشد. چک «لیست خالی»
(<code>VAL001</code>) هم همین‌جاست، چون به هیچ قانون خاصی تعلق ندارد.</p>""",
 "when": "وقتی معیار «آیا ادامه بدهیم» باید عوض شود.",
 "sym": {
  "Validator": "اجراکننده‌ی <code>ALL_RULES</code> روی یک مدل.",
  "Validator.rules": "نمونه‌های ساخته‌شده‌ی همه‌ی قوانین.",
  "Validator.validate": "همه‌ی قوانین را اجرا می‌کند و <code>True</code> می‌دهد اگر تولید کد مجاز باشد.",
 },
}

NOTES["src/pl_codegen/validation/rules/name_rules.py"] = {
 "fa": """<p>چهار قانون درباره‌ی نام‌ها. مهم‌ترینشان <code>IndexMacroCollisionRule</code> است
که فقط ماکروی ایندکس را چک نمی‌کند: یک جدول واحد می‌سازد و <b>هر شناسه‌ای که ابزار
تولید می‌کند</b> را در آن ثبت می‌کند — ماکرو ایندکس، نام شیء smart data، ماکرو سایز
آرایه، ماکروهای آفست، و حتی <code>quantity_define</code> و
<code>TRUE/FALSE/NULL</code>.</p>""",
 "when": "وقتی شناسه‌ی تولیدیِ تازه‌ای اضافه می‌کنید — آن را هم در این جدول ثبت کنید، وگرنه می‌تواند بی‌صدا با چیزی تداخل کند.",
 "sym": {
  "NameSyntaxRule": "نام پارامتر باید شناسه‌ی معتبر C و غیرکلیدواژه باشد (<code>NAME001</code>، <code>NAME002</code>).",
  "NameUniquenessRule": "نام‌ها باید در <b>همه‌ی</b> لیست‌های پارامتر یکتا باشند؛ پیام می‌گوید هر تکرار در کدام فایل است (<code>NAME003</code>).",
  "IndexMacroCollisionRule": "هیچ دو پارامتری نباید به یک شناسه‌ی تولیدی برسند (<code>NAME004</code>). مثال کلاسیک: <code>TestVar</code> و <code>Test_Var</code> هر دو <code>TEST_VAR</code> می‌شوند.",
  "GeneratedIdentifierRule": "شناسه‌ای که از نام پارامتر ساخته می‌شود باید خودش معتبر باشد (<code>NAME005</code>). مثلاً نام <code>_1</code> ماکروی <code>1</code> می‌ساخت.",
  "NameSyntaxRule.check": "همه‌ی پارامترهای فعال را می‌گردد.",
  "NameUniquenessRule.check": "نام‌ها را در یک دیکشنری جمع می‌کند و تکراری‌ها را گزارش می‌دهد.",
  "IndexMacroCollisionRule.check": "همه‌ی شناسه‌های تولیدی را در یک جدول ثبت و تداخل‌ها را گزارش می‌کند.",
  "GeneratedIdentifierRule.check": "هر شناسه‌ی مشتق‌شده را با <code>is_valid_c_identifier</code> می‌سنجد.",
 },
}

NOTES["src/pl_codegen/validation/rules/type_rules.py"] = {
 "fa": "<p>چهار قانون درباره‌ی تایپ، گروه و اندازه‌ی آرایه.</p>",
 "when": "وقتی تایپ تازه‌ای اضافه می‌شود یا قاعده‌ی گروه‌ها عوض می‌شود.",
 "sym": {
  "ValueTypeRule": "<code>ValueType</code> باید پر و پشتیبانی‌شده باشد (<code>TYPE001</code>، <code>TYPE002</code>).",
  "DeclaredTypeRule": "هشدار اگر تایپ در لیست کشویی <code>TYPES</code> نیامده باشد (<code>TYPE003</code>).",
  "ParameterTypeRule": "تایپِ پارامتر (MONITORING / SETTING / COMMAND) باید پر باشد و enum متناظرش در <code>parameter_descriptor.h</code> وجود داشته باشد (<code>GRP001</code>…<code>GRP003</code>؛ کد کوتاهش به‌عمد GRP مانده، چون شناسه‌ی پایدار است).",
  "ArraySizeRule": "سایز آرایه باید بین ۱ و ۶۵۵۳۵ باشد (<code>ARR001</code>، <code>ARR002</code>).",
  "ValueTypeRule.check": "تایپ هر پارامتر فعال را حل و بررسی می‌کند.",
  "DeclaredTypeRule.check": "تایپ‌ها را با لیست کشویی <code>TYPES</code> می‌سنجد.",
  "ParameterTypeRule.check": "تایپِ هر پارامتر را بررسی می‌کند.",
  "ArraySizeRule.check": "اندازه‌ی آرایه‌ها را بررسی می‌کند.",
 },
}

NOTES["src/pl_codegen/validation/rules/range_rules.py"] = {
 "fa": """<p>پنج قانون درباره‌ی مقدار پیش‌فرض، حدها و رزولوشن. این پرحادثه‌ترین فایل قوانین
است، چون بیشتر باگ‌های «بی‌صدا» این‌جا زندگی می‌کردند.</p>""",
 "when": "وقتی قاعده‌ی بازه‌ها عوض می‌شود. همیشه از <code>effective_*</code> استفاده کنید.",
 "sym": {
  "NativeRangeRule": "هیچ مقداری نباید بیرون از بازه‌ی طبیعی تایپ باشد (<code>RNG001</code>).",
  "MinMaxOrderRule": "کمینه نباید از بیشینه بزرگ‌تر باشد (<code>RNG002</code>). حالت «بازه غیرفعال» را کنار می‌گذارد.",
  "DefaultInRangeRule": "مقدار پیش‌فرض باید داخل بازه باشد (<code>RNG003</code>) — با مقادیر <b>مؤثر</b>، و با در نظر گرفتن اینکه <code>DefaultValue</code>ی خالی در کد <code>0</code> می‌شود.",
  "RequiredValuesRule": "هشدارهای «خالی است، فلان مقدار به‌جایش می‌رود» و همه‌ی چک‌های رزولوشن (<code>RNG010</code>…<code>RNG016</code>).",
  "MetadataRule": "خالی بودن Description و Unit؛ سطحش را <code>validation</code> در کانفیگ تعیین می‌کند (<code>META001</code>، <code>META002</code>).",
  "RequiredValuesRule.BOOLEAN_HARMLESS": "مقادیری که در یک ردیف بولین بی‌ضررند: <code>0 / 1 / 1</code>. اینها فقط تعریف بولین را تکرار می‌کنند، پس بی‌صدا پذیرفته می‌شوند.",
  "RequiredValuesRule._check_boolean": "برای یک ردیف بولین <b>یک</b> هشدار می‌دهد و همه‌ی خانه‌های نادرست را در همان یک پیام فهرست می‌کند — نه یک هشدار به‌ازای هر خانه.",
  "NativeRangeRule.check": "چهار مقدار عددی هر پارامتر را با بازه‌ی طبیعی تایپ می‌سنجد.",
  "MinMaxOrderRule.check": "ترتیب دو حد مؤثر را بررسی می‌کند.",
  "DefaultInRangeRule.check": "مقدار پیش‌فرض را با بازه‌ی مؤثر می‌سنجد.",
  "RequiredValuesRule.check": "بولین‌ها را به <code>_check_boolean</code> می‌سپارد و برای بقیه هشدارهای مقادیر خالی و رزولوشن را می‌دهد.",
  "MetadataRule.check": "کامل بودن Description و Unit را بررسی می‌کند.",
 },
 "after": """<div class="warn">
<b>چرا <code>DefaultInRangeRule</code> سلول خالی را هم چک می‌کند</b>
<p>
یک <code>DefaultValue</code>ی خالی در کد تولیدی <code>0</code> می‌شود، و <code>0</code>
بیرون از بازه‌ای مثل <code>[10, 100]</code> است. اگر قانون فقط سلول‌های پرشده را
می‌سنجید، دقیقاً همان حالتی را رد می‌کرد که در زمان اجرا می‌شکست.
</p>
</div>""",
}

NOTES["src/pl_codegen/validation/rules/tag_rules.py"] = {
 "fa": "<p>شش قانون درباره‌ی تگ‌ها. دو تای آخری رفتار ویژه دارند و ارزش خواندن دارند.</p>",
 "when": "وقتی تگ تازه‌ای اضافه می‌کنید یا قاعده‌ی LogID عوض می‌شود.",
 "sym": {
  "MandatoryTagRule": "هر تگ اجباری باید پر باشد (<code>TAG001</code>).",
  "TagEnumValueRule": "مقدار یک تگ enum باید در لیست کشویی متناظرش باشد (<code>TAG002</code>، <code>TAG003</code>).",
  "TagValueRangeRule": "مقدار عددی تگ باید در <code>uint32_t</code> جا شود (<code>TAG004</code>).",
  "FreeTagSyntaxRule": "تگ آزاد یا عدد است یا شناسه‌ی C (<code>TAG005</code>).",
  "UserNameRule": "<code>User Name</code> خالی هشدار می‌گیرد — <b>بدون هیچ شرطی</b>، چون نامی که کاربر می‌بیند به loggable بودن ربطی ندارد (<code>TAG011</code>).",
  "LogIdRule": "همه‌چیزِ شناسه‌ی لاگ: اجباری بودن برای مقدار loggable، تکراری بودن، جا شدن در <code>uint16_t</code>، و نادیده گرفتن شناسه‌ی مقدار غیر loggable (<code>TAG010</code>، <code>TAG012</code>، <code>TAG014</code>، <code>TAG015</code>). <b>حالت «هم‌پوشانی محدوده» دیگر وجود ندارد</b>: هر عنصر آرایه یک مقدار مستقل با شناسه‌ی خودش است، پس دو مقدار یا یک شناسه دارند یا ندارند — چیزی به اسم محدوده در میان نیست.",
  "MandatoryTagRule.check": "تگ‌های اجباری هر پارامتر را بررسی می‌کند.",
  "TagEnumValueRule.check": "مقادیر enum را با لیست‌های کشویی می‌سنجد.",
  "TagValueRangeRule.check": "جا شدن مقادیر عددی در <code>uint32_t</code>.",
  "FreeTagSyntaxRule.check": "شکل مقدار تگ‌های آزاد.",
  "UserNameRule.check": "خالی بودن <code>User Name</code> را برای هر ردیف فعال گزارش می‌دهد.",
  "LogIdRule.check": "روی مقدارهای تخت‌شده راه می‌رود؛ هر شناسه را در یک دیکشنری برمی‌دارد و دومین مدعی همان شناسه را گزارش می‌کند. مقدارهای غیر loggable را کلاً رد می‌کند.",
 },
 "after": """<div class="warn">
<b>محدوده‌ی LogID با آفست حافظه فرق دارد</b>
<div class="pipeline">reserved log ids = Array Size &nbsp;&nbsp;|&nbsp;&nbsp; MemoryOffset step = sizeof(value) &times; Array Size</div>
<p>
یک شناسه‌ی لاگ یک <b>مقدار</b> را شماره‌گذاری می‌کند، نه یک بایت. پس یک
<code>float64_t</code> با <code>Array Size = 10</code> و <code>LogID = 410</code>
شناسه‌های <code>410..419</code> را می‌گیرد و اولین شناسه‌ی آزاد <code>420</code> است —
تایپ داده هیچ نقشی ندارد و یک اسکالر همیشه دقیقاً یک شناسه می‌گیرد.
</p>
<p>
آفست حافظه اما یک آدرس بایتی است و با <code>sizeof(value)</code> هر مقدار جلو
می‌رود. این دو عمداً جدا هستند: اگر شناسه‌ی لاگ هم با <code>sizeof</code> جلو می‌رفت،
فضای شناسه‌ها بی‌دلیل پر از حفره‌های بلااستفاده می‌شد.
</p>
</div>""",
}

NOTES["src/pl_codegen/validation/rules/defines_rules.py"] = {
 "fa": """<p>یک قانون، ولی مهم: مقادیر ستون‌های <code>SYSTEM NAMES</code> و
<code>PARAM MODES</code> مستقیم به‌عنوان عضو <code>enum</code> در کد C نوشته می‌شوند.
پس هرچه آن‌جا تایپ شود، وارد فرم‌ور می‌شود.</p>
<pre><code>typedef enum {
    SYS_NAV = 0,
    GS / PC = 1,        /* does not compile */
} eParameterListSystemName;</code></pre>
<p>بدون این قانون، ابزار چنین چیزی را بی‌هیچ حرفی تولید می‌کرد.</p>""",
 "when": "وقتی ستون تازه‌ای به <code>GENERATED_ENUMS</code> اضافه می‌شود.",
 "sym": {
  "DefinesSheetRule": "هر مقداری که به عضو enum تبدیل می‌شود باید شناسه‌ی معتبر و یکتا باشد (<code>DEF001</code>، <code>DEF002</code>، <code>DEF004</code>).",
  "DefinesSheetRule.check": "ستون‌های <code>GENERATED_ENUMS</code> را می‌گردد: خالی نبودن، معتبر بودن هر مقدار، و تداخل نداشتن میان دو ستون.",
 },
}

NOTES["src/pl_codegen/layout/__init__.py"] = {"fa": "<p>چند <code>import</code> برای راحتی.</p>", "when": "به‌ندرت."}

NOTES["src/pl_codegen/layout/tag_offset.py"] = {
 "fa": """<p>محاسبه‌ی <code>MemoryOffset</code>. هر تگ یک شمارنده‌ی <b>مستقل</b> دارد: از صفر
شروع می‌شود و برای هر پارامتری که آن تگ را حمل می‌کند به اندازه‌ی
<code>sizeof(value)</code> جلو می‌رود. مقداری که تگ را ندارد، آفست صفر
می‌گیرد و هیچ فضایی مصرف نمی‌کند.</p>
<pre><code>P1  uint16_t      loggable       -> offset 0    (2 بایت)
P2  uint8_t       not loggable   -> بدون آفست، بدون مصرف
P3  uint64_t      loggable       -> offset 2    (8 بایت)
P4  uint32_t      loggable       -> offset 10   (4 بایت)
P5  uint16_t[4]   loggable       -> offset 14   (8 بایت)
                                    مجموع: 22 بایت</code></pre>
<p>اندازه‌ها از استاندارد C می‌آیند (<code>uint16_t</code> همه‌جا ۲ بایت است)، پس آفست
تولیدی روی هر کامپایلری یکسان است.</p>""",
 "when": "وقتی قاعده‌ی چیدمان حافظه عوض می‌شود (مثلاً اگر روزی alignment لازم شود).",
 "sym": {
  "reserved_size": "چند <b>بایت</b> یک مقدار در ناحیه‌ی یک تگ می‌گیرد: <code>sizeof(value)</code>. مبنای <code>MemoryOffset</code>. چون بعد از تخت‌شدن هر برگ یک مقدار است، ضریب آرایه اینجا همیشه ۱ است — مجموعِ آرایه از جمعِ عنصرهایش درمی‌آید.",
  "reserved_log_ids": "چند <b>شناسه‌ی لاگ</b> یک اعلان می‌گیرد: دقیقاً <code>ArraySize</code>. به تایپ داده <b>هیچ ربطی ندارد</b> — یک اسکالر همیشه یک شناسه می‌گیرد، چه <code>uint8_t</code> باشد چه <code>float64_t</code>.",
  "build_offset_map": "کل نقشه را می‌سازد: برای هر تگ یک ناحیه، و در هر ناحیه آفست هر پارامتر.",
  "OffsetEntry": "آفستی که یک پارامتر در ناحیه‌ی یک تگ گرفته.",
  "OffsetEntry.tag_id": "کدام تگ.", "OffsetEntry.parameter": "کدام پارامتر.",
  "OffsetEntry.offset": "آفست بایتی.", "OffsetEntry.size": "اندازه‌ی مصرف‌شده.",
  "OffsetArea": "هرچه برای یک تگ تخصیص داده شده.",
  "OffsetArea.tag": "توصیف تگ.", "OffsetArea.entries": "فهرست ورودی‌ها به ترتیب.",
  "OffsetArea.total": "مجموع بایت‌های این تگ.",
  "OffsetMap": "نقشه‌ی کامل؛ چیزی که تولیدکننده‌ی کد از آن سؤال می‌پرسد.",
  "OffsetMap.areas": "همه‌ی ناحیه‌ها.",
  "OffsetMap.area": "ناحیه‌ی یک تگ مشخص.",
  "OffsetMap.has_entry": "آیا این پارامتر در ناحیه‌ی این تگ جا گرفته.",
  "OffsetMap.offset": "آفست یک زوج «تگ + پارامتر».",
  "OffsetMap.size": "اندازه‌ی مصرف‌شده‌ی یک زوج.",
  "OffsetMap.total": "مجموع بایت‌های یک تگ.",
 },
 "after": """<div class="note">
<b>ارتباط با «تگ فعال»</b>
<p>
این ماژول برای تصمیم‌گیری از <code>parameter.has_active_tag()</code> استفاده می‌کند —
همان تابعی که <code>LogID</code> ردیف غیر loggable را نادیده می‌گیرد. اگر این دو با هم
فرق داشتند، نقشه‌ی حافظه و جدول descriptor درباره‌ی یک چیز دو حرف می‌زدند.
</p>
</div>""",
}

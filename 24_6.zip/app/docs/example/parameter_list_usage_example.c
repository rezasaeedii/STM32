/**
  ******************************************************************************
  * @file    parameter_list_usage_example.c
  * @brief   Short example of how the generated parameter list is used.
  *
  * Every function here is a self contained answer to one question, in the order
  * a newcomer asks them:
  *
  *   1. how do I read a value?                       fExample_DirectAccess
  *   2. how do I read it and know the read worked?   fExample_CheckedAccess
  *   3. how do I write one?                          fExample_WriteValue
  *   4. how do I write one and tell the system?      fExample_WriteAndNotify
  *   5. how do I reach a field of a structure?       fExample_StructAccess
  *   6. how do I walk the table at run time?         fExample_DescriptorAccess
  *   7. how do I walk an array parameter?            fExample_ArrayAccess
  *   8. how do I read only what is new to me?        fExample_ReadIfNew
  *
  * This file is NOT generated. It is compiled by the test suite against the
  * generated code, so it is also the proof that the generated header is usable
  * from ordinary application code.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 FAS.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ----------------------------------------------------------------- */
#include "parameter_list_usage_example.h"

#include <string.h>

#include "cg_parameter_list.h"
#include "cg_parameter_list_defines.h"
#include "cg_smart_data.h"
#include "parameter_descriptor.h"

/* Private defines ---------------------------------------------------------- */
/**
 * @brief Which reader this module is.
 *
 * Every reader that wants "has this value changed since *I* last looked?" needs
 * an id of its own; the smart data object keeps one flag per id.
 */
#define EXAMPLE_USER_ID     eSMART_DATA_USER_ID_1

/* Private macros ----------------------------------------------------------- */
/* Private types ------------------------------------------------------------ */
/* Private variables -------------------------------------------------------- */
/* Private functions -------------------------------------------------------- */
/*
  ==============================================================================
                        ##### Exported Functions #####
  ==============================================================================
*/
/**
 * @brief Reads a value the shortest way there is.
 *
 * @note  There is one Read function per type - fSmartData_F32_Read for a
 *        float32_t, fSmartData_U16_Read for a uint16_t - and the compiler
 *        checks that the object and the variable agree. Nothing is cast.
 */
void fExample_DirectAccess(void) {

    float32_t airspeed = 0.0f;

    (void)fSmartData_F32_Read(&Cg_SmartData_Airspeed, &airspeed);

    /* use airspeed ... */
    PARAMETER_LIST_UNUSED_(airspeed);
}

/**
 * @brief Reads a value and reports whether the read was meaningful.
 *
 * @note  A read can fail: a null pointer, or a value nothing has written yet.
 *        Where that matters, keep the status.
 *
 * @return eSmartDataStatus eSMART_DATA_OK when the value came back.
 */
eSmartDataStatus fExample_CheckedAccess(void) {

    float32_t value = 0.0f;

    eSmartDataStatus status = fSmartData_F32_Read(&Cg_SmartData_Airspeed, &value);
    if (status != eSMART_DATA_OK) {
        return status;
    }

    /* use value ... */
    PARAMETER_LIST_UNUSED_(value);

    return eSMART_DATA_OK;
}

/**
 * @brief Writes a value straight into its smart data object.
 *
 * @note  This is the quiet path: the value is range checked and stored, and
 *        nobody is told. Use it for a value the writer owns.
 * @note  The write is REFUSED when the value is outside the parameter's
 *        minimum and maximum, so the status is worth keeping.
 *
 * @return eSmartDataStatus eSMART_DATA_OK when the value was stored.
 */
eSmartDataStatus fExample_WriteValue(float32_t newAirspeed) {

    return fSmartData_F32_Write(&Cg_SmartData_Airspeed, &newAirspeed);
}

/**
 * @brief Writes a value and raises the "this parameter changed" event.
 *
 * @note  This is the loud path, and it is the reason the descriptor has write
 *        functions of its own. It does the same range checked write, and then
 *        calls fParameterDescriptor_ParameterWriteCompletedCallback() so that
 *        whoever is listening - a logger, a telemetry link, a control loop -
 *        finds out. The callback is weak, so the application overrides it.
 * @note  The event is raised ONLY after a write the smart data accepted.
 *
 * @return eParameterDescriptorStatus ePARAMETER_DESCRIPTOR_OK when it landed.
 */
eParameterDescriptorStatus fExample_WriteAndNotify(float32_t newAirspeed) {

    const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(AIRSPEED);

    /* The table is const; the write functions take a mutable descriptor because
       the callback is handed the entry that changed. */
    return fParameterDescriptor_WriteF32((sParameterDescriptor *)pDescriptor,
                                         newAirspeed);
}

/**
 * @brief Reaches a value that lives inside a structure.
 *
 * @note  A structure parameter becomes one C object holding the whole shape, so
 *        a field is reached by writing what it is called:
 *        Cg_SmartData_Position.Home.Lat.
 *
 * @return uint8_t 0 when both reads worked.
 */
uint8_t fExample_StructAccess(void) {

    float64_t latitude = 0.0;
    float64_t longitude = 0.0;

    if (fSmartData_F64_Read(&Cg_SmartData_Position.Home.Lat, &latitude) != eSMART_DATA_OK) {
        return 1U;
    }
    if (fSmartData_F64_Read(&Cg_SmartData_Position.Home.Lon, &longitude) != eSMART_DATA_OK) {
        return 1U;
    }

    return fExample_UseHome(&Cg_SmartData_Position.Home);
}

/**
 * @brief Walks the descriptor table at run time.
 *
 * @note  This is what a generic sub-system does - a logger, a settings menu, a
 *        telemetry link - when it has to work on every parameter without
 *        knowing any of them by name.
 * @note  Each row is one value. An array declaration produces one row per
 *        element, so the table needs no element count.
 *
 * @return uint8_t 0 when the table looks the way it should.
 */
uint8_t fExample_DescriptorAccess(void) {

    const sParameterDescriptor *pByIndex = fParameterList_GetByIndex(POSITION_HOME_LAT);
    const sParameterDescriptor *pByName = fParameterList_GetByName("Position.Home.Lat");

    if ((pByIndex == NULL) || (pByIndex != pByName)) {
        return 1U;
    }

    /* Every parameter carrying the Loggable tag hands the logging sub-system
       its id and its offset inside that tag's own area. */
    for (uint16_t index = 0U; index < fParameterList_GetQuantity(); index++) {

        const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(index);
        if (pDescriptor == NULL) {
            return 1U;
        }

        if (pDescriptor->TagLoggable.Value != 0U) {
            fExample_SendToLog(pDescriptor->LogId,
                               pDescriptor->pSmartData,
                               pDescriptor->TagLoggable.MemoryOffset);
        }
    }

    return 0U;
}

/**
 * @brief Walks every element of an array parameter.
 *
 * @note  The C object is a real array, so the elements are reached with an
 *        index. How many there are is a compile time constant in the generated
 *        <NAME>_ARRAY_SIZE macro - never a field of the table.
 * @note  Each element is also a row of its own: POSITION_SAMPLES_0 is the index
 *        of the first, and it has its own tag offsets and its own log id.
 */
void fExample_ArrayAccess(void) {

    int16_t sample = 0;

    for (uint16_t index = 0U; index < POSITION_SAMPLES_ARRAY_SIZE; index++) {
        (void)fSmartData_I16_Read(&Cg_SmartData_Position.Samples[index], &sample);
        PARAMETER_LIST_UNUSED_(sample);
    }

    /* the first element, through the table */
    const sParameterDescriptor *pDescriptor = fParameterList_GetByIndex(POSITION_SAMPLES_0);
    PARAMETER_LIST_UNUSED_(pDescriptor);
}

/**
 * @brief Reads a value only when it is new to THIS reader.
 *
 * @note  Every reader passes its own id, and the smart data object keeps one
 *        flag per id - so two sub-systems reading the same parameter do not
 *        consume each other's "new value" notification.
 * @note  eSMART_DATA_ERROR_NO_NEW_DATA is the ordinary answer, not a fault: it
 *        means nothing has been written since this reader last looked.
 *
 * @return bool_t TRUE when a new value was read.
 */
bool_t fExample_ReadIfNew(void) {

    float32_t value = 0.0f;

    eSmartDataStatus status = fSmartData_F32_ReadIfIsNewForId(&Cg_SmartData_Airspeed,
                                                              &value,
                                                              EXAMPLE_USER_ID);
    if (status != eSMART_DATA_OK) {
        return FALSE;                       /* nothing new since the last read */
    }

    /* use value ... */
    PARAMETER_LIST_UNUSED_(value);

    return TRUE;
}

/**
 * @brief Stand-in for the logging sub-system.
 *
 * @param logId        Identifier of the value.
 * @param pValue       The smart data object holding it.
 * @param memoryOffset Byte offset of this value inside the Loggable area.
 */
PARAMETER_LIST_WEAK void fExample_SendToLog(uint32_t logId, const void *pValue,
                                            uint32_t memoryOffset) {

    PARAMETER_LIST_UNUSED_(logId);
    PARAMETER_LIST_UNUSED_(pValue);
    PARAMETER_LIST_UNUSED_(memoryOffset);
}

/**
 * @brief Stand-in for something that takes a whole structure.
 *
 * @param pHome The generated structure type, passed as one thing.
 *
 * @return uint8_t 0.
 */
PARAMETER_LIST_WEAK uint8_t fExample_UseHome(const sCgStruct_Home *pHome) {

    PARAMETER_LIST_UNUSED_(pHome);

    return 0U;
}

/**
 * @brief Called once, after every parameter has been constructed.
 *
 * @note  The generated fParameterList_Init() calls this at the end. It is weak,
 *        so an application that has nothing to do here simply does not define
 *        it.
 *
 * @return uint8_t 0 on success.
 */
uint8_t fParameterList_InitCompletedCallback(void) {

    /* Good place to restore the reset-proof parameters from their storage,
       using PARAMETER_LIST_TAG_RESET_PROOF_<NAME>_OFFSET from the defines
       header, and PARAMETER_LIST_TAG_RESET_PROOF_SIZE for the whole area. */
    return 0U;
}

/*
  ==============================================================================
                        ##### Private Functions #####
  ==============================================================================
*/

/* === Copyright (c) 2026 FAS === EOF === */
